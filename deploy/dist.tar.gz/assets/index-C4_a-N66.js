(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const s of document.querySelectorAll('link[rel="modulepreload"]'))n(s);new MutationObserver(s=>{for(const r of s)if(r.type==="childList")for(const a of r.addedNodes)a.tagName==="LINK"&&a.rel==="modulepreload"&&n(a)}).observe(document,{childList:!0,subtree:!0});function e(s){const r={};return s.integrity&&(r.integrity=s.integrity),s.referrerPolicy&&(r.referrerPolicy=s.referrerPolicy),s.crossOrigin==="use-credentials"?r.credentials="include":s.crossOrigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function n(s){if(s.ep)return;s.ep=!0;const r=e(s);fetch(s.href,r)}})();/**
 * @license
 * Copyright 2010-2024 Three.js Authors
 * SPDX-License-Identifier: MIT
 */const xc="169",Nh=0,qc=1,Fh=2,Ru=1,Pu=2,yi=3,Hi=0,fn=1,ln=2,bi=0,hs=1,cn=2,Yc=3,$c=4,Oh=5,is=100,Bh=101,kh=102,Hh=103,Gh=104,Vh=200,Wh=201,Xh=202,qh=203,Tl=204,El=205,Yh=206,$h=207,Kh=208,Zh=209,jh=210,Jh=211,Qh=212,tf=213,ef=214,Al=0,Cl=1,Rl=2,sr=3,Pl=4,Dl=5,Il=6,Ll=7,Du=0,nf=1,sf=2,Bi=0,Iu=1,Lu=2,Uu=3,_c=4,rf=5,zu=6,Nu=7,Fu=300,rr=301,ar=302,Ul=303,zl=304,mo=306,ds=1e3,Si=1001,Nl=1002,Dn=1003,af=1004,Qr=1005,Fn=1006,wo=1007,cs=1008,Ai=1009,Ou=1010,Bu=1011,Xr=1012,Mc=1013,ps=1014,fi=1015,pi=1016,yc=1017,Sc=1018,or=1020,ku=35902,Hu=1021,Gu=1022,ri=1023,Vu=1024,Wu=1025,tr=1026,lr=1027,wc=1028,bc=1029,Xu=1030,Tc=1031,Ec=1033,Va=33776,Wa=33777,Xa=33778,qa=33779,Fl=35840,Ol=35841,Bl=35842,kl=35843,Hl=36196,Gl=37492,Vl=37496,Wl=37808,Xl=37809,ql=37810,Yl=37811,$l=37812,Kl=37813,Zl=37814,jl=37815,Jl=37816,Ql=37817,tc=37818,ec=37819,nc=37820,ic=37821,Ya=36492,sc=36494,rc=36495,qu=36283,ac=36284,oc=36285,lc=36286,of=3200,lf=3201,Yu=0,cf=1,ii="",pn="srgb",Gi="srgb-linear",Ac="display-p3",go="display-p3-linear",Ja="linear",He="srgb",Qa="rec709",to="p3",_s=7680,Kc=519,uf=512,hf=513,ff=514,$u=515,df=516,pf=517,mf=518,gf=519,cc=35044,Hn=35048,Zc="300 es",wi=2e3,eo=2001;class dr{addEventListener(t,e){this._listeners===void 0&&(this._listeners={});const n=this._listeners;n[t]===void 0&&(n[t]=[]),n[t].indexOf(e)===-1&&n[t].push(e)}hasEventListener(t,e){if(this._listeners===void 0)return!1;const n=this._listeners;return n[t]!==void 0&&n[t].indexOf(e)!==-1}removeEventListener(t,e){if(this._listeners===void 0)return;const s=this._listeners[t];if(s!==void 0){const r=s.indexOf(e);r!==-1&&s.splice(r,1)}}dispatchEvent(t){if(this._listeners===void 0)return;const n=this._listeners[t.type];if(n!==void 0){t.target=this;const s=n.slice(0);for(let r=0,a=s.length;r<a;r++)s[r].call(this,t);t.target=null}}}const mn=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"];let jc=1234567;const Br=Math.PI/180,qr=180/Math.PI;function Ti(){const i=Math.random()*4294967295|0,t=Math.random()*4294967295|0,e=Math.random()*4294967295|0,n=Math.random()*4294967295|0;return(mn[i&255]+mn[i>>8&255]+mn[i>>16&255]+mn[i>>24&255]+"-"+mn[t&255]+mn[t>>8&255]+"-"+mn[t>>16&15|64]+mn[t>>24&255]+"-"+mn[e&63|128]+mn[e>>8&255]+"-"+mn[e>>16&255]+mn[e>>24&255]+mn[n&255]+mn[n>>8&255]+mn[n>>16&255]+mn[n>>24&255]).toLowerCase()}function un(i,t,e){return Math.max(t,Math.min(e,i))}function Cc(i,t){return(i%t+t)%t}function vf(i,t,e,n,s){return n+(i-t)*(s-n)/(e-t)}function xf(i,t,e){return i!==t?(e-i)/(t-i):0}function kr(i,t,e){return(1-e)*i+e*t}function _f(i,t,e,n){return kr(i,t,1-Math.exp(-e*n))}function Mf(i,t=1){return t-Math.abs(Cc(i,t*2)-t)}function yf(i,t,e){return i<=t?0:i>=e?1:(i=(i-t)/(e-t),i*i*(3-2*i))}function Sf(i,t,e){return i<=t?0:i>=e?1:(i=(i-t)/(e-t),i*i*i*(i*(i*6-15)+10))}function wf(i,t){return i+Math.floor(Math.random()*(t-i+1))}function bf(i,t){return i+Math.random()*(t-i)}function Tf(i){return i*(.5-Math.random())}function Ef(i){i!==void 0&&(jc=i);let t=jc+=1831565813;return t=Math.imul(t^t>>>15,t|1),t^=t+Math.imul(t^t>>>7,t|61),((t^t>>>14)>>>0)/4294967296}function Af(i){return i*Br}function Cf(i){return i*qr}function Rf(i){return(i&i-1)===0&&i!==0}function Pf(i){return Math.pow(2,Math.ceil(Math.log(i)/Math.LN2))}function Df(i){return Math.pow(2,Math.floor(Math.log(i)/Math.LN2))}function If(i,t,e,n,s){const r=Math.cos,a=Math.sin,o=r(e/2),l=a(e/2),h=r((t+n)/2),f=a((t+n)/2),m=r((t-n)/2),u=a((t-n)/2),d=r((n-t)/2),c=a((n-t)/2);switch(s){case"XYX":i.set(o*f,l*m,l*u,o*h);break;case"YZY":i.set(l*u,o*f,l*m,o*h);break;case"ZXZ":i.set(l*m,l*u,o*f,o*h);break;case"XZX":i.set(o*f,l*c,l*d,o*h);break;case"YXY":i.set(l*d,o*f,l*c,o*h);break;case"ZYZ":i.set(l*c,l*d,o*f,o*h);break;default:console.warn("THREE.MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+s)}}function si(i,t){switch(t.constructor){case Float32Array:return i;case Uint32Array:return i/4294967295;case Uint16Array:return i/65535;case Uint8Array:return i/255;case Int32Array:return Math.max(i/2147483647,-1);case Int16Array:return Math.max(i/32767,-1);case Int8Array:return Math.max(i/127,-1);default:throw new Error("Invalid component type.")}}function Le(i,t){switch(t.constructor){case Float32Array:return i;case Uint32Array:return Math.round(i*4294967295);case Uint16Array:return Math.round(i*65535);case Uint8Array:return Math.round(i*255);case Int32Array:return Math.round(i*2147483647);case Int16Array:return Math.round(i*32767);case Int8Array:return Math.round(i*127);default:throw new Error("Invalid component type.")}}const qe={DEG2RAD:Br,RAD2DEG:qr,generateUUID:Ti,clamp:un,euclideanModulo:Cc,mapLinear:vf,inverseLerp:xf,lerp:kr,damp:_f,pingpong:Mf,smoothstep:yf,smootherstep:Sf,randInt:wf,randFloat:bf,randFloatSpread:Tf,seededRandom:Ef,degToRad:Af,radToDeg:Cf,isPowerOfTwo:Rf,ceilPowerOfTwo:Pf,floorPowerOfTwo:Df,setQuaternionFromProperEuler:If,normalize:Le,denormalize:si};class Pt{constructor(t=0,e=0){Pt.prototype.isVector2=!0,this.x=t,this.y=e}get width(){return this.x}set width(t){this.x=t}get height(){return this.y}set height(t){this.y=t}set(t,e){return this.x=t,this.y=e,this}setScalar(t){return this.x=t,this.y=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y)}copy(t){return this.x=t.x,this.y=t.y,this}add(t){return this.x+=t.x,this.y+=t.y,this}addScalar(t){return this.x+=t,this.y+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this}subScalar(t){return this.x-=t,this.y-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this}multiply(t){return this.x*=t.x,this.y*=t.y,this}multiplyScalar(t){return this.x*=t,this.y*=t,this}divide(t){return this.x/=t.x,this.y/=t.y,this}divideScalar(t){return this.multiplyScalar(1/t)}applyMatrix3(t){const e=this.x,n=this.y,s=t.elements;return this.x=s[0]*e+s[3]*n+s[6],this.y=s[1]*e+s[4]*n+s[7],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this}clampLength(t,e){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(t,Math.min(e,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(t){return this.x*t.x+this.y*t.y}cross(t){return this.x*t.y-this.y*t.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(t){const e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;const n=this.dot(t)/e;return Math.acos(un(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){const e=this.x-t.x,n=this.y-t.y;return e*e+n*n}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this}equals(t){return t.x===this.x&&t.y===this.y}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this}rotateAround(t,e){const n=Math.cos(e),s=Math.sin(e),r=this.x-t.x,a=this.y-t.y;return this.x=r*n-a*s+t.x,this.y=r*s+a*n+t.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}}class Se{constructor(t,e,n,s,r,a,o,l,h){Se.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],t!==void 0&&this.set(t,e,n,s,r,a,o,l,h)}set(t,e,n,s,r,a,o,l,h){const f=this.elements;return f[0]=t,f[1]=s,f[2]=o,f[3]=e,f[4]=r,f[5]=l,f[6]=n,f[7]=a,f[8]=h,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(t){const e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],this}extractBasis(t,e,n){return t.setFromMatrix3Column(this,0),e.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(t){const e=t.elements;return this.set(e[0],e[4],e[8],e[1],e[5],e[9],e[2],e[6],e[10]),this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){const n=t.elements,s=e.elements,r=this.elements,a=n[0],o=n[3],l=n[6],h=n[1],f=n[4],m=n[7],u=n[2],d=n[5],c=n[8],v=s[0],p=s[3],x=s[6],w=s[1],b=s[4],C=s[7],V=s[2],D=s[5],A=s[8];return r[0]=a*v+o*w+l*V,r[3]=a*p+o*b+l*D,r[6]=a*x+o*C+l*A,r[1]=h*v+f*w+m*V,r[4]=h*p+f*b+m*D,r[7]=h*x+f*C+m*A,r[2]=u*v+d*w+c*V,r[5]=u*p+d*b+c*D,r[8]=u*x+d*C+c*A,this}multiplyScalar(t){const e=this.elements;return e[0]*=t,e[3]*=t,e[6]*=t,e[1]*=t,e[4]*=t,e[7]*=t,e[2]*=t,e[5]*=t,e[8]*=t,this}determinant(){const t=this.elements,e=t[0],n=t[1],s=t[2],r=t[3],a=t[4],o=t[5],l=t[6],h=t[7],f=t[8];return e*a*f-e*o*h-n*r*f+n*o*l+s*r*h-s*a*l}invert(){const t=this.elements,e=t[0],n=t[1],s=t[2],r=t[3],a=t[4],o=t[5],l=t[6],h=t[7],f=t[8],m=f*a-o*h,u=o*l-f*r,d=h*r-a*l,c=e*m+n*u+s*d;if(c===0)return this.set(0,0,0,0,0,0,0,0,0);const v=1/c;return t[0]=m*v,t[1]=(s*h-f*n)*v,t[2]=(o*n-s*a)*v,t[3]=u*v,t[4]=(f*e-s*l)*v,t[5]=(s*r-o*e)*v,t[6]=d*v,t[7]=(n*l-h*e)*v,t[8]=(a*e-n*r)*v,this}transpose(){let t;const e=this.elements;return t=e[1],e[1]=e[3],e[3]=t,t=e[2],e[2]=e[6],e[6]=t,t=e[5],e[5]=e[7],e[7]=t,this}getNormalMatrix(t){return this.setFromMatrix4(t).invert().transpose()}transposeIntoArray(t){const e=this.elements;return t[0]=e[0],t[1]=e[3],t[2]=e[6],t[3]=e[1],t[4]=e[4],t[5]=e[7],t[6]=e[2],t[7]=e[5],t[8]=e[8],this}setUvTransform(t,e,n,s,r,a,o){const l=Math.cos(r),h=Math.sin(r);return this.set(n*l,n*h,-n*(l*a+h*o)+a+t,-s*h,s*l,-s*(-h*a+l*o)+o+e,0,0,1),this}scale(t,e){return this.premultiply(bo.makeScale(t,e)),this}rotate(t){return this.premultiply(bo.makeRotation(-t)),this}translate(t,e){return this.premultiply(bo.makeTranslation(t,e)),this}makeTranslation(t,e){return t.isVector2?this.set(1,0,t.x,0,1,t.y,0,0,1):this.set(1,0,t,0,1,e,0,0,1),this}makeRotation(t){const e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,n,e,0,0,0,1),this}makeScale(t,e){return this.set(t,0,0,0,e,0,0,0,1),this}equals(t){const e=this.elements,n=t.elements;for(let s=0;s<9;s++)if(e[s]!==n[s])return!1;return!0}fromArray(t,e=0){for(let n=0;n<9;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){const n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t}clone(){return new this.constructor().fromArray(this.elements)}}const bo=new Se;function Ku(i){for(let t=i.length-1;t>=0;--t)if(i[t]>=65535)return!0;return!1}function no(i){return document.createElementNS("http://www.w3.org/1999/xhtml",i)}function Lf(){const i=no("canvas");return i.style.display="block",i}const Jc={};function $a(i){i in Jc||(Jc[i]=!0,console.warn(i))}function Uf(i,t,e){return new Promise(function(n,s){function r(){switch(i.clientWaitSync(t,i.SYNC_FLUSH_COMMANDS_BIT,0)){case i.WAIT_FAILED:s();break;case i.TIMEOUT_EXPIRED:setTimeout(r,e);break;default:n()}}setTimeout(r,e)})}function zf(i){const t=i.elements;t[2]=.5*t[2]+.5*t[3],t[6]=.5*t[6]+.5*t[7],t[10]=.5*t[10]+.5*t[11],t[14]=.5*t[14]+.5*t[15]}function Nf(i){const t=i.elements;t[11]===-1?(t[10]=-t[10]-1,t[14]=-t[14]):(t[10]=-t[10],t[14]=-t[14]+1)}const Qc=new Se().set(.8224621,.177538,0,.0331941,.9668058,0,.0170827,.0723974,.9105199),t0=new Se().set(1.2249401,-.2249404,0,-.0420569,1.0420571,0,-.0196376,-.0786361,1.0982735),xr={[Gi]:{transfer:Ja,primaries:Qa,luminanceCoefficients:[.2126,.7152,.0722],toReference:i=>i,fromReference:i=>i},[pn]:{transfer:He,primaries:Qa,luminanceCoefficients:[.2126,.7152,.0722],toReference:i=>i.convertSRGBToLinear(),fromReference:i=>i.convertLinearToSRGB()},[go]:{transfer:Ja,primaries:to,luminanceCoefficients:[.2289,.6917,.0793],toReference:i=>i.applyMatrix3(t0),fromReference:i=>i.applyMatrix3(Qc)},[Ac]:{transfer:He,primaries:to,luminanceCoefficients:[.2289,.6917,.0793],toReference:i=>i.convertSRGBToLinear().applyMatrix3(t0),fromReference:i=>i.applyMatrix3(Qc).convertLinearToSRGB()}},Ff=new Set([Gi,go]),Ie={enabled:!0,_workingColorSpace:Gi,get workingColorSpace(){return this._workingColorSpace},set workingColorSpace(i){if(!Ff.has(i))throw new Error(`Unsupported working color space, "${i}".`);this._workingColorSpace=i},convert:function(i,t,e){if(this.enabled===!1||t===e||!t||!e)return i;const n=xr[t].toReference,s=xr[e].fromReference;return s(n(i))},fromWorkingColorSpace:function(i,t){return this.convert(i,this._workingColorSpace,t)},toWorkingColorSpace:function(i,t){return this.convert(i,t,this._workingColorSpace)},getPrimaries:function(i){return xr[i].primaries},getTransfer:function(i){return i===ii?Ja:xr[i].transfer},getLuminanceCoefficients:function(i,t=this._workingColorSpace){return i.fromArray(xr[t].luminanceCoefficients)}};function er(i){return i<.04045?i*.0773993808:Math.pow(i*.9478672986+.0521327014,2.4)}function To(i){return i<.0031308?i*12.92:1.055*Math.pow(i,.41666)-.055}let Ms;class Of{static getDataURL(t){if(/^data:/i.test(t.src)||typeof HTMLCanvasElement>"u")return t.src;let e;if(t instanceof HTMLCanvasElement)e=t;else{Ms===void 0&&(Ms=no("canvas")),Ms.width=t.width,Ms.height=t.height;const n=Ms.getContext("2d");t instanceof ImageData?n.putImageData(t,0,0):n.drawImage(t,0,0,t.width,t.height),e=Ms}return e.width>2048||e.height>2048?(console.warn("THREE.ImageUtils.getDataURL: Image converted to jpg for performance reasons",t),e.toDataURL("image/jpeg",.6)):e.toDataURL("image/png")}static sRGBToLinear(t){if(typeof HTMLImageElement<"u"&&t instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&t instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&t instanceof ImageBitmap){const e=no("canvas");e.width=t.width,e.height=t.height;const n=e.getContext("2d");n.drawImage(t,0,0,t.width,t.height);const s=n.getImageData(0,0,t.width,t.height),r=s.data;for(let a=0;a<r.length;a++)r[a]=er(r[a]/255)*255;return n.putImageData(s,0,0),e}else if(t.data){const e=t.data.slice(0);for(let n=0;n<e.length;n++)e instanceof Uint8Array||e instanceof Uint8ClampedArray?e[n]=Math.floor(er(e[n]/255)*255):e[n]=er(e[n]);return{data:e,width:t.width,height:t.height}}else return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),t}}let Bf=0;class Zu{constructor(t=null){this.isSource=!0,Object.defineProperty(this,"id",{value:Bf++}),this.uuid=Ti(),this.data=t,this.dataReady=!0,this.version=0}set needsUpdate(t){t===!0&&this.version++}toJSON(t){const e=t===void 0||typeof t=="string";if(!e&&t.images[this.uuid]!==void 0)return t.images[this.uuid];const n={uuid:this.uuid,url:""},s=this.data;if(s!==null){let r;if(Array.isArray(s)){r=[];for(let a=0,o=s.length;a<o;a++)s[a].isDataTexture?r.push(Eo(s[a].image)):r.push(Eo(s[a]))}else r=Eo(s);n.url=r}return e||(t.images[this.uuid]=n),n}}function Eo(i){return typeof HTMLImageElement<"u"&&i instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&i instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&i instanceof ImageBitmap?Of.getDataURL(i):i.data?{data:Array.from(i.data),width:i.width,height:i.height,type:i.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}let kf=0;class vn extends dr{constructor(t=vn.DEFAULT_IMAGE,e=vn.DEFAULT_MAPPING,n=Si,s=Si,r=Fn,a=cs,o=ri,l=Ai,h=vn.DEFAULT_ANISOTROPY,f=ii){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:kf++}),this.uuid=Ti(),this.name="",this.source=new Zu(t),this.mipmaps=[],this.mapping=e,this.channel=0,this.wrapS=n,this.wrapT=s,this.magFilter=r,this.minFilter=a,this.anisotropy=h,this.format=o,this.internalFormat=null,this.type=l,this.offset=new Pt(0,0),this.repeat=new Pt(1,1),this.center=new Pt(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new Se,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=f,this.userData={},this.version=0,this.onUpdate=null,this.isRenderTargetTexture=!1,this.pmremVersion=0}get image(){return this.source.data}set image(t=null){this.source.data=t}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}clone(){return new this.constructor().copy(this)}copy(t){return this.name=t.name,this.source=t.source,this.mipmaps=t.mipmaps.slice(0),this.mapping=t.mapping,this.channel=t.channel,this.wrapS=t.wrapS,this.wrapT=t.wrapT,this.magFilter=t.magFilter,this.minFilter=t.minFilter,this.anisotropy=t.anisotropy,this.format=t.format,this.internalFormat=t.internalFormat,this.type=t.type,this.offset.copy(t.offset),this.repeat.copy(t.repeat),this.center.copy(t.center),this.rotation=t.rotation,this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrix.copy(t.matrix),this.generateMipmaps=t.generateMipmaps,this.premultiplyAlpha=t.premultiplyAlpha,this.flipY=t.flipY,this.unpackAlignment=t.unpackAlignment,this.colorSpace=t.colorSpace,this.userData=JSON.parse(JSON.stringify(t.userData)),this.needsUpdate=!0,this}toJSON(t){const e=t===void 0||typeof t=="string";if(!e&&t.textures[this.uuid]!==void 0)return t.textures[this.uuid];const n={metadata:{version:4.6,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(t).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),e||(t.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(t){if(this.mapping!==Fu)return t;if(t.applyMatrix3(this.matrix),t.x<0||t.x>1)switch(this.wrapS){case ds:t.x=t.x-Math.floor(t.x);break;case Si:t.x=t.x<0?0:1;break;case Nl:Math.abs(Math.floor(t.x)%2)===1?t.x=Math.ceil(t.x)-t.x:t.x=t.x-Math.floor(t.x);break}if(t.y<0||t.y>1)switch(this.wrapT){case ds:t.y=t.y-Math.floor(t.y);break;case Si:t.y=t.y<0?0:1;break;case Nl:Math.abs(Math.floor(t.y)%2)===1?t.y=Math.ceil(t.y)-t.y:t.y=t.y-Math.floor(t.y);break}return this.flipY&&(t.y=1-t.y),t}set needsUpdate(t){t===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(t){t===!0&&this.pmremVersion++}}vn.DEFAULT_IMAGE=null;vn.DEFAULT_MAPPING=Fu;vn.DEFAULT_ANISOTROPY=1;class Fe{constructor(t=0,e=0,n=0,s=1){Fe.prototype.isVector4=!0,this.x=t,this.y=e,this.z=n,this.w=s}get width(){return this.z}set width(t){this.z=t}get height(){return this.w}set height(t){this.w=t}set(t,e,n,s){return this.x=t,this.y=e,this.z=n,this.w=s,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this.w=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setW(t){return this.w=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;case 3:this.w=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this.w=t.w!==void 0?t.w:1,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this.w+=t.w,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this.w+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this.w=t.w+e.w,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this.w+=t.w*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this.w-=t.w,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this.w-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this.w=t.w-e.w,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this.w*=t.w,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this.w*=t,this}applyMatrix4(t){const e=this.x,n=this.y,s=this.z,r=this.w,a=t.elements;return this.x=a[0]*e+a[4]*n+a[8]*s+a[12]*r,this.y=a[1]*e+a[5]*n+a[9]*s+a[13]*r,this.z=a[2]*e+a[6]*n+a[10]*s+a[14]*r,this.w=a[3]*e+a[7]*n+a[11]*s+a[15]*r,this}divideScalar(t){return this.multiplyScalar(1/t)}setAxisAngleFromQuaternion(t){this.w=2*Math.acos(t.w);const e=Math.sqrt(1-t.w*t.w);return e<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=t.x/e,this.y=t.y/e,this.z=t.z/e),this}setAxisAngleFromRotationMatrix(t){let e,n,s,r;const l=t.elements,h=l[0],f=l[4],m=l[8],u=l[1],d=l[5],c=l[9],v=l[2],p=l[6],x=l[10];if(Math.abs(f-u)<.01&&Math.abs(m-v)<.01&&Math.abs(c-p)<.01){if(Math.abs(f+u)<.1&&Math.abs(m+v)<.1&&Math.abs(c+p)<.1&&Math.abs(h+d+x-3)<.1)return this.set(1,0,0,0),this;e=Math.PI;const b=(h+1)/2,C=(d+1)/2,V=(x+1)/2,D=(f+u)/4,A=(m+v)/4,y=(c+p)/4;return b>C&&b>V?b<.01?(n=0,s=.707106781,r=.707106781):(n=Math.sqrt(b),s=D/n,r=A/n):C>V?C<.01?(n=.707106781,s=0,r=.707106781):(s=Math.sqrt(C),n=D/s,r=y/s):V<.01?(n=.707106781,s=.707106781,r=0):(r=Math.sqrt(V),n=A/r,s=y/r),this.set(n,s,r,e),this}let w=Math.sqrt((p-c)*(p-c)+(m-v)*(m-v)+(u-f)*(u-f));return Math.abs(w)<.001&&(w=1),this.x=(p-c)/w,this.y=(m-v)/w,this.z=(u-f)/w,this.w=Math.acos((h+d+x-1)/2),this}setFromMatrixPosition(t){const e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this.w=e[15],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this.w=Math.min(this.w,t.w),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this.w=Math.max(this.w,t.w),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this.z=Math.max(t.z,Math.min(e.z,this.z)),this.w=Math.max(t.w,Math.min(e.w,this.w)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this.z=Math.max(t,Math.min(e,this.z)),this.w=Math.max(t,Math.min(e,this.w)),this}clampLength(t,e){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(t,Math.min(e,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z+this.w*t.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this.w+=(t.w-this.w)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this.w=t.w+(e.w-t.w)*n,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z&&t.w===this.w}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this.w=t[e+3],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t[e+3]=this.w,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this.w=t.getW(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}}class Hf extends dr{constructor(t=1,e=1,n={}){super(),this.isRenderTarget=!0,this.width=t,this.height=e,this.depth=1,this.scissor=new Fe(0,0,t,e),this.scissorTest=!1,this.viewport=new Fe(0,0,t,e);const s={width:t,height:e,depth:1};n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:Fn,depthBuffer:!0,stencilBuffer:!1,resolveDepthBuffer:!0,resolveStencilBuffer:!0,depthTexture:null,samples:0,count:1},n);const r=new vn(s,n.mapping,n.wrapS,n.wrapT,n.magFilter,n.minFilter,n.format,n.type,n.anisotropy,n.colorSpace);r.flipY=!1,r.generateMipmaps=n.generateMipmaps,r.internalFormat=n.internalFormat,this.textures=[];const a=n.count;for(let o=0;o<a;o++)this.textures[o]=r.clone(),this.textures[o].isRenderTargetTexture=!0;this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.resolveDepthBuffer=n.resolveDepthBuffer,this.resolveStencilBuffer=n.resolveStencilBuffer,this.depthTexture=n.depthTexture,this.samples=n.samples}get texture(){return this.textures[0]}set texture(t){this.textures[0]=t}setSize(t,e,n=1){if(this.width!==t||this.height!==e||this.depth!==n){this.width=t,this.height=e,this.depth=n;for(let s=0,r=this.textures.length;s<r;s++)this.textures[s].image.width=t,this.textures[s].image.height=e,this.textures[s].image.depth=n;this.dispose()}this.viewport.set(0,0,t,e),this.scissor.set(0,0,t,e)}clone(){return new this.constructor().copy(this)}copy(t){this.width=t.width,this.height=t.height,this.depth=t.depth,this.scissor.copy(t.scissor),this.scissorTest=t.scissorTest,this.viewport.copy(t.viewport),this.textures.length=0;for(let n=0,s=t.textures.length;n<s;n++)this.textures[n]=t.textures[n].clone(),this.textures[n].isRenderTargetTexture=!0;const e=Object.assign({},t.texture.image);return this.texture.source=new Zu(e),this.depthBuffer=t.depthBuffer,this.stencilBuffer=t.stencilBuffer,this.resolveDepthBuffer=t.resolveDepthBuffer,this.resolveStencilBuffer=t.resolveStencilBuffer,t.depthTexture!==null&&(this.depthTexture=t.depthTexture.clone()),this.samples=t.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}}class $n extends Hf{constructor(t=1,e=1,n={}){super(t,e,n),this.isWebGLRenderTarget=!0}}class ju extends vn{constructor(t=null,e=1,n=1,s=1){super(null),this.isDataArrayTexture=!0,this.image={data:t,width:e,height:n,depth:s},this.magFilter=Dn,this.minFilter=Dn,this.wrapR=Si,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}addLayerUpdate(t){this.layerUpdates.add(t)}clearLayerUpdates(){this.layerUpdates.clear()}}class Gf extends vn{constructor(t=null,e=1,n=1,s=1){super(null),this.isData3DTexture=!0,this.image={data:t,width:e,height:n,depth:s},this.magFilter=Dn,this.minFilter=Dn,this.wrapR=Si,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class In{constructor(t=0,e=0,n=0,s=1){this.isQuaternion=!0,this._x=t,this._y=e,this._z=n,this._w=s}static slerpFlat(t,e,n,s,r,a,o){let l=n[s+0],h=n[s+1],f=n[s+2],m=n[s+3];const u=r[a+0],d=r[a+1],c=r[a+2],v=r[a+3];if(o===0){t[e+0]=l,t[e+1]=h,t[e+2]=f,t[e+3]=m;return}if(o===1){t[e+0]=u,t[e+1]=d,t[e+2]=c,t[e+3]=v;return}if(m!==v||l!==u||h!==d||f!==c){let p=1-o;const x=l*u+h*d+f*c+m*v,w=x>=0?1:-1,b=1-x*x;if(b>Number.EPSILON){const V=Math.sqrt(b),D=Math.atan2(V,x*w);p=Math.sin(p*D)/V,o=Math.sin(o*D)/V}const C=o*w;if(l=l*p+u*C,h=h*p+d*C,f=f*p+c*C,m=m*p+v*C,p===1-o){const V=1/Math.sqrt(l*l+h*h+f*f+m*m);l*=V,h*=V,f*=V,m*=V}}t[e]=l,t[e+1]=h,t[e+2]=f,t[e+3]=m}static multiplyQuaternionsFlat(t,e,n,s,r,a){const o=n[s],l=n[s+1],h=n[s+2],f=n[s+3],m=r[a],u=r[a+1],d=r[a+2],c=r[a+3];return t[e]=o*c+f*m+l*d-h*u,t[e+1]=l*c+f*u+h*m-o*d,t[e+2]=h*c+f*d+o*u-l*m,t[e+3]=f*c-o*m-l*u-h*d,t}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get w(){return this._w}set w(t){this._w=t,this._onChangeCallback()}set(t,e,n,s){return this._x=t,this._y=e,this._z=n,this._w=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(t){return this._x=t.x,this._y=t.y,this._z=t.z,this._w=t.w,this._onChangeCallback(),this}setFromEuler(t,e=!0){const n=t._x,s=t._y,r=t._z,a=t._order,o=Math.cos,l=Math.sin,h=o(n/2),f=o(s/2),m=o(r/2),u=l(n/2),d=l(s/2),c=l(r/2);switch(a){case"XYZ":this._x=u*f*m+h*d*c,this._y=h*d*m-u*f*c,this._z=h*f*c+u*d*m,this._w=h*f*m-u*d*c;break;case"YXZ":this._x=u*f*m+h*d*c,this._y=h*d*m-u*f*c,this._z=h*f*c-u*d*m,this._w=h*f*m+u*d*c;break;case"ZXY":this._x=u*f*m-h*d*c,this._y=h*d*m+u*f*c,this._z=h*f*c+u*d*m,this._w=h*f*m-u*d*c;break;case"ZYX":this._x=u*f*m-h*d*c,this._y=h*d*m+u*f*c,this._z=h*f*c-u*d*m,this._w=h*f*m+u*d*c;break;case"YZX":this._x=u*f*m+h*d*c,this._y=h*d*m+u*f*c,this._z=h*f*c-u*d*m,this._w=h*f*m-u*d*c;break;case"XZY":this._x=u*f*m-h*d*c,this._y=h*d*m-u*f*c,this._z=h*f*c+u*d*m,this._w=h*f*m+u*d*c;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+a)}return e===!0&&this._onChangeCallback(),this}setFromAxisAngle(t,e){const n=e/2,s=Math.sin(n);return this._x=t.x*s,this._y=t.y*s,this._z=t.z*s,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(t){const e=t.elements,n=e[0],s=e[4],r=e[8],a=e[1],o=e[5],l=e[9],h=e[2],f=e[6],m=e[10],u=n+o+m;if(u>0){const d=.5/Math.sqrt(u+1);this._w=.25/d,this._x=(f-l)*d,this._y=(r-h)*d,this._z=(a-s)*d}else if(n>o&&n>m){const d=2*Math.sqrt(1+n-o-m);this._w=(f-l)/d,this._x=.25*d,this._y=(s+a)/d,this._z=(r+h)/d}else if(o>m){const d=2*Math.sqrt(1+o-n-m);this._w=(r-h)/d,this._x=(s+a)/d,this._y=.25*d,this._z=(l+f)/d}else{const d=2*Math.sqrt(1+m-n-o);this._w=(a-s)/d,this._x=(r+h)/d,this._y=(l+f)/d,this._z=.25*d}return this._onChangeCallback(),this}setFromUnitVectors(t,e){let n=t.dot(e)+1;return n<Number.EPSILON?(n=0,Math.abs(t.x)>Math.abs(t.z)?(this._x=-t.y,this._y=t.x,this._z=0,this._w=n):(this._x=0,this._y=-t.z,this._z=t.y,this._w=n)):(this._x=t.y*e.z-t.z*e.y,this._y=t.z*e.x-t.x*e.z,this._z=t.x*e.y-t.y*e.x,this._w=n),this.normalize()}angleTo(t){return 2*Math.acos(Math.abs(un(this.dot(t),-1,1)))}rotateTowards(t,e){const n=this.angleTo(t);if(n===0)return this;const s=Math.min(1,e/n);return this.slerp(t,s),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(t){return this._x*t._x+this._y*t._y+this._z*t._z+this._w*t._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let t=this.length();return t===0?(this._x=0,this._y=0,this._z=0,this._w=1):(t=1/t,this._x=this._x*t,this._y=this._y*t,this._z=this._z*t,this._w=this._w*t),this._onChangeCallback(),this}multiply(t){return this.multiplyQuaternions(this,t)}premultiply(t){return this.multiplyQuaternions(t,this)}multiplyQuaternions(t,e){const n=t._x,s=t._y,r=t._z,a=t._w,o=e._x,l=e._y,h=e._z,f=e._w;return this._x=n*f+a*o+s*h-r*l,this._y=s*f+a*l+r*o-n*h,this._z=r*f+a*h+n*l-s*o,this._w=a*f-n*o-s*l-r*h,this._onChangeCallback(),this}slerp(t,e){if(e===0)return this;if(e===1)return this.copy(t);const n=this._x,s=this._y,r=this._z,a=this._w;let o=a*t._w+n*t._x+s*t._y+r*t._z;if(o<0?(this._w=-t._w,this._x=-t._x,this._y=-t._y,this._z=-t._z,o=-o):this.copy(t),o>=1)return this._w=a,this._x=n,this._y=s,this._z=r,this;const l=1-o*o;if(l<=Number.EPSILON){const d=1-e;return this._w=d*a+e*this._w,this._x=d*n+e*this._x,this._y=d*s+e*this._y,this._z=d*r+e*this._z,this.normalize(),this}const h=Math.sqrt(l),f=Math.atan2(h,o),m=Math.sin((1-e)*f)/h,u=Math.sin(e*f)/h;return this._w=a*m+this._w*u,this._x=n*m+this._x*u,this._y=s*m+this._y*u,this._z=r*m+this._z*u,this._onChangeCallback(),this}slerpQuaternions(t,e,n){return this.copy(t).slerp(e,n)}random(){const t=2*Math.PI*Math.random(),e=2*Math.PI*Math.random(),n=Math.random(),s=Math.sqrt(1-n),r=Math.sqrt(n);return this.set(s*Math.sin(t),s*Math.cos(t),r*Math.sin(e),r*Math.cos(e))}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._w===this._w}fromArray(t,e=0){return this._x=t[e],this._y=t[e+1],this._z=t[e+2],this._w=t[e+3],this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._w,t}fromBufferAttribute(t,e){return this._x=t.getX(e),this._y=t.getY(e),this._z=t.getZ(e),this._w=t.getW(e),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}class N{constructor(t=0,e=0,n=0){N.prototype.isVector3=!0,this.x=t,this.y=e,this.z=n}set(t,e,n){return n===void 0&&(n=this.z),this.x=t,this.y=e,this.z=n,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this}multiplyVectors(t,e){return this.x=t.x*e.x,this.y=t.y*e.y,this.z=t.z*e.z,this}applyEuler(t){return this.applyQuaternion(e0.setFromEuler(t))}applyAxisAngle(t,e){return this.applyQuaternion(e0.setFromAxisAngle(t,e))}applyMatrix3(t){const e=this.x,n=this.y,s=this.z,r=t.elements;return this.x=r[0]*e+r[3]*n+r[6]*s,this.y=r[1]*e+r[4]*n+r[7]*s,this.z=r[2]*e+r[5]*n+r[8]*s,this}applyNormalMatrix(t){return this.applyMatrix3(t).normalize()}applyMatrix4(t){const e=this.x,n=this.y,s=this.z,r=t.elements,a=1/(r[3]*e+r[7]*n+r[11]*s+r[15]);return this.x=(r[0]*e+r[4]*n+r[8]*s+r[12])*a,this.y=(r[1]*e+r[5]*n+r[9]*s+r[13])*a,this.z=(r[2]*e+r[6]*n+r[10]*s+r[14])*a,this}applyQuaternion(t){const e=this.x,n=this.y,s=this.z,r=t.x,a=t.y,o=t.z,l=t.w,h=2*(a*s-o*n),f=2*(o*e-r*s),m=2*(r*n-a*e);return this.x=e+l*h+a*m-o*f,this.y=n+l*f+o*h-r*m,this.z=s+l*m+r*f-a*h,this}project(t){return this.applyMatrix4(t.matrixWorldInverse).applyMatrix4(t.projectionMatrix)}unproject(t){return this.applyMatrix4(t.projectionMatrixInverse).applyMatrix4(t.matrixWorld)}transformDirection(t){const e=this.x,n=this.y,s=this.z,r=t.elements;return this.x=r[0]*e+r[4]*n+r[8]*s,this.y=r[1]*e+r[5]*n+r[9]*s,this.z=r[2]*e+r[6]*n+r[10]*s,this.normalize()}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this}divideScalar(t){return this.multiplyScalar(1/t)}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this}clamp(t,e){return this.x=Math.max(t.x,Math.min(e.x,this.x)),this.y=Math.max(t.y,Math.min(e.y,this.y)),this.z=Math.max(t.z,Math.min(e.z,this.z)),this}clampScalar(t,e){return this.x=Math.max(t,Math.min(e,this.x)),this.y=Math.max(t,Math.min(e,this.y)),this.z=Math.max(t,Math.min(e,this.z)),this}clampLength(t,e){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(t,Math.min(e,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this}cross(t){return this.crossVectors(this,t)}crossVectors(t,e){const n=t.x,s=t.y,r=t.z,a=e.x,o=e.y,l=e.z;return this.x=s*l-r*o,this.y=r*a-n*l,this.z=n*o-s*a,this}projectOnVector(t){const e=t.lengthSq();if(e===0)return this.set(0,0,0);const n=t.dot(this)/e;return this.copy(t).multiplyScalar(n)}projectOnPlane(t){return Ao.copy(this).projectOnVector(t),this.sub(Ao)}reflect(t){return this.sub(Ao.copy(t).multiplyScalar(2*this.dot(t)))}angleTo(t){const e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;const n=this.dot(t)/e;return Math.acos(un(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){const e=this.x-t.x,n=this.y-t.y,s=this.z-t.z;return e*e+n*n+s*s}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)+Math.abs(this.z-t.z)}setFromSpherical(t){return this.setFromSphericalCoords(t.radius,t.phi,t.theta)}setFromSphericalCoords(t,e,n){const s=Math.sin(e)*t;return this.x=s*Math.sin(n),this.y=Math.cos(e)*t,this.z=s*Math.cos(n),this}setFromCylindrical(t){return this.setFromCylindricalCoords(t.radius,t.theta,t.y)}setFromCylindricalCoords(t,e,n){return this.x=t*Math.sin(e),this.y=n,this.z=t*Math.cos(e),this}setFromMatrixPosition(t){const e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this}setFromMatrixScale(t){const e=this.setFromMatrixColumn(t,0).length(),n=this.setFromMatrixColumn(t,1).length(),s=this.setFromMatrixColumn(t,2).length();return this.x=e,this.y=n,this.z=s,this}setFromMatrixColumn(t,e){return this.fromArray(t.elements,e*4)}setFromMatrix3Column(t,e){return this.fromArray(t.elements,e*3)}setFromEuler(t){return this.x=t._x,this.y=t._y,this.z=t._z,this}setFromColor(t){return this.x=t.r,this.y=t.g,this.z=t.b,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const t=Math.random()*Math.PI*2,e=Math.random()*2-1,n=Math.sqrt(1-e*e);return this.x=n*Math.cos(t),this.y=e,this.z=n*Math.sin(t),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}}const Ao=new N,e0=new In;class ms{constructor(t=new N(1/0,1/0,1/0),e=new N(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=t,this.max=e}set(t,e){return this.min.copy(t),this.max.copy(e),this}setFromArray(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e+=3)this.expandByPoint(Jn.fromArray(t,e));return this}setFromBufferAttribute(t){this.makeEmpty();for(let e=0,n=t.count;e<n;e++)this.expandByPoint(Jn.fromBufferAttribute(t,e));return this}setFromPoints(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e++)this.expandByPoint(t[e]);return this}setFromCenterAndSize(t,e){const n=Jn.copy(e).multiplyScalar(.5);return this.min.copy(t).sub(n),this.max.copy(t).add(n),this}setFromObject(t,e=!1){return this.makeEmpty(),this.expandByObject(t,e)}clone(){return new this.constructor().copy(this)}copy(t){return this.min.copy(t.min),this.max.copy(t.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(t){return this.isEmpty()?t.set(0,0,0):t.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(t){return this.isEmpty()?t.set(0,0,0):t.subVectors(this.max,this.min)}expandByPoint(t){return this.min.min(t),this.max.max(t),this}expandByVector(t){return this.min.sub(t),this.max.add(t),this}expandByScalar(t){return this.min.addScalar(-t),this.max.addScalar(t),this}expandByObject(t,e=!1){t.updateWorldMatrix(!1,!1);const n=t.geometry;if(n!==void 0){const r=n.getAttribute("position");if(e===!0&&r!==void 0&&t.isInstancedMesh!==!0)for(let a=0,o=r.count;a<o;a++)t.isMesh===!0?t.getVertexPosition(a,Jn):Jn.fromBufferAttribute(r,a),Jn.applyMatrix4(t.matrixWorld),this.expandByPoint(Jn);else t.boundingBox!==void 0?(t.boundingBox===null&&t.computeBoundingBox(),ta.copy(t.boundingBox)):(n.boundingBox===null&&n.computeBoundingBox(),ta.copy(n.boundingBox)),ta.applyMatrix4(t.matrixWorld),this.union(ta)}const s=t.children;for(let r=0,a=s.length;r<a;r++)this.expandByObject(s[r],e);return this}containsPoint(t){return t.x>=this.min.x&&t.x<=this.max.x&&t.y>=this.min.y&&t.y<=this.max.y&&t.z>=this.min.z&&t.z<=this.max.z}containsBox(t){return this.min.x<=t.min.x&&t.max.x<=this.max.x&&this.min.y<=t.min.y&&t.max.y<=this.max.y&&this.min.z<=t.min.z&&t.max.z<=this.max.z}getParameter(t,e){return e.set((t.x-this.min.x)/(this.max.x-this.min.x),(t.y-this.min.y)/(this.max.y-this.min.y),(t.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(t){return t.max.x>=this.min.x&&t.min.x<=this.max.x&&t.max.y>=this.min.y&&t.min.y<=this.max.y&&t.max.z>=this.min.z&&t.min.z<=this.max.z}intersectsSphere(t){return this.clampPoint(t.center,Jn),Jn.distanceToSquared(t.center)<=t.radius*t.radius}intersectsPlane(t){let e,n;return t.normal.x>0?(e=t.normal.x*this.min.x,n=t.normal.x*this.max.x):(e=t.normal.x*this.max.x,n=t.normal.x*this.min.x),t.normal.y>0?(e+=t.normal.y*this.min.y,n+=t.normal.y*this.max.y):(e+=t.normal.y*this.max.y,n+=t.normal.y*this.min.y),t.normal.z>0?(e+=t.normal.z*this.min.z,n+=t.normal.z*this.max.z):(e+=t.normal.z*this.max.z,n+=t.normal.z*this.min.z),e<=-t.constant&&n>=-t.constant}intersectsTriangle(t){if(this.isEmpty())return!1;this.getCenter(_r),ea.subVectors(this.max,_r),ys.subVectors(t.a,_r),Ss.subVectors(t.b,_r),ws.subVectors(t.c,_r),Ii.subVectors(Ss,ys),Li.subVectors(ws,Ss),qi.subVectors(ys,ws);let e=[0,-Ii.z,Ii.y,0,-Li.z,Li.y,0,-qi.z,qi.y,Ii.z,0,-Ii.x,Li.z,0,-Li.x,qi.z,0,-qi.x,-Ii.y,Ii.x,0,-Li.y,Li.x,0,-qi.y,qi.x,0];return!Co(e,ys,Ss,ws,ea)||(e=[1,0,0,0,1,0,0,0,1],!Co(e,ys,Ss,ws,ea))?!1:(na.crossVectors(Ii,Li),e=[na.x,na.y,na.z],Co(e,ys,Ss,ws,ea))}clampPoint(t,e){return e.copy(t).clamp(this.min,this.max)}distanceToPoint(t){return this.clampPoint(t,Jn).distanceTo(t)}getBoundingSphere(t){return this.isEmpty()?t.makeEmpty():(this.getCenter(t.center),t.radius=this.getSize(Jn).length()*.5),t}intersect(t){return this.min.max(t.min),this.max.min(t.max),this.isEmpty()&&this.makeEmpty(),this}union(t){return this.min.min(t.min),this.max.max(t.max),this}applyMatrix4(t){return this.isEmpty()?this:(gi[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(t),gi[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(t),gi[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(t),gi[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(t),gi[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(t),gi[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(t),gi[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(t),gi[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(t),this.setFromPoints(gi),this)}translate(t){return this.min.add(t),this.max.add(t),this}equals(t){return t.min.equals(this.min)&&t.max.equals(this.max)}}const gi=[new N,new N,new N,new N,new N,new N,new N,new N],Jn=new N,ta=new ms,ys=new N,Ss=new N,ws=new N,Ii=new N,Li=new N,qi=new N,_r=new N,ea=new N,na=new N,Yi=new N;function Co(i,t,e,n,s){for(let r=0,a=i.length-3;r<=a;r+=3){Yi.fromArray(i,r);const o=s.x*Math.abs(Yi.x)+s.y*Math.abs(Yi.y)+s.z*Math.abs(Yi.z),l=t.dot(Yi),h=e.dot(Yi),f=n.dot(Yi);if(Math.max(-Math.max(l,h,f),Math.min(l,h,f))>o)return!1}return!0}const Vf=new ms,Mr=new N,Ro=new N;class Kn{constructor(t=new N,e=-1){this.isSphere=!0,this.center=t,this.radius=e}set(t,e){return this.center.copy(t),this.radius=e,this}setFromPoints(t,e){const n=this.center;e!==void 0?n.copy(e):Vf.setFromPoints(t).getCenter(n);let s=0;for(let r=0,a=t.length;r<a;r++)s=Math.max(s,n.distanceToSquared(t[r]));return this.radius=Math.sqrt(s),this}copy(t){return this.center.copy(t.center),this.radius=t.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(t){return t.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(t){return t.distanceTo(this.center)-this.radius}intersectsSphere(t){const e=this.radius+t.radius;return t.center.distanceToSquared(this.center)<=e*e}intersectsBox(t){return t.intersectsSphere(this)}intersectsPlane(t){return Math.abs(t.distanceToPoint(this.center))<=this.radius}clampPoint(t,e){const n=this.center.distanceToSquared(t);return e.copy(t),n>this.radius*this.radius&&(e.sub(this.center).normalize(),e.multiplyScalar(this.radius).add(this.center)),e}getBoundingBox(t){return this.isEmpty()?(t.makeEmpty(),t):(t.set(this.center,this.center),t.expandByScalar(this.radius),t)}applyMatrix4(t){return this.center.applyMatrix4(t),this.radius=this.radius*t.getMaxScaleOnAxis(),this}translate(t){return this.center.add(t),this}expandByPoint(t){if(this.isEmpty())return this.center.copy(t),this.radius=0,this;Mr.subVectors(t,this.center);const e=Mr.lengthSq();if(e>this.radius*this.radius){const n=Math.sqrt(e),s=(n-this.radius)*.5;this.center.addScaledVector(Mr,s/n),this.radius+=s}return this}union(t){return t.isEmpty()?this:this.isEmpty()?(this.copy(t),this):(this.center.equals(t.center)===!0?this.radius=Math.max(this.radius,t.radius):(Ro.subVectors(t.center,this.center).setLength(t.radius),this.expandByPoint(Mr.copy(t.center).add(Ro)),this.expandByPoint(Mr.copy(t.center).sub(Ro))),this)}equals(t){return t.center.equals(this.center)&&t.radius===this.radius}clone(){return new this.constructor().copy(this)}}const vi=new N,Po=new N,ia=new N,Ui=new N,Do=new N,sa=new N,Io=new N;class vo{constructor(t=new N,e=new N(0,0,-1)){this.origin=t,this.direction=e}set(t,e){return this.origin.copy(t),this.direction.copy(e),this}copy(t){return this.origin.copy(t.origin),this.direction.copy(t.direction),this}at(t,e){return e.copy(this.origin).addScaledVector(this.direction,t)}lookAt(t){return this.direction.copy(t).sub(this.origin).normalize(),this}recast(t){return this.origin.copy(this.at(t,vi)),this}closestPointToPoint(t,e){e.subVectors(t,this.origin);const n=e.dot(this.direction);return n<0?e.copy(this.origin):e.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(t){return Math.sqrt(this.distanceSqToPoint(t))}distanceSqToPoint(t){const e=vi.subVectors(t,this.origin).dot(this.direction);return e<0?this.origin.distanceToSquared(t):(vi.copy(this.origin).addScaledVector(this.direction,e),vi.distanceToSquared(t))}distanceSqToSegment(t,e,n,s){Po.copy(t).add(e).multiplyScalar(.5),ia.copy(e).sub(t).normalize(),Ui.copy(this.origin).sub(Po);const r=t.distanceTo(e)*.5,a=-this.direction.dot(ia),o=Ui.dot(this.direction),l=-Ui.dot(ia),h=Ui.lengthSq(),f=Math.abs(1-a*a);let m,u,d,c;if(f>0)if(m=a*l-o,u=a*o-l,c=r*f,m>=0)if(u>=-c)if(u<=c){const v=1/f;m*=v,u*=v,d=m*(m+a*u+2*o)+u*(a*m+u+2*l)+h}else u=r,m=Math.max(0,-(a*u+o)),d=-m*m+u*(u+2*l)+h;else u=-r,m=Math.max(0,-(a*u+o)),d=-m*m+u*(u+2*l)+h;else u<=-c?(m=Math.max(0,-(-a*r+o)),u=m>0?-r:Math.min(Math.max(-r,-l),r),d=-m*m+u*(u+2*l)+h):u<=c?(m=0,u=Math.min(Math.max(-r,-l),r),d=u*(u+2*l)+h):(m=Math.max(0,-(a*r+o)),u=m>0?r:Math.min(Math.max(-r,-l),r),d=-m*m+u*(u+2*l)+h);else u=a>0?-r:r,m=Math.max(0,-(a*u+o)),d=-m*m+u*(u+2*l)+h;return n&&n.copy(this.origin).addScaledVector(this.direction,m),s&&s.copy(Po).addScaledVector(ia,u),d}intersectSphere(t,e){vi.subVectors(t.center,this.origin);const n=vi.dot(this.direction),s=vi.dot(vi)-n*n,r=t.radius*t.radius;if(s>r)return null;const a=Math.sqrt(r-s),o=n-a,l=n+a;return l<0?null:o<0?this.at(l,e):this.at(o,e)}intersectsSphere(t){return this.distanceSqToPoint(t.center)<=t.radius*t.radius}distanceToPlane(t){const e=t.normal.dot(this.direction);if(e===0)return t.distanceToPoint(this.origin)===0?0:null;const n=-(this.origin.dot(t.normal)+t.constant)/e;return n>=0?n:null}intersectPlane(t,e){const n=this.distanceToPlane(t);return n===null?null:this.at(n,e)}intersectsPlane(t){const e=t.distanceToPoint(this.origin);return e===0||t.normal.dot(this.direction)*e<0}intersectBox(t,e){let n,s,r,a,o,l;const h=1/this.direction.x,f=1/this.direction.y,m=1/this.direction.z,u=this.origin;return h>=0?(n=(t.min.x-u.x)*h,s=(t.max.x-u.x)*h):(n=(t.max.x-u.x)*h,s=(t.min.x-u.x)*h),f>=0?(r=(t.min.y-u.y)*f,a=(t.max.y-u.y)*f):(r=(t.max.y-u.y)*f,a=(t.min.y-u.y)*f),n>a||r>s||((r>n||isNaN(n))&&(n=r),(a<s||isNaN(s))&&(s=a),m>=0?(o=(t.min.z-u.z)*m,l=(t.max.z-u.z)*m):(o=(t.max.z-u.z)*m,l=(t.min.z-u.z)*m),n>l||o>s)||((o>n||n!==n)&&(n=o),(l<s||s!==s)&&(s=l),s<0)?null:this.at(n>=0?n:s,e)}intersectsBox(t){return this.intersectBox(t,vi)!==null}intersectTriangle(t,e,n,s,r){Do.subVectors(e,t),sa.subVectors(n,t),Io.crossVectors(Do,sa);let a=this.direction.dot(Io),o;if(a>0){if(s)return null;o=1}else if(a<0)o=-1,a=-a;else return null;Ui.subVectors(this.origin,t);const l=o*this.direction.dot(sa.crossVectors(Ui,sa));if(l<0)return null;const h=o*this.direction.dot(Do.cross(Ui));if(h<0||l+h>a)return null;const f=-o*Ui.dot(Io);return f<0?null:this.at(f/a,r)}applyMatrix4(t){return this.origin.applyMatrix4(t),this.direction.transformDirection(t),this}equals(t){return t.origin.equals(this.origin)&&t.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class Pe{constructor(t,e,n,s,r,a,o,l,h,f,m,u,d,c,v,p){Pe.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],t!==void 0&&this.set(t,e,n,s,r,a,o,l,h,f,m,u,d,c,v,p)}set(t,e,n,s,r,a,o,l,h,f,m,u,d,c,v,p){const x=this.elements;return x[0]=t,x[4]=e,x[8]=n,x[12]=s,x[1]=r,x[5]=a,x[9]=o,x[13]=l,x[2]=h,x[6]=f,x[10]=m,x[14]=u,x[3]=d,x[7]=c,x[11]=v,x[15]=p,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new Pe().fromArray(this.elements)}copy(t){const e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],e[9]=n[9],e[10]=n[10],e[11]=n[11],e[12]=n[12],e[13]=n[13],e[14]=n[14],e[15]=n[15],this}copyPosition(t){const e=this.elements,n=t.elements;return e[12]=n[12],e[13]=n[13],e[14]=n[14],this}setFromMatrix3(t){const e=t.elements;return this.set(e[0],e[3],e[6],0,e[1],e[4],e[7],0,e[2],e[5],e[8],0,0,0,0,1),this}extractBasis(t,e,n){return t.setFromMatrixColumn(this,0),e.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this}makeBasis(t,e,n){return this.set(t.x,e.x,n.x,0,t.y,e.y,n.y,0,t.z,e.z,n.z,0,0,0,0,1),this}extractRotation(t){const e=this.elements,n=t.elements,s=1/bs.setFromMatrixColumn(t,0).length(),r=1/bs.setFromMatrixColumn(t,1).length(),a=1/bs.setFromMatrixColumn(t,2).length();return e[0]=n[0]*s,e[1]=n[1]*s,e[2]=n[2]*s,e[3]=0,e[4]=n[4]*r,e[5]=n[5]*r,e[6]=n[6]*r,e[7]=0,e[8]=n[8]*a,e[9]=n[9]*a,e[10]=n[10]*a,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromEuler(t){const e=this.elements,n=t.x,s=t.y,r=t.z,a=Math.cos(n),o=Math.sin(n),l=Math.cos(s),h=Math.sin(s),f=Math.cos(r),m=Math.sin(r);if(t.order==="XYZ"){const u=a*f,d=a*m,c=o*f,v=o*m;e[0]=l*f,e[4]=-l*m,e[8]=h,e[1]=d+c*h,e[5]=u-v*h,e[9]=-o*l,e[2]=v-u*h,e[6]=c+d*h,e[10]=a*l}else if(t.order==="YXZ"){const u=l*f,d=l*m,c=h*f,v=h*m;e[0]=u+v*o,e[4]=c*o-d,e[8]=a*h,e[1]=a*m,e[5]=a*f,e[9]=-o,e[2]=d*o-c,e[6]=v+u*o,e[10]=a*l}else if(t.order==="ZXY"){const u=l*f,d=l*m,c=h*f,v=h*m;e[0]=u-v*o,e[4]=-a*m,e[8]=c+d*o,e[1]=d+c*o,e[5]=a*f,e[9]=v-u*o,e[2]=-a*h,e[6]=o,e[10]=a*l}else if(t.order==="ZYX"){const u=a*f,d=a*m,c=o*f,v=o*m;e[0]=l*f,e[4]=c*h-d,e[8]=u*h+v,e[1]=l*m,e[5]=v*h+u,e[9]=d*h-c,e[2]=-h,e[6]=o*l,e[10]=a*l}else if(t.order==="YZX"){const u=a*l,d=a*h,c=o*l,v=o*h;e[0]=l*f,e[4]=v-u*m,e[8]=c*m+d,e[1]=m,e[5]=a*f,e[9]=-o*f,e[2]=-h*f,e[6]=d*m+c,e[10]=u-v*m}else if(t.order==="XZY"){const u=a*l,d=a*h,c=o*l,v=o*h;e[0]=l*f,e[4]=-m,e[8]=h*f,e[1]=u*m+v,e[5]=a*f,e[9]=d*m-c,e[2]=c*m-d,e[6]=o*f,e[10]=v*m+u}return e[3]=0,e[7]=0,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromQuaternion(t){return this.compose(Wf,t,Xf)}lookAt(t,e,n){const s=this.elements;return Un.subVectors(t,e),Un.lengthSq()===0&&(Un.z=1),Un.normalize(),zi.crossVectors(n,Un),zi.lengthSq()===0&&(Math.abs(n.z)===1?Un.x+=1e-4:Un.z+=1e-4,Un.normalize(),zi.crossVectors(n,Un)),zi.normalize(),ra.crossVectors(Un,zi),s[0]=zi.x,s[4]=ra.x,s[8]=Un.x,s[1]=zi.y,s[5]=ra.y,s[9]=Un.y,s[2]=zi.z,s[6]=ra.z,s[10]=Un.z,this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){const n=t.elements,s=e.elements,r=this.elements,a=n[0],o=n[4],l=n[8],h=n[12],f=n[1],m=n[5],u=n[9],d=n[13],c=n[2],v=n[6],p=n[10],x=n[14],w=n[3],b=n[7],C=n[11],V=n[15],D=s[0],A=s[4],y=s[8],rt=s[12],S=s[1],z=s[5],nt=s[9],q=s[13],j=s[2],Y=s[6],W=s[10],ht=s[14],lt=s[3],Dt=s[7],yt=s[11],dt=s[15];return r[0]=a*D+o*S+l*j+h*lt,r[4]=a*A+o*z+l*Y+h*Dt,r[8]=a*y+o*nt+l*W+h*yt,r[12]=a*rt+o*q+l*ht+h*dt,r[1]=f*D+m*S+u*j+d*lt,r[5]=f*A+m*z+u*Y+d*Dt,r[9]=f*y+m*nt+u*W+d*yt,r[13]=f*rt+m*q+u*ht+d*dt,r[2]=c*D+v*S+p*j+x*lt,r[6]=c*A+v*z+p*Y+x*Dt,r[10]=c*y+v*nt+p*W+x*yt,r[14]=c*rt+v*q+p*ht+x*dt,r[3]=w*D+b*S+C*j+V*lt,r[7]=w*A+b*z+C*Y+V*Dt,r[11]=w*y+b*nt+C*W+V*yt,r[15]=w*rt+b*q+C*ht+V*dt,this}multiplyScalar(t){const e=this.elements;return e[0]*=t,e[4]*=t,e[8]*=t,e[12]*=t,e[1]*=t,e[5]*=t,e[9]*=t,e[13]*=t,e[2]*=t,e[6]*=t,e[10]*=t,e[14]*=t,e[3]*=t,e[7]*=t,e[11]*=t,e[15]*=t,this}determinant(){const t=this.elements,e=t[0],n=t[4],s=t[8],r=t[12],a=t[1],o=t[5],l=t[9],h=t[13],f=t[2],m=t[6],u=t[10],d=t[14],c=t[3],v=t[7],p=t[11],x=t[15];return c*(+r*l*m-s*h*m-r*o*u+n*h*u+s*o*d-n*l*d)+v*(+e*l*d-e*h*u+r*a*u-s*a*d+s*h*f-r*l*f)+p*(+e*h*m-e*o*d-r*a*m+n*a*d+r*o*f-n*h*f)+x*(-s*o*f-e*l*m+e*o*u+s*a*m-n*a*u+n*l*f)}transpose(){const t=this.elements;let e;return e=t[1],t[1]=t[4],t[4]=e,e=t[2],t[2]=t[8],t[8]=e,e=t[6],t[6]=t[9],t[9]=e,e=t[3],t[3]=t[12],t[12]=e,e=t[7],t[7]=t[13],t[13]=e,e=t[11],t[11]=t[14],t[14]=e,this}setPosition(t,e,n){const s=this.elements;return t.isVector3?(s[12]=t.x,s[13]=t.y,s[14]=t.z):(s[12]=t,s[13]=e,s[14]=n),this}invert(){const t=this.elements,e=t[0],n=t[1],s=t[2],r=t[3],a=t[4],o=t[5],l=t[6],h=t[7],f=t[8],m=t[9],u=t[10],d=t[11],c=t[12],v=t[13],p=t[14],x=t[15],w=m*p*h-v*u*h+v*l*d-o*p*d-m*l*x+o*u*x,b=c*u*h-f*p*h-c*l*d+a*p*d+f*l*x-a*u*x,C=f*v*h-c*m*h+c*o*d-a*v*d-f*o*x+a*m*x,V=c*m*l-f*v*l-c*o*u+a*v*u+f*o*p-a*m*p,D=e*w+n*b+s*C+r*V;if(D===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const A=1/D;return t[0]=w*A,t[1]=(v*u*r-m*p*r-v*s*d+n*p*d+m*s*x-n*u*x)*A,t[2]=(o*p*r-v*l*r+v*s*h-n*p*h-o*s*x+n*l*x)*A,t[3]=(m*l*r-o*u*r-m*s*h+n*u*h+o*s*d-n*l*d)*A,t[4]=b*A,t[5]=(f*p*r-c*u*r+c*s*d-e*p*d-f*s*x+e*u*x)*A,t[6]=(c*l*r-a*p*r-c*s*h+e*p*h+a*s*x-e*l*x)*A,t[7]=(a*u*r-f*l*r+f*s*h-e*u*h-a*s*d+e*l*d)*A,t[8]=C*A,t[9]=(c*m*r-f*v*r-c*n*d+e*v*d+f*n*x-e*m*x)*A,t[10]=(a*v*r-c*o*r+c*n*h-e*v*h-a*n*x+e*o*x)*A,t[11]=(f*o*r-a*m*r-f*n*h+e*m*h+a*n*d-e*o*d)*A,t[12]=V*A,t[13]=(f*v*s-c*m*s+c*n*u-e*v*u-f*n*p+e*m*p)*A,t[14]=(c*o*s-a*v*s-c*n*l+e*v*l+a*n*p-e*o*p)*A,t[15]=(a*m*s-f*o*s+f*n*l-e*m*l-a*n*u+e*o*u)*A,this}scale(t){const e=this.elements,n=t.x,s=t.y,r=t.z;return e[0]*=n,e[4]*=s,e[8]*=r,e[1]*=n,e[5]*=s,e[9]*=r,e[2]*=n,e[6]*=s,e[10]*=r,e[3]*=n,e[7]*=s,e[11]*=r,this}getMaxScaleOnAxis(){const t=this.elements,e=t[0]*t[0]+t[1]*t[1]+t[2]*t[2],n=t[4]*t[4]+t[5]*t[5]+t[6]*t[6],s=t[8]*t[8]+t[9]*t[9]+t[10]*t[10];return Math.sqrt(Math.max(e,n,s))}makeTranslation(t,e,n){return t.isVector3?this.set(1,0,0,t.x,0,1,0,t.y,0,0,1,t.z,0,0,0,1):this.set(1,0,0,t,0,1,0,e,0,0,1,n,0,0,0,1),this}makeRotationX(t){const e=Math.cos(t),n=Math.sin(t);return this.set(1,0,0,0,0,e,-n,0,0,n,e,0,0,0,0,1),this}makeRotationY(t){const e=Math.cos(t),n=Math.sin(t);return this.set(e,0,n,0,0,1,0,0,-n,0,e,0,0,0,0,1),this}makeRotationZ(t){const e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,0,n,e,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(t,e){const n=Math.cos(e),s=Math.sin(e),r=1-n,a=t.x,o=t.y,l=t.z,h=r*a,f=r*o;return this.set(h*a+n,h*o-s*l,h*l+s*o,0,h*o+s*l,f*o+n,f*l-s*a,0,h*l-s*o,f*l+s*a,r*l*l+n,0,0,0,0,1),this}makeScale(t,e,n){return this.set(t,0,0,0,0,e,0,0,0,0,n,0,0,0,0,1),this}makeShear(t,e,n,s,r,a){return this.set(1,n,r,0,t,1,a,0,e,s,1,0,0,0,0,1),this}compose(t,e,n){const s=this.elements,r=e._x,a=e._y,o=e._z,l=e._w,h=r+r,f=a+a,m=o+o,u=r*h,d=r*f,c=r*m,v=a*f,p=a*m,x=o*m,w=l*h,b=l*f,C=l*m,V=n.x,D=n.y,A=n.z;return s[0]=(1-(v+x))*V,s[1]=(d+C)*V,s[2]=(c-b)*V,s[3]=0,s[4]=(d-C)*D,s[5]=(1-(u+x))*D,s[6]=(p+w)*D,s[7]=0,s[8]=(c+b)*A,s[9]=(p-w)*A,s[10]=(1-(u+v))*A,s[11]=0,s[12]=t.x,s[13]=t.y,s[14]=t.z,s[15]=1,this}decompose(t,e,n){const s=this.elements;let r=bs.set(s[0],s[1],s[2]).length();const a=bs.set(s[4],s[5],s[6]).length(),o=bs.set(s[8],s[9],s[10]).length();this.determinant()<0&&(r=-r),t.x=s[12],t.y=s[13],t.z=s[14],Qn.copy(this);const h=1/r,f=1/a,m=1/o;return Qn.elements[0]*=h,Qn.elements[1]*=h,Qn.elements[2]*=h,Qn.elements[4]*=f,Qn.elements[5]*=f,Qn.elements[6]*=f,Qn.elements[8]*=m,Qn.elements[9]*=m,Qn.elements[10]*=m,e.setFromRotationMatrix(Qn),n.x=r,n.y=a,n.z=o,this}makePerspective(t,e,n,s,r,a,o=wi){const l=this.elements,h=2*r/(e-t),f=2*r/(n-s),m=(e+t)/(e-t),u=(n+s)/(n-s);let d,c;if(o===wi)d=-(a+r)/(a-r),c=-2*a*r/(a-r);else if(o===eo)d=-a/(a-r),c=-a*r/(a-r);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+o);return l[0]=h,l[4]=0,l[8]=m,l[12]=0,l[1]=0,l[5]=f,l[9]=u,l[13]=0,l[2]=0,l[6]=0,l[10]=d,l[14]=c,l[3]=0,l[7]=0,l[11]=-1,l[15]=0,this}makeOrthographic(t,e,n,s,r,a,o=wi){const l=this.elements,h=1/(e-t),f=1/(n-s),m=1/(a-r),u=(e+t)*h,d=(n+s)*f;let c,v;if(o===wi)c=(a+r)*m,v=-2*m;else if(o===eo)c=r*m,v=-1*m;else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+o);return l[0]=2*h,l[4]=0,l[8]=0,l[12]=-u,l[1]=0,l[5]=2*f,l[9]=0,l[13]=-d,l[2]=0,l[6]=0,l[10]=v,l[14]=-c,l[3]=0,l[7]=0,l[11]=0,l[15]=1,this}equals(t){const e=this.elements,n=t.elements;for(let s=0;s<16;s++)if(e[s]!==n[s])return!1;return!0}fromArray(t,e=0){for(let n=0;n<16;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){const n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t[e+9]=n[9],t[e+10]=n[10],t[e+11]=n[11],t[e+12]=n[12],t[e+13]=n[13],t[e+14]=n[14],t[e+15]=n[15],t}}const bs=new N,Qn=new Pe,Wf=new N(0,0,0),Xf=new N(1,1,1),zi=new N,ra=new N,Un=new N,n0=new Pe,i0=new In;class wn{constructor(t=0,e=0,n=0,s=wn.DEFAULT_ORDER){this.isEuler=!0,this._x=t,this._y=e,this._z=n,this._order=s}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get order(){return this._order}set order(t){this._order=t,this._onChangeCallback()}set(t,e,n,s=this._order){return this._x=t,this._y=e,this._z=n,this._order=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(t){return this._x=t._x,this._y=t._y,this._z=t._z,this._order=t._order,this._onChangeCallback(),this}setFromRotationMatrix(t,e=this._order,n=!0){const s=t.elements,r=s[0],a=s[4],o=s[8],l=s[1],h=s[5],f=s[9],m=s[2],u=s[6],d=s[10];switch(e){case"XYZ":this._y=Math.asin(un(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(-f,d),this._z=Math.atan2(-a,r)):(this._x=Math.atan2(u,h),this._z=0);break;case"YXZ":this._x=Math.asin(-un(f,-1,1)),Math.abs(f)<.9999999?(this._y=Math.atan2(o,d),this._z=Math.atan2(l,h)):(this._y=Math.atan2(-m,r),this._z=0);break;case"ZXY":this._x=Math.asin(un(u,-1,1)),Math.abs(u)<.9999999?(this._y=Math.atan2(-m,d),this._z=Math.atan2(-a,h)):(this._y=0,this._z=Math.atan2(l,r));break;case"ZYX":this._y=Math.asin(-un(m,-1,1)),Math.abs(m)<.9999999?(this._x=Math.atan2(u,d),this._z=Math.atan2(l,r)):(this._x=0,this._z=Math.atan2(-a,h));break;case"YZX":this._z=Math.asin(un(l,-1,1)),Math.abs(l)<.9999999?(this._x=Math.atan2(-f,h),this._y=Math.atan2(-m,r)):(this._x=0,this._y=Math.atan2(o,d));break;case"XZY":this._z=Math.asin(-un(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(u,h),this._y=Math.atan2(o,r)):(this._x=Math.atan2(-f,d),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+e)}return this._order=e,n===!0&&this._onChangeCallback(),this}setFromQuaternion(t,e,n){return n0.makeRotationFromQuaternion(t),this.setFromRotationMatrix(n0,e,n)}setFromVector3(t,e=this._order){return this.set(t.x,t.y,t.z,e)}reorder(t){return i0.setFromEuler(this),this.setFromQuaternion(i0,t)}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._order===this._order}fromArray(t){return this._x=t[0],this._y=t[1],this._z=t[2],t[3]!==void 0&&(this._order=t[3]),this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._order,t}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}wn.DEFAULT_ORDER="XYZ";class Rc{constructor(){this.mask=1}set(t){this.mask=(1<<t|0)>>>0}enable(t){this.mask|=1<<t|0}enableAll(){this.mask=-1}toggle(t){this.mask^=1<<t|0}disable(t){this.mask&=~(1<<t|0)}disableAll(){this.mask=0}test(t){return(this.mask&t.mask)!==0}isEnabled(t){return(this.mask&(1<<t|0))!==0}}let qf=0;const s0=new N,Ts=new In,xi=new Pe,aa=new N,yr=new N,Yf=new N,$f=new In,r0=new N(1,0,0),a0=new N(0,1,0),o0=new N(0,0,1),l0={type:"added"},Kf={type:"removed"},Es={type:"childadded",child:null},Lo={type:"childremoved",child:null};class Ze extends dr{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:qf++}),this.uuid=Ti(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=Ze.DEFAULT_UP.clone();const t=new N,e=new wn,n=new In,s=new N(1,1,1);function r(){n.setFromEuler(e,!1)}function a(){e.setFromQuaternion(n,void 0,!1)}e._onChange(r),n._onChange(a),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:t},rotation:{configurable:!0,enumerable:!0,value:e},quaternion:{configurable:!0,enumerable:!0,value:n},scale:{configurable:!0,enumerable:!0,value:s},modelViewMatrix:{value:new Pe},normalMatrix:{value:new Se}}),this.matrix=new Pe,this.matrixWorld=new Pe,this.matrixAutoUpdate=Ze.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=Ze.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new Rc,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(t){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(t),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(t){return this.quaternion.premultiply(t),this}setRotationFromAxisAngle(t,e){this.quaternion.setFromAxisAngle(t,e)}setRotationFromEuler(t){this.quaternion.setFromEuler(t,!0)}setRotationFromMatrix(t){this.quaternion.setFromRotationMatrix(t)}setRotationFromQuaternion(t){this.quaternion.copy(t)}rotateOnAxis(t,e){return Ts.setFromAxisAngle(t,e),this.quaternion.multiply(Ts),this}rotateOnWorldAxis(t,e){return Ts.setFromAxisAngle(t,e),this.quaternion.premultiply(Ts),this}rotateX(t){return this.rotateOnAxis(r0,t)}rotateY(t){return this.rotateOnAxis(a0,t)}rotateZ(t){return this.rotateOnAxis(o0,t)}translateOnAxis(t,e){return s0.copy(t).applyQuaternion(this.quaternion),this.position.add(s0.multiplyScalar(e)),this}translateX(t){return this.translateOnAxis(r0,t)}translateY(t){return this.translateOnAxis(a0,t)}translateZ(t){return this.translateOnAxis(o0,t)}localToWorld(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(this.matrixWorld)}worldToLocal(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(xi.copy(this.matrixWorld).invert())}lookAt(t,e,n){t.isVector3?aa.copy(t):aa.set(t,e,n);const s=this.parent;this.updateWorldMatrix(!0,!1),yr.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?xi.lookAt(yr,aa,this.up):xi.lookAt(aa,yr,this.up),this.quaternion.setFromRotationMatrix(xi),s&&(xi.extractRotation(s.matrixWorld),Ts.setFromRotationMatrix(xi),this.quaternion.premultiply(Ts.invert()))}add(t){if(arguments.length>1){for(let e=0;e<arguments.length;e++)this.add(arguments[e]);return this}return t===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",t),this):(t&&t.isObject3D?(t.removeFromParent(),t.parent=this,this.children.push(t),t.dispatchEvent(l0),Es.child=t,this.dispatchEvent(Es),Es.child=null):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",t),this)}remove(t){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.remove(arguments[n]);return this}const e=this.children.indexOf(t);return e!==-1&&(t.parent=null,this.children.splice(e,1),t.dispatchEvent(Kf),Lo.child=t,this.dispatchEvent(Lo),Lo.child=null),this}removeFromParent(){const t=this.parent;return t!==null&&t.remove(this),this}clear(){return this.remove(...this.children)}attach(t){return this.updateWorldMatrix(!0,!1),xi.copy(this.matrixWorld).invert(),t.parent!==null&&(t.parent.updateWorldMatrix(!0,!1),xi.multiply(t.parent.matrixWorld)),t.applyMatrix4(xi),t.removeFromParent(),t.parent=this,this.children.push(t),t.updateWorldMatrix(!1,!0),t.dispatchEvent(l0),Es.child=t,this.dispatchEvent(Es),Es.child=null,this}getObjectById(t){return this.getObjectByProperty("id",t)}getObjectByName(t){return this.getObjectByProperty("name",t)}getObjectByProperty(t,e){if(this[t]===e)return this;for(let n=0,s=this.children.length;n<s;n++){const a=this.children[n].getObjectByProperty(t,e);if(a!==void 0)return a}}getObjectsByProperty(t,e,n=[]){this[t]===e&&n.push(this);const s=this.children;for(let r=0,a=s.length;r<a;r++)s[r].getObjectsByProperty(t,e,n);return n}getWorldPosition(t){return this.updateWorldMatrix(!0,!1),t.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(yr,t,Yf),t}getWorldScale(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(yr,$f,t),t}getWorldDirection(t){this.updateWorldMatrix(!0,!1);const e=this.matrixWorld.elements;return t.set(e[8],e[9],e[10]).normalize()}raycast(){}traverse(t){t(this);const e=this.children;for(let n=0,s=e.length;n<s;n++)e[n].traverse(t)}traverseVisible(t){if(this.visible===!1)return;t(this);const e=this.children;for(let n=0,s=e.length;n<s;n++)e[n].traverseVisible(t)}traverseAncestors(t){const e=this.parent;e!==null&&(t(e),e.traverseAncestors(t))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(t){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||t)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,t=!0);const e=this.children;for(let n=0,s=e.length;n<s;n++)e[n].updateMatrixWorld(t)}updateWorldMatrix(t,e){const n=this.parent;if(t===!0&&n!==null&&n.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),e===!0){const s=this.children;for(let r=0,a=s.length;r<a;r++)s[r].updateWorldMatrix(!1,!0)}}toJSON(t){const e=t===void 0||typeof t=="string",n={};e&&(t={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.6,type:"Object",generator:"Object3D.toJSON"});const s={};s.uuid=this.uuid,s.type=this.type,this.name!==""&&(s.name=this.name),this.castShadow===!0&&(s.castShadow=!0),this.receiveShadow===!0&&(s.receiveShadow=!0),this.visible===!1&&(s.visible=!1),this.frustumCulled===!1&&(s.frustumCulled=!1),this.renderOrder!==0&&(s.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(s.userData=this.userData),s.layers=this.layers.mask,s.matrix=this.matrix.toArray(),s.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(s.matrixAutoUpdate=!1),this.isInstancedMesh&&(s.type="InstancedMesh",s.count=this.count,s.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(s.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(s.type="BatchedMesh",s.perObjectFrustumCulled=this.perObjectFrustumCulled,s.sortObjects=this.sortObjects,s.drawRanges=this._drawRanges,s.reservedRanges=this._reservedRanges,s.visibility=this._visibility,s.active=this._active,s.bounds=this._bounds.map(o=>({boxInitialized:o.boxInitialized,boxMin:o.box.min.toArray(),boxMax:o.box.max.toArray(),sphereInitialized:o.sphereInitialized,sphereRadius:o.sphere.radius,sphereCenter:o.sphere.center.toArray()})),s.maxInstanceCount=this._maxInstanceCount,s.maxVertexCount=this._maxVertexCount,s.maxIndexCount=this._maxIndexCount,s.geometryInitialized=this._geometryInitialized,s.geometryCount=this._geometryCount,s.matricesTexture=this._matricesTexture.toJSON(t),this._colorsTexture!==null&&(s.colorsTexture=this._colorsTexture.toJSON(t)),this.boundingSphere!==null&&(s.boundingSphere={center:s.boundingSphere.center.toArray(),radius:s.boundingSphere.radius}),this.boundingBox!==null&&(s.boundingBox={min:s.boundingBox.min.toArray(),max:s.boundingBox.max.toArray()}));function r(o,l){return o[l.uuid]===void 0&&(o[l.uuid]=l.toJSON(t)),l.uuid}if(this.isScene)this.background&&(this.background.isColor?s.background=this.background.toJSON():this.background.isTexture&&(s.background=this.background.toJSON(t).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(s.environment=this.environment.toJSON(t).uuid);else if(this.isMesh||this.isLine||this.isPoints){s.geometry=r(t.geometries,this.geometry);const o=this.geometry.parameters;if(o!==void 0&&o.shapes!==void 0){const l=o.shapes;if(Array.isArray(l))for(let h=0,f=l.length;h<f;h++){const m=l[h];r(t.shapes,m)}else r(t.shapes,l)}}if(this.isSkinnedMesh&&(s.bindMode=this.bindMode,s.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(r(t.skeletons,this.skeleton),s.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const o=[];for(let l=0,h=this.material.length;l<h;l++)o.push(r(t.materials,this.material[l]));s.material=o}else s.material=r(t.materials,this.material);if(this.children.length>0){s.children=[];for(let o=0;o<this.children.length;o++)s.children.push(this.children[o].toJSON(t).object)}if(this.animations.length>0){s.animations=[];for(let o=0;o<this.animations.length;o++){const l=this.animations[o];s.animations.push(r(t.animations,l))}}if(e){const o=a(t.geometries),l=a(t.materials),h=a(t.textures),f=a(t.images),m=a(t.shapes),u=a(t.skeletons),d=a(t.animations),c=a(t.nodes);o.length>0&&(n.geometries=o),l.length>0&&(n.materials=l),h.length>0&&(n.textures=h),f.length>0&&(n.images=f),m.length>0&&(n.shapes=m),u.length>0&&(n.skeletons=u),d.length>0&&(n.animations=d),c.length>0&&(n.nodes=c)}return n.object=s,n;function a(o){const l=[];for(const h in o){const f=o[h];delete f.metadata,l.push(f)}return l}}clone(t){return new this.constructor().copy(this,t)}copy(t,e=!0){if(this.name=t.name,this.up.copy(t.up),this.position.copy(t.position),this.rotation.order=t.rotation.order,this.quaternion.copy(t.quaternion),this.scale.copy(t.scale),this.matrix.copy(t.matrix),this.matrixWorld.copy(t.matrixWorld),this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrixWorldAutoUpdate=t.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=t.matrixWorldNeedsUpdate,this.layers.mask=t.layers.mask,this.visible=t.visible,this.castShadow=t.castShadow,this.receiveShadow=t.receiveShadow,this.frustumCulled=t.frustumCulled,this.renderOrder=t.renderOrder,this.animations=t.animations.slice(),this.userData=JSON.parse(JSON.stringify(t.userData)),e===!0)for(let n=0;n<t.children.length;n++){const s=t.children[n];this.add(s.clone())}return this}}Ze.DEFAULT_UP=new N(0,1,0);Ze.DEFAULT_MATRIX_AUTO_UPDATE=!0;Ze.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;const ti=new N,_i=new N,Uo=new N,Mi=new N,As=new N,Cs=new N,c0=new N,zo=new N,No=new N,Fo=new N,Oo=new Fe,Bo=new Fe,ko=new Fe;class Yn{constructor(t=new N,e=new N,n=new N){this.a=t,this.b=e,this.c=n}static getNormal(t,e,n,s){s.subVectors(n,e),ti.subVectors(t,e),s.cross(ti);const r=s.lengthSq();return r>0?s.multiplyScalar(1/Math.sqrt(r)):s.set(0,0,0)}static getBarycoord(t,e,n,s,r){ti.subVectors(s,e),_i.subVectors(n,e),Uo.subVectors(t,e);const a=ti.dot(ti),o=ti.dot(_i),l=ti.dot(Uo),h=_i.dot(_i),f=_i.dot(Uo),m=a*h-o*o;if(m===0)return r.set(0,0,0),null;const u=1/m,d=(h*l-o*f)*u,c=(a*f-o*l)*u;return r.set(1-d-c,c,d)}static containsPoint(t,e,n,s){return this.getBarycoord(t,e,n,s,Mi)===null?!1:Mi.x>=0&&Mi.y>=0&&Mi.x+Mi.y<=1}static getInterpolation(t,e,n,s,r,a,o,l){return this.getBarycoord(t,e,n,s,Mi)===null?(l.x=0,l.y=0,"z"in l&&(l.z=0),"w"in l&&(l.w=0),null):(l.setScalar(0),l.addScaledVector(r,Mi.x),l.addScaledVector(a,Mi.y),l.addScaledVector(o,Mi.z),l)}static getInterpolatedAttribute(t,e,n,s,r,a){return Oo.setScalar(0),Bo.setScalar(0),ko.setScalar(0),Oo.fromBufferAttribute(t,e),Bo.fromBufferAttribute(t,n),ko.fromBufferAttribute(t,s),a.setScalar(0),a.addScaledVector(Oo,r.x),a.addScaledVector(Bo,r.y),a.addScaledVector(ko,r.z),a}static isFrontFacing(t,e,n,s){return ti.subVectors(n,e),_i.subVectors(t,e),ti.cross(_i).dot(s)<0}set(t,e,n){return this.a.copy(t),this.b.copy(e),this.c.copy(n),this}setFromPointsAndIndices(t,e,n,s){return this.a.copy(t[e]),this.b.copy(t[n]),this.c.copy(t[s]),this}setFromAttributeAndIndices(t,e,n,s){return this.a.fromBufferAttribute(t,e),this.b.fromBufferAttribute(t,n),this.c.fromBufferAttribute(t,s),this}clone(){return new this.constructor().copy(this)}copy(t){return this.a.copy(t.a),this.b.copy(t.b),this.c.copy(t.c),this}getArea(){return ti.subVectors(this.c,this.b),_i.subVectors(this.a,this.b),ti.cross(_i).length()*.5}getMidpoint(t){return t.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(t){return Yn.getNormal(this.a,this.b,this.c,t)}getPlane(t){return t.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(t,e){return Yn.getBarycoord(t,this.a,this.b,this.c,e)}getInterpolation(t,e,n,s,r){return Yn.getInterpolation(t,this.a,this.b,this.c,e,n,s,r)}containsPoint(t){return Yn.containsPoint(t,this.a,this.b,this.c)}isFrontFacing(t){return Yn.isFrontFacing(this.a,this.b,this.c,t)}intersectsBox(t){return t.intersectsTriangle(this)}closestPointToPoint(t,e){const n=this.a,s=this.b,r=this.c;let a,o;As.subVectors(s,n),Cs.subVectors(r,n),zo.subVectors(t,n);const l=As.dot(zo),h=Cs.dot(zo);if(l<=0&&h<=0)return e.copy(n);No.subVectors(t,s);const f=As.dot(No),m=Cs.dot(No);if(f>=0&&m<=f)return e.copy(s);const u=l*m-f*h;if(u<=0&&l>=0&&f<=0)return a=l/(l-f),e.copy(n).addScaledVector(As,a);Fo.subVectors(t,r);const d=As.dot(Fo),c=Cs.dot(Fo);if(c>=0&&d<=c)return e.copy(r);const v=d*h-l*c;if(v<=0&&h>=0&&c<=0)return o=h/(h-c),e.copy(n).addScaledVector(Cs,o);const p=f*c-d*m;if(p<=0&&m-f>=0&&d-c>=0)return c0.subVectors(r,s),o=(m-f)/(m-f+(d-c)),e.copy(s).addScaledVector(c0,o);const x=1/(p+v+u);return a=v*x,o=u*x,e.copy(n).addScaledVector(As,a).addScaledVector(Cs,o)}equals(t){return t.a.equals(this.a)&&t.b.equals(this.b)&&t.c.equals(this.c)}}const Ju={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},Ni={h:0,s:0,l:0},oa={h:0,s:0,l:0};function Ho(i,t,e){return e<0&&(e+=1),e>1&&(e-=1),e<1/6?i+(t-i)*6*e:e<1/2?t:e<2/3?i+(t-i)*6*(2/3-e):i}class Jt{constructor(t,e,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(t,e,n)}set(t,e,n){if(e===void 0&&n===void 0){const s=t;s&&s.isColor?this.copy(s):typeof s=="number"?this.setHex(s):typeof s=="string"&&this.setStyle(s)}else this.setRGB(t,e,n);return this}setScalar(t){return this.r=t,this.g=t,this.b=t,this}setHex(t,e=pn){return t=Math.floor(t),this.r=(t>>16&255)/255,this.g=(t>>8&255)/255,this.b=(t&255)/255,Ie.toWorkingColorSpace(this,e),this}setRGB(t,e,n,s=Ie.workingColorSpace){return this.r=t,this.g=e,this.b=n,Ie.toWorkingColorSpace(this,s),this}setHSL(t,e,n,s=Ie.workingColorSpace){if(t=Cc(t,1),e=un(e,0,1),n=un(n,0,1),e===0)this.r=this.g=this.b=n;else{const r=n<=.5?n*(1+e):n+e-n*e,a=2*n-r;this.r=Ho(a,r,t+1/3),this.g=Ho(a,r,t),this.b=Ho(a,r,t-1/3)}return Ie.toWorkingColorSpace(this,s),this}setStyle(t,e=pn){function n(r){r!==void 0&&parseFloat(r)<1&&console.warn("THREE.Color: Alpha component of "+t+" will be ignored.")}let s;if(s=/^(\w+)\(([^\)]*)\)/.exec(t)){let r;const a=s[1],o=s[2];switch(a){case"rgb":case"rgba":if(r=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(r[4]),this.setRGB(Math.min(255,parseInt(r[1],10))/255,Math.min(255,parseInt(r[2],10))/255,Math.min(255,parseInt(r[3],10))/255,e);if(r=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(r[4]),this.setRGB(Math.min(100,parseInt(r[1],10))/100,Math.min(100,parseInt(r[2],10))/100,Math.min(100,parseInt(r[3],10))/100,e);break;case"hsl":case"hsla":if(r=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(r[4]),this.setHSL(parseFloat(r[1])/360,parseFloat(r[2])/100,parseFloat(r[3])/100,e);break;default:console.warn("THREE.Color: Unknown color model "+t)}}else if(s=/^\#([A-Fa-f\d]+)$/.exec(t)){const r=s[1],a=r.length;if(a===3)return this.setRGB(parseInt(r.charAt(0),16)/15,parseInt(r.charAt(1),16)/15,parseInt(r.charAt(2),16)/15,e);if(a===6)return this.setHex(parseInt(r,16),e);console.warn("THREE.Color: Invalid hex color "+t)}else if(t&&t.length>0)return this.setColorName(t,e);return this}setColorName(t,e=pn){const n=Ju[t.toLowerCase()];return n!==void 0?this.setHex(n,e):console.warn("THREE.Color: Unknown color "+t),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(t){return this.r=t.r,this.g=t.g,this.b=t.b,this}copySRGBToLinear(t){return this.r=er(t.r),this.g=er(t.g),this.b=er(t.b),this}copyLinearToSRGB(t){return this.r=To(t.r),this.g=To(t.g),this.b=To(t.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(t=pn){return Ie.fromWorkingColorSpace(gn.copy(this),t),Math.round(un(gn.r*255,0,255))*65536+Math.round(un(gn.g*255,0,255))*256+Math.round(un(gn.b*255,0,255))}getHexString(t=pn){return("000000"+this.getHex(t).toString(16)).slice(-6)}getHSL(t,e=Ie.workingColorSpace){Ie.fromWorkingColorSpace(gn.copy(this),e);const n=gn.r,s=gn.g,r=gn.b,a=Math.max(n,s,r),o=Math.min(n,s,r);let l,h;const f=(o+a)/2;if(o===a)l=0,h=0;else{const m=a-o;switch(h=f<=.5?m/(a+o):m/(2-a-o),a){case n:l=(s-r)/m+(s<r?6:0);break;case s:l=(r-n)/m+2;break;case r:l=(n-s)/m+4;break}l/=6}return t.h=l,t.s=h,t.l=f,t}getRGB(t,e=Ie.workingColorSpace){return Ie.fromWorkingColorSpace(gn.copy(this),e),t.r=gn.r,t.g=gn.g,t.b=gn.b,t}getStyle(t=pn){Ie.fromWorkingColorSpace(gn.copy(this),t);const e=gn.r,n=gn.g,s=gn.b;return t!==pn?`color(${t} ${e.toFixed(3)} ${n.toFixed(3)} ${s.toFixed(3)})`:`rgb(${Math.round(e*255)},${Math.round(n*255)},${Math.round(s*255)})`}offsetHSL(t,e,n){return this.getHSL(Ni),this.setHSL(Ni.h+t,Ni.s+e,Ni.l+n)}add(t){return this.r+=t.r,this.g+=t.g,this.b+=t.b,this}addColors(t,e){return this.r=t.r+e.r,this.g=t.g+e.g,this.b=t.b+e.b,this}addScalar(t){return this.r+=t,this.g+=t,this.b+=t,this}sub(t){return this.r=Math.max(0,this.r-t.r),this.g=Math.max(0,this.g-t.g),this.b=Math.max(0,this.b-t.b),this}multiply(t){return this.r*=t.r,this.g*=t.g,this.b*=t.b,this}multiplyScalar(t){return this.r*=t,this.g*=t,this.b*=t,this}lerp(t,e){return this.r+=(t.r-this.r)*e,this.g+=(t.g-this.g)*e,this.b+=(t.b-this.b)*e,this}lerpColors(t,e,n){return this.r=t.r+(e.r-t.r)*n,this.g=t.g+(e.g-t.g)*n,this.b=t.b+(e.b-t.b)*n,this}lerpHSL(t,e){this.getHSL(Ni),t.getHSL(oa);const n=kr(Ni.h,oa.h,e),s=kr(Ni.s,oa.s,e),r=kr(Ni.l,oa.l,e);return this.setHSL(n,s,r),this}setFromVector3(t){return this.r=t.x,this.g=t.y,this.b=t.z,this}applyMatrix3(t){const e=this.r,n=this.g,s=this.b,r=t.elements;return this.r=r[0]*e+r[3]*n+r[6]*s,this.g=r[1]*e+r[4]*n+r[7]*s,this.b=r[2]*e+r[5]*n+r[8]*s,this}equals(t){return t.r===this.r&&t.g===this.g&&t.b===this.b}fromArray(t,e=0){return this.r=t[e],this.g=t[e+1],this.b=t[e+2],this}toArray(t=[],e=0){return t[e]=this.r,t[e+1]=this.g,t[e+2]=this.b,t}fromBufferAttribute(t,e){return this.r=t.getX(e),this.g=t.getY(e),this.b=t.getZ(e),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const gn=new Jt;Jt.NAMES=Ju;let Zf=0;class Vi extends dr{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:Zf++}),this.uuid=Ti(),this.name="",this.type="Material",this.blending=hs,this.side=Hi,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=Tl,this.blendDst=El,this.blendEquation=is,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new Jt(0,0,0),this.blendAlpha=0,this.depthFunc=sr,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=Kc,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=_s,this.stencilZFail=_s,this.stencilZPass=_s,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(t){this._alphaTest>0!=t>0&&this.version++,this._alphaTest=t}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(t){if(t!==void 0)for(const e in t){const n=t[e];if(n===void 0){console.warn(`THREE.Material: parameter '${e}' has value of undefined.`);continue}const s=this[e];if(s===void 0){console.warn(`THREE.Material: '${e}' is not a property of THREE.${this.type}.`);continue}s&&s.isColor?s.set(n):s&&s.isVector3&&n&&n.isVector3?s.copy(n):this[e]=n}}toJSON(t){const e=t===void 0||typeof t=="string";e&&(t={textures:{},images:{}});const n={metadata:{version:4.6,type:"Material",generator:"Material.toJSON"}};n.uuid=this.uuid,n.type=this.type,this.name!==""&&(n.name=this.name),this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(t).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(t).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(t).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.dispersion!==void 0&&(n.dispersion=this.dispersion),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(n.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(t).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(t).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(t).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(t).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(t).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(t).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(t).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(t).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(t).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(t).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(t).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(t).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(t).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(t).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(t).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(t).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(t).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(t).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapRotation!==void 0&&(n.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(t).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(t).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(t).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.shadowSide!==null&&(n.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),this.blending!==hs&&(n.blending=this.blending),this.side!==Hi&&(n.side=this.side),this.vertexColors===!0&&(n.vertexColors=!0),this.opacity<1&&(n.opacity=this.opacity),this.transparent===!0&&(n.transparent=!0),this.blendSrc!==Tl&&(n.blendSrc=this.blendSrc),this.blendDst!==El&&(n.blendDst=this.blendDst),this.blendEquation!==is&&(n.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(n.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(n.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(n.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(n.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(n.blendAlpha=this.blendAlpha),this.depthFunc!==sr&&(n.depthFunc=this.depthFunc),this.depthTest===!1&&(n.depthTest=this.depthTest),this.depthWrite===!1&&(n.depthWrite=this.depthWrite),this.colorWrite===!1&&(n.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(n.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==Kc&&(n.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(n.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(n.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==_s&&(n.stencilFail=this.stencilFail),this.stencilZFail!==_s&&(n.stencilZFail=this.stencilZFail),this.stencilZPass!==_s&&(n.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(n.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(n.rotation=this.rotation),this.polygonOffset===!0&&(n.polygonOffset=!0),this.polygonOffsetFactor!==0&&(n.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(n.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(n.linewidth=this.linewidth),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.dithering===!0&&(n.dithering=!0),this.alphaTest>0&&(n.alphaTest=this.alphaTest),this.alphaHash===!0&&(n.alphaHash=!0),this.alphaToCoverage===!0&&(n.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(n.premultipliedAlpha=!0),this.forceSinglePass===!0&&(n.forceSinglePass=!0),this.wireframe===!0&&(n.wireframe=!0),this.wireframeLinewidth>1&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(n.flatShading=!0),this.visible===!1&&(n.visible=!1),this.toneMapped===!1&&(n.toneMapped=!1),this.fog===!1&&(n.fog=!1),Object.keys(this.userData).length>0&&(n.userData=this.userData);function s(r){const a=[];for(const o in r){const l=r[o];delete l.metadata,a.push(l)}return a}if(e){const r=s(t.textures),a=s(t.images);r.length>0&&(n.textures=r),a.length>0&&(n.images=a)}return n}clone(){return new this.constructor().copy(this)}copy(t){this.name=t.name,this.blending=t.blending,this.side=t.side,this.vertexColors=t.vertexColors,this.opacity=t.opacity,this.transparent=t.transparent,this.blendSrc=t.blendSrc,this.blendDst=t.blendDst,this.blendEquation=t.blendEquation,this.blendSrcAlpha=t.blendSrcAlpha,this.blendDstAlpha=t.blendDstAlpha,this.blendEquationAlpha=t.blendEquationAlpha,this.blendColor.copy(t.blendColor),this.blendAlpha=t.blendAlpha,this.depthFunc=t.depthFunc,this.depthTest=t.depthTest,this.depthWrite=t.depthWrite,this.stencilWriteMask=t.stencilWriteMask,this.stencilFunc=t.stencilFunc,this.stencilRef=t.stencilRef,this.stencilFuncMask=t.stencilFuncMask,this.stencilFail=t.stencilFail,this.stencilZFail=t.stencilZFail,this.stencilZPass=t.stencilZPass,this.stencilWrite=t.stencilWrite;const e=t.clippingPlanes;let n=null;if(e!==null){const s=e.length;n=new Array(s);for(let r=0;r!==s;++r)n[r]=e[r].clone()}return this.clippingPlanes=n,this.clipIntersection=t.clipIntersection,this.clipShadows=t.clipShadows,this.shadowSide=t.shadowSide,this.colorWrite=t.colorWrite,this.precision=t.precision,this.polygonOffset=t.polygonOffset,this.polygonOffsetFactor=t.polygonOffsetFactor,this.polygonOffsetUnits=t.polygonOffsetUnits,this.dithering=t.dithering,this.alphaTest=t.alphaTest,this.alphaHash=t.alphaHash,this.alphaToCoverage=t.alphaToCoverage,this.premultipliedAlpha=t.premultipliedAlpha,this.forceSinglePass=t.forceSinglePass,this.visible=t.visible,this.toneMapped=t.toneMapped,this.userData=JSON.parse(JSON.stringify(t.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(t){t===!0&&this.version++}onBuild(){console.warn("Material: onBuild() has been removed.")}}class Bn extends Vi{constructor(t){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new Jt(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new wn,this.combine=Du,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.specularMap=t.specularMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapRotation.copy(t.envMapRotation),this.combine=t.combine,this.reflectivity=t.reflectivity,this.refractionRatio=t.refractionRatio,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.fog=t.fog,this}}const Je=new N,la=new Pt;class Ve{constructor(t,e,n=!1){if(Array.isArray(t))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,this.name="",this.array=t,this.itemSize=e,this.count=t!==void 0?t.length/e:0,this.normalized=n,this.usage=cc,this.updateRanges=[],this.gpuType=fi,this.version=0}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.name=t.name,this.array=new t.array.constructor(t.array),this.itemSize=t.itemSize,this.count=t.count,this.normalized=t.normalized,this.usage=t.usage,this.gpuType=t.gpuType,this}copyAt(t,e,n){t*=this.itemSize,n*=e.itemSize;for(let s=0,r=this.itemSize;s<r;s++)this.array[t+s]=e.array[n+s];return this}copyArray(t){return this.array.set(t),this}applyMatrix3(t){if(this.itemSize===2)for(let e=0,n=this.count;e<n;e++)la.fromBufferAttribute(this,e),la.applyMatrix3(t),this.setXY(e,la.x,la.y);else if(this.itemSize===3)for(let e=0,n=this.count;e<n;e++)Je.fromBufferAttribute(this,e),Je.applyMatrix3(t),this.setXYZ(e,Je.x,Je.y,Je.z);return this}applyMatrix4(t){for(let e=0,n=this.count;e<n;e++)Je.fromBufferAttribute(this,e),Je.applyMatrix4(t),this.setXYZ(e,Je.x,Je.y,Je.z);return this}applyNormalMatrix(t){for(let e=0,n=this.count;e<n;e++)Je.fromBufferAttribute(this,e),Je.applyNormalMatrix(t),this.setXYZ(e,Je.x,Je.y,Je.z);return this}transformDirection(t){for(let e=0,n=this.count;e<n;e++)Je.fromBufferAttribute(this,e),Je.transformDirection(t),this.setXYZ(e,Je.x,Je.y,Je.z);return this}set(t,e=0){return this.array.set(t,e),this}getComponent(t,e){let n=this.array[t*this.itemSize+e];return this.normalized&&(n=si(n,this.array)),n}setComponent(t,e,n){return this.normalized&&(n=Le(n,this.array)),this.array[t*this.itemSize+e]=n,this}getX(t){let e=this.array[t*this.itemSize];return this.normalized&&(e=si(e,this.array)),e}setX(t,e){return this.normalized&&(e=Le(e,this.array)),this.array[t*this.itemSize]=e,this}getY(t){let e=this.array[t*this.itemSize+1];return this.normalized&&(e=si(e,this.array)),e}setY(t,e){return this.normalized&&(e=Le(e,this.array)),this.array[t*this.itemSize+1]=e,this}getZ(t){let e=this.array[t*this.itemSize+2];return this.normalized&&(e=si(e,this.array)),e}setZ(t,e){return this.normalized&&(e=Le(e,this.array)),this.array[t*this.itemSize+2]=e,this}getW(t){let e=this.array[t*this.itemSize+3];return this.normalized&&(e=si(e,this.array)),e}setW(t,e){return this.normalized&&(e=Le(e,this.array)),this.array[t*this.itemSize+3]=e,this}setXY(t,e,n){return t*=this.itemSize,this.normalized&&(e=Le(e,this.array),n=Le(n,this.array)),this.array[t+0]=e,this.array[t+1]=n,this}setXYZ(t,e,n,s){return t*=this.itemSize,this.normalized&&(e=Le(e,this.array),n=Le(n,this.array),s=Le(s,this.array)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=s,this}setXYZW(t,e,n,s,r){return t*=this.itemSize,this.normalized&&(e=Le(e,this.array),n=Le(n,this.array),s=Le(s,this.array),r=Le(r,this.array)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=s,this.array[t+3]=r,this}onUpload(t){return this.onUploadCallback=t,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const t={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(t.name=this.name),this.usage!==cc&&(t.usage=this.usage),t}}class Qu extends Ve{constructor(t,e,n){super(new Uint16Array(t),e,n)}}class th extends Ve{constructor(t,e,n){super(new Uint32Array(t),e,n)}}class Ce extends Ve{constructor(t,e,n){super(new Float32Array(t),e,n)}}let jf=0;const Gn=new Pe,Go=new Ze,Rs=new N,zn=new ms,Sr=new ms,rn=new N;class Ye extends dr{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:jf++}),this.uuid=Ti(),this.name="",this.type="BufferGeometry",this.index=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(t){return Array.isArray(t)?this.index=new(Ku(t)?th:Qu)(t,1):this.index=t,this}getAttribute(t){return this.attributes[t]}setAttribute(t,e){return this.attributes[t]=e,this}deleteAttribute(t){return delete this.attributes[t],this}hasAttribute(t){return this.attributes[t]!==void 0}addGroup(t,e,n=0){this.groups.push({start:t,count:e,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(t,e){this.drawRange.start=t,this.drawRange.count=e}applyMatrix4(t){const e=this.attributes.position;e!==void 0&&(e.applyMatrix4(t),e.needsUpdate=!0);const n=this.attributes.normal;if(n!==void 0){const r=new Se().getNormalMatrix(t);n.applyNormalMatrix(r),n.needsUpdate=!0}const s=this.attributes.tangent;return s!==void 0&&(s.transformDirection(t),s.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(t){return Gn.makeRotationFromQuaternion(t),this.applyMatrix4(Gn),this}rotateX(t){return Gn.makeRotationX(t),this.applyMatrix4(Gn),this}rotateY(t){return Gn.makeRotationY(t),this.applyMatrix4(Gn),this}rotateZ(t){return Gn.makeRotationZ(t),this.applyMatrix4(Gn),this}translate(t,e,n){return Gn.makeTranslation(t,e,n),this.applyMatrix4(Gn),this}scale(t,e,n){return Gn.makeScale(t,e,n),this.applyMatrix4(Gn),this}lookAt(t){return Go.lookAt(t),Go.updateMatrix(),this.applyMatrix4(Go.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Rs).negate(),this.translate(Rs.x,Rs.y,Rs.z),this}setFromPoints(t){const e=[];for(let n=0,s=t.length;n<s;n++){const r=t[n];e.push(r.x,r.y,r.z||0)}return this.setAttribute("position",new Ce(e,3)),this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new ms);const t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new N(-1/0,-1/0,-1/0),new N(1/0,1/0,1/0));return}if(t!==void 0){if(this.boundingBox.setFromBufferAttribute(t),e)for(let n=0,s=e.length;n<s;n++){const r=e[n];zn.setFromBufferAttribute(r),this.morphTargetsRelative?(rn.addVectors(this.boundingBox.min,zn.min),this.boundingBox.expandByPoint(rn),rn.addVectors(this.boundingBox.max,zn.max),this.boundingBox.expandByPoint(rn)):(this.boundingBox.expandByPoint(zn.min),this.boundingBox.expandByPoint(zn.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new Kn);const t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new N,1/0);return}if(t){const n=this.boundingSphere.center;if(zn.setFromBufferAttribute(t),e)for(let r=0,a=e.length;r<a;r++){const o=e[r];Sr.setFromBufferAttribute(o),this.morphTargetsRelative?(rn.addVectors(zn.min,Sr.min),zn.expandByPoint(rn),rn.addVectors(zn.max,Sr.max),zn.expandByPoint(rn)):(zn.expandByPoint(Sr.min),zn.expandByPoint(Sr.max))}zn.getCenter(n);let s=0;for(let r=0,a=t.count;r<a;r++)rn.fromBufferAttribute(t,r),s=Math.max(s,n.distanceToSquared(rn));if(e)for(let r=0,a=e.length;r<a;r++){const o=e[r],l=this.morphTargetsRelative;for(let h=0,f=o.count;h<f;h++)rn.fromBufferAttribute(o,h),l&&(Rs.fromBufferAttribute(t,h),rn.add(Rs)),s=Math.max(s,n.distanceToSquared(rn))}this.boundingSphere.radius=Math.sqrt(s),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const t=this.index,e=this.attributes;if(t===null||e.position===void 0||e.normal===void 0||e.uv===void 0){console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const n=e.position,s=e.normal,r=e.uv;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new Ve(new Float32Array(4*n.count),4));const a=this.getAttribute("tangent"),o=[],l=[];for(let y=0;y<n.count;y++)o[y]=new N,l[y]=new N;const h=new N,f=new N,m=new N,u=new Pt,d=new Pt,c=new Pt,v=new N,p=new N;function x(y,rt,S){h.fromBufferAttribute(n,y),f.fromBufferAttribute(n,rt),m.fromBufferAttribute(n,S),u.fromBufferAttribute(r,y),d.fromBufferAttribute(r,rt),c.fromBufferAttribute(r,S),f.sub(h),m.sub(h),d.sub(u),c.sub(u);const z=1/(d.x*c.y-c.x*d.y);isFinite(z)&&(v.copy(f).multiplyScalar(c.y).addScaledVector(m,-d.y).multiplyScalar(z),p.copy(m).multiplyScalar(d.x).addScaledVector(f,-c.x).multiplyScalar(z),o[y].add(v),o[rt].add(v),o[S].add(v),l[y].add(p),l[rt].add(p),l[S].add(p))}let w=this.groups;w.length===0&&(w=[{start:0,count:t.count}]);for(let y=0,rt=w.length;y<rt;++y){const S=w[y],z=S.start,nt=S.count;for(let q=z,j=z+nt;q<j;q+=3)x(t.getX(q+0),t.getX(q+1),t.getX(q+2))}const b=new N,C=new N,V=new N,D=new N;function A(y){V.fromBufferAttribute(s,y),D.copy(V);const rt=o[y];b.copy(rt),b.sub(V.multiplyScalar(V.dot(rt))).normalize(),C.crossVectors(D,rt);const z=C.dot(l[y])<0?-1:1;a.setXYZW(y,b.x,b.y,b.z,z)}for(let y=0,rt=w.length;y<rt;++y){const S=w[y],z=S.start,nt=S.count;for(let q=z,j=z+nt;q<j;q+=3)A(t.getX(q+0)),A(t.getX(q+1)),A(t.getX(q+2))}}computeVertexNormals(){const t=this.index,e=this.getAttribute("position");if(e!==void 0){let n=this.getAttribute("normal");if(n===void 0)n=new Ve(new Float32Array(e.count*3),3),this.setAttribute("normal",n);else for(let u=0,d=n.count;u<d;u++)n.setXYZ(u,0,0,0);const s=new N,r=new N,a=new N,o=new N,l=new N,h=new N,f=new N,m=new N;if(t)for(let u=0,d=t.count;u<d;u+=3){const c=t.getX(u+0),v=t.getX(u+1),p=t.getX(u+2);s.fromBufferAttribute(e,c),r.fromBufferAttribute(e,v),a.fromBufferAttribute(e,p),f.subVectors(a,r),m.subVectors(s,r),f.cross(m),o.fromBufferAttribute(n,c),l.fromBufferAttribute(n,v),h.fromBufferAttribute(n,p),o.add(f),l.add(f),h.add(f),n.setXYZ(c,o.x,o.y,o.z),n.setXYZ(v,l.x,l.y,l.z),n.setXYZ(p,h.x,h.y,h.z)}else for(let u=0,d=e.count;u<d;u+=3)s.fromBufferAttribute(e,u+0),r.fromBufferAttribute(e,u+1),a.fromBufferAttribute(e,u+2),f.subVectors(a,r),m.subVectors(s,r),f.cross(m),n.setXYZ(u+0,f.x,f.y,f.z),n.setXYZ(u+1,f.x,f.y,f.z),n.setXYZ(u+2,f.x,f.y,f.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){const t=this.attributes.normal;for(let e=0,n=t.count;e<n;e++)rn.fromBufferAttribute(t,e),rn.normalize(),t.setXYZ(e,rn.x,rn.y,rn.z)}toNonIndexed(){function t(o,l){const h=o.array,f=o.itemSize,m=o.normalized,u=new h.constructor(l.length*f);let d=0,c=0;for(let v=0,p=l.length;v<p;v++){o.isInterleavedBufferAttribute?d=l[v]*o.data.stride+o.offset:d=l[v]*f;for(let x=0;x<f;x++)u[c++]=h[d++]}return new Ve(u,f,m)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const e=new Ye,n=this.index.array,s=this.attributes;for(const o in s){const l=s[o],h=t(l,n);e.setAttribute(o,h)}const r=this.morphAttributes;for(const o in r){const l=[],h=r[o];for(let f=0,m=h.length;f<m;f++){const u=h[f],d=t(u,n);l.push(d)}e.morphAttributes[o]=l}e.morphTargetsRelative=this.morphTargetsRelative;const a=this.groups;for(let o=0,l=a.length;o<l;o++){const h=a[o];e.addGroup(h.start,h.count,h.materialIndex)}return e}toJSON(){const t={metadata:{version:4.6,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(t.uuid=this.uuid,t.type=this.type,this.name!==""&&(t.name=this.name),Object.keys(this.userData).length>0&&(t.userData=this.userData),this.parameters!==void 0){const l=this.parameters;for(const h in l)l[h]!==void 0&&(t[h]=l[h]);return t}t.data={attributes:{}};const e=this.index;e!==null&&(t.data.index={type:e.array.constructor.name,array:Array.prototype.slice.call(e.array)});const n=this.attributes;for(const l in n){const h=n[l];t.data.attributes[l]=h.toJSON(t.data)}const s={};let r=!1;for(const l in this.morphAttributes){const h=this.morphAttributes[l],f=[];for(let m=0,u=h.length;m<u;m++){const d=h[m];f.push(d.toJSON(t.data))}f.length>0&&(s[l]=f,r=!0)}r&&(t.data.morphAttributes=s,t.data.morphTargetsRelative=this.morphTargetsRelative);const a=this.groups;a.length>0&&(t.data.groups=JSON.parse(JSON.stringify(a)));const o=this.boundingSphere;return o!==null&&(t.data.boundingSphere={center:o.center.toArray(),radius:o.radius}),t}clone(){return new this.constructor().copy(this)}copy(t){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const e={};this.name=t.name;const n=t.index;n!==null&&this.setIndex(n.clone(e));const s=t.attributes;for(const h in s){const f=s[h];this.setAttribute(h,f.clone(e))}const r=t.morphAttributes;for(const h in r){const f=[],m=r[h];for(let u=0,d=m.length;u<d;u++)f.push(m[u].clone(e));this.morphAttributes[h]=f}this.morphTargetsRelative=t.morphTargetsRelative;const a=t.groups;for(let h=0,f=a.length;h<f;h++){const m=a[h];this.addGroup(m.start,m.count,m.materialIndex)}const o=t.boundingBox;o!==null&&(this.boundingBox=o.clone());const l=t.boundingSphere;return l!==null&&(this.boundingSphere=l.clone()),this.drawRange.start=t.drawRange.start,this.drawRange.count=t.drawRange.count,this.userData=t.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}}const u0=new Pe,$i=new vo,ca=new Kn,h0=new N,ua=new N,ha=new N,fa=new N,Vo=new N,da=new N,f0=new N,pa=new N;class K extends Ze{constructor(t=new Ye,e=new Bn){super(),this.isMesh=!0,this.type="Mesh",this.geometry=t,this.material=e,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),t.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=t.morphTargetInfluences.slice()),t.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},t.morphTargetDictionary)),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}updateMorphTargets(){const e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){const s=e[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,a=s.length;r<a;r++){const o=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=r}}}}getVertexPosition(t,e){const n=this.geometry,s=n.attributes.position,r=n.morphAttributes.position,a=n.morphTargetsRelative;e.fromBufferAttribute(s,t);const o=this.morphTargetInfluences;if(r&&o){da.set(0,0,0);for(let l=0,h=r.length;l<h;l++){const f=o[l],m=r[l];f!==0&&(Vo.fromBufferAttribute(m,t),a?da.addScaledVector(Vo,f):da.addScaledVector(Vo.sub(e),f))}e.add(da)}return e}raycast(t,e){const n=this.geometry,s=this.material,r=this.matrixWorld;s!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),ca.copy(n.boundingSphere),ca.applyMatrix4(r),$i.copy(t.ray).recast(t.near),!(ca.containsPoint($i.origin)===!1&&($i.intersectSphere(ca,h0)===null||$i.origin.distanceToSquared(h0)>(t.far-t.near)**2))&&(u0.copy(r).invert(),$i.copy(t.ray).applyMatrix4(u0),!(n.boundingBox!==null&&$i.intersectsBox(n.boundingBox)===!1)&&this._computeIntersections(t,e,$i)))}_computeIntersections(t,e,n){let s;const r=this.geometry,a=this.material,o=r.index,l=r.attributes.position,h=r.attributes.uv,f=r.attributes.uv1,m=r.attributes.normal,u=r.groups,d=r.drawRange;if(o!==null)if(Array.isArray(a))for(let c=0,v=u.length;c<v;c++){const p=u[c],x=a[p.materialIndex],w=Math.max(p.start,d.start),b=Math.min(o.count,Math.min(p.start+p.count,d.start+d.count));for(let C=w,V=b;C<V;C+=3){const D=o.getX(C),A=o.getX(C+1),y=o.getX(C+2);s=ma(this,x,t,n,h,f,m,D,A,y),s&&(s.faceIndex=Math.floor(C/3),s.face.materialIndex=p.materialIndex,e.push(s))}}else{const c=Math.max(0,d.start),v=Math.min(o.count,d.start+d.count);for(let p=c,x=v;p<x;p+=3){const w=o.getX(p),b=o.getX(p+1),C=o.getX(p+2);s=ma(this,a,t,n,h,f,m,w,b,C),s&&(s.faceIndex=Math.floor(p/3),e.push(s))}}else if(l!==void 0)if(Array.isArray(a))for(let c=0,v=u.length;c<v;c++){const p=u[c],x=a[p.materialIndex],w=Math.max(p.start,d.start),b=Math.min(l.count,Math.min(p.start+p.count,d.start+d.count));for(let C=w,V=b;C<V;C+=3){const D=C,A=C+1,y=C+2;s=ma(this,x,t,n,h,f,m,D,A,y),s&&(s.faceIndex=Math.floor(C/3),s.face.materialIndex=p.materialIndex,e.push(s))}}else{const c=Math.max(0,d.start),v=Math.min(l.count,d.start+d.count);for(let p=c,x=v;p<x;p+=3){const w=p,b=p+1,C=p+2;s=ma(this,a,t,n,h,f,m,w,b,C),s&&(s.faceIndex=Math.floor(p/3),e.push(s))}}}}function Jf(i,t,e,n,s,r,a,o){let l;if(t.side===fn?l=n.intersectTriangle(a,r,s,!0,o):l=n.intersectTriangle(s,r,a,t.side===Hi,o),l===null)return null;pa.copy(o),pa.applyMatrix4(i.matrixWorld);const h=e.ray.origin.distanceTo(pa);return h<e.near||h>e.far?null:{distance:h,point:pa.clone(),object:i}}function ma(i,t,e,n,s,r,a,o,l,h){i.getVertexPosition(o,ua),i.getVertexPosition(l,ha),i.getVertexPosition(h,fa);const f=Jf(i,t,e,n,ua,ha,fa,f0);if(f){const m=new N;Yn.getBarycoord(f0,ua,ha,fa,m),s&&(f.uv=Yn.getInterpolatedAttribute(s,o,l,h,m,new Pt)),r&&(f.uv1=Yn.getInterpolatedAttribute(r,o,l,h,m,new Pt)),a&&(f.normal=Yn.getInterpolatedAttribute(a,o,l,h,m,new N),f.normal.dot(n.direction)>0&&f.normal.multiplyScalar(-1));const u={a:o,b:l,c:h,normal:new N,materialIndex:0};Yn.getNormal(ua,ha,fa,u.normal),f.face=u,f.barycoord=m}return f}class Rt extends Ye{constructor(t=1,e=1,n=1,s=1,r=1,a=1){super(),this.type="BoxGeometry",this.parameters={width:t,height:e,depth:n,widthSegments:s,heightSegments:r,depthSegments:a};const o=this;s=Math.floor(s),r=Math.floor(r),a=Math.floor(a);const l=[],h=[],f=[],m=[];let u=0,d=0;c("z","y","x",-1,-1,n,e,t,a,r,0),c("z","y","x",1,-1,n,e,-t,a,r,1),c("x","z","y",1,1,t,n,e,s,a,2),c("x","z","y",1,-1,t,n,-e,s,a,3),c("x","y","z",1,-1,t,e,n,s,r,4),c("x","y","z",-1,-1,t,e,-n,s,r,5),this.setIndex(l),this.setAttribute("position",new Ce(h,3)),this.setAttribute("normal",new Ce(f,3)),this.setAttribute("uv",new Ce(m,2));function c(v,p,x,w,b,C,V,D,A,y,rt){const S=C/A,z=V/y,nt=C/2,q=V/2,j=D/2,Y=A+1,W=y+1;let ht=0,lt=0;const Dt=new N;for(let yt=0;yt<W;yt++){const dt=yt*z-q;for(let et=0;et<Y;et++){const Lt=et*S-nt;Dt[v]=Lt*w,Dt[p]=dt*b,Dt[x]=j,h.push(Dt.x,Dt.y,Dt.z),Dt[v]=0,Dt[p]=0,Dt[x]=D>0?1:-1,f.push(Dt.x,Dt.y,Dt.z),m.push(et/A),m.push(1-yt/y),ht+=1}}for(let yt=0;yt<y;yt++)for(let dt=0;dt<A;dt++){const et=u+dt+Y*yt,Lt=u+dt+Y*(yt+1),k=u+(dt+1)+Y*(yt+1),at=u+(dt+1)+Y*yt;l.push(et,Lt,at),l.push(Lt,k,at),lt+=6}o.addGroup(d,lt,rt),d+=lt,u+=ht}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Rt(t.width,t.height,t.depth,t.widthSegments,t.heightSegments,t.depthSegments)}}function cr(i){const t={};for(const e in i){t[e]={};for(const n in i[e]){const s=i[e][n];s&&(s.isColor||s.isMatrix3||s.isMatrix4||s.isVector2||s.isVector3||s.isVector4||s.isTexture||s.isQuaternion)?s.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),t[e][n]=null):t[e][n]=s.clone():Array.isArray(s)?t[e][n]=s.slice():t[e][n]=s}}return t}function Sn(i){const t={};for(let e=0;e<i.length;e++){const n=cr(i[e]);for(const s in n)t[s]=n[s]}return t}function Qf(i){const t=[];for(let e=0;e<i.length;e++)t.push(i[e].clone());return t}function eh(i){const t=i.getRenderTarget();return t===null?i.outputColorSpace:t.isXRRenderTarget===!0?t.texture.colorSpace:Ie.workingColorSpace}const Yr={clone:cr,merge:Sn};var td=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,ed=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class Ke extends Vi{constructor(t){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=td,this.fragmentShader=ed,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,t!==void 0&&this.setValues(t)}copy(t){return super.copy(t),this.fragmentShader=t.fragmentShader,this.vertexShader=t.vertexShader,this.uniforms=cr(t.uniforms),this.uniformsGroups=Qf(t.uniformsGroups),this.defines=Object.assign({},t.defines),this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.fog=t.fog,this.lights=t.lights,this.clipping=t.clipping,this.extensions=Object.assign({},t.extensions),this.glslVersion=t.glslVersion,this}toJSON(t){const e=super.toJSON(t);e.glslVersion=this.glslVersion,e.uniforms={};for(const s in this.uniforms){const a=this.uniforms[s].value;a&&a.isTexture?e.uniforms[s]={type:"t",value:a.toJSON(t).uuid}:a&&a.isColor?e.uniforms[s]={type:"c",value:a.getHex()}:a&&a.isVector2?e.uniforms[s]={type:"v2",value:a.toArray()}:a&&a.isVector3?e.uniforms[s]={type:"v3",value:a.toArray()}:a&&a.isVector4?e.uniforms[s]={type:"v4",value:a.toArray()}:a&&a.isMatrix3?e.uniforms[s]={type:"m3",value:a.toArray()}:a&&a.isMatrix4?e.uniforms[s]={type:"m4",value:a.toArray()}:e.uniforms[s]={value:a}}Object.keys(this.defines).length>0&&(e.defines=this.defines),e.vertexShader=this.vertexShader,e.fragmentShader=this.fragmentShader,e.lights=this.lights,e.clipping=this.clipping;const n={};for(const s in this.extensions)this.extensions[s]===!0&&(n[s]=!0);return Object.keys(n).length>0&&(e.extensions=n),e}}class nh extends Ze{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new Pe,this.projectionMatrix=new Pe,this.projectionMatrixInverse=new Pe,this.coordinateSystem=wi}copy(t,e){return super.copy(t,e),this.matrixWorldInverse.copy(t.matrixWorldInverse),this.projectionMatrix.copy(t.projectionMatrix),this.projectionMatrixInverse.copy(t.projectionMatrixInverse),this.coordinateSystem=t.coordinateSystem,this}getWorldDirection(t){return super.getWorldDirection(t).negate()}updateMatrixWorld(t){super.updateMatrixWorld(t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(t,e){super.updateWorldMatrix(t,e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}}const Fi=new N,d0=new Pt,p0=new Pt;class Pn extends nh{constructor(t=50,e=1,n=.1,s=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=t,this.zoom=1,this.near=n,this.far=s,this.focus=10,this.aspect=e,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.fov=t.fov,this.zoom=t.zoom,this.near=t.near,this.far=t.far,this.focus=t.focus,this.aspect=t.aspect,this.view=t.view===null?null:Object.assign({},t.view),this.filmGauge=t.filmGauge,this.filmOffset=t.filmOffset,this}setFocalLength(t){const e=.5*this.getFilmHeight()/t;this.fov=qr*2*Math.atan(e),this.updateProjectionMatrix()}getFocalLength(){const t=Math.tan(Br*.5*this.fov);return .5*this.getFilmHeight()/t}getEffectiveFOV(){return qr*2*Math.atan(Math.tan(Br*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(t,e,n){Fi.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),e.set(Fi.x,Fi.y).multiplyScalar(-t/Fi.z),Fi.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(Fi.x,Fi.y).multiplyScalar(-t/Fi.z)}getViewSize(t,e){return this.getViewBounds(t,d0,p0),e.subVectors(p0,d0)}setViewOffset(t,e,n,s,r,a){this.aspect=t/e,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=n,this.view.offsetY=s,this.view.width=r,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const t=this.near;let e=t*Math.tan(Br*.5*this.fov)/this.zoom,n=2*e,s=this.aspect*n,r=-.5*s;const a=this.view;if(this.view!==null&&this.view.enabled){const l=a.fullWidth,h=a.fullHeight;r+=a.offsetX*s/l,e-=a.offsetY*n/h,s*=a.width/l,n*=a.height/h}const o=this.filmOffset;o!==0&&(r+=t*o/this.getFilmWidth()),this.projectionMatrix.makePerspective(r,r+s,e,e-n,t,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){const e=super.toJSON(t);return e.object.fov=this.fov,e.object.zoom=this.zoom,e.object.near=this.near,e.object.far=this.far,e.object.focus=this.focus,e.object.aspect=this.aspect,this.view!==null&&(e.object.view=Object.assign({},this.view)),e.object.filmGauge=this.filmGauge,e.object.filmOffset=this.filmOffset,e}}const Ps=-90,Ds=1;class nd extends Ze{constructor(t,e,n){super(),this.type="CubeCamera",this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;const s=new Pn(Ps,Ds,t,e);s.layers=this.layers,this.add(s);const r=new Pn(Ps,Ds,t,e);r.layers=this.layers,this.add(r);const a=new Pn(Ps,Ds,t,e);a.layers=this.layers,this.add(a);const o=new Pn(Ps,Ds,t,e);o.layers=this.layers,this.add(o);const l=new Pn(Ps,Ds,t,e);l.layers=this.layers,this.add(l);const h=new Pn(Ps,Ds,t,e);h.layers=this.layers,this.add(h)}updateCoordinateSystem(){const t=this.coordinateSystem,e=this.children.concat(),[n,s,r,a,o,l]=e;for(const h of e)this.remove(h);if(t===wi)n.up.set(0,1,0),n.lookAt(1,0,0),s.up.set(0,1,0),s.lookAt(-1,0,0),r.up.set(0,0,-1),r.lookAt(0,1,0),a.up.set(0,0,1),a.lookAt(0,-1,0),o.up.set(0,1,0),o.lookAt(0,0,1),l.up.set(0,1,0),l.lookAt(0,0,-1);else if(t===eo)n.up.set(0,-1,0),n.lookAt(-1,0,0),s.up.set(0,-1,0),s.lookAt(1,0,0),r.up.set(0,0,1),r.lookAt(0,1,0),a.up.set(0,0,-1),a.lookAt(0,-1,0),o.up.set(0,-1,0),o.lookAt(0,0,1),l.up.set(0,-1,0),l.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+t);for(const h of e)this.add(h),h.updateMatrixWorld()}update(t,e){this.parent===null&&this.updateMatrixWorld();const{renderTarget:n,activeMipmapLevel:s}=this;this.coordinateSystem!==t.coordinateSystem&&(this.coordinateSystem=t.coordinateSystem,this.updateCoordinateSystem());const[r,a,o,l,h,f]=this.children,m=t.getRenderTarget(),u=t.getActiveCubeFace(),d=t.getActiveMipmapLevel(),c=t.xr.enabled;t.xr.enabled=!1;const v=n.texture.generateMipmaps;n.texture.generateMipmaps=!1,t.setRenderTarget(n,0,s),t.render(e,r),t.setRenderTarget(n,1,s),t.render(e,a),t.setRenderTarget(n,2,s),t.render(e,o),t.setRenderTarget(n,3,s),t.render(e,l),t.setRenderTarget(n,4,s),t.render(e,h),n.texture.generateMipmaps=v,t.setRenderTarget(n,5,s),t.render(e,f),t.setRenderTarget(m,u,d),t.xr.enabled=c,n.texture.needsPMREMUpdate=!0}}class ih extends vn{constructor(t,e,n,s,r,a,o,l,h,f){t=t!==void 0?t:[],e=e!==void 0?e:rr,super(t,e,n,s,r,a,o,l,h,f),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(t){this.image=t}}class id extends $n{constructor(t=1,e={}){super(t,t,e),this.isWebGLCubeRenderTarget=!0;const n={width:t,height:t,depth:1},s=[n,n,n,n,n,n];this.texture=new ih(s,e.mapping,e.wrapS,e.wrapT,e.magFilter,e.minFilter,e.format,e.type,e.anisotropy,e.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.generateMipmaps=e.generateMipmaps!==void 0?e.generateMipmaps:!1,this.texture.minFilter=e.minFilter!==void 0?e.minFilter:Fn}fromEquirectangularTexture(t,e){this.texture.type=e.type,this.texture.colorSpace=e.colorSpace,this.texture.generateMipmaps=e.generateMipmaps,this.texture.minFilter=e.minFilter,this.texture.magFilter=e.magFilter;const n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},s=new Rt(5,5,5),r=new Ke({name:"CubemapFromEquirect",uniforms:cr(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:fn,blending:bi});r.uniforms.tEquirect.value=e;const a=new K(s,r),o=e.minFilter;return e.minFilter===cs&&(e.minFilter=Fn),new nd(1,10,this).update(t,a),e.minFilter=o,a.geometry.dispose(),a.material.dispose(),this}clear(t,e,n,s){const r=t.getRenderTarget();for(let a=0;a<6;a++)t.setRenderTarget(this,a),t.clear(e,n,s);t.setRenderTarget(r)}}const Wo=new N,sd=new N,rd=new Se;class ts{constructor(t=new N(1,0,0),e=0){this.isPlane=!0,this.normal=t,this.constant=e}set(t,e){return this.normal.copy(t),this.constant=e,this}setComponents(t,e,n,s){return this.normal.set(t,e,n),this.constant=s,this}setFromNormalAndCoplanarPoint(t,e){return this.normal.copy(t),this.constant=-e.dot(this.normal),this}setFromCoplanarPoints(t,e,n){const s=Wo.subVectors(n,e).cross(sd.subVectors(t,e)).normalize();return this.setFromNormalAndCoplanarPoint(s,t),this}copy(t){return this.normal.copy(t.normal),this.constant=t.constant,this}normalize(){const t=1/this.normal.length();return this.normal.multiplyScalar(t),this.constant*=t,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(t){return this.normal.dot(t)+this.constant}distanceToSphere(t){return this.distanceToPoint(t.center)-t.radius}projectPoint(t,e){return e.copy(t).addScaledVector(this.normal,-this.distanceToPoint(t))}intersectLine(t,e){const n=t.delta(Wo),s=this.normal.dot(n);if(s===0)return this.distanceToPoint(t.start)===0?e.copy(t.start):null;const r=-(t.start.dot(this.normal)+this.constant)/s;return r<0||r>1?null:e.copy(t.start).addScaledVector(n,r)}intersectsLine(t){const e=this.distanceToPoint(t.start),n=this.distanceToPoint(t.end);return e<0&&n>0||n<0&&e>0}intersectsBox(t){return t.intersectsPlane(this)}intersectsSphere(t){return t.intersectsPlane(this)}coplanarPoint(t){return t.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(t,e){const n=e||rd.getNormalMatrix(t),s=this.coplanarPoint(Wo).applyMatrix4(t),r=this.normal.applyMatrix3(n).normalize();return this.constant=-s.dot(r),this}translate(t){return this.constant-=t.dot(this.normal),this}equals(t){return t.normal.equals(this.normal)&&t.constant===this.constant}clone(){return new this.constructor().copy(this)}}const Ki=new Kn,ga=new N;class Pc{constructor(t=new ts,e=new ts,n=new ts,s=new ts,r=new ts,a=new ts){this.planes=[t,e,n,s,r,a]}set(t,e,n,s,r,a){const o=this.planes;return o[0].copy(t),o[1].copy(e),o[2].copy(n),o[3].copy(s),o[4].copy(r),o[5].copy(a),this}copy(t){const e=this.planes;for(let n=0;n<6;n++)e[n].copy(t.planes[n]);return this}setFromProjectionMatrix(t,e=wi){const n=this.planes,s=t.elements,r=s[0],a=s[1],o=s[2],l=s[3],h=s[4],f=s[5],m=s[6],u=s[7],d=s[8],c=s[9],v=s[10],p=s[11],x=s[12],w=s[13],b=s[14],C=s[15];if(n[0].setComponents(l-r,u-h,p-d,C-x).normalize(),n[1].setComponents(l+r,u+h,p+d,C+x).normalize(),n[2].setComponents(l+a,u+f,p+c,C+w).normalize(),n[3].setComponents(l-a,u-f,p-c,C-w).normalize(),n[4].setComponents(l-o,u-m,p-v,C-b).normalize(),e===wi)n[5].setComponents(l+o,u+m,p+v,C+b).normalize();else if(e===eo)n[5].setComponents(o,m,v,b).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+e);return this}intersectsObject(t){if(t.boundingSphere!==void 0)t.boundingSphere===null&&t.computeBoundingSphere(),Ki.copy(t.boundingSphere).applyMatrix4(t.matrixWorld);else{const e=t.geometry;e.boundingSphere===null&&e.computeBoundingSphere(),Ki.copy(e.boundingSphere).applyMatrix4(t.matrixWorld)}return this.intersectsSphere(Ki)}intersectsSprite(t){return Ki.center.set(0,0,0),Ki.radius=.7071067811865476,Ki.applyMatrix4(t.matrixWorld),this.intersectsSphere(Ki)}intersectsSphere(t){const e=this.planes,n=t.center,s=-t.radius;for(let r=0;r<6;r++)if(e[r].distanceToPoint(n)<s)return!1;return!0}intersectsBox(t){const e=this.planes;for(let n=0;n<6;n++){const s=e[n];if(ga.x=s.normal.x>0?t.max.x:t.min.x,ga.y=s.normal.y>0?t.max.y:t.min.y,ga.z=s.normal.z>0?t.max.z:t.min.z,s.distanceToPoint(ga)<0)return!1}return!0}containsPoint(t){const e=this.planes;for(let n=0;n<6;n++)if(e[n].distanceToPoint(t)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}function sh(){let i=null,t=!1,e=null,n=null;function s(r,a){e(r,a),n=i.requestAnimationFrame(s)}return{start:function(){t!==!0&&e!==null&&(n=i.requestAnimationFrame(s),t=!0)},stop:function(){i.cancelAnimationFrame(n),t=!1},setAnimationLoop:function(r){e=r},setContext:function(r){i=r}}}function ad(i){const t=new WeakMap;function e(o,l){const h=o.array,f=o.usage,m=h.byteLength,u=i.createBuffer();i.bindBuffer(l,u),i.bufferData(l,h,f),o.onUploadCallback();let d;if(h instanceof Float32Array)d=i.FLOAT;else if(h instanceof Uint16Array)o.isFloat16BufferAttribute?d=i.HALF_FLOAT:d=i.UNSIGNED_SHORT;else if(h instanceof Int16Array)d=i.SHORT;else if(h instanceof Uint32Array)d=i.UNSIGNED_INT;else if(h instanceof Int32Array)d=i.INT;else if(h instanceof Int8Array)d=i.BYTE;else if(h instanceof Uint8Array)d=i.UNSIGNED_BYTE;else if(h instanceof Uint8ClampedArray)d=i.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+h);return{buffer:u,type:d,bytesPerElement:h.BYTES_PER_ELEMENT,version:o.version,size:m}}function n(o,l,h){const f=l.array,m=l.updateRanges;if(i.bindBuffer(h,o),m.length===0)i.bufferSubData(h,0,f);else{m.sort((d,c)=>d.start-c.start);let u=0;for(let d=1;d<m.length;d++){const c=m[u],v=m[d];v.start<=c.start+c.count+1?c.count=Math.max(c.count,v.start+v.count-c.start):(++u,m[u]=v)}m.length=u+1;for(let d=0,c=m.length;d<c;d++){const v=m[d];i.bufferSubData(h,v.start*f.BYTES_PER_ELEMENT,f,v.start,v.count)}l.clearUpdateRanges()}l.onUploadCallback()}function s(o){return o.isInterleavedBufferAttribute&&(o=o.data),t.get(o)}function r(o){o.isInterleavedBufferAttribute&&(o=o.data);const l=t.get(o);l&&(i.deleteBuffer(l.buffer),t.delete(o))}function a(o,l){if(o.isInterleavedBufferAttribute&&(o=o.data),o.isGLBufferAttribute){const f=t.get(o);(!f||f.version<o.version)&&t.set(o,{buffer:o.buffer,type:o.type,bytesPerElement:o.elementSize,version:o.version});return}const h=t.get(o);if(h===void 0)t.set(o,e(o,l));else if(h.version<o.version){if(h.size!==o.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");n(h.buffer,o,l),h.version=o.version}}return{get:s,remove:r,update:a}}class ue extends Ye{constructor(t=1,e=1,n=1,s=1){super(),this.type="PlaneGeometry",this.parameters={width:t,height:e,widthSegments:n,heightSegments:s};const r=t/2,a=e/2,o=Math.floor(n),l=Math.floor(s),h=o+1,f=l+1,m=t/o,u=e/l,d=[],c=[],v=[],p=[];for(let x=0;x<f;x++){const w=x*u-a;for(let b=0;b<h;b++){const C=b*m-r;c.push(C,-w,0),v.push(0,0,1),p.push(b/o),p.push(1-x/l)}}for(let x=0;x<l;x++)for(let w=0;w<o;w++){const b=w+h*x,C=w+h*(x+1),V=w+1+h*(x+1),D=w+1+h*x;d.push(b,C,D),d.push(C,V,D)}this.setIndex(d),this.setAttribute("position",new Ce(c,3)),this.setAttribute("normal",new Ce(v,3)),this.setAttribute("uv",new Ce(p,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new ue(t.width,t.height,t.widthSegments,t.heightSegments)}}var od=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,ld=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,cd=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,ud=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,hd=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,fd=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,dd=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,pd=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,md=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec3 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 ).rgb;
	}
#endif`,gd=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,vd=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,xd=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,_d=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,Md=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,yd=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,Sd=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,wd=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,bd=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,Td=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,Ed=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,Ad=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,Cd=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec3 vColor;
#endif`,Rd=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif
#ifdef USE_BATCHING_COLOR
	vec3 batchingColor = getBatchingColor( getIndirectIndex( gl_DrawID ) );
	vColor.xyz *= batchingColor.xyz;
#endif`,Pd=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,Dd=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,Id=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,Ld=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,Ud=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,zd=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,Nd=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,Fd="gl_FragColor = linearToOutputTexel( gl_FragColor );",Od=`
const mat3 LINEAR_SRGB_TO_LINEAR_DISPLAY_P3 = mat3(
	vec3( 0.8224621, 0.177538, 0.0 ),
	vec3( 0.0331941, 0.9668058, 0.0 ),
	vec3( 0.0170827, 0.0723974, 0.9105199 )
);
const mat3 LINEAR_DISPLAY_P3_TO_LINEAR_SRGB = mat3(
	vec3( 1.2249401, - 0.2249404, 0.0 ),
	vec3( - 0.0420569, 1.0420571, 0.0 ),
	vec3( - 0.0196376, - 0.0786361, 1.0982735 )
);
vec4 LinearSRGBToLinearDisplayP3( in vec4 value ) {
	return vec4( value.rgb * LINEAR_SRGB_TO_LINEAR_DISPLAY_P3, value.a );
}
vec4 LinearDisplayP3ToLinearSRGB( in vec4 value ) {
	return vec4( value.rgb * LINEAR_DISPLAY_P3_TO_LINEAR_SRGB, value.a );
}
vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,Bd=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,kd=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,Hd=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,Gd=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,Vd=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,Wd=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,Xd=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,qd=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,Yd=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,$d=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,Kd=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,Zd=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,jd=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,Jd=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,Qd=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,tp=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,ep=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,np=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,ip=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,sp=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,rp=`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,ap=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,op=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,lp=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,cp=`#if defined( USE_LOGDEPTHBUF )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,up=`#if defined( USE_LOGDEPTHBUF )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,hp=`#ifdef USE_LOGDEPTHBUF
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,fp=`#ifdef USE_LOGDEPTHBUF
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,dp=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = vec4( mix( pow( sampledDiffuseColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), sampledDiffuseColor.rgb * 0.0773993808, vec3( lessThanEqual( sampledDiffuseColor.rgb, vec3( 0.04045 ) ) ) ), sampledDiffuseColor.w );
	
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,pp=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,mp=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,gp=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,vp=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,xp=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,_p=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,Mp=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,yp=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,Sp=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,wp=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,bp=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,Tp=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,Ep=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Ap=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Cp=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,Rp=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,Pp=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,Dp=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,Ip=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,Lp=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,Up=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,zp=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,Np=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,Fp=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,Op=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,Bp=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,kp=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,Hp=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,Gp=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		return step( compare, unpackRGBAToDepth( texture2D( depths, uv ) ) );
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow (sampler2D shadow, vec2 uv, float compare ){
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		float hard_shadow = step( compare , distribution.x );
		if (hard_shadow != 1.0 ) {
			float distance = compare - distribution.x ;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		
		float lightToPositionLength = length( lightToPosition );
		if ( lightToPositionLength - shadowCameraFar <= 0.0 && lightToPositionLength - shadowCameraNear >= 0.0 ) {
			float dp = ( lightToPositionLength - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
			#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
				vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
				shadow = (
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
				) * ( 1.0 / 9.0 );
			#else
				shadow = texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
			#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
#endif`,Vp=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,Wp=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,Xp=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,qp=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,Yp=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,$p=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,Kp=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,Zp=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,jp=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,Jp=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,Qp=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,tm=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,em=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
		
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
		
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		
		#else
		
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,nm=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,im=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,sm=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,rm=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const am=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,om=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,lm=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,cm=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,um=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,hm=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,fm=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,dm=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	float fragCoordZ = 0.5 * vHighPrecisionZW[0] / vHighPrecisionZW[1] + 0.5;
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,pm=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,mm=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,gm=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,vm=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,xm=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,_m=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Mm=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,ym=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Sm=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,wm=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,bm=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,Tm=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Em=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,Am=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,Cm=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Rm=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Pm=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,Dm=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Im=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Lm=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Um=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,zm=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Nm=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Fm=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Om=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Bm=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,ye={alphahash_fragment:od,alphahash_pars_fragment:ld,alphamap_fragment:cd,alphamap_pars_fragment:ud,alphatest_fragment:hd,alphatest_pars_fragment:fd,aomap_fragment:dd,aomap_pars_fragment:pd,batching_pars_vertex:md,batching_vertex:gd,begin_vertex:vd,beginnormal_vertex:xd,bsdfs:_d,iridescence_fragment:Md,bumpmap_pars_fragment:yd,clipping_planes_fragment:Sd,clipping_planes_pars_fragment:wd,clipping_planes_pars_vertex:bd,clipping_planes_vertex:Td,color_fragment:Ed,color_pars_fragment:Ad,color_pars_vertex:Cd,color_vertex:Rd,common:Pd,cube_uv_reflection_fragment:Dd,defaultnormal_vertex:Id,displacementmap_pars_vertex:Ld,displacementmap_vertex:Ud,emissivemap_fragment:zd,emissivemap_pars_fragment:Nd,colorspace_fragment:Fd,colorspace_pars_fragment:Od,envmap_fragment:Bd,envmap_common_pars_fragment:kd,envmap_pars_fragment:Hd,envmap_pars_vertex:Gd,envmap_physical_pars_fragment:Qd,envmap_vertex:Vd,fog_vertex:Wd,fog_pars_vertex:Xd,fog_fragment:qd,fog_pars_fragment:Yd,gradientmap_pars_fragment:$d,lightmap_pars_fragment:Kd,lights_lambert_fragment:Zd,lights_lambert_pars_fragment:jd,lights_pars_begin:Jd,lights_toon_fragment:tp,lights_toon_pars_fragment:ep,lights_phong_fragment:np,lights_phong_pars_fragment:ip,lights_physical_fragment:sp,lights_physical_pars_fragment:rp,lights_fragment_begin:ap,lights_fragment_maps:op,lights_fragment_end:lp,logdepthbuf_fragment:cp,logdepthbuf_pars_fragment:up,logdepthbuf_pars_vertex:hp,logdepthbuf_vertex:fp,map_fragment:dp,map_pars_fragment:pp,map_particle_fragment:mp,map_particle_pars_fragment:gp,metalnessmap_fragment:vp,metalnessmap_pars_fragment:xp,morphinstance_vertex:_p,morphcolor_vertex:Mp,morphnormal_vertex:yp,morphtarget_pars_vertex:Sp,morphtarget_vertex:wp,normal_fragment_begin:bp,normal_fragment_maps:Tp,normal_pars_fragment:Ep,normal_pars_vertex:Ap,normal_vertex:Cp,normalmap_pars_fragment:Rp,clearcoat_normal_fragment_begin:Pp,clearcoat_normal_fragment_maps:Dp,clearcoat_pars_fragment:Ip,iridescence_pars_fragment:Lp,opaque_fragment:Up,packing:zp,premultiplied_alpha_fragment:Np,project_vertex:Fp,dithering_fragment:Op,dithering_pars_fragment:Bp,roughnessmap_fragment:kp,roughnessmap_pars_fragment:Hp,shadowmap_pars_fragment:Gp,shadowmap_pars_vertex:Vp,shadowmap_vertex:Wp,shadowmask_pars_fragment:Xp,skinbase_vertex:qp,skinning_pars_vertex:Yp,skinning_vertex:$p,skinnormal_vertex:Kp,specularmap_fragment:Zp,specularmap_pars_fragment:jp,tonemapping_fragment:Jp,tonemapping_pars_fragment:Qp,transmission_fragment:tm,transmission_pars_fragment:em,uv_pars_fragment:nm,uv_pars_vertex:im,uv_vertex:sm,worldpos_vertex:rm,background_vert:am,background_frag:om,backgroundCube_vert:lm,backgroundCube_frag:cm,cube_vert:um,cube_frag:hm,depth_vert:fm,depth_frag:dm,distanceRGBA_vert:pm,distanceRGBA_frag:mm,equirect_vert:gm,equirect_frag:vm,linedashed_vert:xm,linedashed_frag:_m,meshbasic_vert:Mm,meshbasic_frag:ym,meshlambert_vert:Sm,meshlambert_frag:wm,meshmatcap_vert:bm,meshmatcap_frag:Tm,meshnormal_vert:Em,meshnormal_frag:Am,meshphong_vert:Cm,meshphong_frag:Rm,meshphysical_vert:Pm,meshphysical_frag:Dm,meshtoon_vert:Im,meshtoon_frag:Lm,points_vert:Um,points_frag:zm,shadow_vert:Nm,shadow_frag:Fm,sprite_vert:Om,sprite_frag:Bm},Kt={common:{diffuse:{value:new Jt(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new Se},alphaMap:{value:null},alphaMapTransform:{value:new Se},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new Se}},envmap:{envMap:{value:null},envMapRotation:{value:new Se},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new Se}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new Se}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new Se},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new Se},normalScale:{value:new Pt(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new Se},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new Se}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new Se}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new Se}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new Jt(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new Jt(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new Se},alphaTest:{value:0},uvTransform:{value:new Se}},sprite:{diffuse:{value:new Jt(16777215)},opacity:{value:1},center:{value:new Pt(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new Se},alphaMap:{value:null},alphaMapTransform:{value:new Se},alphaTest:{value:0}}},ci={basic:{uniforms:Sn([Kt.common,Kt.specularmap,Kt.envmap,Kt.aomap,Kt.lightmap,Kt.fog]),vertexShader:ye.meshbasic_vert,fragmentShader:ye.meshbasic_frag},lambert:{uniforms:Sn([Kt.common,Kt.specularmap,Kt.envmap,Kt.aomap,Kt.lightmap,Kt.emissivemap,Kt.bumpmap,Kt.normalmap,Kt.displacementmap,Kt.fog,Kt.lights,{emissive:{value:new Jt(0)}}]),vertexShader:ye.meshlambert_vert,fragmentShader:ye.meshlambert_frag},phong:{uniforms:Sn([Kt.common,Kt.specularmap,Kt.envmap,Kt.aomap,Kt.lightmap,Kt.emissivemap,Kt.bumpmap,Kt.normalmap,Kt.displacementmap,Kt.fog,Kt.lights,{emissive:{value:new Jt(0)},specular:{value:new Jt(1118481)},shininess:{value:30}}]),vertexShader:ye.meshphong_vert,fragmentShader:ye.meshphong_frag},standard:{uniforms:Sn([Kt.common,Kt.envmap,Kt.aomap,Kt.lightmap,Kt.emissivemap,Kt.bumpmap,Kt.normalmap,Kt.displacementmap,Kt.roughnessmap,Kt.metalnessmap,Kt.fog,Kt.lights,{emissive:{value:new Jt(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:ye.meshphysical_vert,fragmentShader:ye.meshphysical_frag},toon:{uniforms:Sn([Kt.common,Kt.aomap,Kt.lightmap,Kt.emissivemap,Kt.bumpmap,Kt.normalmap,Kt.displacementmap,Kt.gradientmap,Kt.fog,Kt.lights,{emissive:{value:new Jt(0)}}]),vertexShader:ye.meshtoon_vert,fragmentShader:ye.meshtoon_frag},matcap:{uniforms:Sn([Kt.common,Kt.bumpmap,Kt.normalmap,Kt.displacementmap,Kt.fog,{matcap:{value:null}}]),vertexShader:ye.meshmatcap_vert,fragmentShader:ye.meshmatcap_frag},points:{uniforms:Sn([Kt.points,Kt.fog]),vertexShader:ye.points_vert,fragmentShader:ye.points_frag},dashed:{uniforms:Sn([Kt.common,Kt.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:ye.linedashed_vert,fragmentShader:ye.linedashed_frag},depth:{uniforms:Sn([Kt.common,Kt.displacementmap]),vertexShader:ye.depth_vert,fragmentShader:ye.depth_frag},normal:{uniforms:Sn([Kt.common,Kt.bumpmap,Kt.normalmap,Kt.displacementmap,{opacity:{value:1}}]),vertexShader:ye.meshnormal_vert,fragmentShader:ye.meshnormal_frag},sprite:{uniforms:Sn([Kt.sprite,Kt.fog]),vertexShader:ye.sprite_vert,fragmentShader:ye.sprite_frag},background:{uniforms:{uvTransform:{value:new Se},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:ye.background_vert,fragmentShader:ye.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new Se}},vertexShader:ye.backgroundCube_vert,fragmentShader:ye.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:ye.cube_vert,fragmentShader:ye.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:ye.equirect_vert,fragmentShader:ye.equirect_frag},distanceRGBA:{uniforms:Sn([Kt.common,Kt.displacementmap,{referencePosition:{value:new N},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:ye.distanceRGBA_vert,fragmentShader:ye.distanceRGBA_frag},shadow:{uniforms:Sn([Kt.lights,Kt.fog,{color:{value:new Jt(0)},opacity:{value:1}}]),vertexShader:ye.shadow_vert,fragmentShader:ye.shadow_frag}};ci.physical={uniforms:Sn([ci.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new Se},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new Se},clearcoatNormalScale:{value:new Pt(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new Se},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new Se},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new Se},sheen:{value:0},sheenColor:{value:new Jt(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new Se},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new Se},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new Se},transmissionSamplerSize:{value:new Pt},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new Se},attenuationDistance:{value:0},attenuationColor:{value:new Jt(0)},specularColor:{value:new Jt(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new Se},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new Se},anisotropyVector:{value:new Pt},anisotropyMap:{value:null},anisotropyMapTransform:{value:new Se}}]),vertexShader:ye.meshphysical_vert,fragmentShader:ye.meshphysical_frag};const va={r:0,b:0,g:0},Zi=new wn,km=new Pe;function Hm(i,t,e,n,s,r,a){const o=new Jt(0);let l=r===!0?0:1,h,f,m=null,u=0,d=null;function c(w){let b=w.isScene===!0?w.background:null;return b&&b.isTexture&&(b=(w.backgroundBlurriness>0?e:t).get(b)),b}function v(w){let b=!1;const C=c(w);C===null?x(o,l):C&&C.isColor&&(x(C,1),b=!0);const V=i.xr.getEnvironmentBlendMode();V==="additive"?n.buffers.color.setClear(0,0,0,1,a):V==="alpha-blend"&&n.buffers.color.setClear(0,0,0,0,a),(i.autoClear||b)&&(n.buffers.depth.setTest(!0),n.buffers.depth.setMask(!0),n.buffers.color.setMask(!0),i.clear(i.autoClearColor,i.autoClearDepth,i.autoClearStencil))}function p(w,b){const C=c(b);C&&(C.isCubeTexture||C.mapping===mo)?(f===void 0&&(f=new K(new Rt(1,1,1),new Ke({name:"BackgroundCubeMaterial",uniforms:cr(ci.backgroundCube.uniforms),vertexShader:ci.backgroundCube.vertexShader,fragmentShader:ci.backgroundCube.fragmentShader,side:fn,depthTest:!1,depthWrite:!1,fog:!1})),f.geometry.deleteAttribute("normal"),f.geometry.deleteAttribute("uv"),f.onBeforeRender=function(V,D,A){this.matrixWorld.copyPosition(A.matrixWorld)},Object.defineProperty(f.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),s.update(f)),Zi.copy(b.backgroundRotation),Zi.x*=-1,Zi.y*=-1,Zi.z*=-1,C.isCubeTexture&&C.isRenderTargetTexture===!1&&(Zi.y*=-1,Zi.z*=-1),f.material.uniforms.envMap.value=C,f.material.uniforms.flipEnvMap.value=C.isCubeTexture&&C.isRenderTargetTexture===!1?-1:1,f.material.uniforms.backgroundBlurriness.value=b.backgroundBlurriness,f.material.uniforms.backgroundIntensity.value=b.backgroundIntensity,f.material.uniforms.backgroundRotation.value.setFromMatrix4(km.makeRotationFromEuler(Zi)),f.material.toneMapped=Ie.getTransfer(C.colorSpace)!==He,(m!==C||u!==C.version||d!==i.toneMapping)&&(f.material.needsUpdate=!0,m=C,u=C.version,d=i.toneMapping),f.layers.enableAll(),w.unshift(f,f.geometry,f.material,0,0,null)):C&&C.isTexture&&(h===void 0&&(h=new K(new ue(2,2),new Ke({name:"BackgroundMaterial",uniforms:cr(ci.background.uniforms),vertexShader:ci.background.vertexShader,fragmentShader:ci.background.fragmentShader,side:Hi,depthTest:!1,depthWrite:!1,fog:!1})),h.geometry.deleteAttribute("normal"),Object.defineProperty(h.material,"map",{get:function(){return this.uniforms.t2D.value}}),s.update(h)),h.material.uniforms.t2D.value=C,h.material.uniforms.backgroundIntensity.value=b.backgroundIntensity,h.material.toneMapped=Ie.getTransfer(C.colorSpace)!==He,C.matrixAutoUpdate===!0&&C.updateMatrix(),h.material.uniforms.uvTransform.value.copy(C.matrix),(m!==C||u!==C.version||d!==i.toneMapping)&&(h.material.needsUpdate=!0,m=C,u=C.version,d=i.toneMapping),h.layers.enableAll(),w.unshift(h,h.geometry,h.material,0,0,null))}function x(w,b){w.getRGB(va,eh(i)),n.buffers.color.setClear(va.r,va.g,va.b,b,a)}return{getClearColor:function(){return o},setClearColor:function(w,b=1){o.set(w),l=b,x(o,l)},getClearAlpha:function(){return l},setClearAlpha:function(w){l=w,x(o,l)},render:v,addToRenderList:p}}function Gm(i,t){const e=i.getParameter(i.MAX_VERTEX_ATTRIBS),n={},s=u(null);let r=s,a=!1;function o(S,z,nt,q,j){let Y=!1;const W=m(q,nt,z);r!==W&&(r=W,h(r.object)),Y=d(S,q,nt,j),Y&&c(S,q,nt,j),j!==null&&t.update(j,i.ELEMENT_ARRAY_BUFFER),(Y||a)&&(a=!1,C(S,z,nt,q),j!==null&&i.bindBuffer(i.ELEMENT_ARRAY_BUFFER,t.get(j).buffer))}function l(){return i.createVertexArray()}function h(S){return i.bindVertexArray(S)}function f(S){return i.deleteVertexArray(S)}function m(S,z,nt){const q=nt.wireframe===!0;let j=n[S.id];j===void 0&&(j={},n[S.id]=j);let Y=j[z.id];Y===void 0&&(Y={},j[z.id]=Y);let W=Y[q];return W===void 0&&(W=u(l()),Y[q]=W),W}function u(S){const z=[],nt=[],q=[];for(let j=0;j<e;j++)z[j]=0,nt[j]=0,q[j]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:z,enabledAttributes:nt,attributeDivisors:q,object:S,attributes:{},index:null}}function d(S,z,nt,q){const j=r.attributes,Y=z.attributes;let W=0;const ht=nt.getAttributes();for(const lt in ht)if(ht[lt].location>=0){const yt=j[lt];let dt=Y[lt];if(dt===void 0&&(lt==="instanceMatrix"&&S.instanceMatrix&&(dt=S.instanceMatrix),lt==="instanceColor"&&S.instanceColor&&(dt=S.instanceColor)),yt===void 0||yt.attribute!==dt||dt&&yt.data!==dt.data)return!0;W++}return r.attributesNum!==W||r.index!==q}function c(S,z,nt,q){const j={},Y=z.attributes;let W=0;const ht=nt.getAttributes();for(const lt in ht)if(ht[lt].location>=0){let yt=Y[lt];yt===void 0&&(lt==="instanceMatrix"&&S.instanceMatrix&&(yt=S.instanceMatrix),lt==="instanceColor"&&S.instanceColor&&(yt=S.instanceColor));const dt={};dt.attribute=yt,yt&&yt.data&&(dt.data=yt.data),j[lt]=dt,W++}r.attributes=j,r.attributesNum=W,r.index=q}function v(){const S=r.newAttributes;for(let z=0,nt=S.length;z<nt;z++)S[z]=0}function p(S){x(S,0)}function x(S,z){const nt=r.newAttributes,q=r.enabledAttributes,j=r.attributeDivisors;nt[S]=1,q[S]===0&&(i.enableVertexAttribArray(S),q[S]=1),j[S]!==z&&(i.vertexAttribDivisor(S,z),j[S]=z)}function w(){const S=r.newAttributes,z=r.enabledAttributes;for(let nt=0,q=z.length;nt<q;nt++)z[nt]!==S[nt]&&(i.disableVertexAttribArray(nt),z[nt]=0)}function b(S,z,nt,q,j,Y,W){W===!0?i.vertexAttribIPointer(S,z,nt,j,Y):i.vertexAttribPointer(S,z,nt,q,j,Y)}function C(S,z,nt,q){v();const j=q.attributes,Y=nt.getAttributes(),W=z.defaultAttributeValues;for(const ht in Y){const lt=Y[ht];if(lt.location>=0){let Dt=j[ht];if(Dt===void 0&&(ht==="instanceMatrix"&&S.instanceMatrix&&(Dt=S.instanceMatrix),ht==="instanceColor"&&S.instanceColor&&(Dt=S.instanceColor)),Dt!==void 0){const yt=Dt.normalized,dt=Dt.itemSize,et=t.get(Dt);if(et===void 0)continue;const Lt=et.buffer,k=et.type,at=et.bytesPerElement,gt=k===i.INT||k===i.UNSIGNED_INT||Dt.gpuType===Mc;if(Dt.isInterleavedBufferAttribute){const Mt=Dt.data,Et=Mt.stride,Bt=Dt.offset;if(Mt.isInstancedInterleavedBuffer){for(let Zt=0;Zt<lt.locationSize;Zt++)x(lt.location+Zt,Mt.meshPerAttribute);S.isInstancedMesh!==!0&&q._maxInstanceCount===void 0&&(q._maxInstanceCount=Mt.meshPerAttribute*Mt.count)}else for(let Zt=0;Zt<lt.locationSize;Zt++)p(lt.location+Zt);i.bindBuffer(i.ARRAY_BUFFER,Lt);for(let Zt=0;Zt<lt.locationSize;Zt++)b(lt.location+Zt,dt/lt.locationSize,k,yt,Et*at,(Bt+dt/lt.locationSize*Zt)*at,gt)}else{if(Dt.isInstancedBufferAttribute){for(let Mt=0;Mt<lt.locationSize;Mt++)x(lt.location+Mt,Dt.meshPerAttribute);S.isInstancedMesh!==!0&&q._maxInstanceCount===void 0&&(q._maxInstanceCount=Dt.meshPerAttribute*Dt.count)}else for(let Mt=0;Mt<lt.locationSize;Mt++)p(lt.location+Mt);i.bindBuffer(i.ARRAY_BUFFER,Lt);for(let Mt=0;Mt<lt.locationSize;Mt++)b(lt.location+Mt,dt/lt.locationSize,k,yt,dt*at,dt/lt.locationSize*Mt*at,gt)}}else if(W!==void 0){const yt=W[ht];if(yt!==void 0)switch(yt.length){case 2:i.vertexAttrib2fv(lt.location,yt);break;case 3:i.vertexAttrib3fv(lt.location,yt);break;case 4:i.vertexAttrib4fv(lt.location,yt);break;default:i.vertexAttrib1fv(lt.location,yt)}}}}w()}function V(){y();for(const S in n){const z=n[S];for(const nt in z){const q=z[nt];for(const j in q)f(q[j].object),delete q[j];delete z[nt]}delete n[S]}}function D(S){if(n[S.id]===void 0)return;const z=n[S.id];for(const nt in z){const q=z[nt];for(const j in q)f(q[j].object),delete q[j];delete z[nt]}delete n[S.id]}function A(S){for(const z in n){const nt=n[z];if(nt[S.id]===void 0)continue;const q=nt[S.id];for(const j in q)f(q[j].object),delete q[j];delete nt[S.id]}}function y(){rt(),a=!0,r!==s&&(r=s,h(r.object))}function rt(){s.geometry=null,s.program=null,s.wireframe=!1}return{setup:o,reset:y,resetDefaultState:rt,dispose:V,releaseStatesOfGeometry:D,releaseStatesOfProgram:A,initAttributes:v,enableAttribute:p,disableUnusedAttributes:w}}function Vm(i,t,e){let n;function s(h){n=h}function r(h,f){i.drawArrays(n,h,f),e.update(f,n,1)}function a(h,f,m){m!==0&&(i.drawArraysInstanced(n,h,f,m),e.update(f,n,m))}function o(h,f,m){if(m===0)return;t.get("WEBGL_multi_draw").multiDrawArraysWEBGL(n,h,0,f,0,m);let d=0;for(let c=0;c<m;c++)d+=f[c];e.update(d,n,1)}function l(h,f,m,u){if(m===0)return;const d=t.get("WEBGL_multi_draw");if(d===null)for(let c=0;c<h.length;c++)a(h[c],f[c],u[c]);else{d.multiDrawArraysInstancedWEBGL(n,h,0,f,0,u,0,m);let c=0;for(let v=0;v<m;v++)c+=f[v];for(let v=0;v<u.length;v++)e.update(c,n,u[v])}}this.setMode=s,this.render=r,this.renderInstances=a,this.renderMultiDraw=o,this.renderMultiDrawInstances=l}function Wm(i,t,e,n){let s;function r(){if(s!==void 0)return s;if(t.has("EXT_texture_filter_anisotropic")===!0){const A=t.get("EXT_texture_filter_anisotropic");s=i.getParameter(A.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else s=0;return s}function a(A){return!(A!==ri&&n.convert(A)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_FORMAT))}function o(A){const y=A===pi&&(t.has("EXT_color_buffer_half_float")||t.has("EXT_color_buffer_float"));return!(A!==Ai&&n.convert(A)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_TYPE)&&A!==fi&&!y)}function l(A){if(A==="highp"){if(i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.HIGH_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.HIGH_FLOAT).precision>0)return"highp";A="mediump"}return A==="mediump"&&i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.MEDIUM_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let h=e.precision!==void 0?e.precision:"highp";const f=l(h);f!==h&&(console.warn("THREE.WebGLRenderer:",h,"not supported, using",f,"instead."),h=f);const m=e.logarithmicDepthBuffer===!0,u=e.reverseDepthBuffer===!0&&t.has("EXT_clip_control");if(u===!0){const A=t.get("EXT_clip_control");A.clipControlEXT(A.LOWER_LEFT_EXT,A.ZERO_TO_ONE_EXT)}const d=i.getParameter(i.MAX_TEXTURE_IMAGE_UNITS),c=i.getParameter(i.MAX_VERTEX_TEXTURE_IMAGE_UNITS),v=i.getParameter(i.MAX_TEXTURE_SIZE),p=i.getParameter(i.MAX_CUBE_MAP_TEXTURE_SIZE),x=i.getParameter(i.MAX_VERTEX_ATTRIBS),w=i.getParameter(i.MAX_VERTEX_UNIFORM_VECTORS),b=i.getParameter(i.MAX_VARYING_VECTORS),C=i.getParameter(i.MAX_FRAGMENT_UNIFORM_VECTORS),V=c>0,D=i.getParameter(i.MAX_SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:r,getMaxPrecision:l,textureFormatReadable:a,textureTypeReadable:o,precision:h,logarithmicDepthBuffer:m,reverseDepthBuffer:u,maxTextures:d,maxVertexTextures:c,maxTextureSize:v,maxCubemapSize:p,maxAttributes:x,maxVertexUniforms:w,maxVaryings:b,maxFragmentUniforms:C,vertexTextures:V,maxSamples:D}}function Xm(i){const t=this;let e=null,n=0,s=!1,r=!1;const a=new ts,o=new Se,l={value:null,needsUpdate:!1};this.uniform=l,this.numPlanes=0,this.numIntersection=0,this.init=function(m,u){const d=m.length!==0||u||n!==0||s;return s=u,n=m.length,d},this.beginShadows=function(){r=!0,f(null)},this.endShadows=function(){r=!1},this.setGlobalState=function(m,u){e=f(m,u,0)},this.setState=function(m,u,d){const c=m.clippingPlanes,v=m.clipIntersection,p=m.clipShadows,x=i.get(m);if(!s||c===null||c.length===0||r&&!p)r?f(null):h();else{const w=r?0:n,b=w*4;let C=x.clippingState||null;l.value=C,C=f(c,u,b,d);for(let V=0;V!==b;++V)C[V]=e[V];x.clippingState=C,this.numIntersection=v?this.numPlanes:0,this.numPlanes+=w}};function h(){l.value!==e&&(l.value=e,l.needsUpdate=n>0),t.numPlanes=n,t.numIntersection=0}function f(m,u,d,c){const v=m!==null?m.length:0;let p=null;if(v!==0){if(p=l.value,c!==!0||p===null){const x=d+v*4,w=u.matrixWorldInverse;o.getNormalMatrix(w),(p===null||p.length<x)&&(p=new Float32Array(x));for(let b=0,C=d;b!==v;++b,C+=4)a.copy(m[b]).applyMatrix4(w,o),a.normal.toArray(p,C),p[C+3]=a.constant}l.value=p,l.needsUpdate=!0}return t.numPlanes=v,t.numIntersection=0,p}}function qm(i){let t=new WeakMap;function e(a,o){return o===Ul?a.mapping=rr:o===zl&&(a.mapping=ar),a}function n(a){if(a&&a.isTexture){const o=a.mapping;if(o===Ul||o===zl)if(t.has(a)){const l=t.get(a).texture;return e(l,a.mapping)}else{const l=a.image;if(l&&l.height>0){const h=new id(l.height);return h.fromEquirectangularTexture(i,a),t.set(a,h),a.addEventListener("dispose",s),e(h.texture,a.mapping)}else return null}}return a}function s(a){const o=a.target;o.removeEventListener("dispose",s);const l=t.get(o);l!==void 0&&(t.delete(o),l.dispose())}function r(){t=new WeakMap}return{get:n,dispose:r}}class Dc extends nh{constructor(t=-1,e=1,n=1,s=-1,r=.1,a=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=t,this.right=e,this.top=n,this.bottom=s,this.near=r,this.far=a,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.left=t.left,this.right=t.right,this.top=t.top,this.bottom=t.bottom,this.near=t.near,this.far=t.far,this.zoom=t.zoom,this.view=t.view===null?null:Object.assign({},t.view),this}setViewOffset(t,e,n,s,r,a){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=n,this.view.offsetY=s,this.view.width=r,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const t=(this.right-this.left)/(2*this.zoom),e=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,s=(this.top+this.bottom)/2;let r=n-t,a=n+t,o=s+e,l=s-e;if(this.view!==null&&this.view.enabled){const h=(this.right-this.left)/this.view.fullWidth/this.zoom,f=(this.top-this.bottom)/this.view.fullHeight/this.zoom;r+=h*this.view.offsetX,a=r+h*this.view.width,o-=f*this.view.offsetY,l=o-f*this.view.height}this.projectionMatrix.makeOrthographic(r,a,o,l,this.near,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){const e=super.toJSON(t);return e.object.zoom=this.zoom,e.object.left=this.left,e.object.right=this.right,e.object.top=this.top,e.object.bottom=this.bottom,e.object.near=this.near,e.object.far=this.far,this.view!==null&&(e.object.view=Object.assign({},this.view)),e}}const js=4,m0=[.125,.215,.35,.446,.526,.582],ss=20,Xo=new Dc,g0=new Jt;let qo=null,Yo=0,$o=0,Ko=!1;const es=(1+Math.sqrt(5))/2,Is=1/es,v0=[new N(-es,Is,0),new N(es,Is,0),new N(-Is,0,es),new N(Is,0,es),new N(0,es,-Is),new N(0,es,Is),new N(-1,1,-1),new N(1,1,-1),new N(-1,1,1),new N(1,1,1)];class uc{constructor(t){this._renderer=t,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(t,e=0,n=.1,s=100){qo=this._renderer.getRenderTarget(),Yo=this._renderer.getActiveCubeFace(),$o=this._renderer.getActiveMipmapLevel(),Ko=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(256);const r=this._allocateTargets();return r.depthBuffer=!0,this._sceneToCubeUV(t,n,s,r),e>0&&this._blur(r,0,0,e),this._applyPMREM(r),this._cleanup(r),r}fromEquirectangular(t,e=null){return this._fromTexture(t,e)}fromCubemap(t,e=null){return this._fromTexture(t,e)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=M0(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=_0(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(t){this._lodMax=Math.floor(Math.log2(t)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let t=0;t<this._lodPlanes.length;t++)this._lodPlanes[t].dispose()}_cleanup(t){this._renderer.setRenderTarget(qo,Yo,$o),this._renderer.xr.enabled=Ko,t.scissorTest=!1,xa(t,0,0,t.width,t.height)}_fromTexture(t,e){t.mapping===rr||t.mapping===ar?this._setSize(t.image.length===0?16:t.image[0].width||t.image[0].image.width):this._setSize(t.image.width/4),qo=this._renderer.getRenderTarget(),Yo=this._renderer.getActiveCubeFace(),$o=this._renderer.getActiveMipmapLevel(),Ko=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;const n=e||this._allocateTargets();return this._textureToCubeUV(t,n),this._applyPMREM(n),this._cleanup(n),n}_allocateTargets(){const t=3*Math.max(this._cubeSize,112),e=4*this._cubeSize,n={magFilter:Fn,minFilter:Fn,generateMipmaps:!1,type:pi,format:ri,colorSpace:Gi,depthBuffer:!1},s=x0(t,e,n);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==t||this._pingPongRenderTarget.height!==e){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=x0(t,e,n);const{_lodMax:r}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=Ym(r)),this._blurMaterial=$m(r,t,e)}return s}_compileMaterial(t){const e=new K(this._lodPlanes[0],t);this._renderer.compile(e,Xo)}_sceneToCubeUV(t,e,n,s){const o=new Pn(90,1,e,n),l=[1,-1,1,1,1,1],h=[1,1,1,-1,-1,-1],f=this._renderer,m=f.autoClear,u=f.toneMapping;f.getClearColor(g0),f.toneMapping=Bi,f.autoClear=!1;const d=new Bn({name:"PMREM.Background",side:fn,depthWrite:!1,depthTest:!1}),c=new K(new Rt,d);let v=!1;const p=t.background;p?p.isColor&&(d.color.copy(p),t.background=null,v=!0):(d.color.copy(g0),v=!0);for(let x=0;x<6;x++){const w=x%3;w===0?(o.up.set(0,l[x],0),o.lookAt(h[x],0,0)):w===1?(o.up.set(0,0,l[x]),o.lookAt(0,h[x],0)):(o.up.set(0,l[x],0),o.lookAt(0,0,h[x]));const b=this._cubeSize;xa(s,w*b,x>2?b:0,b,b),f.setRenderTarget(s),v&&f.render(c,o),f.render(t,o)}c.geometry.dispose(),c.material.dispose(),f.toneMapping=u,f.autoClear=m,t.background=p}_textureToCubeUV(t,e){const n=this._renderer,s=t.mapping===rr||t.mapping===ar;s?(this._cubemapMaterial===null&&(this._cubemapMaterial=M0()),this._cubemapMaterial.uniforms.flipEnvMap.value=t.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=_0());const r=s?this._cubemapMaterial:this._equirectMaterial,a=new K(this._lodPlanes[0],r),o=r.uniforms;o.envMap.value=t;const l=this._cubeSize;xa(e,0,0,3*l,2*l),n.setRenderTarget(e),n.render(a,Xo)}_applyPMREM(t){const e=this._renderer,n=e.autoClear;e.autoClear=!1;const s=this._lodPlanes.length;for(let r=1;r<s;r++){const a=Math.sqrt(this._sigmas[r]*this._sigmas[r]-this._sigmas[r-1]*this._sigmas[r-1]),o=v0[(s-r-1)%v0.length];this._blur(t,r-1,r,a,o)}e.autoClear=n}_blur(t,e,n,s,r){const a=this._pingPongRenderTarget;this._halfBlur(t,a,e,n,s,"latitudinal",r),this._halfBlur(a,t,n,n,s,"longitudinal",r)}_halfBlur(t,e,n,s,r,a,o){const l=this._renderer,h=this._blurMaterial;a!=="latitudinal"&&a!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");const f=3,m=new K(this._lodPlanes[s],h),u=h.uniforms,d=this._sizeLods[n]-1,c=isFinite(r)?Math.PI/(2*d):2*Math.PI/(2*ss-1),v=r/c,p=isFinite(r)?1+Math.floor(f*v):ss;p>ss&&console.warn(`sigmaRadians, ${r}, is too large and will clip, as it requested ${p} samples when the maximum is set to ${ss}`);const x=[];let w=0;for(let A=0;A<ss;++A){const y=A/v,rt=Math.exp(-y*y/2);x.push(rt),A===0?w+=rt:A<p&&(w+=2*rt)}for(let A=0;A<x.length;A++)x[A]=x[A]/w;u.envMap.value=t.texture,u.samples.value=p,u.weights.value=x,u.latitudinal.value=a==="latitudinal",o&&(u.poleAxis.value=o);const{_lodMax:b}=this;u.dTheta.value=c,u.mipInt.value=b-n;const C=this._sizeLods[s],V=3*C*(s>b-js?s-b+js:0),D=4*(this._cubeSize-C);xa(e,V,D,3*C,2*C),l.setRenderTarget(e),l.render(m,Xo)}}function Ym(i){const t=[],e=[],n=[];let s=i;const r=i-js+1+m0.length;for(let a=0;a<r;a++){const o=Math.pow(2,s);e.push(o);let l=1/o;a>i-js?l=m0[a-i+js-1]:a===0&&(l=0),n.push(l);const h=1/(o-2),f=-h,m=1+h,u=[f,f,m,f,m,m,f,f,m,m,f,m],d=6,c=6,v=3,p=2,x=1,w=new Float32Array(v*c*d),b=new Float32Array(p*c*d),C=new Float32Array(x*c*d);for(let D=0;D<d;D++){const A=D%3*2/3-1,y=D>2?0:-1,rt=[A,y,0,A+2/3,y,0,A+2/3,y+1,0,A,y,0,A+2/3,y+1,0,A,y+1,0];w.set(rt,v*c*D),b.set(u,p*c*D);const S=[D,D,D,D,D,D];C.set(S,x*c*D)}const V=new Ye;V.setAttribute("position",new Ve(w,v)),V.setAttribute("uv",new Ve(b,p)),V.setAttribute("faceIndex",new Ve(C,x)),t.push(V),s>js&&s--}return{lodPlanes:t,sizeLods:e,sigmas:n}}function x0(i,t,e){const n=new $n(i,t,e);return n.texture.mapping=mo,n.texture.name="PMREM.cubeUv",n.scissorTest=!0,n}function xa(i,t,e,n,s){i.viewport.set(t,e,n,s),i.scissor.set(t,e,n,s)}function $m(i,t,e){const n=new Float32Array(ss),s=new N(0,1,0);return new Ke({name:"SphericalGaussianBlur",defines:{n:ss,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/e,CUBEUV_MAX_MIP:`${i}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:n},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:s}},vertexShader:Ic(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:bi,depthTest:!1,depthWrite:!1})}function _0(){return new Ke({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:Ic(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:bi,depthTest:!1,depthWrite:!1})}function M0(){return new Ke({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:Ic(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:bi,depthTest:!1,depthWrite:!1})}function Ic(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function Km(i){let t=new WeakMap,e=null;function n(o){if(o&&o.isTexture){const l=o.mapping,h=l===Ul||l===zl,f=l===rr||l===ar;if(h||f){let m=t.get(o);const u=m!==void 0?m.texture.pmremVersion:0;if(o.isRenderTargetTexture&&o.pmremVersion!==u)return e===null&&(e=new uc(i)),m=h?e.fromEquirectangular(o,m):e.fromCubemap(o,m),m.texture.pmremVersion=o.pmremVersion,t.set(o,m),m.texture;if(m!==void 0)return m.texture;{const d=o.image;return h&&d&&d.height>0||f&&d&&s(d)?(e===null&&(e=new uc(i)),m=h?e.fromEquirectangular(o):e.fromCubemap(o),m.texture.pmremVersion=o.pmremVersion,t.set(o,m),o.addEventListener("dispose",r),m.texture):null}}}return o}function s(o){let l=0;const h=6;for(let f=0;f<h;f++)o[f]!==void 0&&l++;return l===h}function r(o){const l=o.target;l.removeEventListener("dispose",r);const h=t.get(l);h!==void 0&&(t.delete(l),h.dispose())}function a(){t=new WeakMap,e!==null&&(e.dispose(),e=null)}return{get:n,dispose:a}}function Zm(i){const t={};function e(n){if(t[n]!==void 0)return t[n];let s;switch(n){case"WEBGL_depth_texture":s=i.getExtension("WEBGL_depth_texture")||i.getExtension("MOZ_WEBGL_depth_texture")||i.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":s=i.getExtension("EXT_texture_filter_anisotropic")||i.getExtension("MOZ_EXT_texture_filter_anisotropic")||i.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":s=i.getExtension("WEBGL_compressed_texture_s3tc")||i.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||i.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":s=i.getExtension("WEBGL_compressed_texture_pvrtc")||i.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:s=i.getExtension(n)}return t[n]=s,s}return{has:function(n){return e(n)!==null},init:function(){e("EXT_color_buffer_float"),e("WEBGL_clip_cull_distance"),e("OES_texture_float_linear"),e("EXT_color_buffer_half_float"),e("WEBGL_multisampled_render_to_texture"),e("WEBGL_render_shared_exponent")},get:function(n){const s=e(n);return s===null&&$a("THREE.WebGLRenderer: "+n+" extension not supported."),s}}}function jm(i,t,e,n){const s={},r=new WeakMap;function a(m){const u=m.target;u.index!==null&&t.remove(u.index);for(const c in u.attributes)t.remove(u.attributes[c]);for(const c in u.morphAttributes){const v=u.morphAttributes[c];for(let p=0,x=v.length;p<x;p++)t.remove(v[p])}u.removeEventListener("dispose",a),delete s[u.id];const d=r.get(u);d&&(t.remove(d),r.delete(u)),n.releaseStatesOfGeometry(u),u.isInstancedBufferGeometry===!0&&delete u._maxInstanceCount,e.memory.geometries--}function o(m,u){return s[u.id]===!0||(u.addEventListener("dispose",a),s[u.id]=!0,e.memory.geometries++),u}function l(m){const u=m.attributes;for(const c in u)t.update(u[c],i.ARRAY_BUFFER);const d=m.morphAttributes;for(const c in d){const v=d[c];for(let p=0,x=v.length;p<x;p++)t.update(v[p],i.ARRAY_BUFFER)}}function h(m){const u=[],d=m.index,c=m.attributes.position;let v=0;if(d!==null){const w=d.array;v=d.version;for(let b=0,C=w.length;b<C;b+=3){const V=w[b+0],D=w[b+1],A=w[b+2];u.push(V,D,D,A,A,V)}}else if(c!==void 0){const w=c.array;v=c.version;for(let b=0,C=w.length/3-1;b<C;b+=3){const V=b+0,D=b+1,A=b+2;u.push(V,D,D,A,A,V)}}else return;const p=new(Ku(u)?th:Qu)(u,1);p.version=v;const x=r.get(m);x&&t.remove(x),r.set(m,p)}function f(m){const u=r.get(m);if(u){const d=m.index;d!==null&&u.version<d.version&&h(m)}else h(m);return r.get(m)}return{get:o,update:l,getWireframeAttribute:f}}function Jm(i,t,e){let n;function s(u){n=u}let r,a;function o(u){r=u.type,a=u.bytesPerElement}function l(u,d){i.drawElements(n,d,r,u*a),e.update(d,n,1)}function h(u,d,c){c!==0&&(i.drawElementsInstanced(n,d,r,u*a,c),e.update(d,n,c))}function f(u,d,c){if(c===0)return;t.get("WEBGL_multi_draw").multiDrawElementsWEBGL(n,d,0,r,u,0,c);let p=0;for(let x=0;x<c;x++)p+=d[x];e.update(p,n,1)}function m(u,d,c,v){if(c===0)return;const p=t.get("WEBGL_multi_draw");if(p===null)for(let x=0;x<u.length;x++)h(u[x]/a,d[x],v[x]);else{p.multiDrawElementsInstancedWEBGL(n,d,0,r,u,0,v,0,c);let x=0;for(let w=0;w<c;w++)x+=d[w];for(let w=0;w<v.length;w++)e.update(x,n,v[w])}}this.setMode=s,this.setIndex=o,this.render=l,this.renderInstances=h,this.renderMultiDraw=f,this.renderMultiDrawInstances=m}function Qm(i){const t={geometries:0,textures:0},e={frame:0,calls:0,triangles:0,points:0,lines:0};function n(r,a,o){switch(e.calls++,a){case i.TRIANGLES:e.triangles+=o*(r/3);break;case i.LINES:e.lines+=o*(r/2);break;case i.LINE_STRIP:e.lines+=o*(r-1);break;case i.LINE_LOOP:e.lines+=o*r;break;case i.POINTS:e.points+=o*r;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",a);break}}function s(){e.calls=0,e.triangles=0,e.points=0,e.lines=0}return{memory:t,render:e,programs:null,autoReset:!0,reset:s,update:n}}function tg(i,t,e){const n=new WeakMap,s=new Fe;function r(a,o,l){const h=a.morphTargetInfluences,f=o.morphAttributes.position||o.morphAttributes.normal||o.morphAttributes.color,m=f!==void 0?f.length:0;let u=n.get(o);if(u===void 0||u.count!==m){let S=function(){y.dispose(),n.delete(o),o.removeEventListener("dispose",S)};var d=S;u!==void 0&&u.texture.dispose();const c=o.morphAttributes.position!==void 0,v=o.morphAttributes.normal!==void 0,p=o.morphAttributes.color!==void 0,x=o.morphAttributes.position||[],w=o.morphAttributes.normal||[],b=o.morphAttributes.color||[];let C=0;c===!0&&(C=1),v===!0&&(C=2),p===!0&&(C=3);let V=o.attributes.position.count*C,D=1;V>t.maxTextureSize&&(D=Math.ceil(V/t.maxTextureSize),V=t.maxTextureSize);const A=new Float32Array(V*D*4*m),y=new ju(A,V,D,m);y.type=fi,y.needsUpdate=!0;const rt=C*4;for(let z=0;z<m;z++){const nt=x[z],q=w[z],j=b[z],Y=V*D*4*z;for(let W=0;W<nt.count;W++){const ht=W*rt;c===!0&&(s.fromBufferAttribute(nt,W),A[Y+ht+0]=s.x,A[Y+ht+1]=s.y,A[Y+ht+2]=s.z,A[Y+ht+3]=0),v===!0&&(s.fromBufferAttribute(q,W),A[Y+ht+4]=s.x,A[Y+ht+5]=s.y,A[Y+ht+6]=s.z,A[Y+ht+7]=0),p===!0&&(s.fromBufferAttribute(j,W),A[Y+ht+8]=s.x,A[Y+ht+9]=s.y,A[Y+ht+10]=s.z,A[Y+ht+11]=j.itemSize===4?s.w:1)}}u={count:m,texture:y,size:new Pt(V,D)},n.set(o,u),o.addEventListener("dispose",S)}if(a.isInstancedMesh===!0&&a.morphTexture!==null)l.getUniforms().setValue(i,"morphTexture",a.morphTexture,e);else{let c=0;for(let p=0;p<h.length;p++)c+=h[p];const v=o.morphTargetsRelative?1:1-c;l.getUniforms().setValue(i,"morphTargetBaseInfluence",v),l.getUniforms().setValue(i,"morphTargetInfluences",h)}l.getUniforms().setValue(i,"morphTargetsTexture",u.texture,e),l.getUniforms().setValue(i,"morphTargetsTextureSize",u.size)}return{update:r}}function eg(i,t,e,n){let s=new WeakMap;function r(l){const h=n.render.frame,f=l.geometry,m=t.get(l,f);if(s.get(m)!==h&&(t.update(m),s.set(m,h)),l.isInstancedMesh&&(l.hasEventListener("dispose",o)===!1&&l.addEventListener("dispose",o),s.get(l)!==h&&(e.update(l.instanceMatrix,i.ARRAY_BUFFER),l.instanceColor!==null&&e.update(l.instanceColor,i.ARRAY_BUFFER),s.set(l,h))),l.isSkinnedMesh){const u=l.skeleton;s.get(u)!==h&&(u.update(),s.set(u,h))}return m}function a(){s=new WeakMap}function o(l){const h=l.target;h.removeEventListener("dispose",o),e.remove(h.instanceMatrix),h.instanceColor!==null&&e.remove(h.instanceColor)}return{update:r,dispose:a}}class rh extends vn{constructor(t,e,n,s,r,a,o,l,h,f=tr){if(f!==tr&&f!==lr)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");n===void 0&&f===tr&&(n=ps),n===void 0&&f===lr&&(n=or),super(null,s,r,a,o,l,f,n,h),this.isDepthTexture=!0,this.image={width:t,height:e},this.magFilter=o!==void 0?o:Dn,this.minFilter=l!==void 0?l:Dn,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(t){return super.copy(t),this.compareFunction=t.compareFunction,this}toJSON(t){const e=super.toJSON(t);return this.compareFunction!==null&&(e.compareFunction=this.compareFunction),e}}const ah=new vn,y0=new rh(1,1),oh=new ju,lh=new Gf,ch=new ih,S0=[],w0=[],b0=new Float32Array(16),T0=new Float32Array(9),E0=new Float32Array(4);function pr(i,t,e){const n=i[0];if(n<=0||n>0)return i;const s=t*e;let r=S0[s];if(r===void 0&&(r=new Float32Array(s),S0[s]=r),t!==0){n.toArray(r,0);for(let a=1,o=0;a!==t;++a)o+=e,i[a].toArray(r,o)}return r}function tn(i,t){if(i.length!==t.length)return!1;for(let e=0,n=i.length;e<n;e++)if(i[e]!==t[e])return!1;return!0}function en(i,t){for(let e=0,n=t.length;e<n;e++)i[e]=t[e]}function xo(i,t){let e=w0[t];e===void 0&&(e=new Int32Array(t),w0[t]=e);for(let n=0;n!==t;++n)e[n]=i.allocateTextureUnit();return e}function ng(i,t){const e=this.cache;e[0]!==t&&(i.uniform1f(this.addr,t),e[0]=t)}function ig(i,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(i.uniform2f(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(tn(e,t))return;i.uniform2fv(this.addr,t),en(e,t)}}function sg(i,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(i.uniform3f(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else if(t.r!==void 0)(e[0]!==t.r||e[1]!==t.g||e[2]!==t.b)&&(i.uniform3f(this.addr,t.r,t.g,t.b),e[0]=t.r,e[1]=t.g,e[2]=t.b);else{if(tn(e,t))return;i.uniform3fv(this.addr,t),en(e,t)}}function rg(i,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(i.uniform4f(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(tn(e,t))return;i.uniform4fv(this.addr,t),en(e,t)}}function ag(i,t){const e=this.cache,n=t.elements;if(n===void 0){if(tn(e,t))return;i.uniformMatrix2fv(this.addr,!1,t),en(e,t)}else{if(tn(e,n))return;E0.set(n),i.uniformMatrix2fv(this.addr,!1,E0),en(e,n)}}function og(i,t){const e=this.cache,n=t.elements;if(n===void 0){if(tn(e,t))return;i.uniformMatrix3fv(this.addr,!1,t),en(e,t)}else{if(tn(e,n))return;T0.set(n),i.uniformMatrix3fv(this.addr,!1,T0),en(e,n)}}function lg(i,t){const e=this.cache,n=t.elements;if(n===void 0){if(tn(e,t))return;i.uniformMatrix4fv(this.addr,!1,t),en(e,t)}else{if(tn(e,n))return;b0.set(n),i.uniformMatrix4fv(this.addr,!1,b0),en(e,n)}}function cg(i,t){const e=this.cache;e[0]!==t&&(i.uniform1i(this.addr,t),e[0]=t)}function ug(i,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(i.uniform2i(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(tn(e,t))return;i.uniform2iv(this.addr,t),en(e,t)}}function hg(i,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(i.uniform3i(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(tn(e,t))return;i.uniform3iv(this.addr,t),en(e,t)}}function fg(i,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(i.uniform4i(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(tn(e,t))return;i.uniform4iv(this.addr,t),en(e,t)}}function dg(i,t){const e=this.cache;e[0]!==t&&(i.uniform1ui(this.addr,t),e[0]=t)}function pg(i,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(i.uniform2ui(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(tn(e,t))return;i.uniform2uiv(this.addr,t),en(e,t)}}function mg(i,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(i.uniform3ui(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(tn(e,t))return;i.uniform3uiv(this.addr,t),en(e,t)}}function gg(i,t){const e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(i.uniform4ui(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(tn(e,t))return;i.uniform4uiv(this.addr,t),en(e,t)}}function vg(i,t,e){const n=this.cache,s=e.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s);let r;this.type===i.SAMPLER_2D_SHADOW?(y0.compareFunction=$u,r=y0):r=ah,e.setTexture2D(t||r,s)}function xg(i,t,e){const n=this.cache,s=e.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),e.setTexture3D(t||lh,s)}function _g(i,t,e){const n=this.cache,s=e.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),e.setTextureCube(t||ch,s)}function Mg(i,t,e){const n=this.cache,s=e.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),e.setTexture2DArray(t||oh,s)}function yg(i){switch(i){case 5126:return ng;case 35664:return ig;case 35665:return sg;case 35666:return rg;case 35674:return ag;case 35675:return og;case 35676:return lg;case 5124:case 35670:return cg;case 35667:case 35671:return ug;case 35668:case 35672:return hg;case 35669:case 35673:return fg;case 5125:return dg;case 36294:return pg;case 36295:return mg;case 36296:return gg;case 35678:case 36198:case 36298:case 36306:case 35682:return vg;case 35679:case 36299:case 36307:return xg;case 35680:case 36300:case 36308:case 36293:return _g;case 36289:case 36303:case 36311:case 36292:return Mg}}function Sg(i,t){i.uniform1fv(this.addr,t)}function wg(i,t){const e=pr(t,this.size,2);i.uniform2fv(this.addr,e)}function bg(i,t){const e=pr(t,this.size,3);i.uniform3fv(this.addr,e)}function Tg(i,t){const e=pr(t,this.size,4);i.uniform4fv(this.addr,e)}function Eg(i,t){const e=pr(t,this.size,4);i.uniformMatrix2fv(this.addr,!1,e)}function Ag(i,t){const e=pr(t,this.size,9);i.uniformMatrix3fv(this.addr,!1,e)}function Cg(i,t){const e=pr(t,this.size,16);i.uniformMatrix4fv(this.addr,!1,e)}function Rg(i,t){i.uniform1iv(this.addr,t)}function Pg(i,t){i.uniform2iv(this.addr,t)}function Dg(i,t){i.uniform3iv(this.addr,t)}function Ig(i,t){i.uniform4iv(this.addr,t)}function Lg(i,t){i.uniform1uiv(this.addr,t)}function Ug(i,t){i.uniform2uiv(this.addr,t)}function zg(i,t){i.uniform3uiv(this.addr,t)}function Ng(i,t){i.uniform4uiv(this.addr,t)}function Fg(i,t,e){const n=this.cache,s=t.length,r=xo(e,s);tn(n,r)||(i.uniform1iv(this.addr,r),en(n,r));for(let a=0;a!==s;++a)e.setTexture2D(t[a]||ah,r[a])}function Og(i,t,e){const n=this.cache,s=t.length,r=xo(e,s);tn(n,r)||(i.uniform1iv(this.addr,r),en(n,r));for(let a=0;a!==s;++a)e.setTexture3D(t[a]||lh,r[a])}function Bg(i,t,e){const n=this.cache,s=t.length,r=xo(e,s);tn(n,r)||(i.uniform1iv(this.addr,r),en(n,r));for(let a=0;a!==s;++a)e.setTextureCube(t[a]||ch,r[a])}function kg(i,t,e){const n=this.cache,s=t.length,r=xo(e,s);tn(n,r)||(i.uniform1iv(this.addr,r),en(n,r));for(let a=0;a!==s;++a)e.setTexture2DArray(t[a]||oh,r[a])}function Hg(i){switch(i){case 5126:return Sg;case 35664:return wg;case 35665:return bg;case 35666:return Tg;case 35674:return Eg;case 35675:return Ag;case 35676:return Cg;case 5124:case 35670:return Rg;case 35667:case 35671:return Pg;case 35668:case 35672:return Dg;case 35669:case 35673:return Ig;case 5125:return Lg;case 36294:return Ug;case 36295:return zg;case 36296:return Ng;case 35678:case 36198:case 36298:case 36306:case 35682:return Fg;case 35679:case 36299:case 36307:return Og;case 35680:case 36300:case 36308:case 36293:return Bg;case 36289:case 36303:case 36311:case 36292:return kg}}class Gg{constructor(t,e,n){this.id=t,this.addr=n,this.cache=[],this.type=e.type,this.setValue=yg(e.type)}}class Vg{constructor(t,e,n){this.id=t,this.addr=n,this.cache=[],this.type=e.type,this.size=e.size,this.setValue=Hg(e.type)}}class Wg{constructor(t){this.id=t,this.seq=[],this.map={}}setValue(t,e,n){const s=this.seq;for(let r=0,a=s.length;r!==a;++r){const o=s[r];o.setValue(t,e[o.id],n)}}}const Zo=/(\w+)(\])?(\[|\.)?/g;function A0(i,t){i.seq.push(t),i.map[t.id]=t}function Xg(i,t,e){const n=i.name,s=n.length;for(Zo.lastIndex=0;;){const r=Zo.exec(n),a=Zo.lastIndex;let o=r[1];const l=r[2]==="]",h=r[3];if(l&&(o=o|0),h===void 0||h==="["&&a+2===s){A0(e,h===void 0?new Gg(o,i,t):new Vg(o,i,t));break}else{let m=e.map[o];m===void 0&&(m=new Wg(o),A0(e,m)),e=m}}}class Ka{constructor(t,e){this.seq=[],this.map={};const n=t.getProgramParameter(e,t.ACTIVE_UNIFORMS);for(let s=0;s<n;++s){const r=t.getActiveUniform(e,s),a=t.getUniformLocation(e,r.name);Xg(r,a,this)}}setValue(t,e,n,s){const r=this.map[e];r!==void 0&&r.setValue(t,n,s)}setOptional(t,e,n){const s=e[n];s!==void 0&&this.setValue(t,n,s)}static upload(t,e,n,s){for(let r=0,a=e.length;r!==a;++r){const o=e[r],l=n[o.id];l.needsUpdate!==!1&&o.setValue(t,l.value,s)}}static seqWithValue(t,e){const n=[];for(let s=0,r=t.length;s!==r;++s){const a=t[s];a.id in e&&n.push(a)}return n}}function C0(i,t,e){const n=i.createShader(t);return i.shaderSource(n,e),i.compileShader(n),n}const qg=37297;let Yg=0;function $g(i,t){const e=i.split(`
`),n=[],s=Math.max(t-6,0),r=Math.min(t+6,e.length);for(let a=s;a<r;a++){const o=a+1;n.push(`${o===t?">":" "} ${o}: ${e[a]}`)}return n.join(`
`)}function Kg(i){const t=Ie.getPrimaries(Ie.workingColorSpace),e=Ie.getPrimaries(i);let n;switch(t===e?n="":t===to&&e===Qa?n="LinearDisplayP3ToLinearSRGB":t===Qa&&e===to&&(n="LinearSRGBToLinearDisplayP3"),i){case Gi:case go:return[n,"LinearTransferOETF"];case pn:case Ac:return[n,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space:",i),[n,"LinearTransferOETF"]}}function R0(i,t,e){const n=i.getShaderParameter(t,i.COMPILE_STATUS),s=i.getShaderInfoLog(t).trim();if(n&&s==="")return"";const r=/ERROR: 0:(\d+)/.exec(s);if(r){const a=parseInt(r[1]);return e.toUpperCase()+`

`+s+`

`+$g(i.getShaderSource(t),a)}else return s}function Zg(i,t){const e=Kg(t);return`vec4 ${i}( vec4 value ) { return ${e[0]}( ${e[1]}( value ) ); }`}function jg(i,t){let e;switch(t){case Iu:e="Linear";break;case Lu:e="Reinhard";break;case Uu:e="Cineon";break;case _c:e="ACESFilmic";break;case zu:e="AgX";break;case Nu:e="Neutral";break;case rf:e="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",t),e="Linear"}return"vec3 "+i+"( vec3 color ) { return "+e+"ToneMapping( color ); }"}const _a=new N;function Jg(){Ie.getLuminanceCoefficients(_a);const i=_a.x.toFixed(4),t=_a.y.toFixed(4),e=_a.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${i}, ${t}, ${e} );`,"	return dot( weights, rgb );","}"].join(`
`)}function Qg(i){return[i.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",i.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(Fr).join(`
`)}function t1(i){const t=[];for(const e in i){const n=i[e];n!==!1&&t.push("#define "+e+" "+n)}return t.join(`
`)}function e1(i,t){const e={},n=i.getProgramParameter(t,i.ACTIVE_ATTRIBUTES);for(let s=0;s<n;s++){const r=i.getActiveAttrib(t,s),a=r.name;let o=1;r.type===i.FLOAT_MAT2&&(o=2),r.type===i.FLOAT_MAT3&&(o=3),r.type===i.FLOAT_MAT4&&(o=4),e[a]={type:r.type,location:i.getAttribLocation(t,a),locationSize:o}}return e}function Fr(i){return i!==""}function P0(i,t){const e=t.numSpotLightShadows+t.numSpotLightMaps-t.numSpotLightShadowsWithMaps;return i.replace(/NUM_DIR_LIGHTS/g,t.numDirLights).replace(/NUM_SPOT_LIGHTS/g,t.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,t.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,e).replace(/NUM_RECT_AREA_LIGHTS/g,t.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,t.numPointLights).replace(/NUM_HEMI_LIGHTS/g,t.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,t.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,t.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,t.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,t.numPointLightShadows)}function D0(i,t){return i.replace(/NUM_CLIPPING_PLANES/g,t.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,t.numClippingPlanes-t.numClipIntersection)}const n1=/^[ \t]*#include +<([\w\d./]+)>/gm;function hc(i){return i.replace(n1,s1)}const i1=new Map;function s1(i,t){let e=ye[t];if(e===void 0){const n=i1.get(t);if(n!==void 0)e=ye[n],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',t,n);else throw new Error("Can not resolve #include <"+t+">")}return hc(e)}const r1=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function I0(i){return i.replace(r1,a1)}function a1(i,t,e,n){let s="";for(let r=parseInt(t);r<parseInt(e);r++)s+=n.replace(/\[\s*i\s*\]/g,"[ "+r+" ]").replace(/UNROLLED_LOOP_INDEX/g,r);return s}function L0(i){let t=`precision ${i.precision} float;
	precision ${i.precision} int;
	precision ${i.precision} sampler2D;
	precision ${i.precision} samplerCube;
	precision ${i.precision} sampler3D;
	precision ${i.precision} sampler2DArray;
	precision ${i.precision} sampler2DShadow;
	precision ${i.precision} samplerCubeShadow;
	precision ${i.precision} sampler2DArrayShadow;
	precision ${i.precision} isampler2D;
	precision ${i.precision} isampler3D;
	precision ${i.precision} isamplerCube;
	precision ${i.precision} isampler2DArray;
	precision ${i.precision} usampler2D;
	precision ${i.precision} usampler3D;
	precision ${i.precision} usamplerCube;
	precision ${i.precision} usampler2DArray;
	`;return i.precision==="highp"?t+=`
#define HIGH_PRECISION`:i.precision==="mediump"?t+=`
#define MEDIUM_PRECISION`:i.precision==="lowp"&&(t+=`
#define LOW_PRECISION`),t}function o1(i){let t="SHADOWMAP_TYPE_BASIC";return i.shadowMapType===Ru?t="SHADOWMAP_TYPE_PCF":i.shadowMapType===Pu?t="SHADOWMAP_TYPE_PCF_SOFT":i.shadowMapType===yi&&(t="SHADOWMAP_TYPE_VSM"),t}function l1(i){let t="ENVMAP_TYPE_CUBE";if(i.envMap)switch(i.envMapMode){case rr:case ar:t="ENVMAP_TYPE_CUBE";break;case mo:t="ENVMAP_TYPE_CUBE_UV";break}return t}function c1(i){let t="ENVMAP_MODE_REFLECTION";if(i.envMap)switch(i.envMapMode){case ar:t="ENVMAP_MODE_REFRACTION";break}return t}function u1(i){let t="ENVMAP_BLENDING_NONE";if(i.envMap)switch(i.combine){case Du:t="ENVMAP_BLENDING_MULTIPLY";break;case nf:t="ENVMAP_BLENDING_MIX";break;case sf:t="ENVMAP_BLENDING_ADD";break}return t}function h1(i){const t=i.envMapCubeUVHeight;if(t===null)return null;const e=Math.log2(t)-2,n=1/t;return{texelWidth:1/(3*Math.max(Math.pow(2,e),7*16)),texelHeight:n,maxMip:e}}function f1(i,t,e,n){const s=i.getContext(),r=e.defines;let a=e.vertexShader,o=e.fragmentShader;const l=o1(e),h=l1(e),f=c1(e),m=u1(e),u=h1(e),d=Qg(e),c=t1(r),v=s.createProgram();let p,x,w=e.glslVersion?"#version "+e.glslVersion+`
`:"";e.isRawShaderMaterial?(p=["#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,c].filter(Fr).join(`
`),p.length>0&&(p+=`
`),x=["#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,c].filter(Fr).join(`
`),x.length>0&&(x+=`
`)):(p=[L0(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,c,e.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",e.batching?"#define USE_BATCHING":"",e.batchingColor?"#define USE_BATCHING_COLOR":"",e.instancing?"#define USE_INSTANCING":"",e.instancingColor?"#define USE_INSTANCING_COLOR":"",e.instancingMorph?"#define USE_INSTANCING_MORPH":"",e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.map?"#define USE_MAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+f:"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.displacementMap?"#define USE_DISPLACEMENTMAP":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.mapUv?"#define MAP_UV "+e.mapUv:"",e.alphaMapUv?"#define ALPHAMAP_UV "+e.alphaMapUv:"",e.lightMapUv?"#define LIGHTMAP_UV "+e.lightMapUv:"",e.aoMapUv?"#define AOMAP_UV "+e.aoMapUv:"",e.emissiveMapUv?"#define EMISSIVEMAP_UV "+e.emissiveMapUv:"",e.bumpMapUv?"#define BUMPMAP_UV "+e.bumpMapUv:"",e.normalMapUv?"#define NORMALMAP_UV "+e.normalMapUv:"",e.displacementMapUv?"#define DISPLACEMENTMAP_UV "+e.displacementMapUv:"",e.metalnessMapUv?"#define METALNESSMAP_UV "+e.metalnessMapUv:"",e.roughnessMapUv?"#define ROUGHNESSMAP_UV "+e.roughnessMapUv:"",e.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+e.anisotropyMapUv:"",e.clearcoatMapUv?"#define CLEARCOATMAP_UV "+e.clearcoatMapUv:"",e.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+e.clearcoatNormalMapUv:"",e.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+e.clearcoatRoughnessMapUv:"",e.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+e.iridescenceMapUv:"",e.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+e.iridescenceThicknessMapUv:"",e.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+e.sheenColorMapUv:"",e.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+e.sheenRoughnessMapUv:"",e.specularMapUv?"#define SPECULARMAP_UV "+e.specularMapUv:"",e.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+e.specularColorMapUv:"",e.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+e.specularIntensityMapUv:"",e.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+e.transmissionMapUv:"",e.thicknessMapUv?"#define THICKNESSMAP_UV "+e.thicknessMapUv:"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.flatShading?"#define FLAT_SHADED":"",e.skinning?"#define USE_SKINNING":"",e.morphTargets?"#define USE_MORPHTARGETS":"",e.morphNormals&&e.flatShading===!1?"#define USE_MORPHNORMALS":"",e.morphColors?"#define USE_MORPHCOLORS":"",e.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+e.morphTextureStride:"",e.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+e.morphTargetsCount:"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+l:"",e.sizeAttenuation?"#define USE_SIZEATTENUATION":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",e.reverseDepthBuffer?"#define USE_REVERSEDEPTHBUF":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(Fr).join(`
`),x=[L0(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,c,e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",e.map?"#define USE_MAP":"",e.matcap?"#define USE_MATCAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+h:"",e.envMap?"#define "+f:"",e.envMap?"#define "+m:"",u?"#define CUBEUV_TEXEL_WIDTH "+u.texelWidth:"",u?"#define CUBEUV_TEXEL_HEIGHT "+u.texelHeight:"",u?"#define CUBEUV_MAX_MIP "+u.maxMip+".0":"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoat?"#define USE_CLEARCOAT":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.dispersion?"#define USE_DISPERSION":"",e.iridescence?"#define USE_IRIDESCENCE":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaTest?"#define USE_ALPHATEST":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.sheen?"#define USE_SHEEN":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors||e.instancingColor||e.batchingColor?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.gradientMap?"#define USE_GRADIENTMAP":"",e.flatShading?"#define FLAT_SHADED":"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+l:"",e.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",e.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",e.reverseDepthBuffer?"#define USE_REVERSEDEPTHBUF":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",e.toneMapping!==Bi?"#define TONE_MAPPING":"",e.toneMapping!==Bi?ye.tonemapping_pars_fragment:"",e.toneMapping!==Bi?jg("toneMapping",e.toneMapping):"",e.dithering?"#define DITHERING":"",e.opaque?"#define OPAQUE":"",ye.colorspace_pars_fragment,Zg("linearToOutputTexel",e.outputColorSpace),Jg(),e.useDepthPacking?"#define DEPTH_PACKING "+e.depthPacking:"",`
`].filter(Fr).join(`
`)),a=hc(a),a=P0(a,e),a=D0(a,e),o=hc(o),o=P0(o,e),o=D0(o,e),a=I0(a),o=I0(o),e.isRawShaderMaterial!==!0&&(w=`#version 300 es
`,p=[d,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+p,x=["#define varying in",e.glslVersion===Zc?"":"layout(location = 0) out highp vec4 pc_fragColor;",e.glslVersion===Zc?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+x);const b=w+p+a,C=w+x+o,V=C0(s,s.VERTEX_SHADER,b),D=C0(s,s.FRAGMENT_SHADER,C);s.attachShader(v,V),s.attachShader(v,D),e.index0AttributeName!==void 0?s.bindAttribLocation(v,0,e.index0AttributeName):e.morphTargets===!0&&s.bindAttribLocation(v,0,"position"),s.linkProgram(v);function A(z){if(i.debug.checkShaderErrors){const nt=s.getProgramInfoLog(v).trim(),q=s.getShaderInfoLog(V).trim(),j=s.getShaderInfoLog(D).trim();let Y=!0,W=!0;if(s.getProgramParameter(v,s.LINK_STATUS)===!1)if(Y=!1,typeof i.debug.onShaderError=="function")i.debug.onShaderError(s,v,V,D);else{const ht=R0(s,V,"vertex"),lt=R0(s,D,"fragment");console.error("THREE.WebGLProgram: Shader Error "+s.getError()+" - VALIDATE_STATUS "+s.getProgramParameter(v,s.VALIDATE_STATUS)+`

Material Name: `+z.name+`
Material Type: `+z.type+`

Program Info Log: `+nt+`
`+ht+`
`+lt)}else nt!==""?console.warn("THREE.WebGLProgram: Program Info Log:",nt):(q===""||j==="")&&(W=!1);W&&(z.diagnostics={runnable:Y,programLog:nt,vertexShader:{log:q,prefix:p},fragmentShader:{log:j,prefix:x}})}s.deleteShader(V),s.deleteShader(D),y=new Ka(s,v),rt=e1(s,v)}let y;this.getUniforms=function(){return y===void 0&&A(this),y};let rt;this.getAttributes=function(){return rt===void 0&&A(this),rt};let S=e.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return S===!1&&(S=s.getProgramParameter(v,qg)),S},this.destroy=function(){n.releaseStatesOfProgram(this),s.deleteProgram(v),this.program=void 0},this.type=e.shaderType,this.name=e.shaderName,this.id=Yg++,this.cacheKey=t,this.usedTimes=1,this.program=v,this.vertexShader=V,this.fragmentShader=D,this}let d1=0;class p1{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(t){const e=t.vertexShader,n=t.fragmentShader,s=this._getShaderStage(e),r=this._getShaderStage(n),a=this._getShaderCacheForMaterial(t);return a.has(s)===!1&&(a.add(s),s.usedTimes++),a.has(r)===!1&&(a.add(r),r.usedTimes++),this}remove(t){const e=this.materialCache.get(t);for(const n of e)n.usedTimes--,n.usedTimes===0&&this.shaderCache.delete(n.code);return this.materialCache.delete(t),this}getVertexShaderID(t){return this._getShaderStage(t.vertexShader).id}getFragmentShaderID(t){return this._getShaderStage(t.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(t){const e=this.materialCache;let n=e.get(t);return n===void 0&&(n=new Set,e.set(t,n)),n}_getShaderStage(t){const e=this.shaderCache;let n=e.get(t);return n===void 0&&(n=new m1(t),e.set(t,n)),n}}class m1{constructor(t){this.id=d1++,this.code=t,this.usedTimes=0}}function g1(i,t,e,n,s,r,a){const o=new Rc,l=new p1,h=new Set,f=[],m=s.logarithmicDepthBuffer,u=s.reverseDepthBuffer,d=s.vertexTextures;let c=s.precision;const v={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function p(S){return h.add(S),S===0?"uv":`uv${S}`}function x(S,z,nt,q,j){const Y=q.fog,W=j.geometry,ht=S.isMeshStandardMaterial?q.environment:null,lt=(S.isMeshStandardMaterial?e:t).get(S.envMap||ht),Dt=lt&&lt.mapping===mo?lt.image.height:null,yt=v[S.type];S.precision!==null&&(c=s.getMaxPrecision(S.precision),c!==S.precision&&console.warn("THREE.WebGLProgram.getParameters:",S.precision,"not supported, using",c,"instead."));const dt=W.morphAttributes.position||W.morphAttributes.normal||W.morphAttributes.color,et=dt!==void 0?dt.length:0;let Lt=0;W.morphAttributes.position!==void 0&&(Lt=1),W.morphAttributes.normal!==void 0&&(Lt=2),W.morphAttributes.color!==void 0&&(Lt=3);let k,at,gt,Mt;if(yt){const je=ci[yt];k=je.vertexShader,at=je.fragmentShader}else k=S.vertexShader,at=S.fragmentShader,l.update(S),gt=l.getVertexShaderID(S),Mt=l.getFragmentShaderID(S);const Et=i.getRenderTarget(),Bt=j.isInstancedMesh===!0,Zt=j.isBatchedMesh===!0,Xt=!!S.map,ie=!!S.matcap,$=!!lt,wt=!!S.aoMap,At=!!S.lightMap,ct=!!S.bumpMap,Ct=!!S.normalMap,jt=!!S.displacementMap,kt=!!S.emissiveMap,B=!!S.metalnessMap,P=!!S.roughnessMap,tt=S.anisotropy>0,vt=S.clearcoat>0,bt=S.dispersion>0,mt=S.iridescence>0,Ot=S.sheen>0,Ut=S.transmission>0,zt=tt&&!!S.anisotropyMap,te=vt&&!!S.clearcoatMap,St=vt&&!!S.clearcoatNormalMap,Ft=vt&&!!S.clearcoatRoughnessMap,re=mt&&!!S.iridescenceMap,ne=mt&&!!S.iridescenceThicknessMap,qt=Ot&&!!S.sheenColorMap,Qt=Ot&&!!S.sheenRoughnessMap,ae=!!S.specularMap,Ae=!!S.specularColorMap,Q=!!S.specularIntensityMap,Yt=Ut&&!!S.transmissionMap,_t=Ut&&!!S.thicknessMap,Tt=!!S.gradientMap,Vt=!!S.alphaMap,Wt=S.alphaTest>0,ge=!!S.alphaHash,Ee=!!S.extensions;let ke=Bi;S.toneMapped&&(Et===null||Et.isXRRenderTarget===!0)&&(ke=i.toneMapping);const me={shaderID:yt,shaderType:S.type,shaderName:S.name,vertexShader:k,fragmentShader:at,defines:S.defines,customVertexShaderID:gt,customFragmentShaderID:Mt,isRawShaderMaterial:S.isRawShaderMaterial===!0,glslVersion:S.glslVersion,precision:c,batching:Zt,batchingColor:Zt&&j._colorsTexture!==null,instancing:Bt,instancingColor:Bt&&j.instanceColor!==null,instancingMorph:Bt&&j.morphTexture!==null,supportsVertexTextures:d,outputColorSpace:Et===null?i.outputColorSpace:Et.isXRRenderTarget===!0?Et.texture.colorSpace:Gi,alphaToCoverage:!!S.alphaToCoverage,map:Xt,matcap:ie,envMap:$,envMapMode:$&&lt.mapping,envMapCubeUVHeight:Dt,aoMap:wt,lightMap:At,bumpMap:ct,normalMap:Ct,displacementMap:d&&jt,emissiveMap:kt,normalMapObjectSpace:Ct&&S.normalMapType===cf,normalMapTangentSpace:Ct&&S.normalMapType===Yu,metalnessMap:B,roughnessMap:P,anisotropy:tt,anisotropyMap:zt,clearcoat:vt,clearcoatMap:te,clearcoatNormalMap:St,clearcoatRoughnessMap:Ft,dispersion:bt,iridescence:mt,iridescenceMap:re,iridescenceThicknessMap:ne,sheen:Ot,sheenColorMap:qt,sheenRoughnessMap:Qt,specularMap:ae,specularColorMap:Ae,specularIntensityMap:Q,transmission:Ut,transmissionMap:Yt,thicknessMap:_t,gradientMap:Tt,opaque:S.transparent===!1&&S.blending===hs&&S.alphaToCoverage===!1,alphaMap:Vt,alphaTest:Wt,alphaHash:ge,combine:S.combine,mapUv:Xt&&p(S.map.channel),aoMapUv:wt&&p(S.aoMap.channel),lightMapUv:At&&p(S.lightMap.channel),bumpMapUv:ct&&p(S.bumpMap.channel),normalMapUv:Ct&&p(S.normalMap.channel),displacementMapUv:jt&&p(S.displacementMap.channel),emissiveMapUv:kt&&p(S.emissiveMap.channel),metalnessMapUv:B&&p(S.metalnessMap.channel),roughnessMapUv:P&&p(S.roughnessMap.channel),anisotropyMapUv:zt&&p(S.anisotropyMap.channel),clearcoatMapUv:te&&p(S.clearcoatMap.channel),clearcoatNormalMapUv:St&&p(S.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:Ft&&p(S.clearcoatRoughnessMap.channel),iridescenceMapUv:re&&p(S.iridescenceMap.channel),iridescenceThicknessMapUv:ne&&p(S.iridescenceThicknessMap.channel),sheenColorMapUv:qt&&p(S.sheenColorMap.channel),sheenRoughnessMapUv:Qt&&p(S.sheenRoughnessMap.channel),specularMapUv:ae&&p(S.specularMap.channel),specularColorMapUv:Ae&&p(S.specularColorMap.channel),specularIntensityMapUv:Q&&p(S.specularIntensityMap.channel),transmissionMapUv:Yt&&p(S.transmissionMap.channel),thicknessMapUv:_t&&p(S.thicknessMap.channel),alphaMapUv:Vt&&p(S.alphaMap.channel),vertexTangents:!!W.attributes.tangent&&(Ct||tt),vertexColors:S.vertexColors,vertexAlphas:S.vertexColors===!0&&!!W.attributes.color&&W.attributes.color.itemSize===4,pointsUvs:j.isPoints===!0&&!!W.attributes.uv&&(Xt||Vt),fog:!!Y,useFog:S.fog===!0,fogExp2:!!Y&&Y.isFogExp2,flatShading:S.flatShading===!0,sizeAttenuation:S.sizeAttenuation===!0,logarithmicDepthBuffer:m,reverseDepthBuffer:u,skinning:j.isSkinnedMesh===!0,morphTargets:W.morphAttributes.position!==void 0,morphNormals:W.morphAttributes.normal!==void 0,morphColors:W.morphAttributes.color!==void 0,morphTargetsCount:et,morphTextureStride:Lt,numDirLights:z.directional.length,numPointLights:z.point.length,numSpotLights:z.spot.length,numSpotLightMaps:z.spotLightMap.length,numRectAreaLights:z.rectArea.length,numHemiLights:z.hemi.length,numDirLightShadows:z.directionalShadowMap.length,numPointLightShadows:z.pointShadowMap.length,numSpotLightShadows:z.spotShadowMap.length,numSpotLightShadowsWithMaps:z.numSpotLightShadowsWithMaps,numLightProbes:z.numLightProbes,numClippingPlanes:a.numPlanes,numClipIntersection:a.numIntersection,dithering:S.dithering,shadowMapEnabled:i.shadowMap.enabled&&nt.length>0,shadowMapType:i.shadowMap.type,toneMapping:ke,decodeVideoTexture:Xt&&S.map.isVideoTexture===!0&&Ie.getTransfer(S.map.colorSpace)===He,premultipliedAlpha:S.premultipliedAlpha,doubleSided:S.side===ln,flipSided:S.side===fn,useDepthPacking:S.depthPacking>=0,depthPacking:S.depthPacking||0,index0AttributeName:S.index0AttributeName,extensionClipCullDistance:Ee&&S.extensions.clipCullDistance===!0&&n.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(Ee&&S.extensions.multiDraw===!0||Zt)&&n.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:n.has("KHR_parallel_shader_compile"),customProgramCacheKey:S.customProgramCacheKey()};return me.vertexUv1s=h.has(1),me.vertexUv2s=h.has(2),me.vertexUv3s=h.has(3),h.clear(),me}function w(S){const z=[];if(S.shaderID?z.push(S.shaderID):(z.push(S.customVertexShaderID),z.push(S.customFragmentShaderID)),S.defines!==void 0)for(const nt in S.defines)z.push(nt),z.push(S.defines[nt]);return S.isRawShaderMaterial===!1&&(b(z,S),C(z,S),z.push(i.outputColorSpace)),z.push(S.customProgramCacheKey),z.join()}function b(S,z){S.push(z.precision),S.push(z.outputColorSpace),S.push(z.envMapMode),S.push(z.envMapCubeUVHeight),S.push(z.mapUv),S.push(z.alphaMapUv),S.push(z.lightMapUv),S.push(z.aoMapUv),S.push(z.bumpMapUv),S.push(z.normalMapUv),S.push(z.displacementMapUv),S.push(z.emissiveMapUv),S.push(z.metalnessMapUv),S.push(z.roughnessMapUv),S.push(z.anisotropyMapUv),S.push(z.clearcoatMapUv),S.push(z.clearcoatNormalMapUv),S.push(z.clearcoatRoughnessMapUv),S.push(z.iridescenceMapUv),S.push(z.iridescenceThicknessMapUv),S.push(z.sheenColorMapUv),S.push(z.sheenRoughnessMapUv),S.push(z.specularMapUv),S.push(z.specularColorMapUv),S.push(z.specularIntensityMapUv),S.push(z.transmissionMapUv),S.push(z.thicknessMapUv),S.push(z.combine),S.push(z.fogExp2),S.push(z.sizeAttenuation),S.push(z.morphTargetsCount),S.push(z.morphAttributeCount),S.push(z.numDirLights),S.push(z.numPointLights),S.push(z.numSpotLights),S.push(z.numSpotLightMaps),S.push(z.numHemiLights),S.push(z.numRectAreaLights),S.push(z.numDirLightShadows),S.push(z.numPointLightShadows),S.push(z.numSpotLightShadows),S.push(z.numSpotLightShadowsWithMaps),S.push(z.numLightProbes),S.push(z.shadowMapType),S.push(z.toneMapping),S.push(z.numClippingPlanes),S.push(z.numClipIntersection),S.push(z.depthPacking)}function C(S,z){o.disableAll(),z.supportsVertexTextures&&o.enable(0),z.instancing&&o.enable(1),z.instancingColor&&o.enable(2),z.instancingMorph&&o.enable(3),z.matcap&&o.enable(4),z.envMap&&o.enable(5),z.normalMapObjectSpace&&o.enable(6),z.normalMapTangentSpace&&o.enable(7),z.clearcoat&&o.enable(8),z.iridescence&&o.enable(9),z.alphaTest&&o.enable(10),z.vertexColors&&o.enable(11),z.vertexAlphas&&o.enable(12),z.vertexUv1s&&o.enable(13),z.vertexUv2s&&o.enable(14),z.vertexUv3s&&o.enable(15),z.vertexTangents&&o.enable(16),z.anisotropy&&o.enable(17),z.alphaHash&&o.enable(18),z.batching&&o.enable(19),z.dispersion&&o.enable(20),z.batchingColor&&o.enable(21),S.push(o.mask),o.disableAll(),z.fog&&o.enable(0),z.useFog&&o.enable(1),z.flatShading&&o.enable(2),z.logarithmicDepthBuffer&&o.enable(3),z.reverseDepthBuffer&&o.enable(4),z.skinning&&o.enable(5),z.morphTargets&&o.enable(6),z.morphNormals&&o.enable(7),z.morphColors&&o.enable(8),z.premultipliedAlpha&&o.enable(9),z.shadowMapEnabled&&o.enable(10),z.doubleSided&&o.enable(11),z.flipSided&&o.enable(12),z.useDepthPacking&&o.enable(13),z.dithering&&o.enable(14),z.transmission&&o.enable(15),z.sheen&&o.enable(16),z.opaque&&o.enable(17),z.pointsUvs&&o.enable(18),z.decodeVideoTexture&&o.enable(19),z.alphaToCoverage&&o.enable(20),S.push(o.mask)}function V(S){const z=v[S.type];let nt;if(z){const q=ci[z];nt=Yr.clone(q.uniforms)}else nt=S.uniforms;return nt}function D(S,z){let nt;for(let q=0,j=f.length;q<j;q++){const Y=f[q];if(Y.cacheKey===z){nt=Y,++nt.usedTimes;break}}return nt===void 0&&(nt=new f1(i,z,S,r),f.push(nt)),nt}function A(S){if(--S.usedTimes===0){const z=f.indexOf(S);f[z]=f[f.length-1],f.pop(),S.destroy()}}function y(S){l.remove(S)}function rt(){l.dispose()}return{getParameters:x,getProgramCacheKey:w,getUniforms:V,acquireProgram:D,releaseProgram:A,releaseShaderCache:y,programs:f,dispose:rt}}function v1(){let i=new WeakMap;function t(a){return i.has(a)}function e(a){let o=i.get(a);return o===void 0&&(o={},i.set(a,o)),o}function n(a){i.delete(a)}function s(a,o,l){i.get(a)[o]=l}function r(){i=new WeakMap}return{has:t,get:e,remove:n,update:s,dispose:r}}function x1(i,t){return i.groupOrder!==t.groupOrder?i.groupOrder-t.groupOrder:i.renderOrder!==t.renderOrder?i.renderOrder-t.renderOrder:i.material.id!==t.material.id?i.material.id-t.material.id:i.z!==t.z?i.z-t.z:i.id-t.id}function U0(i,t){return i.groupOrder!==t.groupOrder?i.groupOrder-t.groupOrder:i.renderOrder!==t.renderOrder?i.renderOrder-t.renderOrder:i.z!==t.z?t.z-i.z:i.id-t.id}function z0(){const i=[];let t=0;const e=[],n=[],s=[];function r(){t=0,e.length=0,n.length=0,s.length=0}function a(m,u,d,c,v,p){let x=i[t];return x===void 0?(x={id:m.id,object:m,geometry:u,material:d,groupOrder:c,renderOrder:m.renderOrder,z:v,group:p},i[t]=x):(x.id=m.id,x.object=m,x.geometry=u,x.material=d,x.groupOrder=c,x.renderOrder=m.renderOrder,x.z=v,x.group=p),t++,x}function o(m,u,d,c,v,p){const x=a(m,u,d,c,v,p);d.transmission>0?n.push(x):d.transparent===!0?s.push(x):e.push(x)}function l(m,u,d,c,v,p){const x=a(m,u,d,c,v,p);d.transmission>0?n.unshift(x):d.transparent===!0?s.unshift(x):e.unshift(x)}function h(m,u){e.length>1&&e.sort(m||x1),n.length>1&&n.sort(u||U0),s.length>1&&s.sort(u||U0)}function f(){for(let m=t,u=i.length;m<u;m++){const d=i[m];if(d.id===null)break;d.id=null,d.object=null,d.geometry=null,d.material=null,d.group=null}}return{opaque:e,transmissive:n,transparent:s,init:r,push:o,unshift:l,finish:f,sort:h}}function _1(){let i=new WeakMap;function t(n,s){const r=i.get(n);let a;return r===void 0?(a=new z0,i.set(n,[a])):s>=r.length?(a=new z0,r.push(a)):a=r[s],a}function e(){i=new WeakMap}return{get:t,dispose:e}}function M1(){const i={};return{get:function(t){if(i[t.id]!==void 0)return i[t.id];let e;switch(t.type){case"DirectionalLight":e={direction:new N,color:new Jt};break;case"SpotLight":e={position:new N,direction:new N,color:new Jt,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":e={position:new N,color:new Jt,distance:0,decay:0};break;case"HemisphereLight":e={direction:new N,skyColor:new Jt,groundColor:new Jt};break;case"RectAreaLight":e={color:new Jt,position:new N,halfWidth:new N,halfHeight:new N};break}return i[t.id]=e,e}}}function y1(){const i={};return{get:function(t){if(i[t.id]!==void 0)return i[t.id];let e;switch(t.type){case"DirectionalLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Pt};break;case"SpotLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Pt};break;case"PointLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Pt,shadowCameraNear:1,shadowCameraFar:1e3};break}return i[t.id]=e,e}}}let S1=0;function w1(i,t){return(t.castShadow?2:0)-(i.castShadow?2:0)+(t.map?1:0)-(i.map?1:0)}function b1(i){const t=new M1,e=y1(),n={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let h=0;h<9;h++)n.probe.push(new N);const s=new N,r=new Pe,a=new Pe;function o(h){let f=0,m=0,u=0;for(let rt=0;rt<9;rt++)n.probe[rt].set(0,0,0);let d=0,c=0,v=0,p=0,x=0,w=0,b=0,C=0,V=0,D=0,A=0;h.sort(w1);for(let rt=0,S=h.length;rt<S;rt++){const z=h[rt],nt=z.color,q=z.intensity,j=z.distance,Y=z.shadow&&z.shadow.map?z.shadow.map.texture:null;if(z.isAmbientLight)f+=nt.r*q,m+=nt.g*q,u+=nt.b*q;else if(z.isLightProbe){for(let W=0;W<9;W++)n.probe[W].addScaledVector(z.sh.coefficients[W],q);A++}else if(z.isDirectionalLight){const W=t.get(z);if(W.color.copy(z.color).multiplyScalar(z.intensity),z.castShadow){const ht=z.shadow,lt=e.get(z);lt.shadowIntensity=ht.intensity,lt.shadowBias=ht.bias,lt.shadowNormalBias=ht.normalBias,lt.shadowRadius=ht.radius,lt.shadowMapSize=ht.mapSize,n.directionalShadow[d]=lt,n.directionalShadowMap[d]=Y,n.directionalShadowMatrix[d]=z.shadow.matrix,w++}n.directional[d]=W,d++}else if(z.isSpotLight){const W=t.get(z);W.position.setFromMatrixPosition(z.matrixWorld),W.color.copy(nt).multiplyScalar(q),W.distance=j,W.coneCos=Math.cos(z.angle),W.penumbraCos=Math.cos(z.angle*(1-z.penumbra)),W.decay=z.decay,n.spot[v]=W;const ht=z.shadow;if(z.map&&(n.spotLightMap[V]=z.map,V++,ht.updateMatrices(z),z.castShadow&&D++),n.spotLightMatrix[v]=ht.matrix,z.castShadow){const lt=e.get(z);lt.shadowIntensity=ht.intensity,lt.shadowBias=ht.bias,lt.shadowNormalBias=ht.normalBias,lt.shadowRadius=ht.radius,lt.shadowMapSize=ht.mapSize,n.spotShadow[v]=lt,n.spotShadowMap[v]=Y,C++}v++}else if(z.isRectAreaLight){const W=t.get(z);W.color.copy(nt).multiplyScalar(q),W.halfWidth.set(z.width*.5,0,0),W.halfHeight.set(0,z.height*.5,0),n.rectArea[p]=W,p++}else if(z.isPointLight){const W=t.get(z);if(W.color.copy(z.color).multiplyScalar(z.intensity),W.distance=z.distance,W.decay=z.decay,z.castShadow){const ht=z.shadow,lt=e.get(z);lt.shadowIntensity=ht.intensity,lt.shadowBias=ht.bias,lt.shadowNormalBias=ht.normalBias,lt.shadowRadius=ht.radius,lt.shadowMapSize=ht.mapSize,lt.shadowCameraNear=ht.camera.near,lt.shadowCameraFar=ht.camera.far,n.pointShadow[c]=lt,n.pointShadowMap[c]=Y,n.pointShadowMatrix[c]=z.shadow.matrix,b++}n.point[c]=W,c++}else if(z.isHemisphereLight){const W=t.get(z);W.skyColor.copy(z.color).multiplyScalar(q),W.groundColor.copy(z.groundColor).multiplyScalar(q),n.hemi[x]=W,x++}}p>0&&(i.has("OES_texture_float_linear")===!0?(n.rectAreaLTC1=Kt.LTC_FLOAT_1,n.rectAreaLTC2=Kt.LTC_FLOAT_2):(n.rectAreaLTC1=Kt.LTC_HALF_1,n.rectAreaLTC2=Kt.LTC_HALF_2)),n.ambient[0]=f,n.ambient[1]=m,n.ambient[2]=u;const y=n.hash;(y.directionalLength!==d||y.pointLength!==c||y.spotLength!==v||y.rectAreaLength!==p||y.hemiLength!==x||y.numDirectionalShadows!==w||y.numPointShadows!==b||y.numSpotShadows!==C||y.numSpotMaps!==V||y.numLightProbes!==A)&&(n.directional.length=d,n.spot.length=v,n.rectArea.length=p,n.point.length=c,n.hemi.length=x,n.directionalShadow.length=w,n.directionalShadowMap.length=w,n.pointShadow.length=b,n.pointShadowMap.length=b,n.spotShadow.length=C,n.spotShadowMap.length=C,n.directionalShadowMatrix.length=w,n.pointShadowMatrix.length=b,n.spotLightMatrix.length=C+V-D,n.spotLightMap.length=V,n.numSpotLightShadowsWithMaps=D,n.numLightProbes=A,y.directionalLength=d,y.pointLength=c,y.spotLength=v,y.rectAreaLength=p,y.hemiLength=x,y.numDirectionalShadows=w,y.numPointShadows=b,y.numSpotShadows=C,y.numSpotMaps=V,y.numLightProbes=A,n.version=S1++)}function l(h,f){let m=0,u=0,d=0,c=0,v=0;const p=f.matrixWorldInverse;for(let x=0,w=h.length;x<w;x++){const b=h[x];if(b.isDirectionalLight){const C=n.directional[m];C.direction.setFromMatrixPosition(b.matrixWorld),s.setFromMatrixPosition(b.target.matrixWorld),C.direction.sub(s),C.direction.transformDirection(p),m++}else if(b.isSpotLight){const C=n.spot[d];C.position.setFromMatrixPosition(b.matrixWorld),C.position.applyMatrix4(p),C.direction.setFromMatrixPosition(b.matrixWorld),s.setFromMatrixPosition(b.target.matrixWorld),C.direction.sub(s),C.direction.transformDirection(p),d++}else if(b.isRectAreaLight){const C=n.rectArea[c];C.position.setFromMatrixPosition(b.matrixWorld),C.position.applyMatrix4(p),a.identity(),r.copy(b.matrixWorld),r.premultiply(p),a.extractRotation(r),C.halfWidth.set(b.width*.5,0,0),C.halfHeight.set(0,b.height*.5,0),C.halfWidth.applyMatrix4(a),C.halfHeight.applyMatrix4(a),c++}else if(b.isPointLight){const C=n.point[u];C.position.setFromMatrixPosition(b.matrixWorld),C.position.applyMatrix4(p),u++}else if(b.isHemisphereLight){const C=n.hemi[v];C.direction.setFromMatrixPosition(b.matrixWorld),C.direction.transformDirection(p),v++}}}return{setup:o,setupView:l,state:n}}function N0(i){const t=new b1(i),e=[],n=[];function s(f){h.camera=f,e.length=0,n.length=0}function r(f){e.push(f)}function a(f){n.push(f)}function o(){t.setup(e)}function l(f){t.setupView(e,f)}const h={lightsArray:e,shadowsArray:n,camera:null,lights:t,transmissionRenderTarget:{}};return{init:s,state:h,setupLights:o,setupLightsView:l,pushLight:r,pushShadow:a}}function T1(i){let t=new WeakMap;function e(s,r=0){const a=t.get(s);let o;return a===void 0?(o=new N0(i),t.set(s,[o])):r>=a.length?(o=new N0(i),a.push(o)):o=a[r],o}function n(){t=new WeakMap}return{get:e,dispose:n}}class E1 extends Vi{constructor(t){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=of,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(t)}copy(t){return super.copy(t),this.depthPacking=t.depthPacking,this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this}}class A1 extends Vi{constructor(t){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(t)}copy(t){return super.copy(t),this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this}}const C1=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,R1=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function P1(i,t,e){let n=new Pc;const s=new Pt,r=new Pt,a=new Fe,o=new E1({depthPacking:lf}),l=new A1,h={},f=e.maxTextureSize,m={[Hi]:fn,[fn]:Hi,[ln]:ln},u=new Ke({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new Pt},radius:{value:4}},vertexShader:C1,fragmentShader:R1}),d=u.clone();d.defines.HORIZONTAL_PASS=1;const c=new Ye;c.setAttribute("position",new Ve(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const v=new K(c,u),p=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=Ru;let x=this.type;this.render=function(D,A,y){if(p.enabled===!1||p.autoUpdate===!1&&p.needsUpdate===!1||D.length===0)return;const rt=i.getRenderTarget(),S=i.getActiveCubeFace(),z=i.getActiveMipmapLevel(),nt=i.state;nt.setBlending(bi),nt.buffers.color.setClear(1,1,1,1),nt.buffers.depth.setTest(!0),nt.setScissorTest(!1);const q=x!==yi&&this.type===yi,j=x===yi&&this.type!==yi;for(let Y=0,W=D.length;Y<W;Y++){const ht=D[Y],lt=ht.shadow;if(lt===void 0){console.warn("THREE.WebGLShadowMap:",ht,"has no shadow.");continue}if(lt.autoUpdate===!1&&lt.needsUpdate===!1)continue;s.copy(lt.mapSize);const Dt=lt.getFrameExtents();if(s.multiply(Dt),r.copy(lt.mapSize),(s.x>f||s.y>f)&&(s.x>f&&(r.x=Math.floor(f/Dt.x),s.x=r.x*Dt.x,lt.mapSize.x=r.x),s.y>f&&(r.y=Math.floor(f/Dt.y),s.y=r.y*Dt.y,lt.mapSize.y=r.y)),lt.map===null||q===!0||j===!0){const dt=this.type!==yi?{minFilter:Dn,magFilter:Dn}:{};lt.map!==null&&lt.map.dispose(),lt.map=new $n(s.x,s.y,dt),lt.map.texture.name=ht.name+".shadowMap",lt.camera.updateProjectionMatrix()}i.setRenderTarget(lt.map),i.clear();const yt=lt.getViewportCount();for(let dt=0;dt<yt;dt++){const et=lt.getViewport(dt);a.set(r.x*et.x,r.y*et.y,r.x*et.z,r.y*et.w),nt.viewport(a),lt.updateMatrices(ht,dt),n=lt.getFrustum(),C(A,y,lt.camera,ht,this.type)}lt.isPointLightShadow!==!0&&this.type===yi&&w(lt,y),lt.needsUpdate=!1}x=this.type,p.needsUpdate=!1,i.setRenderTarget(rt,S,z)};function w(D,A){const y=t.update(v);u.defines.VSM_SAMPLES!==D.blurSamples&&(u.defines.VSM_SAMPLES=D.blurSamples,d.defines.VSM_SAMPLES=D.blurSamples,u.needsUpdate=!0,d.needsUpdate=!0),D.mapPass===null&&(D.mapPass=new $n(s.x,s.y)),u.uniforms.shadow_pass.value=D.map.texture,u.uniforms.resolution.value=D.mapSize,u.uniforms.radius.value=D.radius,i.setRenderTarget(D.mapPass),i.clear(),i.renderBufferDirect(A,null,y,u,v,null),d.uniforms.shadow_pass.value=D.mapPass.texture,d.uniforms.resolution.value=D.mapSize,d.uniforms.radius.value=D.radius,i.setRenderTarget(D.map),i.clear(),i.renderBufferDirect(A,null,y,d,v,null)}function b(D,A,y,rt){let S=null;const z=y.isPointLight===!0?D.customDistanceMaterial:D.customDepthMaterial;if(z!==void 0)S=z;else if(S=y.isPointLight===!0?l:o,i.localClippingEnabled&&A.clipShadows===!0&&Array.isArray(A.clippingPlanes)&&A.clippingPlanes.length!==0||A.displacementMap&&A.displacementScale!==0||A.alphaMap&&A.alphaTest>0||A.map&&A.alphaTest>0){const nt=S.uuid,q=A.uuid;let j=h[nt];j===void 0&&(j={},h[nt]=j);let Y=j[q];Y===void 0&&(Y=S.clone(),j[q]=Y,A.addEventListener("dispose",V)),S=Y}if(S.visible=A.visible,S.wireframe=A.wireframe,rt===yi?S.side=A.shadowSide!==null?A.shadowSide:A.side:S.side=A.shadowSide!==null?A.shadowSide:m[A.side],S.alphaMap=A.alphaMap,S.alphaTest=A.alphaTest,S.map=A.map,S.clipShadows=A.clipShadows,S.clippingPlanes=A.clippingPlanes,S.clipIntersection=A.clipIntersection,S.displacementMap=A.displacementMap,S.displacementScale=A.displacementScale,S.displacementBias=A.displacementBias,S.wireframeLinewidth=A.wireframeLinewidth,S.linewidth=A.linewidth,y.isPointLight===!0&&S.isMeshDistanceMaterial===!0){const nt=i.properties.get(S);nt.light=y}return S}function C(D,A,y,rt,S){if(D.visible===!1)return;if(D.layers.test(A.layers)&&(D.isMesh||D.isLine||D.isPoints)&&(D.castShadow||D.receiveShadow&&S===yi)&&(!D.frustumCulled||n.intersectsObject(D))){D.modelViewMatrix.multiplyMatrices(y.matrixWorldInverse,D.matrixWorld);const q=t.update(D),j=D.material;if(Array.isArray(j)){const Y=q.groups;for(let W=0,ht=Y.length;W<ht;W++){const lt=Y[W],Dt=j[lt.materialIndex];if(Dt&&Dt.visible){const yt=b(D,Dt,rt,S);D.onBeforeShadow(i,D,A,y,q,yt,lt),i.renderBufferDirect(y,null,q,yt,D,lt),D.onAfterShadow(i,D,A,y,q,yt,lt)}}}else if(j.visible){const Y=b(D,j,rt,S);D.onBeforeShadow(i,D,A,y,q,Y,null),i.renderBufferDirect(y,null,q,Y,D,null),D.onAfterShadow(i,D,A,y,q,Y,null)}}const nt=D.children;for(let q=0,j=nt.length;q<j;q++)C(nt[q],A,y,rt,S)}function V(D){D.target.removeEventListener("dispose",V);for(const y in h){const rt=h[y],S=D.target.uuid;S in rt&&(rt[S].dispose(),delete rt[S])}}}const D1={[Al]:Cl,[Rl]:Il,[Pl]:Ll,[sr]:Dl,[Cl]:Al,[Il]:Rl,[Ll]:Pl,[Dl]:sr};function I1(i){function t(){let Q=!1;const Yt=new Fe;let _t=null;const Tt=new Fe(0,0,0,0);return{setMask:function(Vt){_t!==Vt&&!Q&&(i.colorMask(Vt,Vt,Vt,Vt),_t=Vt)},setLocked:function(Vt){Q=Vt},setClear:function(Vt,Wt,ge,Ee,ke){ke===!0&&(Vt*=Ee,Wt*=Ee,ge*=Ee),Yt.set(Vt,Wt,ge,Ee),Tt.equals(Yt)===!1&&(i.clearColor(Vt,Wt,ge,Ee),Tt.copy(Yt))},reset:function(){Q=!1,_t=null,Tt.set(-1,0,0,0)}}}function e(){let Q=!1,Yt=!1,_t=null,Tt=null,Vt=null;return{setReversed:function(Wt){Yt=Wt},setTest:function(Wt){Wt?gt(i.DEPTH_TEST):Mt(i.DEPTH_TEST)},setMask:function(Wt){_t!==Wt&&!Q&&(i.depthMask(Wt),_t=Wt)},setFunc:function(Wt){if(Yt&&(Wt=D1[Wt]),Tt!==Wt){switch(Wt){case Al:i.depthFunc(i.NEVER);break;case Cl:i.depthFunc(i.ALWAYS);break;case Rl:i.depthFunc(i.LESS);break;case sr:i.depthFunc(i.LEQUAL);break;case Pl:i.depthFunc(i.EQUAL);break;case Dl:i.depthFunc(i.GEQUAL);break;case Il:i.depthFunc(i.GREATER);break;case Ll:i.depthFunc(i.NOTEQUAL);break;default:i.depthFunc(i.LEQUAL)}Tt=Wt}},setLocked:function(Wt){Q=Wt},setClear:function(Wt){Vt!==Wt&&(i.clearDepth(Wt),Vt=Wt)},reset:function(){Q=!1,_t=null,Tt=null,Vt=null}}}function n(){let Q=!1,Yt=null,_t=null,Tt=null,Vt=null,Wt=null,ge=null,Ee=null,ke=null;return{setTest:function(me){Q||(me?gt(i.STENCIL_TEST):Mt(i.STENCIL_TEST))},setMask:function(me){Yt!==me&&!Q&&(i.stencilMask(me),Yt=me)},setFunc:function(me,je,nn){(_t!==me||Tt!==je||Vt!==nn)&&(i.stencilFunc(me,je,nn),_t=me,Tt=je,Vt=nn)},setOp:function(me,je,nn){(Wt!==me||ge!==je||Ee!==nn)&&(i.stencilOp(me,je,nn),Wt=me,ge=je,Ee=nn)},setLocked:function(me){Q=me},setClear:function(me){ke!==me&&(i.clearStencil(me),ke=me)},reset:function(){Q=!1,Yt=null,_t=null,Tt=null,Vt=null,Wt=null,ge=null,Ee=null,ke=null}}}const s=new t,r=new e,a=new n,o=new WeakMap,l=new WeakMap;let h={},f={},m=new WeakMap,u=[],d=null,c=!1,v=null,p=null,x=null,w=null,b=null,C=null,V=null,D=new Jt(0,0,0),A=0,y=!1,rt=null,S=null,z=null,nt=null,q=null;const j=i.getParameter(i.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let Y=!1,W=0;const ht=i.getParameter(i.VERSION);ht.indexOf("WebGL")!==-1?(W=parseFloat(/^WebGL (\d)/.exec(ht)[1]),Y=W>=1):ht.indexOf("OpenGL ES")!==-1&&(W=parseFloat(/^OpenGL ES (\d)/.exec(ht)[1]),Y=W>=2);let lt=null,Dt={};const yt=i.getParameter(i.SCISSOR_BOX),dt=i.getParameter(i.VIEWPORT),et=new Fe().fromArray(yt),Lt=new Fe().fromArray(dt);function k(Q,Yt,_t,Tt){const Vt=new Uint8Array(4),Wt=i.createTexture();i.bindTexture(Q,Wt),i.texParameteri(Q,i.TEXTURE_MIN_FILTER,i.NEAREST),i.texParameteri(Q,i.TEXTURE_MAG_FILTER,i.NEAREST);for(let ge=0;ge<_t;ge++)Q===i.TEXTURE_3D||Q===i.TEXTURE_2D_ARRAY?i.texImage3D(Yt,0,i.RGBA,1,1,Tt,0,i.RGBA,i.UNSIGNED_BYTE,Vt):i.texImage2D(Yt+ge,0,i.RGBA,1,1,0,i.RGBA,i.UNSIGNED_BYTE,Vt);return Wt}const at={};at[i.TEXTURE_2D]=k(i.TEXTURE_2D,i.TEXTURE_2D,1),at[i.TEXTURE_CUBE_MAP]=k(i.TEXTURE_CUBE_MAP,i.TEXTURE_CUBE_MAP_POSITIVE_X,6),at[i.TEXTURE_2D_ARRAY]=k(i.TEXTURE_2D_ARRAY,i.TEXTURE_2D_ARRAY,1,1),at[i.TEXTURE_3D]=k(i.TEXTURE_3D,i.TEXTURE_3D,1,1),s.setClear(0,0,0,1),r.setClear(1),a.setClear(0),gt(i.DEPTH_TEST),r.setFunc(sr),At(!1),ct(qc),gt(i.CULL_FACE),$(bi);function gt(Q){h[Q]!==!0&&(i.enable(Q),h[Q]=!0)}function Mt(Q){h[Q]!==!1&&(i.disable(Q),h[Q]=!1)}function Et(Q,Yt){return f[Q]!==Yt?(i.bindFramebuffer(Q,Yt),f[Q]=Yt,Q===i.DRAW_FRAMEBUFFER&&(f[i.FRAMEBUFFER]=Yt),Q===i.FRAMEBUFFER&&(f[i.DRAW_FRAMEBUFFER]=Yt),!0):!1}function Bt(Q,Yt){let _t=u,Tt=!1;if(Q){_t=m.get(Yt),_t===void 0&&(_t=[],m.set(Yt,_t));const Vt=Q.textures;if(_t.length!==Vt.length||_t[0]!==i.COLOR_ATTACHMENT0){for(let Wt=0,ge=Vt.length;Wt<ge;Wt++)_t[Wt]=i.COLOR_ATTACHMENT0+Wt;_t.length=Vt.length,Tt=!0}}else _t[0]!==i.BACK&&(_t[0]=i.BACK,Tt=!0);Tt&&i.drawBuffers(_t)}function Zt(Q){return d!==Q?(i.useProgram(Q),d=Q,!0):!1}const Xt={[is]:i.FUNC_ADD,[Bh]:i.FUNC_SUBTRACT,[kh]:i.FUNC_REVERSE_SUBTRACT};Xt[Hh]=i.MIN,Xt[Gh]=i.MAX;const ie={[Vh]:i.ZERO,[Wh]:i.ONE,[Xh]:i.SRC_COLOR,[Tl]:i.SRC_ALPHA,[jh]:i.SRC_ALPHA_SATURATE,[Kh]:i.DST_COLOR,[Yh]:i.DST_ALPHA,[qh]:i.ONE_MINUS_SRC_COLOR,[El]:i.ONE_MINUS_SRC_ALPHA,[Zh]:i.ONE_MINUS_DST_COLOR,[$h]:i.ONE_MINUS_DST_ALPHA,[Jh]:i.CONSTANT_COLOR,[Qh]:i.ONE_MINUS_CONSTANT_COLOR,[tf]:i.CONSTANT_ALPHA,[ef]:i.ONE_MINUS_CONSTANT_ALPHA};function $(Q,Yt,_t,Tt,Vt,Wt,ge,Ee,ke,me){if(Q===bi){c===!0&&(Mt(i.BLEND),c=!1);return}if(c===!1&&(gt(i.BLEND),c=!0),Q!==Oh){if(Q!==v||me!==y){if((p!==is||b!==is)&&(i.blendEquation(i.FUNC_ADD),p=is,b=is),me)switch(Q){case hs:i.blendFuncSeparate(i.ONE,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case cn:i.blendFunc(i.ONE,i.ONE);break;case Yc:i.blendFuncSeparate(i.ZERO,i.ONE_MINUS_SRC_COLOR,i.ZERO,i.ONE);break;case $c:i.blendFuncSeparate(i.ZERO,i.SRC_COLOR,i.ZERO,i.SRC_ALPHA);break;default:console.error("THREE.WebGLState: Invalid blending: ",Q);break}else switch(Q){case hs:i.blendFuncSeparate(i.SRC_ALPHA,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case cn:i.blendFunc(i.SRC_ALPHA,i.ONE);break;case Yc:i.blendFuncSeparate(i.ZERO,i.ONE_MINUS_SRC_COLOR,i.ZERO,i.ONE);break;case $c:i.blendFunc(i.ZERO,i.SRC_COLOR);break;default:console.error("THREE.WebGLState: Invalid blending: ",Q);break}x=null,w=null,C=null,V=null,D.set(0,0,0),A=0,v=Q,y=me}return}Vt=Vt||Yt,Wt=Wt||_t,ge=ge||Tt,(Yt!==p||Vt!==b)&&(i.blendEquationSeparate(Xt[Yt],Xt[Vt]),p=Yt,b=Vt),(_t!==x||Tt!==w||Wt!==C||ge!==V)&&(i.blendFuncSeparate(ie[_t],ie[Tt],ie[Wt],ie[ge]),x=_t,w=Tt,C=Wt,V=ge),(Ee.equals(D)===!1||ke!==A)&&(i.blendColor(Ee.r,Ee.g,Ee.b,ke),D.copy(Ee),A=ke),v=Q,y=!1}function wt(Q,Yt){Q.side===ln?Mt(i.CULL_FACE):gt(i.CULL_FACE);let _t=Q.side===fn;Yt&&(_t=!_t),At(_t),Q.blending===hs&&Q.transparent===!1?$(bi):$(Q.blending,Q.blendEquation,Q.blendSrc,Q.blendDst,Q.blendEquationAlpha,Q.blendSrcAlpha,Q.blendDstAlpha,Q.blendColor,Q.blendAlpha,Q.premultipliedAlpha),r.setFunc(Q.depthFunc),r.setTest(Q.depthTest),r.setMask(Q.depthWrite),s.setMask(Q.colorWrite);const Tt=Q.stencilWrite;a.setTest(Tt),Tt&&(a.setMask(Q.stencilWriteMask),a.setFunc(Q.stencilFunc,Q.stencilRef,Q.stencilFuncMask),a.setOp(Q.stencilFail,Q.stencilZFail,Q.stencilZPass)),jt(Q.polygonOffset,Q.polygonOffsetFactor,Q.polygonOffsetUnits),Q.alphaToCoverage===!0?gt(i.SAMPLE_ALPHA_TO_COVERAGE):Mt(i.SAMPLE_ALPHA_TO_COVERAGE)}function At(Q){rt!==Q&&(Q?i.frontFace(i.CW):i.frontFace(i.CCW),rt=Q)}function ct(Q){Q!==Nh?(gt(i.CULL_FACE),Q!==S&&(Q===qc?i.cullFace(i.BACK):Q===Fh?i.cullFace(i.FRONT):i.cullFace(i.FRONT_AND_BACK))):Mt(i.CULL_FACE),S=Q}function Ct(Q){Q!==z&&(Y&&i.lineWidth(Q),z=Q)}function jt(Q,Yt,_t){Q?(gt(i.POLYGON_OFFSET_FILL),(nt!==Yt||q!==_t)&&(i.polygonOffset(Yt,_t),nt=Yt,q=_t)):Mt(i.POLYGON_OFFSET_FILL)}function kt(Q){Q?gt(i.SCISSOR_TEST):Mt(i.SCISSOR_TEST)}function B(Q){Q===void 0&&(Q=i.TEXTURE0+j-1),lt!==Q&&(i.activeTexture(Q),lt=Q)}function P(Q,Yt,_t){_t===void 0&&(lt===null?_t=i.TEXTURE0+j-1:_t=lt);let Tt=Dt[_t];Tt===void 0&&(Tt={type:void 0,texture:void 0},Dt[_t]=Tt),(Tt.type!==Q||Tt.texture!==Yt)&&(lt!==_t&&(i.activeTexture(_t),lt=_t),i.bindTexture(Q,Yt||at[Q]),Tt.type=Q,Tt.texture=Yt)}function tt(){const Q=Dt[lt];Q!==void 0&&Q.type!==void 0&&(i.bindTexture(Q.type,null),Q.type=void 0,Q.texture=void 0)}function vt(){try{i.compressedTexImage2D.apply(i,arguments)}catch(Q){console.error("THREE.WebGLState:",Q)}}function bt(){try{i.compressedTexImage3D.apply(i,arguments)}catch(Q){console.error("THREE.WebGLState:",Q)}}function mt(){try{i.texSubImage2D.apply(i,arguments)}catch(Q){console.error("THREE.WebGLState:",Q)}}function Ot(){try{i.texSubImage3D.apply(i,arguments)}catch(Q){console.error("THREE.WebGLState:",Q)}}function Ut(){try{i.compressedTexSubImage2D.apply(i,arguments)}catch(Q){console.error("THREE.WebGLState:",Q)}}function zt(){try{i.compressedTexSubImage3D.apply(i,arguments)}catch(Q){console.error("THREE.WebGLState:",Q)}}function te(){try{i.texStorage2D.apply(i,arguments)}catch(Q){console.error("THREE.WebGLState:",Q)}}function St(){try{i.texStorage3D.apply(i,arguments)}catch(Q){console.error("THREE.WebGLState:",Q)}}function Ft(){try{i.texImage2D.apply(i,arguments)}catch(Q){console.error("THREE.WebGLState:",Q)}}function re(){try{i.texImage3D.apply(i,arguments)}catch(Q){console.error("THREE.WebGLState:",Q)}}function ne(Q){et.equals(Q)===!1&&(i.scissor(Q.x,Q.y,Q.z,Q.w),et.copy(Q))}function qt(Q){Lt.equals(Q)===!1&&(i.viewport(Q.x,Q.y,Q.z,Q.w),Lt.copy(Q))}function Qt(Q,Yt){let _t=l.get(Yt);_t===void 0&&(_t=new WeakMap,l.set(Yt,_t));let Tt=_t.get(Q);Tt===void 0&&(Tt=i.getUniformBlockIndex(Yt,Q.name),_t.set(Q,Tt))}function ae(Q,Yt){const Tt=l.get(Yt).get(Q);o.get(Yt)!==Tt&&(i.uniformBlockBinding(Yt,Tt,Q.__bindingPointIndex),o.set(Yt,Tt))}function Ae(){i.disable(i.BLEND),i.disable(i.CULL_FACE),i.disable(i.DEPTH_TEST),i.disable(i.POLYGON_OFFSET_FILL),i.disable(i.SCISSOR_TEST),i.disable(i.STENCIL_TEST),i.disable(i.SAMPLE_ALPHA_TO_COVERAGE),i.blendEquation(i.FUNC_ADD),i.blendFunc(i.ONE,i.ZERO),i.blendFuncSeparate(i.ONE,i.ZERO,i.ONE,i.ZERO),i.blendColor(0,0,0,0),i.colorMask(!0,!0,!0,!0),i.clearColor(0,0,0,0),i.depthMask(!0),i.depthFunc(i.LESS),i.clearDepth(1),i.stencilMask(4294967295),i.stencilFunc(i.ALWAYS,0,4294967295),i.stencilOp(i.KEEP,i.KEEP,i.KEEP),i.clearStencil(0),i.cullFace(i.BACK),i.frontFace(i.CCW),i.polygonOffset(0,0),i.activeTexture(i.TEXTURE0),i.bindFramebuffer(i.FRAMEBUFFER,null),i.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),i.bindFramebuffer(i.READ_FRAMEBUFFER,null),i.useProgram(null),i.lineWidth(1),i.scissor(0,0,i.canvas.width,i.canvas.height),i.viewport(0,0,i.canvas.width,i.canvas.height),h={},lt=null,Dt={},f={},m=new WeakMap,u=[],d=null,c=!1,v=null,p=null,x=null,w=null,b=null,C=null,V=null,D=new Jt(0,0,0),A=0,y=!1,rt=null,S=null,z=null,nt=null,q=null,et.set(0,0,i.canvas.width,i.canvas.height),Lt.set(0,0,i.canvas.width,i.canvas.height),s.reset(),r.reset(),a.reset()}return{buffers:{color:s,depth:r,stencil:a},enable:gt,disable:Mt,bindFramebuffer:Et,drawBuffers:Bt,useProgram:Zt,setBlending:$,setMaterial:wt,setFlipSided:At,setCullFace:ct,setLineWidth:Ct,setPolygonOffset:jt,setScissorTest:kt,activeTexture:B,bindTexture:P,unbindTexture:tt,compressedTexImage2D:vt,compressedTexImage3D:bt,texImage2D:Ft,texImage3D:re,updateUBOMapping:Qt,uniformBlockBinding:ae,texStorage2D:te,texStorage3D:St,texSubImage2D:mt,texSubImage3D:Ot,compressedTexSubImage2D:Ut,compressedTexSubImage3D:zt,scissor:ne,viewport:qt,reset:Ae}}function F0(i,t,e,n){const s=L1(n);switch(e){case Hu:return i*t;case Vu:return i*t;case Wu:return i*t*2;case wc:return i*t/s.components*s.byteLength;case bc:return i*t/s.components*s.byteLength;case Xu:return i*t*2/s.components*s.byteLength;case Tc:return i*t*2/s.components*s.byteLength;case Gu:return i*t*3/s.components*s.byteLength;case ri:return i*t*4/s.components*s.byteLength;case Ec:return i*t*4/s.components*s.byteLength;case Va:case Wa:return Math.floor((i+3)/4)*Math.floor((t+3)/4)*8;case Xa:case qa:return Math.floor((i+3)/4)*Math.floor((t+3)/4)*16;case Ol:case kl:return Math.max(i,16)*Math.max(t,8)/4;case Fl:case Bl:return Math.max(i,8)*Math.max(t,8)/2;case Hl:case Gl:return Math.floor((i+3)/4)*Math.floor((t+3)/4)*8;case Vl:return Math.floor((i+3)/4)*Math.floor((t+3)/4)*16;case Wl:return Math.floor((i+3)/4)*Math.floor((t+3)/4)*16;case Xl:return Math.floor((i+4)/5)*Math.floor((t+3)/4)*16;case ql:return Math.floor((i+4)/5)*Math.floor((t+4)/5)*16;case Yl:return Math.floor((i+5)/6)*Math.floor((t+4)/5)*16;case $l:return Math.floor((i+5)/6)*Math.floor((t+5)/6)*16;case Kl:return Math.floor((i+7)/8)*Math.floor((t+4)/5)*16;case Zl:return Math.floor((i+7)/8)*Math.floor((t+5)/6)*16;case jl:return Math.floor((i+7)/8)*Math.floor((t+7)/8)*16;case Jl:return Math.floor((i+9)/10)*Math.floor((t+4)/5)*16;case Ql:return Math.floor((i+9)/10)*Math.floor((t+5)/6)*16;case tc:return Math.floor((i+9)/10)*Math.floor((t+7)/8)*16;case ec:return Math.floor((i+9)/10)*Math.floor((t+9)/10)*16;case nc:return Math.floor((i+11)/12)*Math.floor((t+9)/10)*16;case ic:return Math.floor((i+11)/12)*Math.floor((t+11)/12)*16;case Ya:case sc:case rc:return Math.ceil(i/4)*Math.ceil(t/4)*16;case qu:case ac:return Math.ceil(i/4)*Math.ceil(t/4)*8;case oc:case lc:return Math.ceil(i/4)*Math.ceil(t/4)*16}throw new Error(`Unable to determine texture byte length for ${e} format.`)}function L1(i){switch(i){case Ai:case Ou:return{byteLength:1,components:1};case Xr:case Bu:case pi:return{byteLength:2,components:1};case yc:case Sc:return{byteLength:2,components:4};case ps:case Mc:case fi:return{byteLength:4,components:1};case ku:return{byteLength:4,components:3}}throw new Error(`Unknown texture type ${i}.`)}function U1(i,t,e,n,s,r,a){const o=t.has("WEBGL_multisampled_render_to_texture")?t.get("WEBGL_multisampled_render_to_texture"):null,l=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),h=new Pt,f=new WeakMap;let m;const u=new WeakMap;let d=!1;try{d=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function c(B,P){return d?new OffscreenCanvas(B,P):no("canvas")}function v(B,P,tt){let vt=1;const bt=kt(B);if((bt.width>tt||bt.height>tt)&&(vt=tt/Math.max(bt.width,bt.height)),vt<1)if(typeof HTMLImageElement<"u"&&B instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&B instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&B instanceof ImageBitmap||typeof VideoFrame<"u"&&B instanceof VideoFrame){const mt=Math.floor(vt*bt.width),Ot=Math.floor(vt*bt.height);m===void 0&&(m=c(mt,Ot));const Ut=P?c(mt,Ot):m;return Ut.width=mt,Ut.height=Ot,Ut.getContext("2d").drawImage(B,0,0,mt,Ot),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+bt.width+"x"+bt.height+") to ("+mt+"x"+Ot+")."),Ut}else return"data"in B&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+bt.width+"x"+bt.height+")."),B;return B}function p(B){return B.generateMipmaps&&B.minFilter!==Dn&&B.minFilter!==Fn}function x(B){i.generateMipmap(B)}function w(B,P,tt,vt,bt=!1){if(B!==null){if(i[B]!==void 0)return i[B];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+B+"'")}let mt=P;if(P===i.RED&&(tt===i.FLOAT&&(mt=i.R32F),tt===i.HALF_FLOAT&&(mt=i.R16F),tt===i.UNSIGNED_BYTE&&(mt=i.R8)),P===i.RED_INTEGER&&(tt===i.UNSIGNED_BYTE&&(mt=i.R8UI),tt===i.UNSIGNED_SHORT&&(mt=i.R16UI),tt===i.UNSIGNED_INT&&(mt=i.R32UI),tt===i.BYTE&&(mt=i.R8I),tt===i.SHORT&&(mt=i.R16I),tt===i.INT&&(mt=i.R32I)),P===i.RG&&(tt===i.FLOAT&&(mt=i.RG32F),tt===i.HALF_FLOAT&&(mt=i.RG16F),tt===i.UNSIGNED_BYTE&&(mt=i.RG8)),P===i.RG_INTEGER&&(tt===i.UNSIGNED_BYTE&&(mt=i.RG8UI),tt===i.UNSIGNED_SHORT&&(mt=i.RG16UI),tt===i.UNSIGNED_INT&&(mt=i.RG32UI),tt===i.BYTE&&(mt=i.RG8I),tt===i.SHORT&&(mt=i.RG16I),tt===i.INT&&(mt=i.RG32I)),P===i.RGB_INTEGER&&(tt===i.UNSIGNED_BYTE&&(mt=i.RGB8UI),tt===i.UNSIGNED_SHORT&&(mt=i.RGB16UI),tt===i.UNSIGNED_INT&&(mt=i.RGB32UI),tt===i.BYTE&&(mt=i.RGB8I),tt===i.SHORT&&(mt=i.RGB16I),tt===i.INT&&(mt=i.RGB32I)),P===i.RGBA_INTEGER&&(tt===i.UNSIGNED_BYTE&&(mt=i.RGBA8UI),tt===i.UNSIGNED_SHORT&&(mt=i.RGBA16UI),tt===i.UNSIGNED_INT&&(mt=i.RGBA32UI),tt===i.BYTE&&(mt=i.RGBA8I),tt===i.SHORT&&(mt=i.RGBA16I),tt===i.INT&&(mt=i.RGBA32I)),P===i.RGB&&tt===i.UNSIGNED_INT_5_9_9_9_REV&&(mt=i.RGB9_E5),P===i.RGBA){const Ot=bt?Ja:Ie.getTransfer(vt);tt===i.FLOAT&&(mt=i.RGBA32F),tt===i.HALF_FLOAT&&(mt=i.RGBA16F),tt===i.UNSIGNED_BYTE&&(mt=Ot===He?i.SRGB8_ALPHA8:i.RGBA8),tt===i.UNSIGNED_SHORT_4_4_4_4&&(mt=i.RGBA4),tt===i.UNSIGNED_SHORT_5_5_5_1&&(mt=i.RGB5_A1)}return(mt===i.R16F||mt===i.R32F||mt===i.RG16F||mt===i.RG32F||mt===i.RGBA16F||mt===i.RGBA32F)&&t.get("EXT_color_buffer_float"),mt}function b(B,P){let tt;return B?P===null||P===ps||P===or?tt=i.DEPTH24_STENCIL8:P===fi?tt=i.DEPTH32F_STENCIL8:P===Xr&&(tt=i.DEPTH24_STENCIL8,console.warn("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):P===null||P===ps||P===or?tt=i.DEPTH_COMPONENT24:P===fi?tt=i.DEPTH_COMPONENT32F:P===Xr&&(tt=i.DEPTH_COMPONENT16),tt}function C(B,P){return p(B)===!0||B.isFramebufferTexture&&B.minFilter!==Dn&&B.minFilter!==Fn?Math.log2(Math.max(P.width,P.height))+1:B.mipmaps!==void 0&&B.mipmaps.length>0?B.mipmaps.length:B.isCompressedTexture&&Array.isArray(B.image)?P.mipmaps.length:1}function V(B){const P=B.target;P.removeEventListener("dispose",V),A(P),P.isVideoTexture&&f.delete(P)}function D(B){const P=B.target;P.removeEventListener("dispose",D),rt(P)}function A(B){const P=n.get(B);if(P.__webglInit===void 0)return;const tt=B.source,vt=u.get(tt);if(vt){const bt=vt[P.__cacheKey];bt.usedTimes--,bt.usedTimes===0&&y(B),Object.keys(vt).length===0&&u.delete(tt)}n.remove(B)}function y(B){const P=n.get(B);i.deleteTexture(P.__webglTexture);const tt=B.source,vt=u.get(tt);delete vt[P.__cacheKey],a.memory.textures--}function rt(B){const P=n.get(B);if(B.depthTexture&&B.depthTexture.dispose(),B.isWebGLCubeRenderTarget)for(let vt=0;vt<6;vt++){if(Array.isArray(P.__webglFramebuffer[vt]))for(let bt=0;bt<P.__webglFramebuffer[vt].length;bt++)i.deleteFramebuffer(P.__webglFramebuffer[vt][bt]);else i.deleteFramebuffer(P.__webglFramebuffer[vt]);P.__webglDepthbuffer&&i.deleteRenderbuffer(P.__webglDepthbuffer[vt])}else{if(Array.isArray(P.__webglFramebuffer))for(let vt=0;vt<P.__webglFramebuffer.length;vt++)i.deleteFramebuffer(P.__webglFramebuffer[vt]);else i.deleteFramebuffer(P.__webglFramebuffer);if(P.__webglDepthbuffer&&i.deleteRenderbuffer(P.__webglDepthbuffer),P.__webglMultisampledFramebuffer&&i.deleteFramebuffer(P.__webglMultisampledFramebuffer),P.__webglColorRenderbuffer)for(let vt=0;vt<P.__webglColorRenderbuffer.length;vt++)P.__webglColorRenderbuffer[vt]&&i.deleteRenderbuffer(P.__webglColorRenderbuffer[vt]);P.__webglDepthRenderbuffer&&i.deleteRenderbuffer(P.__webglDepthRenderbuffer)}const tt=B.textures;for(let vt=0,bt=tt.length;vt<bt;vt++){const mt=n.get(tt[vt]);mt.__webglTexture&&(i.deleteTexture(mt.__webglTexture),a.memory.textures--),n.remove(tt[vt])}n.remove(B)}let S=0;function z(){S=0}function nt(){const B=S;return B>=s.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+B+" texture units while this GPU supports only "+s.maxTextures),S+=1,B}function q(B){const P=[];return P.push(B.wrapS),P.push(B.wrapT),P.push(B.wrapR||0),P.push(B.magFilter),P.push(B.minFilter),P.push(B.anisotropy),P.push(B.internalFormat),P.push(B.format),P.push(B.type),P.push(B.generateMipmaps),P.push(B.premultiplyAlpha),P.push(B.flipY),P.push(B.unpackAlignment),P.push(B.colorSpace),P.join()}function j(B,P){const tt=n.get(B);if(B.isVideoTexture&&Ct(B),B.isRenderTargetTexture===!1&&B.version>0&&tt.__version!==B.version){const vt=B.image;if(vt===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else if(vt.complete===!1)console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete");else{Lt(tt,B,P);return}}e.bindTexture(i.TEXTURE_2D,tt.__webglTexture,i.TEXTURE0+P)}function Y(B,P){const tt=n.get(B);if(B.version>0&&tt.__version!==B.version){Lt(tt,B,P);return}e.bindTexture(i.TEXTURE_2D_ARRAY,tt.__webglTexture,i.TEXTURE0+P)}function W(B,P){const tt=n.get(B);if(B.version>0&&tt.__version!==B.version){Lt(tt,B,P);return}e.bindTexture(i.TEXTURE_3D,tt.__webglTexture,i.TEXTURE0+P)}function ht(B,P){const tt=n.get(B);if(B.version>0&&tt.__version!==B.version){k(tt,B,P);return}e.bindTexture(i.TEXTURE_CUBE_MAP,tt.__webglTexture,i.TEXTURE0+P)}const lt={[ds]:i.REPEAT,[Si]:i.CLAMP_TO_EDGE,[Nl]:i.MIRRORED_REPEAT},Dt={[Dn]:i.NEAREST,[af]:i.NEAREST_MIPMAP_NEAREST,[Qr]:i.NEAREST_MIPMAP_LINEAR,[Fn]:i.LINEAR,[wo]:i.LINEAR_MIPMAP_NEAREST,[cs]:i.LINEAR_MIPMAP_LINEAR},yt={[uf]:i.NEVER,[gf]:i.ALWAYS,[hf]:i.LESS,[$u]:i.LEQUAL,[ff]:i.EQUAL,[mf]:i.GEQUAL,[df]:i.GREATER,[pf]:i.NOTEQUAL};function dt(B,P){if(P.type===fi&&t.has("OES_texture_float_linear")===!1&&(P.magFilter===Fn||P.magFilter===wo||P.magFilter===Qr||P.magFilter===cs||P.minFilter===Fn||P.minFilter===wo||P.minFilter===Qr||P.minFilter===cs)&&console.warn("THREE.WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),i.texParameteri(B,i.TEXTURE_WRAP_S,lt[P.wrapS]),i.texParameteri(B,i.TEXTURE_WRAP_T,lt[P.wrapT]),(B===i.TEXTURE_3D||B===i.TEXTURE_2D_ARRAY)&&i.texParameteri(B,i.TEXTURE_WRAP_R,lt[P.wrapR]),i.texParameteri(B,i.TEXTURE_MAG_FILTER,Dt[P.magFilter]),i.texParameteri(B,i.TEXTURE_MIN_FILTER,Dt[P.minFilter]),P.compareFunction&&(i.texParameteri(B,i.TEXTURE_COMPARE_MODE,i.COMPARE_REF_TO_TEXTURE),i.texParameteri(B,i.TEXTURE_COMPARE_FUNC,yt[P.compareFunction])),t.has("EXT_texture_filter_anisotropic")===!0){if(P.magFilter===Dn||P.minFilter!==Qr&&P.minFilter!==cs||P.type===fi&&t.has("OES_texture_float_linear")===!1)return;if(P.anisotropy>1||n.get(P).__currentAnisotropy){const tt=t.get("EXT_texture_filter_anisotropic");i.texParameterf(B,tt.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(P.anisotropy,s.getMaxAnisotropy())),n.get(P).__currentAnisotropy=P.anisotropy}}}function et(B,P){let tt=!1;B.__webglInit===void 0&&(B.__webglInit=!0,P.addEventListener("dispose",V));const vt=P.source;let bt=u.get(vt);bt===void 0&&(bt={},u.set(vt,bt));const mt=q(P);if(mt!==B.__cacheKey){bt[mt]===void 0&&(bt[mt]={texture:i.createTexture(),usedTimes:0},a.memory.textures++,tt=!0),bt[mt].usedTimes++;const Ot=bt[B.__cacheKey];Ot!==void 0&&(bt[B.__cacheKey].usedTimes--,Ot.usedTimes===0&&y(P)),B.__cacheKey=mt,B.__webglTexture=bt[mt].texture}return tt}function Lt(B,P,tt){let vt=i.TEXTURE_2D;(P.isDataArrayTexture||P.isCompressedArrayTexture)&&(vt=i.TEXTURE_2D_ARRAY),P.isData3DTexture&&(vt=i.TEXTURE_3D);const bt=et(B,P),mt=P.source;e.bindTexture(vt,B.__webglTexture,i.TEXTURE0+tt);const Ot=n.get(mt);if(mt.version!==Ot.__version||bt===!0){e.activeTexture(i.TEXTURE0+tt);const Ut=Ie.getPrimaries(Ie.workingColorSpace),zt=P.colorSpace===ii?null:Ie.getPrimaries(P.colorSpace),te=P.colorSpace===ii||Ut===zt?i.NONE:i.BROWSER_DEFAULT_WEBGL;i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,P.flipY),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,P.premultiplyAlpha),i.pixelStorei(i.UNPACK_ALIGNMENT,P.unpackAlignment),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,te);let St=v(P.image,!1,s.maxTextureSize);St=jt(P,St);const Ft=r.convert(P.format,P.colorSpace),re=r.convert(P.type);let ne=w(P.internalFormat,Ft,re,P.colorSpace,P.isVideoTexture);dt(vt,P);let qt;const Qt=P.mipmaps,ae=P.isVideoTexture!==!0,Ae=Ot.__version===void 0||bt===!0,Q=mt.dataReady,Yt=C(P,St);if(P.isDepthTexture)ne=b(P.format===lr,P.type),Ae&&(ae?e.texStorage2D(i.TEXTURE_2D,1,ne,St.width,St.height):e.texImage2D(i.TEXTURE_2D,0,ne,St.width,St.height,0,Ft,re,null));else if(P.isDataTexture)if(Qt.length>0){ae&&Ae&&e.texStorage2D(i.TEXTURE_2D,Yt,ne,Qt[0].width,Qt[0].height);for(let _t=0,Tt=Qt.length;_t<Tt;_t++)qt=Qt[_t],ae?Q&&e.texSubImage2D(i.TEXTURE_2D,_t,0,0,qt.width,qt.height,Ft,re,qt.data):e.texImage2D(i.TEXTURE_2D,_t,ne,qt.width,qt.height,0,Ft,re,qt.data);P.generateMipmaps=!1}else ae?(Ae&&e.texStorage2D(i.TEXTURE_2D,Yt,ne,St.width,St.height),Q&&e.texSubImage2D(i.TEXTURE_2D,0,0,0,St.width,St.height,Ft,re,St.data)):e.texImage2D(i.TEXTURE_2D,0,ne,St.width,St.height,0,Ft,re,St.data);else if(P.isCompressedTexture)if(P.isCompressedArrayTexture){ae&&Ae&&e.texStorage3D(i.TEXTURE_2D_ARRAY,Yt,ne,Qt[0].width,Qt[0].height,St.depth);for(let _t=0,Tt=Qt.length;_t<Tt;_t++)if(qt=Qt[_t],P.format!==ri)if(Ft!==null)if(ae){if(Q)if(P.layerUpdates.size>0){const Vt=F0(qt.width,qt.height,P.format,P.type);for(const Wt of P.layerUpdates){const ge=qt.data.subarray(Wt*Vt/qt.data.BYTES_PER_ELEMENT,(Wt+1)*Vt/qt.data.BYTES_PER_ELEMENT);e.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,_t,0,0,Wt,qt.width,qt.height,1,Ft,ge,0,0)}P.clearLayerUpdates()}else e.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,_t,0,0,0,qt.width,qt.height,St.depth,Ft,qt.data,0,0)}else e.compressedTexImage3D(i.TEXTURE_2D_ARRAY,_t,ne,qt.width,qt.height,St.depth,0,qt.data,0,0);else console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else ae?Q&&e.texSubImage3D(i.TEXTURE_2D_ARRAY,_t,0,0,0,qt.width,qt.height,St.depth,Ft,re,qt.data):e.texImage3D(i.TEXTURE_2D_ARRAY,_t,ne,qt.width,qt.height,St.depth,0,Ft,re,qt.data)}else{ae&&Ae&&e.texStorage2D(i.TEXTURE_2D,Yt,ne,Qt[0].width,Qt[0].height);for(let _t=0,Tt=Qt.length;_t<Tt;_t++)qt=Qt[_t],P.format!==ri?Ft!==null?ae?Q&&e.compressedTexSubImage2D(i.TEXTURE_2D,_t,0,0,qt.width,qt.height,Ft,qt.data):e.compressedTexImage2D(i.TEXTURE_2D,_t,ne,qt.width,qt.height,0,qt.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):ae?Q&&e.texSubImage2D(i.TEXTURE_2D,_t,0,0,qt.width,qt.height,Ft,re,qt.data):e.texImage2D(i.TEXTURE_2D,_t,ne,qt.width,qt.height,0,Ft,re,qt.data)}else if(P.isDataArrayTexture)if(ae){if(Ae&&e.texStorage3D(i.TEXTURE_2D_ARRAY,Yt,ne,St.width,St.height,St.depth),Q)if(P.layerUpdates.size>0){const _t=F0(St.width,St.height,P.format,P.type);for(const Tt of P.layerUpdates){const Vt=St.data.subarray(Tt*_t/St.data.BYTES_PER_ELEMENT,(Tt+1)*_t/St.data.BYTES_PER_ELEMENT);e.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,Tt,St.width,St.height,1,Ft,re,Vt)}P.clearLayerUpdates()}else e.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,0,St.width,St.height,St.depth,Ft,re,St.data)}else e.texImage3D(i.TEXTURE_2D_ARRAY,0,ne,St.width,St.height,St.depth,0,Ft,re,St.data);else if(P.isData3DTexture)ae?(Ae&&e.texStorage3D(i.TEXTURE_3D,Yt,ne,St.width,St.height,St.depth),Q&&e.texSubImage3D(i.TEXTURE_3D,0,0,0,0,St.width,St.height,St.depth,Ft,re,St.data)):e.texImage3D(i.TEXTURE_3D,0,ne,St.width,St.height,St.depth,0,Ft,re,St.data);else if(P.isFramebufferTexture){if(Ae)if(ae)e.texStorage2D(i.TEXTURE_2D,Yt,ne,St.width,St.height);else{let _t=St.width,Tt=St.height;for(let Vt=0;Vt<Yt;Vt++)e.texImage2D(i.TEXTURE_2D,Vt,ne,_t,Tt,0,Ft,re,null),_t>>=1,Tt>>=1}}else if(Qt.length>0){if(ae&&Ae){const _t=kt(Qt[0]);e.texStorage2D(i.TEXTURE_2D,Yt,ne,_t.width,_t.height)}for(let _t=0,Tt=Qt.length;_t<Tt;_t++)qt=Qt[_t],ae?Q&&e.texSubImage2D(i.TEXTURE_2D,_t,0,0,Ft,re,qt):e.texImage2D(i.TEXTURE_2D,_t,ne,Ft,re,qt);P.generateMipmaps=!1}else if(ae){if(Ae){const _t=kt(St);e.texStorage2D(i.TEXTURE_2D,Yt,ne,_t.width,_t.height)}Q&&e.texSubImage2D(i.TEXTURE_2D,0,0,0,Ft,re,St)}else e.texImage2D(i.TEXTURE_2D,0,ne,Ft,re,St);p(P)&&x(vt),Ot.__version=mt.version,P.onUpdate&&P.onUpdate(P)}B.__version=P.version}function k(B,P,tt){if(P.image.length!==6)return;const vt=et(B,P),bt=P.source;e.bindTexture(i.TEXTURE_CUBE_MAP,B.__webglTexture,i.TEXTURE0+tt);const mt=n.get(bt);if(bt.version!==mt.__version||vt===!0){e.activeTexture(i.TEXTURE0+tt);const Ot=Ie.getPrimaries(Ie.workingColorSpace),Ut=P.colorSpace===ii?null:Ie.getPrimaries(P.colorSpace),zt=P.colorSpace===ii||Ot===Ut?i.NONE:i.BROWSER_DEFAULT_WEBGL;i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,P.flipY),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,P.premultiplyAlpha),i.pixelStorei(i.UNPACK_ALIGNMENT,P.unpackAlignment),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,zt);const te=P.isCompressedTexture||P.image[0].isCompressedTexture,St=P.image[0]&&P.image[0].isDataTexture,Ft=[];for(let Tt=0;Tt<6;Tt++)!te&&!St?Ft[Tt]=v(P.image[Tt],!0,s.maxCubemapSize):Ft[Tt]=St?P.image[Tt].image:P.image[Tt],Ft[Tt]=jt(P,Ft[Tt]);const re=Ft[0],ne=r.convert(P.format,P.colorSpace),qt=r.convert(P.type),Qt=w(P.internalFormat,ne,qt,P.colorSpace),ae=P.isVideoTexture!==!0,Ae=mt.__version===void 0||vt===!0,Q=bt.dataReady;let Yt=C(P,re);dt(i.TEXTURE_CUBE_MAP,P);let _t;if(te){ae&&Ae&&e.texStorage2D(i.TEXTURE_CUBE_MAP,Yt,Qt,re.width,re.height);for(let Tt=0;Tt<6;Tt++){_t=Ft[Tt].mipmaps;for(let Vt=0;Vt<_t.length;Vt++){const Wt=_t[Vt];P.format!==ri?ne!==null?ae?Q&&e.compressedTexSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Tt,Vt,0,0,Wt.width,Wt.height,ne,Wt.data):e.compressedTexImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Tt,Vt,Qt,Wt.width,Wt.height,0,Wt.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):ae?Q&&e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Tt,Vt,0,0,Wt.width,Wt.height,ne,qt,Wt.data):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Tt,Vt,Qt,Wt.width,Wt.height,0,ne,qt,Wt.data)}}}else{if(_t=P.mipmaps,ae&&Ae){_t.length>0&&Yt++;const Tt=kt(Ft[0]);e.texStorage2D(i.TEXTURE_CUBE_MAP,Yt,Qt,Tt.width,Tt.height)}for(let Tt=0;Tt<6;Tt++)if(St){ae?Q&&e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Tt,0,0,0,Ft[Tt].width,Ft[Tt].height,ne,qt,Ft[Tt].data):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Tt,0,Qt,Ft[Tt].width,Ft[Tt].height,0,ne,qt,Ft[Tt].data);for(let Vt=0;Vt<_t.length;Vt++){const ge=_t[Vt].image[Tt].image;ae?Q&&e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Tt,Vt+1,0,0,ge.width,ge.height,ne,qt,ge.data):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Tt,Vt+1,Qt,ge.width,ge.height,0,ne,qt,ge.data)}}else{ae?Q&&e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Tt,0,0,0,ne,qt,Ft[Tt]):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Tt,0,Qt,ne,qt,Ft[Tt]);for(let Vt=0;Vt<_t.length;Vt++){const Wt=_t[Vt];ae?Q&&e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Tt,Vt+1,0,0,ne,qt,Wt.image[Tt]):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Tt,Vt+1,Qt,ne,qt,Wt.image[Tt])}}}p(P)&&x(i.TEXTURE_CUBE_MAP),mt.__version=bt.version,P.onUpdate&&P.onUpdate(P)}B.__version=P.version}function at(B,P,tt,vt,bt,mt){const Ot=r.convert(tt.format,tt.colorSpace),Ut=r.convert(tt.type),zt=w(tt.internalFormat,Ot,Ut,tt.colorSpace);if(!n.get(P).__hasExternalTextures){const St=Math.max(1,P.width>>mt),Ft=Math.max(1,P.height>>mt);bt===i.TEXTURE_3D||bt===i.TEXTURE_2D_ARRAY?e.texImage3D(bt,mt,zt,St,Ft,P.depth,0,Ot,Ut,null):e.texImage2D(bt,mt,zt,St,Ft,0,Ot,Ut,null)}e.bindFramebuffer(i.FRAMEBUFFER,B),ct(P)?o.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,vt,bt,n.get(tt).__webglTexture,0,At(P)):(bt===i.TEXTURE_2D||bt>=i.TEXTURE_CUBE_MAP_POSITIVE_X&&bt<=i.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&i.framebufferTexture2D(i.FRAMEBUFFER,vt,bt,n.get(tt).__webglTexture,mt),e.bindFramebuffer(i.FRAMEBUFFER,null)}function gt(B,P,tt){if(i.bindRenderbuffer(i.RENDERBUFFER,B),P.depthBuffer){const vt=P.depthTexture,bt=vt&&vt.isDepthTexture?vt.type:null,mt=b(P.stencilBuffer,bt),Ot=P.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,Ut=At(P);ct(P)?o.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,Ut,mt,P.width,P.height):tt?i.renderbufferStorageMultisample(i.RENDERBUFFER,Ut,mt,P.width,P.height):i.renderbufferStorage(i.RENDERBUFFER,mt,P.width,P.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,Ot,i.RENDERBUFFER,B)}else{const vt=P.textures;for(let bt=0;bt<vt.length;bt++){const mt=vt[bt],Ot=r.convert(mt.format,mt.colorSpace),Ut=r.convert(mt.type),zt=w(mt.internalFormat,Ot,Ut,mt.colorSpace),te=At(P);tt&&ct(P)===!1?i.renderbufferStorageMultisample(i.RENDERBUFFER,te,zt,P.width,P.height):ct(P)?o.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,te,zt,P.width,P.height):i.renderbufferStorage(i.RENDERBUFFER,zt,P.width,P.height)}}i.bindRenderbuffer(i.RENDERBUFFER,null)}function Mt(B,P){if(P&&P.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(e.bindFramebuffer(i.FRAMEBUFFER,B),!(P.depthTexture&&P.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");(!n.get(P.depthTexture).__webglTexture||P.depthTexture.image.width!==P.width||P.depthTexture.image.height!==P.height)&&(P.depthTexture.image.width=P.width,P.depthTexture.image.height=P.height,P.depthTexture.needsUpdate=!0),j(P.depthTexture,0);const vt=n.get(P.depthTexture).__webglTexture,bt=At(P);if(P.depthTexture.format===tr)ct(P)?o.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,i.DEPTH_ATTACHMENT,i.TEXTURE_2D,vt,0,bt):i.framebufferTexture2D(i.FRAMEBUFFER,i.DEPTH_ATTACHMENT,i.TEXTURE_2D,vt,0);else if(P.depthTexture.format===lr)ct(P)?o.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,i.DEPTH_STENCIL_ATTACHMENT,i.TEXTURE_2D,vt,0,bt):i.framebufferTexture2D(i.FRAMEBUFFER,i.DEPTH_STENCIL_ATTACHMENT,i.TEXTURE_2D,vt,0);else throw new Error("Unknown depthTexture format")}function Et(B){const P=n.get(B),tt=B.isWebGLCubeRenderTarget===!0;if(P.__boundDepthTexture!==B.depthTexture){const vt=B.depthTexture;if(P.__depthDisposeCallback&&P.__depthDisposeCallback(),vt){const bt=()=>{delete P.__boundDepthTexture,delete P.__depthDisposeCallback,vt.removeEventListener("dispose",bt)};vt.addEventListener("dispose",bt),P.__depthDisposeCallback=bt}P.__boundDepthTexture=vt}if(B.depthTexture&&!P.__autoAllocateDepthBuffer){if(tt)throw new Error("target.depthTexture not supported in Cube render targets");Mt(P.__webglFramebuffer,B)}else if(tt){P.__webglDepthbuffer=[];for(let vt=0;vt<6;vt++)if(e.bindFramebuffer(i.FRAMEBUFFER,P.__webglFramebuffer[vt]),P.__webglDepthbuffer[vt]===void 0)P.__webglDepthbuffer[vt]=i.createRenderbuffer(),gt(P.__webglDepthbuffer[vt],B,!1);else{const bt=B.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,mt=P.__webglDepthbuffer[vt];i.bindRenderbuffer(i.RENDERBUFFER,mt),i.framebufferRenderbuffer(i.FRAMEBUFFER,bt,i.RENDERBUFFER,mt)}}else if(e.bindFramebuffer(i.FRAMEBUFFER,P.__webglFramebuffer),P.__webglDepthbuffer===void 0)P.__webglDepthbuffer=i.createRenderbuffer(),gt(P.__webglDepthbuffer,B,!1);else{const vt=B.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,bt=P.__webglDepthbuffer;i.bindRenderbuffer(i.RENDERBUFFER,bt),i.framebufferRenderbuffer(i.FRAMEBUFFER,vt,i.RENDERBUFFER,bt)}e.bindFramebuffer(i.FRAMEBUFFER,null)}function Bt(B,P,tt){const vt=n.get(B);P!==void 0&&at(vt.__webglFramebuffer,B,B.texture,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,0),tt!==void 0&&Et(B)}function Zt(B){const P=B.texture,tt=n.get(B),vt=n.get(P);B.addEventListener("dispose",D);const bt=B.textures,mt=B.isWebGLCubeRenderTarget===!0,Ot=bt.length>1;if(Ot||(vt.__webglTexture===void 0&&(vt.__webglTexture=i.createTexture()),vt.__version=P.version,a.memory.textures++),mt){tt.__webglFramebuffer=[];for(let Ut=0;Ut<6;Ut++)if(P.mipmaps&&P.mipmaps.length>0){tt.__webglFramebuffer[Ut]=[];for(let zt=0;zt<P.mipmaps.length;zt++)tt.__webglFramebuffer[Ut][zt]=i.createFramebuffer()}else tt.__webglFramebuffer[Ut]=i.createFramebuffer()}else{if(P.mipmaps&&P.mipmaps.length>0){tt.__webglFramebuffer=[];for(let Ut=0;Ut<P.mipmaps.length;Ut++)tt.__webglFramebuffer[Ut]=i.createFramebuffer()}else tt.__webglFramebuffer=i.createFramebuffer();if(Ot)for(let Ut=0,zt=bt.length;Ut<zt;Ut++){const te=n.get(bt[Ut]);te.__webglTexture===void 0&&(te.__webglTexture=i.createTexture(),a.memory.textures++)}if(B.samples>0&&ct(B)===!1){tt.__webglMultisampledFramebuffer=i.createFramebuffer(),tt.__webglColorRenderbuffer=[],e.bindFramebuffer(i.FRAMEBUFFER,tt.__webglMultisampledFramebuffer);for(let Ut=0;Ut<bt.length;Ut++){const zt=bt[Ut];tt.__webglColorRenderbuffer[Ut]=i.createRenderbuffer(),i.bindRenderbuffer(i.RENDERBUFFER,tt.__webglColorRenderbuffer[Ut]);const te=r.convert(zt.format,zt.colorSpace),St=r.convert(zt.type),Ft=w(zt.internalFormat,te,St,zt.colorSpace,B.isXRRenderTarget===!0),re=At(B);i.renderbufferStorageMultisample(i.RENDERBUFFER,re,Ft,B.width,B.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+Ut,i.RENDERBUFFER,tt.__webglColorRenderbuffer[Ut])}i.bindRenderbuffer(i.RENDERBUFFER,null),B.depthBuffer&&(tt.__webglDepthRenderbuffer=i.createRenderbuffer(),gt(tt.__webglDepthRenderbuffer,B,!0)),e.bindFramebuffer(i.FRAMEBUFFER,null)}}if(mt){e.bindTexture(i.TEXTURE_CUBE_MAP,vt.__webglTexture),dt(i.TEXTURE_CUBE_MAP,P);for(let Ut=0;Ut<6;Ut++)if(P.mipmaps&&P.mipmaps.length>0)for(let zt=0;zt<P.mipmaps.length;zt++)at(tt.__webglFramebuffer[Ut][zt],B,P,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+Ut,zt);else at(tt.__webglFramebuffer[Ut],B,P,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+Ut,0);p(P)&&x(i.TEXTURE_CUBE_MAP),e.unbindTexture()}else if(Ot){for(let Ut=0,zt=bt.length;Ut<zt;Ut++){const te=bt[Ut],St=n.get(te);e.bindTexture(i.TEXTURE_2D,St.__webglTexture),dt(i.TEXTURE_2D,te),at(tt.__webglFramebuffer,B,te,i.COLOR_ATTACHMENT0+Ut,i.TEXTURE_2D,0),p(te)&&x(i.TEXTURE_2D)}e.unbindTexture()}else{let Ut=i.TEXTURE_2D;if((B.isWebGL3DRenderTarget||B.isWebGLArrayRenderTarget)&&(Ut=B.isWebGL3DRenderTarget?i.TEXTURE_3D:i.TEXTURE_2D_ARRAY),e.bindTexture(Ut,vt.__webglTexture),dt(Ut,P),P.mipmaps&&P.mipmaps.length>0)for(let zt=0;zt<P.mipmaps.length;zt++)at(tt.__webglFramebuffer[zt],B,P,i.COLOR_ATTACHMENT0,Ut,zt);else at(tt.__webglFramebuffer,B,P,i.COLOR_ATTACHMENT0,Ut,0);p(P)&&x(Ut),e.unbindTexture()}B.depthBuffer&&Et(B)}function Xt(B){const P=B.textures;for(let tt=0,vt=P.length;tt<vt;tt++){const bt=P[tt];if(p(bt)){const mt=B.isWebGLCubeRenderTarget?i.TEXTURE_CUBE_MAP:i.TEXTURE_2D,Ot=n.get(bt).__webglTexture;e.bindTexture(mt,Ot),x(mt),e.unbindTexture()}}}const ie=[],$=[];function wt(B){if(B.samples>0){if(ct(B)===!1){const P=B.textures,tt=B.width,vt=B.height;let bt=i.COLOR_BUFFER_BIT;const mt=B.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,Ot=n.get(B),Ut=P.length>1;if(Ut)for(let zt=0;zt<P.length;zt++)e.bindFramebuffer(i.FRAMEBUFFER,Ot.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+zt,i.RENDERBUFFER,null),e.bindFramebuffer(i.FRAMEBUFFER,Ot.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+zt,i.TEXTURE_2D,null,0);e.bindFramebuffer(i.READ_FRAMEBUFFER,Ot.__webglMultisampledFramebuffer),e.bindFramebuffer(i.DRAW_FRAMEBUFFER,Ot.__webglFramebuffer);for(let zt=0;zt<P.length;zt++){if(B.resolveDepthBuffer&&(B.depthBuffer&&(bt|=i.DEPTH_BUFFER_BIT),B.stencilBuffer&&B.resolveStencilBuffer&&(bt|=i.STENCIL_BUFFER_BIT)),Ut){i.framebufferRenderbuffer(i.READ_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.RENDERBUFFER,Ot.__webglColorRenderbuffer[zt]);const te=n.get(P[zt]).__webglTexture;i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,te,0)}i.blitFramebuffer(0,0,tt,vt,0,0,tt,vt,bt,i.NEAREST),l===!0&&(ie.length=0,$.length=0,ie.push(i.COLOR_ATTACHMENT0+zt),B.depthBuffer&&B.resolveDepthBuffer===!1&&(ie.push(mt),$.push(mt),i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,$)),i.invalidateFramebuffer(i.READ_FRAMEBUFFER,ie))}if(e.bindFramebuffer(i.READ_FRAMEBUFFER,null),e.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),Ut)for(let zt=0;zt<P.length;zt++){e.bindFramebuffer(i.FRAMEBUFFER,Ot.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+zt,i.RENDERBUFFER,Ot.__webglColorRenderbuffer[zt]);const te=n.get(P[zt]).__webglTexture;e.bindFramebuffer(i.FRAMEBUFFER,Ot.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+zt,i.TEXTURE_2D,te,0)}e.bindFramebuffer(i.DRAW_FRAMEBUFFER,Ot.__webglMultisampledFramebuffer)}else if(B.depthBuffer&&B.resolveDepthBuffer===!1&&l){const P=B.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT;i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,[P])}}}function At(B){return Math.min(s.maxSamples,B.samples)}function ct(B){const P=n.get(B);return B.samples>0&&t.has("WEBGL_multisampled_render_to_texture")===!0&&P.__useRenderToTexture!==!1}function Ct(B){const P=a.render.frame;f.get(B)!==P&&(f.set(B,P),B.update())}function jt(B,P){const tt=B.colorSpace,vt=B.format,bt=B.type;return B.isCompressedTexture===!0||B.isVideoTexture===!0||tt!==Gi&&tt!==ii&&(Ie.getTransfer(tt)===He?(vt!==ri||bt!==Ai)&&console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",tt)),P}function kt(B){return typeof HTMLImageElement<"u"&&B instanceof HTMLImageElement?(h.width=B.naturalWidth||B.width,h.height=B.naturalHeight||B.height):typeof VideoFrame<"u"&&B instanceof VideoFrame?(h.width=B.displayWidth,h.height=B.displayHeight):(h.width=B.width,h.height=B.height),h}this.allocateTextureUnit=nt,this.resetTextureUnits=z,this.setTexture2D=j,this.setTexture2DArray=Y,this.setTexture3D=W,this.setTextureCube=ht,this.rebindTextures=Bt,this.setupRenderTarget=Zt,this.updateRenderTargetMipmap=Xt,this.updateMultisampleRenderTarget=wt,this.setupDepthRenderbuffer=Et,this.setupFrameBufferTexture=at,this.useMultisampledRTT=ct}function z1(i,t){function e(n,s=ii){let r;const a=Ie.getTransfer(s);if(n===Ai)return i.UNSIGNED_BYTE;if(n===yc)return i.UNSIGNED_SHORT_4_4_4_4;if(n===Sc)return i.UNSIGNED_SHORT_5_5_5_1;if(n===ku)return i.UNSIGNED_INT_5_9_9_9_REV;if(n===Ou)return i.BYTE;if(n===Bu)return i.SHORT;if(n===Xr)return i.UNSIGNED_SHORT;if(n===Mc)return i.INT;if(n===ps)return i.UNSIGNED_INT;if(n===fi)return i.FLOAT;if(n===pi)return i.HALF_FLOAT;if(n===Hu)return i.ALPHA;if(n===Gu)return i.RGB;if(n===ri)return i.RGBA;if(n===Vu)return i.LUMINANCE;if(n===Wu)return i.LUMINANCE_ALPHA;if(n===tr)return i.DEPTH_COMPONENT;if(n===lr)return i.DEPTH_STENCIL;if(n===wc)return i.RED;if(n===bc)return i.RED_INTEGER;if(n===Xu)return i.RG;if(n===Tc)return i.RG_INTEGER;if(n===Ec)return i.RGBA_INTEGER;if(n===Va||n===Wa||n===Xa||n===qa)if(a===He)if(r=t.get("WEBGL_compressed_texture_s3tc_srgb"),r!==null){if(n===Va)return r.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(n===Wa)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(n===Xa)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(n===qa)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(r=t.get("WEBGL_compressed_texture_s3tc"),r!==null){if(n===Va)return r.COMPRESSED_RGB_S3TC_DXT1_EXT;if(n===Wa)return r.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(n===Xa)return r.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(n===qa)return r.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(n===Fl||n===Ol||n===Bl||n===kl)if(r=t.get("WEBGL_compressed_texture_pvrtc"),r!==null){if(n===Fl)return r.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(n===Ol)return r.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(n===Bl)return r.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(n===kl)return r.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(n===Hl||n===Gl||n===Vl)if(r=t.get("WEBGL_compressed_texture_etc"),r!==null){if(n===Hl||n===Gl)return a===He?r.COMPRESSED_SRGB8_ETC2:r.COMPRESSED_RGB8_ETC2;if(n===Vl)return a===He?r.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:r.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(n===Wl||n===Xl||n===ql||n===Yl||n===$l||n===Kl||n===Zl||n===jl||n===Jl||n===Ql||n===tc||n===ec||n===nc||n===ic)if(r=t.get("WEBGL_compressed_texture_astc"),r!==null){if(n===Wl)return a===He?r.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:r.COMPRESSED_RGBA_ASTC_4x4_KHR;if(n===Xl)return a===He?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:r.COMPRESSED_RGBA_ASTC_5x4_KHR;if(n===ql)return a===He?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:r.COMPRESSED_RGBA_ASTC_5x5_KHR;if(n===Yl)return a===He?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:r.COMPRESSED_RGBA_ASTC_6x5_KHR;if(n===$l)return a===He?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:r.COMPRESSED_RGBA_ASTC_6x6_KHR;if(n===Kl)return a===He?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:r.COMPRESSED_RGBA_ASTC_8x5_KHR;if(n===Zl)return a===He?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:r.COMPRESSED_RGBA_ASTC_8x6_KHR;if(n===jl)return a===He?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:r.COMPRESSED_RGBA_ASTC_8x8_KHR;if(n===Jl)return a===He?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:r.COMPRESSED_RGBA_ASTC_10x5_KHR;if(n===Ql)return a===He?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:r.COMPRESSED_RGBA_ASTC_10x6_KHR;if(n===tc)return a===He?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:r.COMPRESSED_RGBA_ASTC_10x8_KHR;if(n===ec)return a===He?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:r.COMPRESSED_RGBA_ASTC_10x10_KHR;if(n===nc)return a===He?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:r.COMPRESSED_RGBA_ASTC_12x10_KHR;if(n===ic)return a===He?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:r.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(n===Ya||n===sc||n===rc)if(r=t.get("EXT_texture_compression_bptc"),r!==null){if(n===Ya)return a===He?r.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:r.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(n===sc)return r.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(n===rc)return r.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(n===qu||n===ac||n===oc||n===lc)if(r=t.get("EXT_texture_compression_rgtc"),r!==null){if(n===Ya)return r.COMPRESSED_RED_RGTC1_EXT;if(n===ac)return r.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(n===oc)return r.COMPRESSED_RED_GREEN_RGTC2_EXT;if(n===lc)return r.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return n===or?i.UNSIGNED_INT_24_8:i[n]!==void 0?i[n]:null}return{convert:e}}class N1 extends Pn{constructor(t=[]){super(),this.isArrayCamera=!0,this.cameras=t}}class xe extends Ze{constructor(){super(),this.isGroup=!0,this.type="Group"}}const F1={type:"move"};class jo{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new xe,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new xe,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new N,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new N),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new xe,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new N,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new N),this._grip}dispatchEvent(t){return this._targetRay!==null&&this._targetRay.dispatchEvent(t),this._grip!==null&&this._grip.dispatchEvent(t),this._hand!==null&&this._hand.dispatchEvent(t),this}connect(t){if(t&&t.hand){const e=this._hand;if(e)for(const n of t.hand.values())this._getHandJoint(e,n)}return this.dispatchEvent({type:"connected",data:t}),this}disconnect(t){return this.dispatchEvent({type:"disconnected",data:t}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(t,e,n){let s=null,r=null,a=null;const o=this._targetRay,l=this._grip,h=this._hand;if(t&&e.session.visibilityState!=="visible-blurred"){if(h&&t.hand){a=!0;for(const v of t.hand.values()){const p=e.getJointPose(v,n),x=this._getHandJoint(h,v);p!==null&&(x.matrix.fromArray(p.transform.matrix),x.matrix.decompose(x.position,x.rotation,x.scale),x.matrixWorldNeedsUpdate=!0,x.jointRadius=p.radius),x.visible=p!==null}const f=h.joints["index-finger-tip"],m=h.joints["thumb-tip"],u=f.position.distanceTo(m.position),d=.02,c=.005;h.inputState.pinching&&u>d+c?(h.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:t.handedness,target:this})):!h.inputState.pinching&&u<=d-c&&(h.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:t.handedness,target:this}))}else l!==null&&t.gripSpace&&(r=e.getPose(t.gripSpace,n),r!==null&&(l.matrix.fromArray(r.transform.matrix),l.matrix.decompose(l.position,l.rotation,l.scale),l.matrixWorldNeedsUpdate=!0,r.linearVelocity?(l.hasLinearVelocity=!0,l.linearVelocity.copy(r.linearVelocity)):l.hasLinearVelocity=!1,r.angularVelocity?(l.hasAngularVelocity=!0,l.angularVelocity.copy(r.angularVelocity)):l.hasAngularVelocity=!1));o!==null&&(s=e.getPose(t.targetRaySpace,n),s===null&&r!==null&&(s=r),s!==null&&(o.matrix.fromArray(s.transform.matrix),o.matrix.decompose(o.position,o.rotation,o.scale),o.matrixWorldNeedsUpdate=!0,s.linearVelocity?(o.hasLinearVelocity=!0,o.linearVelocity.copy(s.linearVelocity)):o.hasLinearVelocity=!1,s.angularVelocity?(o.hasAngularVelocity=!0,o.angularVelocity.copy(s.angularVelocity)):o.hasAngularVelocity=!1,this.dispatchEvent(F1)))}return o!==null&&(o.visible=s!==null),l!==null&&(l.visible=r!==null),h!==null&&(h.visible=a!==null),this}_getHandJoint(t,e){if(t.joints[e.jointName]===void 0){const n=new xe;n.matrixAutoUpdate=!1,n.visible=!1,t.joints[e.jointName]=n,t.add(n)}return t.joints[e.jointName]}}const O1=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,B1=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class k1{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(t,e,n){if(this.texture===null){const s=new vn,r=t.properties.get(s);r.__webglTexture=e.texture,(e.depthNear!=n.depthNear||e.depthFar!=n.depthFar)&&(this.depthNear=e.depthNear,this.depthFar=e.depthFar),this.texture=s}}getMesh(t){if(this.texture!==null&&this.mesh===null){const e=t.cameras[0].viewport,n=new Ke({vertexShader:O1,fragmentShader:B1,uniforms:{depthColor:{value:this.texture},depthWidth:{value:e.z},depthHeight:{value:e.w}}});this.mesh=new K(new ue(20,20),n)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class H1 extends dr{constructor(t,e){super();const n=this;let s=null,r=1,a=null,o="local-floor",l=1,h=null,f=null,m=null,u=null,d=null,c=null;const v=new k1,p=e.getContextAttributes();let x=null,w=null;const b=[],C=[],V=new Pt;let D=null;const A=new Pn;A.layers.enable(1),A.viewport=new Fe;const y=new Pn;y.layers.enable(2),y.viewport=new Fe;const rt=[A,y],S=new N1;S.layers.enable(1),S.layers.enable(2);let z=null,nt=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(k){let at=b[k];return at===void 0&&(at=new jo,b[k]=at),at.getTargetRaySpace()},this.getControllerGrip=function(k){let at=b[k];return at===void 0&&(at=new jo,b[k]=at),at.getGripSpace()},this.getHand=function(k){let at=b[k];return at===void 0&&(at=new jo,b[k]=at),at.getHandSpace()};function q(k){const at=C.indexOf(k.inputSource);if(at===-1)return;const gt=b[at];gt!==void 0&&(gt.update(k.inputSource,k.frame,h||a),gt.dispatchEvent({type:k.type,data:k.inputSource}))}function j(){s.removeEventListener("select",q),s.removeEventListener("selectstart",q),s.removeEventListener("selectend",q),s.removeEventListener("squeeze",q),s.removeEventListener("squeezestart",q),s.removeEventListener("squeezeend",q),s.removeEventListener("end",j),s.removeEventListener("inputsourceschange",Y);for(let k=0;k<b.length;k++){const at=C[k];at!==null&&(C[k]=null,b[k].disconnect(at))}z=null,nt=null,v.reset(),t.setRenderTarget(x),d=null,u=null,m=null,s=null,w=null,Lt.stop(),n.isPresenting=!1,t.setPixelRatio(D),t.setSize(V.width,V.height,!1),n.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(k){r=k,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(k){o=k,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return h||a},this.setReferenceSpace=function(k){h=k},this.getBaseLayer=function(){return u!==null?u:d},this.getBinding=function(){return m},this.getFrame=function(){return c},this.getSession=function(){return s},this.setSession=async function(k){if(s=k,s!==null){if(x=t.getRenderTarget(),s.addEventListener("select",q),s.addEventListener("selectstart",q),s.addEventListener("selectend",q),s.addEventListener("squeeze",q),s.addEventListener("squeezestart",q),s.addEventListener("squeezeend",q),s.addEventListener("end",j),s.addEventListener("inputsourceschange",Y),p.xrCompatible!==!0&&await e.makeXRCompatible(),D=t.getPixelRatio(),t.getSize(V),s.renderState.layers===void 0){const at={antialias:p.antialias,alpha:!0,depth:p.depth,stencil:p.stencil,framebufferScaleFactor:r};d=new XRWebGLLayer(s,e,at),s.updateRenderState({baseLayer:d}),t.setPixelRatio(1),t.setSize(d.framebufferWidth,d.framebufferHeight,!1),w=new $n(d.framebufferWidth,d.framebufferHeight,{format:ri,type:Ai,colorSpace:t.outputColorSpace,stencilBuffer:p.stencil})}else{let at=null,gt=null,Mt=null;p.depth&&(Mt=p.stencil?e.DEPTH24_STENCIL8:e.DEPTH_COMPONENT24,at=p.stencil?lr:tr,gt=p.stencil?or:ps);const Et={colorFormat:e.RGBA8,depthFormat:Mt,scaleFactor:r};m=new XRWebGLBinding(s,e),u=m.createProjectionLayer(Et),s.updateRenderState({layers:[u]}),t.setPixelRatio(1),t.setSize(u.textureWidth,u.textureHeight,!1),w=new $n(u.textureWidth,u.textureHeight,{format:ri,type:Ai,depthTexture:new rh(u.textureWidth,u.textureHeight,gt,void 0,void 0,void 0,void 0,void 0,void 0,at),stencilBuffer:p.stencil,colorSpace:t.outputColorSpace,samples:p.antialias?4:0,resolveDepthBuffer:u.ignoreDepthValues===!1})}w.isXRRenderTarget=!0,this.setFoveation(l),h=null,a=await s.requestReferenceSpace(o),Lt.setContext(s),Lt.start(),n.isPresenting=!0,n.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(s!==null)return s.environmentBlendMode},this.getDepthTexture=function(){return v.getDepthTexture()};function Y(k){for(let at=0;at<k.removed.length;at++){const gt=k.removed[at],Mt=C.indexOf(gt);Mt>=0&&(C[Mt]=null,b[Mt].disconnect(gt))}for(let at=0;at<k.added.length;at++){const gt=k.added[at];let Mt=C.indexOf(gt);if(Mt===-1){for(let Bt=0;Bt<b.length;Bt++)if(Bt>=C.length){C.push(gt),Mt=Bt;break}else if(C[Bt]===null){C[Bt]=gt,Mt=Bt;break}if(Mt===-1)break}const Et=b[Mt];Et&&Et.connect(gt)}}const W=new N,ht=new N;function lt(k,at,gt){W.setFromMatrixPosition(at.matrixWorld),ht.setFromMatrixPosition(gt.matrixWorld);const Mt=W.distanceTo(ht),Et=at.projectionMatrix.elements,Bt=gt.projectionMatrix.elements,Zt=Et[14]/(Et[10]-1),Xt=Et[14]/(Et[10]+1),ie=(Et[9]+1)/Et[5],$=(Et[9]-1)/Et[5],wt=(Et[8]-1)/Et[0],At=(Bt[8]+1)/Bt[0],ct=Zt*wt,Ct=Zt*At,jt=Mt/(-wt+At),kt=jt*-wt;if(at.matrixWorld.decompose(k.position,k.quaternion,k.scale),k.translateX(kt),k.translateZ(jt),k.matrixWorld.compose(k.position,k.quaternion,k.scale),k.matrixWorldInverse.copy(k.matrixWorld).invert(),Et[10]===-1)k.projectionMatrix.copy(at.projectionMatrix),k.projectionMatrixInverse.copy(at.projectionMatrixInverse);else{const B=Zt+jt,P=Xt+jt,tt=ct-kt,vt=Ct+(Mt-kt),bt=ie*Xt/P*B,mt=$*Xt/P*B;k.projectionMatrix.makePerspective(tt,vt,bt,mt,B,P),k.projectionMatrixInverse.copy(k.projectionMatrix).invert()}}function Dt(k,at){at===null?k.matrixWorld.copy(k.matrix):k.matrixWorld.multiplyMatrices(at.matrixWorld,k.matrix),k.matrixWorldInverse.copy(k.matrixWorld).invert()}this.updateCamera=function(k){if(s===null)return;let at=k.near,gt=k.far;v.texture!==null&&(v.depthNear>0&&(at=v.depthNear),v.depthFar>0&&(gt=v.depthFar)),S.near=y.near=A.near=at,S.far=y.far=A.far=gt,(z!==S.near||nt!==S.far)&&(s.updateRenderState({depthNear:S.near,depthFar:S.far}),z=S.near,nt=S.far);const Mt=k.parent,Et=S.cameras;Dt(S,Mt);for(let Bt=0;Bt<Et.length;Bt++)Dt(Et[Bt],Mt);Et.length===2?lt(S,A,y):S.projectionMatrix.copy(A.projectionMatrix),yt(k,S,Mt)};function yt(k,at,gt){gt===null?k.matrix.copy(at.matrixWorld):(k.matrix.copy(gt.matrixWorld),k.matrix.invert(),k.matrix.multiply(at.matrixWorld)),k.matrix.decompose(k.position,k.quaternion,k.scale),k.updateMatrixWorld(!0),k.projectionMatrix.copy(at.projectionMatrix),k.projectionMatrixInverse.copy(at.projectionMatrixInverse),k.isPerspectiveCamera&&(k.fov=qr*2*Math.atan(1/k.projectionMatrix.elements[5]),k.zoom=1)}this.getCamera=function(){return S},this.getFoveation=function(){if(!(u===null&&d===null))return l},this.setFoveation=function(k){l=k,u!==null&&(u.fixedFoveation=k),d!==null&&d.fixedFoveation!==void 0&&(d.fixedFoveation=k)},this.hasDepthSensing=function(){return v.texture!==null},this.getDepthSensingMesh=function(){return v.getMesh(S)};let dt=null;function et(k,at){if(f=at.getViewerPose(h||a),c=at,f!==null){const gt=f.views;d!==null&&(t.setRenderTargetFramebuffer(w,d.framebuffer),t.setRenderTarget(w));let Mt=!1;gt.length!==S.cameras.length&&(S.cameras.length=0,Mt=!0);for(let Bt=0;Bt<gt.length;Bt++){const Zt=gt[Bt];let Xt=null;if(d!==null)Xt=d.getViewport(Zt);else{const $=m.getViewSubImage(u,Zt);Xt=$.viewport,Bt===0&&(t.setRenderTargetTextures(w,$.colorTexture,u.ignoreDepthValues?void 0:$.depthStencilTexture),t.setRenderTarget(w))}let ie=rt[Bt];ie===void 0&&(ie=new Pn,ie.layers.enable(Bt),ie.viewport=new Fe,rt[Bt]=ie),ie.matrix.fromArray(Zt.transform.matrix),ie.matrix.decompose(ie.position,ie.quaternion,ie.scale),ie.projectionMatrix.fromArray(Zt.projectionMatrix),ie.projectionMatrixInverse.copy(ie.projectionMatrix).invert(),ie.viewport.set(Xt.x,Xt.y,Xt.width,Xt.height),Bt===0&&(S.matrix.copy(ie.matrix),S.matrix.decompose(S.position,S.quaternion,S.scale)),Mt===!0&&S.cameras.push(ie)}const Et=s.enabledFeatures;if(Et&&Et.includes("depth-sensing")){const Bt=m.getDepthInformation(gt[0]);Bt&&Bt.isValid&&Bt.texture&&v.init(t,Bt,s.renderState)}}for(let gt=0;gt<b.length;gt++){const Mt=C[gt],Et=b[gt];Mt!==null&&Et!==void 0&&Et.update(Mt,at,h||a)}dt&&dt(k,at),at.detectedPlanes&&n.dispatchEvent({type:"planesdetected",data:at}),c=null}const Lt=new sh;Lt.setAnimationLoop(et),this.setAnimationLoop=function(k){dt=k},this.dispose=function(){}}}const ji=new wn,G1=new Pe;function V1(i,t){function e(p,x){p.matrixAutoUpdate===!0&&p.updateMatrix(),x.value.copy(p.matrix)}function n(p,x){x.color.getRGB(p.fogColor.value,eh(i)),x.isFog?(p.fogNear.value=x.near,p.fogFar.value=x.far):x.isFogExp2&&(p.fogDensity.value=x.density)}function s(p,x,w,b,C){x.isMeshBasicMaterial||x.isMeshLambertMaterial?r(p,x):x.isMeshToonMaterial?(r(p,x),m(p,x)):x.isMeshPhongMaterial?(r(p,x),f(p,x)):x.isMeshStandardMaterial?(r(p,x),u(p,x),x.isMeshPhysicalMaterial&&d(p,x,C)):x.isMeshMatcapMaterial?(r(p,x),c(p,x)):x.isMeshDepthMaterial?r(p,x):x.isMeshDistanceMaterial?(r(p,x),v(p,x)):x.isMeshNormalMaterial?r(p,x):x.isLineBasicMaterial?(a(p,x),x.isLineDashedMaterial&&o(p,x)):x.isPointsMaterial?l(p,x,w,b):x.isSpriteMaterial?h(p,x):x.isShadowMaterial?(p.color.value.copy(x.color),p.opacity.value=x.opacity):x.isShaderMaterial&&(x.uniformsNeedUpdate=!1)}function r(p,x){p.opacity.value=x.opacity,x.color&&p.diffuse.value.copy(x.color),x.emissive&&p.emissive.value.copy(x.emissive).multiplyScalar(x.emissiveIntensity),x.map&&(p.map.value=x.map,e(x.map,p.mapTransform)),x.alphaMap&&(p.alphaMap.value=x.alphaMap,e(x.alphaMap,p.alphaMapTransform)),x.bumpMap&&(p.bumpMap.value=x.bumpMap,e(x.bumpMap,p.bumpMapTransform),p.bumpScale.value=x.bumpScale,x.side===fn&&(p.bumpScale.value*=-1)),x.normalMap&&(p.normalMap.value=x.normalMap,e(x.normalMap,p.normalMapTransform),p.normalScale.value.copy(x.normalScale),x.side===fn&&p.normalScale.value.negate()),x.displacementMap&&(p.displacementMap.value=x.displacementMap,e(x.displacementMap,p.displacementMapTransform),p.displacementScale.value=x.displacementScale,p.displacementBias.value=x.displacementBias),x.emissiveMap&&(p.emissiveMap.value=x.emissiveMap,e(x.emissiveMap,p.emissiveMapTransform)),x.specularMap&&(p.specularMap.value=x.specularMap,e(x.specularMap,p.specularMapTransform)),x.alphaTest>0&&(p.alphaTest.value=x.alphaTest);const w=t.get(x),b=w.envMap,C=w.envMapRotation;b&&(p.envMap.value=b,ji.copy(C),ji.x*=-1,ji.y*=-1,ji.z*=-1,b.isCubeTexture&&b.isRenderTargetTexture===!1&&(ji.y*=-1,ji.z*=-1),p.envMapRotation.value.setFromMatrix4(G1.makeRotationFromEuler(ji)),p.flipEnvMap.value=b.isCubeTexture&&b.isRenderTargetTexture===!1?-1:1,p.reflectivity.value=x.reflectivity,p.ior.value=x.ior,p.refractionRatio.value=x.refractionRatio),x.lightMap&&(p.lightMap.value=x.lightMap,p.lightMapIntensity.value=x.lightMapIntensity,e(x.lightMap,p.lightMapTransform)),x.aoMap&&(p.aoMap.value=x.aoMap,p.aoMapIntensity.value=x.aoMapIntensity,e(x.aoMap,p.aoMapTransform))}function a(p,x){p.diffuse.value.copy(x.color),p.opacity.value=x.opacity,x.map&&(p.map.value=x.map,e(x.map,p.mapTransform))}function o(p,x){p.dashSize.value=x.dashSize,p.totalSize.value=x.dashSize+x.gapSize,p.scale.value=x.scale}function l(p,x,w,b){p.diffuse.value.copy(x.color),p.opacity.value=x.opacity,p.size.value=x.size*w,p.scale.value=b*.5,x.map&&(p.map.value=x.map,e(x.map,p.uvTransform)),x.alphaMap&&(p.alphaMap.value=x.alphaMap,e(x.alphaMap,p.alphaMapTransform)),x.alphaTest>0&&(p.alphaTest.value=x.alphaTest)}function h(p,x){p.diffuse.value.copy(x.color),p.opacity.value=x.opacity,p.rotation.value=x.rotation,x.map&&(p.map.value=x.map,e(x.map,p.mapTransform)),x.alphaMap&&(p.alphaMap.value=x.alphaMap,e(x.alphaMap,p.alphaMapTransform)),x.alphaTest>0&&(p.alphaTest.value=x.alphaTest)}function f(p,x){p.specular.value.copy(x.specular),p.shininess.value=Math.max(x.shininess,1e-4)}function m(p,x){x.gradientMap&&(p.gradientMap.value=x.gradientMap)}function u(p,x){p.metalness.value=x.metalness,x.metalnessMap&&(p.metalnessMap.value=x.metalnessMap,e(x.metalnessMap,p.metalnessMapTransform)),p.roughness.value=x.roughness,x.roughnessMap&&(p.roughnessMap.value=x.roughnessMap,e(x.roughnessMap,p.roughnessMapTransform)),x.envMap&&(p.envMapIntensity.value=x.envMapIntensity)}function d(p,x,w){p.ior.value=x.ior,x.sheen>0&&(p.sheenColor.value.copy(x.sheenColor).multiplyScalar(x.sheen),p.sheenRoughness.value=x.sheenRoughness,x.sheenColorMap&&(p.sheenColorMap.value=x.sheenColorMap,e(x.sheenColorMap,p.sheenColorMapTransform)),x.sheenRoughnessMap&&(p.sheenRoughnessMap.value=x.sheenRoughnessMap,e(x.sheenRoughnessMap,p.sheenRoughnessMapTransform))),x.clearcoat>0&&(p.clearcoat.value=x.clearcoat,p.clearcoatRoughness.value=x.clearcoatRoughness,x.clearcoatMap&&(p.clearcoatMap.value=x.clearcoatMap,e(x.clearcoatMap,p.clearcoatMapTransform)),x.clearcoatRoughnessMap&&(p.clearcoatRoughnessMap.value=x.clearcoatRoughnessMap,e(x.clearcoatRoughnessMap,p.clearcoatRoughnessMapTransform)),x.clearcoatNormalMap&&(p.clearcoatNormalMap.value=x.clearcoatNormalMap,e(x.clearcoatNormalMap,p.clearcoatNormalMapTransform),p.clearcoatNormalScale.value.copy(x.clearcoatNormalScale),x.side===fn&&p.clearcoatNormalScale.value.negate())),x.dispersion>0&&(p.dispersion.value=x.dispersion),x.iridescence>0&&(p.iridescence.value=x.iridescence,p.iridescenceIOR.value=x.iridescenceIOR,p.iridescenceThicknessMinimum.value=x.iridescenceThicknessRange[0],p.iridescenceThicknessMaximum.value=x.iridescenceThicknessRange[1],x.iridescenceMap&&(p.iridescenceMap.value=x.iridescenceMap,e(x.iridescenceMap,p.iridescenceMapTransform)),x.iridescenceThicknessMap&&(p.iridescenceThicknessMap.value=x.iridescenceThicknessMap,e(x.iridescenceThicknessMap,p.iridescenceThicknessMapTransform))),x.transmission>0&&(p.transmission.value=x.transmission,p.transmissionSamplerMap.value=w.texture,p.transmissionSamplerSize.value.set(w.width,w.height),x.transmissionMap&&(p.transmissionMap.value=x.transmissionMap,e(x.transmissionMap,p.transmissionMapTransform)),p.thickness.value=x.thickness,x.thicknessMap&&(p.thicknessMap.value=x.thicknessMap,e(x.thicknessMap,p.thicknessMapTransform)),p.attenuationDistance.value=x.attenuationDistance,p.attenuationColor.value.copy(x.attenuationColor)),x.anisotropy>0&&(p.anisotropyVector.value.set(x.anisotropy*Math.cos(x.anisotropyRotation),x.anisotropy*Math.sin(x.anisotropyRotation)),x.anisotropyMap&&(p.anisotropyMap.value=x.anisotropyMap,e(x.anisotropyMap,p.anisotropyMapTransform))),p.specularIntensity.value=x.specularIntensity,p.specularColor.value.copy(x.specularColor),x.specularColorMap&&(p.specularColorMap.value=x.specularColorMap,e(x.specularColorMap,p.specularColorMapTransform)),x.specularIntensityMap&&(p.specularIntensityMap.value=x.specularIntensityMap,e(x.specularIntensityMap,p.specularIntensityMapTransform))}function c(p,x){x.matcap&&(p.matcap.value=x.matcap)}function v(p,x){const w=t.get(x).light;p.referencePosition.value.setFromMatrixPosition(w.matrixWorld),p.nearDistance.value=w.shadow.camera.near,p.farDistance.value=w.shadow.camera.far}return{refreshFogUniforms:n,refreshMaterialUniforms:s}}function W1(i,t,e,n){let s={},r={},a=[];const o=i.getParameter(i.MAX_UNIFORM_BUFFER_BINDINGS);function l(w,b){const C=b.program;n.uniformBlockBinding(w,C)}function h(w,b){let C=s[w.id];C===void 0&&(c(w),C=f(w),s[w.id]=C,w.addEventListener("dispose",p));const V=b.program;n.updateUBOMapping(w,V);const D=t.render.frame;r[w.id]!==D&&(u(w),r[w.id]=D)}function f(w){const b=m();w.__bindingPointIndex=b;const C=i.createBuffer(),V=w.__size,D=w.usage;return i.bindBuffer(i.UNIFORM_BUFFER,C),i.bufferData(i.UNIFORM_BUFFER,V,D),i.bindBuffer(i.UNIFORM_BUFFER,null),i.bindBufferBase(i.UNIFORM_BUFFER,b,C),C}function m(){for(let w=0;w<o;w++)if(a.indexOf(w)===-1)return a.push(w),w;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function u(w){const b=s[w.id],C=w.uniforms,V=w.__cache;i.bindBuffer(i.UNIFORM_BUFFER,b);for(let D=0,A=C.length;D<A;D++){const y=Array.isArray(C[D])?C[D]:[C[D]];for(let rt=0,S=y.length;rt<S;rt++){const z=y[rt];if(d(z,D,rt,V)===!0){const nt=z.__offset,q=Array.isArray(z.value)?z.value:[z.value];let j=0;for(let Y=0;Y<q.length;Y++){const W=q[Y],ht=v(W);typeof W=="number"||typeof W=="boolean"?(z.__data[0]=W,i.bufferSubData(i.UNIFORM_BUFFER,nt+j,z.__data)):W.isMatrix3?(z.__data[0]=W.elements[0],z.__data[1]=W.elements[1],z.__data[2]=W.elements[2],z.__data[3]=0,z.__data[4]=W.elements[3],z.__data[5]=W.elements[4],z.__data[6]=W.elements[5],z.__data[7]=0,z.__data[8]=W.elements[6],z.__data[9]=W.elements[7],z.__data[10]=W.elements[8],z.__data[11]=0):(W.toArray(z.__data,j),j+=ht.storage/Float32Array.BYTES_PER_ELEMENT)}i.bufferSubData(i.UNIFORM_BUFFER,nt,z.__data)}}}i.bindBuffer(i.UNIFORM_BUFFER,null)}function d(w,b,C,V){const D=w.value,A=b+"_"+C;if(V[A]===void 0)return typeof D=="number"||typeof D=="boolean"?V[A]=D:V[A]=D.clone(),!0;{const y=V[A];if(typeof D=="number"||typeof D=="boolean"){if(y!==D)return V[A]=D,!0}else if(y.equals(D)===!1)return y.copy(D),!0}return!1}function c(w){const b=w.uniforms;let C=0;const V=16;for(let A=0,y=b.length;A<y;A++){const rt=Array.isArray(b[A])?b[A]:[b[A]];for(let S=0,z=rt.length;S<z;S++){const nt=rt[S],q=Array.isArray(nt.value)?nt.value:[nt.value];for(let j=0,Y=q.length;j<Y;j++){const W=q[j],ht=v(W),lt=C%V,Dt=lt%ht.boundary,yt=lt+Dt;C+=Dt,yt!==0&&V-yt<ht.storage&&(C+=V-yt),nt.__data=new Float32Array(ht.storage/Float32Array.BYTES_PER_ELEMENT),nt.__offset=C,C+=ht.storage}}}const D=C%V;return D>0&&(C+=V-D),w.__size=C,w.__cache={},this}function v(w){const b={boundary:0,storage:0};return typeof w=="number"||typeof w=="boolean"?(b.boundary=4,b.storage=4):w.isVector2?(b.boundary=8,b.storage=8):w.isVector3||w.isColor?(b.boundary=16,b.storage=12):w.isVector4?(b.boundary=16,b.storage=16):w.isMatrix3?(b.boundary=48,b.storage=48):w.isMatrix4?(b.boundary=64,b.storage=64):w.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",w),b}function p(w){const b=w.target;b.removeEventListener("dispose",p);const C=a.indexOf(b.__bindingPointIndex);a.splice(C,1),i.deleteBuffer(s[b.id]),delete s[b.id],delete r[b.id]}function x(){for(const w in s)i.deleteBuffer(s[w]);a=[],s={},r={}}return{bind:l,update:h,dispose:x}}class X1{constructor(t={}){const{canvas:e=Lf(),context:n=null,depth:s=!0,stencil:r=!1,alpha:a=!1,antialias:o=!1,premultipliedAlpha:l=!0,preserveDrawingBuffer:h=!1,powerPreference:f="default",failIfMajorPerformanceCaveat:m=!1}=t;this.isWebGLRenderer=!0;let u;if(n!==null){if(typeof WebGLRenderingContext<"u"&&n instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");u=n.getContextAttributes().alpha}else u=a;const d=new Uint32Array(4),c=new Int32Array(4);let v=null,p=null;const x=[],w=[];this.domElement=e,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this._outputColorSpace=pn,this.toneMapping=Bi,this.toneMappingExposure=1;const b=this;let C=!1,V=0,D=0,A=null,y=-1,rt=null;const S=new Fe,z=new Fe;let nt=null;const q=new Jt(0);let j=0,Y=e.width,W=e.height,ht=1,lt=null,Dt=null;const yt=new Fe(0,0,Y,W),dt=new Fe(0,0,Y,W);let et=!1;const Lt=new Pc;let k=!1,at=!1;const gt=new Pe,Mt=new Pe,Et=new N,Bt=new Fe,Zt={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let Xt=!1;function ie(){return A===null?ht:1}let $=n;function wt(g,M){return e.getContext(g,M)}try{const g={alpha:!0,depth:s,stencil:r,antialias:o,premultipliedAlpha:l,preserveDrawingBuffer:h,powerPreference:f,failIfMajorPerformanceCaveat:m};if("setAttribute"in e&&e.setAttribute("data-engine",`three.js r${xc}`),e.addEventListener("webglcontextlost",Tt,!1),e.addEventListener("webglcontextrestored",Vt,!1),e.addEventListener("webglcontextcreationerror",Wt,!1),$===null){const M="webgl2";if($=wt(M,g),$===null)throw wt(M)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}}catch(g){throw console.error("THREE.WebGLRenderer: "+g.message),g}let At,ct,Ct,jt,kt,B,P,tt,vt,bt,mt,Ot,Ut,zt,te,St,Ft,re,ne,qt,Qt,ae,Ae,Q;function Yt(){At=new Zm($),At.init(),ae=new z1($,At),ct=new Wm($,At,t,ae),Ct=new I1($),ct.reverseDepthBuffer&&Ct.buffers.depth.setReversed(!0),jt=new Qm($),kt=new v1,B=new U1($,At,Ct,kt,ct,ae,jt),P=new qm(b),tt=new Km(b),vt=new ad($),Ae=new Gm($,vt),bt=new jm($,vt,jt,Ae),mt=new eg($,bt,vt,jt),ne=new tg($,ct,B),St=new Xm(kt),Ot=new g1(b,P,tt,At,ct,Ae,St),Ut=new V1(b,kt),zt=new _1,te=new T1(At),re=new Hm(b,P,tt,Ct,mt,u,l),Ft=new P1(b,mt,ct),Q=new W1($,jt,ct,Ct),qt=new Vm($,At,jt),Qt=new Jm($,At,jt),jt.programs=Ot.programs,b.capabilities=ct,b.extensions=At,b.properties=kt,b.renderLists=zt,b.shadowMap=Ft,b.state=Ct,b.info=jt}Yt();const _t=new H1(b,$);this.xr=_t,this.getContext=function(){return $},this.getContextAttributes=function(){return $.getContextAttributes()},this.forceContextLoss=function(){const g=At.get("WEBGL_lose_context");g&&g.loseContext()},this.forceContextRestore=function(){const g=At.get("WEBGL_lose_context");g&&g.restoreContext()},this.getPixelRatio=function(){return ht},this.setPixelRatio=function(g){g!==void 0&&(ht=g,this.setSize(Y,W,!1))},this.getSize=function(g){return g.set(Y,W)},this.setSize=function(g,M,U=!0){if(_t.isPresenting){console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting.");return}Y=g,W=M,e.width=Math.floor(g*ht),e.height=Math.floor(M*ht),U===!0&&(e.style.width=g+"px",e.style.height=M+"px"),this.setViewport(0,0,g,M)},this.getDrawingBufferSize=function(g){return g.set(Y*ht,W*ht).floor()},this.setDrawingBufferSize=function(g,M,U){Y=g,W=M,ht=U,e.width=Math.floor(g*U),e.height=Math.floor(M*U),this.setViewport(0,0,g,M)},this.getCurrentViewport=function(g){return g.copy(S)},this.getViewport=function(g){return g.copy(yt)},this.setViewport=function(g,M,U,E){g.isVector4?yt.set(g.x,g.y,g.z,g.w):yt.set(g,M,U,E),Ct.viewport(S.copy(yt).multiplyScalar(ht).round())},this.getScissor=function(g){return g.copy(dt)},this.setScissor=function(g,M,U,E){g.isVector4?dt.set(g.x,g.y,g.z,g.w):dt.set(g,M,U,E),Ct.scissor(z.copy(dt).multiplyScalar(ht).round())},this.getScissorTest=function(){return et},this.setScissorTest=function(g){Ct.setScissorTest(et=g)},this.setOpaqueSort=function(g){lt=g},this.setTransparentSort=function(g){Dt=g},this.getClearColor=function(g){return g.copy(re.getClearColor())},this.setClearColor=function(){re.setClearColor.apply(re,arguments)},this.getClearAlpha=function(){return re.getClearAlpha()},this.setClearAlpha=function(){re.setClearAlpha.apply(re,arguments)},this.clear=function(g=!0,M=!0,U=!0){let E=0;if(g){let L=!1;if(A!==null){const J=A.texture.format;L=J===Ec||J===Tc||J===bc}if(L){const J=A.texture.type,st=J===Ai||J===ps||J===Xr||J===or||J===yc||J===Sc,it=re.getClearColor(),pt=re.getClearAlpha(),ot=it.r,xt=it.g,ut=it.b;st?(d[0]=ot,d[1]=xt,d[2]=ut,d[3]=pt,$.clearBufferuiv($.COLOR,0,d)):(c[0]=ot,c[1]=xt,c[2]=ut,c[3]=pt,$.clearBufferiv($.COLOR,0,c))}else E|=$.COLOR_BUFFER_BIT}M&&(E|=$.DEPTH_BUFFER_BIT,$.clearDepth(this.capabilities.reverseDepthBuffer?0:1)),U&&(E|=$.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),$.clear(E)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){e.removeEventListener("webglcontextlost",Tt,!1),e.removeEventListener("webglcontextrestored",Vt,!1),e.removeEventListener("webglcontextcreationerror",Wt,!1),zt.dispose(),te.dispose(),kt.dispose(),P.dispose(),tt.dispose(),mt.dispose(),Ae.dispose(),Q.dispose(),Ot.dispose(),_t.dispose(),_t.removeEventListener("sessionstart",bn),_t.removeEventListener("sessionend",oi),sn.stop()};function Tt(g){g.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),C=!0}function Vt(){console.log("THREE.WebGLRenderer: Context Restored."),C=!1;const g=jt.autoReset,M=Ft.enabled,U=Ft.autoUpdate,E=Ft.needsUpdate,L=Ft.type;Yt(),jt.autoReset=g,Ft.enabled=M,Ft.autoUpdate=U,Ft.needsUpdate=E,Ft.type=L}function Wt(g){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",g.statusMessage)}function ge(g){const M=g.target;M.removeEventListener("dispose",ge),Ee(M)}function Ee(g){ke(g),kt.remove(g)}function ke(g){const M=kt.get(g).programs;M!==void 0&&(M.forEach(function(U){Ot.releaseProgram(U)}),g.isShaderMaterial&&Ot.releaseShaderCache(g))}this.renderBufferDirect=function(g,M,U,E,L,J){M===null&&(M=Zt);const st=L.isMesh&&L.matrixWorld.determinant()<0,it=T(g,M,U,E,L);Ct.setMaterial(E,st);let pt=U.index,ot=1;if(E.wireframe===!0){if(pt=bt.getWireframeAttribute(U),pt===void 0)return;ot=2}const xt=U.drawRange,ut=U.attributes.position;let It=xt.start*ot,Nt=(xt.start+xt.count)*ot;J!==null&&(It=Math.max(It,J.start*ot),Nt=Math.min(Nt,(J.start+J.count)*ot)),pt!==null?(It=Math.max(It,0),Nt=Math.min(Nt,pt.count)):ut!=null&&(It=Math.max(It,0),Nt=Math.min(Nt,ut.count));const Ht=Nt-It;if(Ht<0||Ht===1/0)return;Ae.setup(L,E,it,U,pt);let le,ee=qt;if(pt!==null&&(le=vt.get(pt),ee=Qt,ee.setIndex(le)),L.isMesh)E.wireframe===!0?(Ct.setLineWidth(E.wireframeLinewidth*ie()),ee.setMode($.LINES)):ee.setMode($.TRIANGLES);else if(L.isLine){let $t=E.linewidth;$t===void 0&&($t=1),Ct.setLineWidth($t*ie()),L.isLineSegments?ee.setMode($.LINES):L.isLineLoop?ee.setMode($.LINE_LOOP):ee.setMode($.LINE_STRIP)}else L.isPoints?ee.setMode($.POINTS):L.isSprite&&ee.setMode($.TRIANGLES);if(L.isBatchedMesh)if(L._multiDrawInstances!==null)ee.renderMultiDrawInstances(L._multiDrawStarts,L._multiDrawCounts,L._multiDrawCount,L._multiDrawInstances);else if(At.get("WEBGL_multi_draw"))ee.renderMultiDraw(L._multiDrawStarts,L._multiDrawCounts,L._multiDrawCount);else{const $t=L._multiDrawStarts,Ue=L._multiDrawCounts,_e=L._multiDrawCount,Ln=pt?vt.get(pt).bytesPerElement:1,Di=kt.get(E).currentProgram.getUniforms();for(let de=0;de<_e;de++)Di.setValue($,"_gl_DrawID",de),ee.render($t[de]/Ln,Ue[de])}else if(L.isInstancedMesh)ee.renderInstances(It,Ht,L.count);else if(U.isInstancedBufferGeometry){const $t=U._maxInstanceCount!==void 0?U._maxInstanceCount:1/0,Ue=Math.min(U.instanceCount,$t);ee.renderInstances(It,Ht,Ue)}else ee.render(It,Ht)};function me(g,M,U){g.transparent===!0&&g.side===ln&&g.forceSinglePass===!1?(g.side=fn,g.needsUpdate=!0,H(g,M,U),g.side=Hi,g.needsUpdate=!0,H(g,M,U),g.side=ln):H(g,M,U)}this.compile=function(g,M,U=null){U===null&&(U=g),p=te.get(U),p.init(M),w.push(p),U.traverseVisible(function(L){L.isLight&&L.layers.test(M.layers)&&(p.pushLight(L),L.castShadow&&p.pushShadow(L))}),g!==U&&g.traverseVisible(function(L){L.isLight&&L.layers.test(M.layers)&&(p.pushLight(L),L.castShadow&&p.pushShadow(L))}),p.setupLights();const E=new Set;return g.traverse(function(L){if(!(L.isMesh||L.isPoints||L.isLine||L.isSprite))return;const J=L.material;if(J)if(Array.isArray(J))for(let st=0;st<J.length;st++){const it=J[st];me(it,U,L),E.add(it)}else me(J,U,L),E.add(J)}),w.pop(),p=null,E},this.compileAsync=function(g,M,U=null){const E=this.compile(g,M,U);return new Promise(L=>{function J(){if(E.forEach(function(st){kt.get(st).currentProgram.isReady()&&E.delete(st)}),E.size===0){L(g);return}setTimeout(J,10)}At.get("KHR_parallel_shader_compile")!==null?J():setTimeout(J,10)})};let je=null;function nn(g){je&&je(g)}function bn(){sn.stop()}function oi(){sn.start()}const sn=new sh;sn.setAnimationLoop(nn),typeof self<"u"&&sn.setContext(self),this.setAnimationLoop=function(g){je=g,_t.setAnimationLoop(g),g===null?sn.stop():sn.start()},_t.addEventListener("sessionstart",bn),_t.addEventListener("sessionend",oi),this.render=function(g,M){if(M!==void 0&&M.isCamera!==!0){console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(C===!0)return;if(g.matrixWorldAutoUpdate===!0&&g.updateMatrixWorld(),M.parent===null&&M.matrixWorldAutoUpdate===!0&&M.updateMatrixWorld(),_t.enabled===!0&&_t.isPresenting===!0&&(_t.cameraAutoUpdate===!0&&_t.updateCamera(M),M=_t.getCamera()),g.isScene===!0&&g.onBeforeRender(b,g,M,A),p=te.get(g,w.length),p.init(M),w.push(p),Mt.multiplyMatrices(M.projectionMatrix,M.matrixWorldInverse),Lt.setFromProjectionMatrix(Mt),at=this.localClippingEnabled,k=St.init(this.clippingPlanes,at),v=zt.get(g,x.length),v.init(),x.push(v),_t.enabled===!0&&_t.isPresenting===!0){const J=b.xr.getDepthSensingMesh();J!==null&&Tn(J,M,-1/0,b.sortObjects)}Tn(g,M,0,b.sortObjects),v.finish(),b.sortObjects===!0&&v.sort(lt,Dt),Xt=_t.enabled===!1||_t.isPresenting===!1||_t.hasDepthSensing()===!1,Xt&&re.addToRenderList(v,g),this.info.render.frame++,k===!0&&St.beginShadows();const U=p.state.shadowsArray;Ft.render(U,g,M),k===!0&&St.endShadows(),this.info.autoReset===!0&&this.info.reset();const E=v.opaque,L=v.transmissive;if(p.setupLights(),M.isArrayCamera){const J=M.cameras;if(L.length>0)for(let st=0,it=J.length;st<it;st++){const pt=J[st];I(E,L,g,pt)}Xt&&re.render(g);for(let st=0,it=J.length;st<it;st++){const pt=J[st];jn(v,g,pt,pt.viewport)}}else L.length>0&&I(E,L,g,M),Xt&&re.render(g),jn(v,g,M);A!==null&&(B.updateMultisampleRenderTarget(A),B.updateRenderTargetMipmap(A)),g.isScene===!0&&g.onAfterRender(b,g,M),Ae.resetDefaultState(),y=-1,rt=null,w.pop(),w.length>0?(p=w[w.length-1],k===!0&&St.setGlobalState(b.clippingPlanes,p.state.camera)):p=null,x.pop(),x.length>0?v=x[x.length-1]:v=null};function Tn(g,M,U,E){if(g.visible===!1)return;if(g.layers.test(M.layers)){if(g.isGroup)U=g.renderOrder;else if(g.isLOD)g.autoUpdate===!0&&g.update(M);else if(g.isLight)p.pushLight(g),g.castShadow&&p.pushShadow(g);else if(g.isSprite){if(!g.frustumCulled||Lt.intersectsSprite(g)){E&&Bt.setFromMatrixPosition(g.matrixWorld).applyMatrix4(Mt);const st=mt.update(g),it=g.material;it.visible&&v.push(g,st,it,U,Bt.z,null)}}else if((g.isMesh||g.isLine||g.isPoints)&&(!g.frustumCulled||Lt.intersectsObject(g))){const st=mt.update(g),it=g.material;if(E&&(g.boundingSphere!==void 0?(g.boundingSphere===null&&g.computeBoundingSphere(),Bt.copy(g.boundingSphere.center)):(st.boundingSphere===null&&st.computeBoundingSphere(),Bt.copy(st.boundingSphere.center)),Bt.applyMatrix4(g.matrixWorld).applyMatrix4(Mt)),Array.isArray(it)){const pt=st.groups;for(let ot=0,xt=pt.length;ot<xt;ot++){const ut=pt[ot],It=it[ut.materialIndex];It&&It.visible&&v.push(g,st,It,U,Bt.z,ut)}}else it.visible&&v.push(g,st,it,U,Bt.z,null)}}const J=g.children;for(let st=0,it=J.length;st<it;st++)Tn(J[st],M,U,E)}function jn(g,M,U,E){const L=g.opaque,J=g.transmissive,st=g.transparent;p.setupLightsView(U),k===!0&&St.setGlobalState(b.clippingPlanes,U),E&&Ct.viewport(S.copy(E)),L.length>0&&G(L,M,U),J.length>0&&G(J,M,U),st.length>0&&G(st,M,U),Ct.buffers.depth.setTest(!0),Ct.buffers.depth.setMask(!0),Ct.buffers.color.setMask(!0),Ct.setPolygonOffset(!1)}function I(g,M,U,E){if((U.isScene===!0?U.overrideMaterial:null)!==null)return;p.state.transmissionRenderTarget[E.id]===void 0&&(p.state.transmissionRenderTarget[E.id]=new $n(1,1,{generateMipmaps:!0,type:At.has("EXT_color_buffer_half_float")||At.has("EXT_color_buffer_float")?pi:Ai,minFilter:cs,samples:4,stencilBuffer:r,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:Ie.workingColorSpace}));const J=p.state.transmissionRenderTarget[E.id],st=E.viewport||S;J.setSize(st.z,st.w);const it=b.getRenderTarget();b.setRenderTarget(J),b.getClearColor(q),j=b.getClearAlpha(),j<1&&b.setClearColor(16777215,.5),b.clear(),Xt&&re.render(U);const pt=b.toneMapping;b.toneMapping=Bi;const ot=E.viewport;if(E.viewport!==void 0&&(E.viewport=void 0),p.setupLightsView(E),k===!0&&St.setGlobalState(b.clippingPlanes,E),G(g,U,E),B.updateMultisampleRenderTarget(J),B.updateRenderTargetMipmap(J),At.has("WEBGL_multisampled_render_to_texture")===!1){let xt=!1;for(let ut=0,It=M.length;ut<It;ut++){const Nt=M[ut],Ht=Nt.object,le=Nt.geometry,ee=Nt.material,$t=Nt.group;if(ee.side===ln&&Ht.layers.test(E.layers)){const Ue=ee.side;ee.side=fn,ee.needsUpdate=!0,X(Ht,U,E,le,ee,$t),ee.side=Ue,ee.needsUpdate=!0,xt=!0}}xt===!0&&(B.updateMultisampleRenderTarget(J),B.updateRenderTargetMipmap(J))}b.setRenderTarget(it),b.setClearColor(q,j),ot!==void 0&&(E.viewport=ot),b.toneMapping=pt}function G(g,M,U){const E=M.isScene===!0?M.overrideMaterial:null;for(let L=0,J=g.length;L<J;L++){const st=g[L],it=st.object,pt=st.geometry,ot=E===null?st.material:E,xt=st.group;it.layers.test(U.layers)&&X(it,M,U,pt,ot,xt)}}function X(g,M,U,E,L,J){g.onBeforeRender(b,M,U,E,L,J),g.modelViewMatrix.multiplyMatrices(U.matrixWorldInverse,g.matrixWorld),g.normalMatrix.getNormalMatrix(g.modelViewMatrix),L.onBeforeRender(b,M,U,E,g,J),L.transparent===!0&&L.side===ln&&L.forceSinglePass===!1?(L.side=fn,L.needsUpdate=!0,b.renderBufferDirect(U,M,E,L,g,J),L.side=Hi,L.needsUpdate=!0,b.renderBufferDirect(U,M,E,L,g,J),L.side=ln):b.renderBufferDirect(U,M,E,L,g,J),g.onAfterRender(b,M,U,E,L,J)}function H(g,M,U){M.isScene!==!0&&(M=Zt);const E=kt.get(g),L=p.state.lights,J=p.state.shadowsArray,st=L.state.version,it=Ot.getParameters(g,L.state,J,M,U),pt=Ot.getProgramCacheKey(it);let ot=E.programs;E.environment=g.isMeshStandardMaterial?M.environment:null,E.fog=M.fog,E.envMap=(g.isMeshStandardMaterial?tt:P).get(g.envMap||E.environment),E.envMapRotation=E.environment!==null&&g.envMap===null?M.environmentRotation:g.envMapRotation,ot===void 0&&(g.addEventListener("dispose",ge),ot=new Map,E.programs=ot);let xt=ot.get(pt);if(xt!==void 0){if(E.currentProgram===xt&&E.lightsStateVersion===st)return R(g,it),xt}else it.uniforms=Ot.getUniforms(g),g.onBeforeCompile(it,b),xt=Ot.acquireProgram(it,pt),ot.set(pt,xt),E.uniforms=it.uniforms;const ut=E.uniforms;return(!g.isShaderMaterial&&!g.isRawShaderMaterial||g.clipping===!0)&&(ut.clippingPlanes=St.uniform),R(g,it),E.needsLights=F(g),E.lightsStateVersion=st,E.needsLights&&(ut.ambientLightColor.value=L.state.ambient,ut.lightProbe.value=L.state.probe,ut.directionalLights.value=L.state.directional,ut.directionalLightShadows.value=L.state.directionalShadow,ut.spotLights.value=L.state.spot,ut.spotLightShadows.value=L.state.spotShadow,ut.rectAreaLights.value=L.state.rectArea,ut.ltc_1.value=L.state.rectAreaLTC1,ut.ltc_2.value=L.state.rectAreaLTC2,ut.pointLights.value=L.state.point,ut.pointLightShadows.value=L.state.pointShadow,ut.hemisphereLights.value=L.state.hemi,ut.directionalShadowMap.value=L.state.directionalShadowMap,ut.directionalShadowMatrix.value=L.state.directionalShadowMatrix,ut.spotShadowMap.value=L.state.spotShadowMap,ut.spotLightMatrix.value=L.state.spotLightMatrix,ut.spotLightMap.value=L.state.spotLightMap,ut.pointShadowMap.value=L.state.pointShadowMap,ut.pointShadowMatrix.value=L.state.pointShadowMatrix),E.currentProgram=xt,E.uniformsList=null,xt}function _(g){if(g.uniformsList===null){const M=g.currentProgram.getUniforms();g.uniformsList=Ka.seqWithValue(M.seq,g.uniforms)}return g.uniformsList}function R(g,M){const U=kt.get(g);U.outputColorSpace=M.outputColorSpace,U.batching=M.batching,U.batchingColor=M.batchingColor,U.instancing=M.instancing,U.instancingColor=M.instancingColor,U.instancingMorph=M.instancingMorph,U.skinning=M.skinning,U.morphTargets=M.morphTargets,U.morphNormals=M.morphNormals,U.morphColors=M.morphColors,U.morphTargetsCount=M.morphTargetsCount,U.numClippingPlanes=M.numClippingPlanes,U.numIntersection=M.numClipIntersection,U.vertexAlphas=M.vertexAlphas,U.vertexTangents=M.vertexTangents,U.toneMapping=M.toneMapping}function T(g,M,U,E,L){M.isScene!==!0&&(M=Zt),B.resetTextureUnits();const J=M.fog,st=E.isMeshStandardMaterial?M.environment:null,it=A===null?b.outputColorSpace:A.isXRRenderTarget===!0?A.texture.colorSpace:Gi,pt=(E.isMeshStandardMaterial?tt:P).get(E.envMap||st),ot=E.vertexColors===!0&&!!U.attributes.color&&U.attributes.color.itemSize===4,xt=!!U.attributes.tangent&&(!!E.normalMap||E.anisotropy>0),ut=!!U.morphAttributes.position,It=!!U.morphAttributes.normal,Nt=!!U.morphAttributes.color;let Ht=Bi;E.toneMapped&&(A===null||A.isXRRenderTarget===!0)&&(Ht=b.toneMapping);const le=U.morphAttributes.position||U.morphAttributes.normal||U.morphAttributes.color,ee=le!==void 0?le.length:0,$t=kt.get(E),Ue=p.state.lights;if(k===!0&&(at===!0||g!==rt)){const En=g===rt&&E.id===y;St.setState(E,g,En)}let _e=!1;E.version===$t.__version?($t.needsLights&&$t.lightsStateVersion!==Ue.state.version||$t.outputColorSpace!==it||L.isBatchedMesh&&$t.batching===!1||!L.isBatchedMesh&&$t.batching===!0||L.isBatchedMesh&&$t.batchingColor===!0&&L.colorTexture===null||L.isBatchedMesh&&$t.batchingColor===!1&&L.colorTexture!==null||L.isInstancedMesh&&$t.instancing===!1||!L.isInstancedMesh&&$t.instancing===!0||L.isSkinnedMesh&&$t.skinning===!1||!L.isSkinnedMesh&&$t.skinning===!0||L.isInstancedMesh&&$t.instancingColor===!0&&L.instanceColor===null||L.isInstancedMesh&&$t.instancingColor===!1&&L.instanceColor!==null||L.isInstancedMesh&&$t.instancingMorph===!0&&L.morphTexture===null||L.isInstancedMesh&&$t.instancingMorph===!1&&L.morphTexture!==null||$t.envMap!==pt||E.fog===!0&&$t.fog!==J||$t.numClippingPlanes!==void 0&&($t.numClippingPlanes!==St.numPlanes||$t.numIntersection!==St.numIntersection)||$t.vertexAlphas!==ot||$t.vertexTangents!==xt||$t.morphTargets!==ut||$t.morphNormals!==It||$t.morphColors!==Nt||$t.toneMapping!==Ht||$t.morphTargetsCount!==ee)&&(_e=!0):(_e=!0,$t.__version=E.version);let Ln=$t.currentProgram;_e===!0&&(Ln=H(E,M,L));let Di=!1,de=!1,we=!1;const se=Ln.getUniforms(),dn=$t.uniforms;if(Ct.useProgram(Ln.program)&&(Di=!0,de=!0,we=!0),E.id!==y&&(y=E.id,de=!0),Di||rt!==g){ct.reverseDepthBuffer?(gt.copy(g.projectionMatrix),zf(gt),Nf(gt),se.setValue($,"projectionMatrix",gt)):se.setValue($,"projectionMatrix",g.projectionMatrix),se.setValue($,"viewMatrix",g.matrixWorldInverse);const En=se.map.cameraPosition;En!==void 0&&En.setValue($,Et.setFromMatrixPosition(g.matrixWorld)),ct.logarithmicDepthBuffer&&se.setValue($,"logDepthBufFC",2/(Math.log(g.far+1)/Math.LN2)),(E.isMeshPhongMaterial||E.isMeshToonMaterial||E.isMeshLambertMaterial||E.isMeshBasicMaterial||E.isMeshStandardMaterial||E.isShaderMaterial)&&se.setValue($,"isOrthographic",g.isOrthographicCamera===!0),rt!==g&&(rt=g,de=!0,we=!0)}if(L.isSkinnedMesh){se.setOptional($,L,"bindMatrix"),se.setOptional($,L,"bindMatrixInverse");const En=L.skeleton;En&&(En.boneTexture===null&&En.computeBoneTexture(),se.setValue($,"boneTexture",En.boneTexture,B))}L.isBatchedMesh&&(se.setOptional($,L,"batchingTexture"),se.setValue($,"batchingTexture",L._matricesTexture,B),se.setOptional($,L,"batchingIdTexture"),se.setValue($,"batchingIdTexture",L._indirectTexture,B),se.setOptional($,L,"batchingColorTexture"),L._colorsTexture!==null&&se.setValue($,"batchingColorTexture",L._colorsTexture,B));const gr=U.morphAttributes;if((gr.position!==void 0||gr.normal!==void 0||gr.color!==void 0)&&ne.update(L,U,Ln),(de||$t.receiveShadow!==L.receiveShadow)&&($t.receiveShadow=L.receiveShadow,se.setValue($,"receiveShadow",L.receiveShadow)),E.isMeshGouraudMaterial&&E.envMap!==null&&(dn.envMap.value=pt,dn.flipEnvMap.value=pt.isCubeTexture&&pt.isRenderTargetTexture===!1?-1:1),E.isMeshStandardMaterial&&E.envMap===null&&M.environment!==null&&(dn.envMapIntensity.value=M.environmentIntensity),de&&(se.setValue($,"toneMappingExposure",b.toneMappingExposure),$t.needsLights&&O(dn,we),J&&E.fog===!0&&Ut.refreshFogUniforms(dn,J),Ut.refreshMaterialUniforms(dn,E,ht,W,p.state.transmissionRenderTarget[g.id]),Ka.upload($,_($t),dn,B)),E.isShaderMaterial&&E.uniformsNeedUpdate===!0&&(Ka.upload($,_($t),dn,B),E.uniformsNeedUpdate=!1),E.isSpriteMaterial&&se.setValue($,"center",L.center),se.setValue($,"modelViewMatrix",L.modelViewMatrix),se.setValue($,"normalMatrix",L.normalMatrix),se.setValue($,"modelMatrix",L.matrixWorld),E.isShaderMaterial||E.isRawShaderMaterial){const En=E.uniformsGroups;for(let Xi=0,vr=En.length;Xi<vr;Xi++){const Xc=En[Xi];Q.update(Xc,Ln),Q.bind(Xc,Ln)}}return Ln}function O(g,M){g.ambientLightColor.needsUpdate=M,g.lightProbe.needsUpdate=M,g.directionalLights.needsUpdate=M,g.directionalLightShadows.needsUpdate=M,g.pointLights.needsUpdate=M,g.pointLightShadows.needsUpdate=M,g.spotLights.needsUpdate=M,g.spotLightShadows.needsUpdate=M,g.rectAreaLights.needsUpdate=M,g.hemisphereLights.needsUpdate=M}function F(g){return g.isMeshLambertMaterial||g.isMeshToonMaterial||g.isMeshPhongMaterial||g.isMeshStandardMaterial||g.isShadowMaterial||g.isShaderMaterial&&g.lights===!0}this.getActiveCubeFace=function(){return V},this.getActiveMipmapLevel=function(){return D},this.getRenderTarget=function(){return A},this.setRenderTargetTextures=function(g,M,U){kt.get(g.texture).__webglTexture=M,kt.get(g.depthTexture).__webglTexture=U;const E=kt.get(g);E.__hasExternalTextures=!0,E.__autoAllocateDepthBuffer=U===void 0,E.__autoAllocateDepthBuffer||At.has("WEBGL_multisampled_render_to_texture")===!0&&(console.warn("THREE.WebGLRenderer: Render-to-texture extension was disabled because an external texture was provided"),E.__useRenderToTexture=!1)},this.setRenderTargetFramebuffer=function(g,M){const U=kt.get(g);U.__webglFramebuffer=M,U.__useDefaultFramebuffer=M===void 0},this.setRenderTarget=function(g,M=0,U=0){A=g,V=M,D=U;let E=!0,L=null,J=!1,st=!1;if(g){const pt=kt.get(g);if(pt.__useDefaultFramebuffer!==void 0)Ct.bindFramebuffer($.FRAMEBUFFER,null),E=!1;else if(pt.__webglFramebuffer===void 0)B.setupRenderTarget(g);else if(pt.__hasExternalTextures)B.rebindTextures(g,kt.get(g.texture).__webglTexture,kt.get(g.depthTexture).__webglTexture);else if(g.depthBuffer){const ut=g.depthTexture;if(pt.__boundDepthTexture!==ut){if(ut!==null&&kt.has(ut)&&(g.width!==ut.image.width||g.height!==ut.image.height))throw new Error("WebGLRenderTarget: Attached DepthTexture is initialized to the incorrect size.");B.setupDepthRenderbuffer(g)}}const ot=g.texture;(ot.isData3DTexture||ot.isDataArrayTexture||ot.isCompressedArrayTexture)&&(st=!0);const xt=kt.get(g).__webglFramebuffer;g.isWebGLCubeRenderTarget?(Array.isArray(xt[M])?L=xt[M][U]:L=xt[M],J=!0):g.samples>0&&B.useMultisampledRTT(g)===!1?L=kt.get(g).__webglMultisampledFramebuffer:Array.isArray(xt)?L=xt[U]:L=xt,S.copy(g.viewport),z.copy(g.scissor),nt=g.scissorTest}else S.copy(yt).multiplyScalar(ht).floor(),z.copy(dt).multiplyScalar(ht).floor(),nt=et;if(Ct.bindFramebuffer($.FRAMEBUFFER,L)&&E&&Ct.drawBuffers(g,L),Ct.viewport(S),Ct.scissor(z),Ct.setScissorTest(nt),J){const pt=kt.get(g.texture);$.framebufferTexture2D($.FRAMEBUFFER,$.COLOR_ATTACHMENT0,$.TEXTURE_CUBE_MAP_POSITIVE_X+M,pt.__webglTexture,U)}else if(st){const pt=kt.get(g.texture),ot=M||0;$.framebufferTextureLayer($.FRAMEBUFFER,$.COLOR_ATTACHMENT0,pt.__webglTexture,U||0,ot)}y=-1},this.readRenderTargetPixels=function(g,M,U,E,L,J,st){if(!(g&&g.isWebGLRenderTarget)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let it=kt.get(g).__webglFramebuffer;if(g.isWebGLCubeRenderTarget&&st!==void 0&&(it=it[st]),it){Ct.bindFramebuffer($.FRAMEBUFFER,it);try{const pt=g.texture,ot=pt.format,xt=pt.type;if(!ct.textureFormatReadable(ot)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!ct.textureTypeReadable(xt)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}M>=0&&M<=g.width-E&&U>=0&&U<=g.height-L&&$.readPixels(M,U,E,L,ae.convert(ot),ae.convert(xt),J)}finally{const pt=A!==null?kt.get(A).__webglFramebuffer:null;Ct.bindFramebuffer($.FRAMEBUFFER,pt)}}},this.readRenderTargetPixelsAsync=async function(g,M,U,E,L,J,st){if(!(g&&g.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let it=kt.get(g).__webglFramebuffer;if(g.isWebGLCubeRenderTarget&&st!==void 0&&(it=it[st]),it){const pt=g.texture,ot=pt.format,xt=pt.type;if(!ct.textureFormatReadable(ot))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!ct.textureTypeReadable(xt))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");if(M>=0&&M<=g.width-E&&U>=0&&U<=g.height-L){Ct.bindFramebuffer($.FRAMEBUFFER,it);const ut=$.createBuffer();$.bindBuffer($.PIXEL_PACK_BUFFER,ut),$.bufferData($.PIXEL_PACK_BUFFER,J.byteLength,$.STREAM_READ),$.readPixels(M,U,E,L,ae.convert(ot),ae.convert(xt),0);const It=A!==null?kt.get(A).__webglFramebuffer:null;Ct.bindFramebuffer($.FRAMEBUFFER,It);const Nt=$.fenceSync($.SYNC_GPU_COMMANDS_COMPLETE,0);return $.flush(),await Uf($,Nt,4),$.bindBuffer($.PIXEL_PACK_BUFFER,ut),$.getBufferSubData($.PIXEL_PACK_BUFFER,0,J),$.deleteBuffer(ut),$.deleteSync(Nt),J}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")}},this.copyFramebufferToTexture=function(g,M=null,U=0){g.isTexture!==!0&&($a("WebGLRenderer: copyFramebufferToTexture function signature has changed."),M=arguments[0]||null,g=arguments[1]);const E=Math.pow(2,-U),L=Math.floor(g.image.width*E),J=Math.floor(g.image.height*E),st=M!==null?M.x:0,it=M!==null?M.y:0;B.setTexture2D(g,0),$.copyTexSubImage2D($.TEXTURE_2D,U,0,0,st,it,L,J),Ct.unbindTexture()},this.copyTextureToTexture=function(g,M,U=null,E=null,L=0){g.isTexture!==!0&&($a("WebGLRenderer: copyTextureToTexture function signature has changed."),E=arguments[0]||null,g=arguments[1],M=arguments[2],L=arguments[3]||0,U=null);let J,st,it,pt,ot,xt;U!==null?(J=U.max.x-U.min.x,st=U.max.y-U.min.y,it=U.min.x,pt=U.min.y):(J=g.image.width,st=g.image.height,it=0,pt=0),E!==null?(ot=E.x,xt=E.y):(ot=0,xt=0);const ut=ae.convert(M.format),It=ae.convert(M.type);B.setTexture2D(M,0),$.pixelStorei($.UNPACK_FLIP_Y_WEBGL,M.flipY),$.pixelStorei($.UNPACK_PREMULTIPLY_ALPHA_WEBGL,M.premultiplyAlpha),$.pixelStorei($.UNPACK_ALIGNMENT,M.unpackAlignment);const Nt=$.getParameter($.UNPACK_ROW_LENGTH),Ht=$.getParameter($.UNPACK_IMAGE_HEIGHT),le=$.getParameter($.UNPACK_SKIP_PIXELS),ee=$.getParameter($.UNPACK_SKIP_ROWS),$t=$.getParameter($.UNPACK_SKIP_IMAGES),Ue=g.isCompressedTexture?g.mipmaps[L]:g.image;$.pixelStorei($.UNPACK_ROW_LENGTH,Ue.width),$.pixelStorei($.UNPACK_IMAGE_HEIGHT,Ue.height),$.pixelStorei($.UNPACK_SKIP_PIXELS,it),$.pixelStorei($.UNPACK_SKIP_ROWS,pt),g.isDataTexture?$.texSubImage2D($.TEXTURE_2D,L,ot,xt,J,st,ut,It,Ue.data):g.isCompressedTexture?$.compressedTexSubImage2D($.TEXTURE_2D,L,ot,xt,Ue.width,Ue.height,ut,Ue.data):$.texSubImage2D($.TEXTURE_2D,L,ot,xt,J,st,ut,It,Ue),$.pixelStorei($.UNPACK_ROW_LENGTH,Nt),$.pixelStorei($.UNPACK_IMAGE_HEIGHT,Ht),$.pixelStorei($.UNPACK_SKIP_PIXELS,le),$.pixelStorei($.UNPACK_SKIP_ROWS,ee),$.pixelStorei($.UNPACK_SKIP_IMAGES,$t),L===0&&M.generateMipmaps&&$.generateMipmap($.TEXTURE_2D),Ct.unbindTexture()},this.copyTextureToTexture3D=function(g,M,U=null,E=null,L=0){g.isTexture!==!0&&($a("WebGLRenderer: copyTextureToTexture3D function signature has changed."),U=arguments[0]||null,E=arguments[1]||null,g=arguments[2],M=arguments[3],L=arguments[4]||0);let J,st,it,pt,ot,xt,ut,It,Nt;const Ht=g.isCompressedTexture?g.mipmaps[L]:g.image;U!==null?(J=U.max.x-U.min.x,st=U.max.y-U.min.y,it=U.max.z-U.min.z,pt=U.min.x,ot=U.min.y,xt=U.min.z):(J=Ht.width,st=Ht.height,it=Ht.depth,pt=0,ot=0,xt=0),E!==null?(ut=E.x,It=E.y,Nt=E.z):(ut=0,It=0,Nt=0);const le=ae.convert(M.format),ee=ae.convert(M.type);let $t;if(M.isData3DTexture)B.setTexture3D(M,0),$t=$.TEXTURE_3D;else if(M.isDataArrayTexture||M.isCompressedArrayTexture)B.setTexture2DArray(M,0),$t=$.TEXTURE_2D_ARRAY;else{console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: only supports THREE.DataTexture3D and THREE.DataTexture2DArray.");return}$.pixelStorei($.UNPACK_FLIP_Y_WEBGL,M.flipY),$.pixelStorei($.UNPACK_PREMULTIPLY_ALPHA_WEBGL,M.premultiplyAlpha),$.pixelStorei($.UNPACK_ALIGNMENT,M.unpackAlignment);const Ue=$.getParameter($.UNPACK_ROW_LENGTH),_e=$.getParameter($.UNPACK_IMAGE_HEIGHT),Ln=$.getParameter($.UNPACK_SKIP_PIXELS),Di=$.getParameter($.UNPACK_SKIP_ROWS),de=$.getParameter($.UNPACK_SKIP_IMAGES);$.pixelStorei($.UNPACK_ROW_LENGTH,Ht.width),$.pixelStorei($.UNPACK_IMAGE_HEIGHT,Ht.height),$.pixelStorei($.UNPACK_SKIP_PIXELS,pt),$.pixelStorei($.UNPACK_SKIP_ROWS,ot),$.pixelStorei($.UNPACK_SKIP_IMAGES,xt),g.isDataTexture||g.isData3DTexture?$.texSubImage3D($t,L,ut,It,Nt,J,st,it,le,ee,Ht.data):M.isCompressedArrayTexture?$.compressedTexSubImage3D($t,L,ut,It,Nt,J,st,it,le,Ht.data):$.texSubImage3D($t,L,ut,It,Nt,J,st,it,le,ee,Ht),$.pixelStorei($.UNPACK_ROW_LENGTH,Ue),$.pixelStorei($.UNPACK_IMAGE_HEIGHT,_e),$.pixelStorei($.UNPACK_SKIP_PIXELS,Ln),$.pixelStorei($.UNPACK_SKIP_ROWS,Di),$.pixelStorei($.UNPACK_SKIP_IMAGES,de),L===0&&M.generateMipmaps&&$.generateMipmap($t),Ct.unbindTexture()},this.initRenderTarget=function(g){kt.get(g).__webglFramebuffer===void 0&&B.setupRenderTarget(g)},this.initTexture=function(g){g.isCubeTexture?B.setTextureCube(g,0):g.isData3DTexture?B.setTexture3D(g,0):g.isDataArrayTexture||g.isCompressedArrayTexture?B.setTexture2DArray(g,0):B.setTexture2D(g,0),Ct.unbindTexture()},this.resetState=function(){V=0,D=0,A=null,Ct.reset(),Ae.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return wi}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(t){this._outputColorSpace=t;const e=this.getContext();e.drawingBufferColorSpace=t===Ac?"display-p3":"srgb",e.unpackColorSpace=Ie.workingColorSpace===go?"display-p3":"srgb"}}class Lc{constructor(t,e=25e-5){this.isFogExp2=!0,this.name="",this.color=new Jt(t),this.density=e}clone(){return new Lc(this.color,this.density)}toJSON(){return{type:"FogExp2",name:this.name,color:this.color.getHex(),density:this.density}}}class Uc extends Ze{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new wn,this.environmentIntensity=1,this.environmentRotation=new wn,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(t,e){return super.copy(t,e),t.background!==null&&(this.background=t.background.clone()),t.environment!==null&&(this.environment=t.environment.clone()),t.fog!==null&&(this.fog=t.fog.clone()),this.backgroundBlurriness=t.backgroundBlurriness,this.backgroundIntensity=t.backgroundIntensity,this.backgroundRotation.copy(t.backgroundRotation),this.environmentIntensity=t.environmentIntensity,this.environmentRotation.copy(t.environmentRotation),t.overrideMaterial!==null&&(this.overrideMaterial=t.overrideMaterial.clone()),this.matrixAutoUpdate=t.matrixAutoUpdate,this}toJSON(t){const e=super.toJSON(t);return this.fog!==null&&(e.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(e.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(e.object.backgroundIntensity=this.backgroundIntensity),e.object.backgroundRotation=this.backgroundRotation.toArray(),this.environmentIntensity!==1&&(e.object.environmentIntensity=this.environmentIntensity),e.object.environmentRotation=this.environmentRotation.toArray(),e}}class q1{constructor(t,e){this.isInterleavedBuffer=!0,this.array=t,this.stride=e,this.count=t!==void 0?t.length/e:0,this.usage=cc,this.updateRanges=[],this.version=0,this.uuid=Ti()}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.array=new t.array.constructor(t.array),this.count=t.count,this.stride=t.stride,this.usage=t.usage,this}copyAt(t,e,n){t*=this.stride,n*=e.stride;for(let s=0,r=this.stride;s<r;s++)this.array[t+s]=e.array[n+s];return this}set(t,e=0){return this.array.set(t,e),this}clone(t){t.arrayBuffers===void 0&&(t.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=Ti()),t.arrayBuffers[this.array.buffer._uuid]===void 0&&(t.arrayBuffers[this.array.buffer._uuid]=this.array.slice(0).buffer);const e=new this.array.constructor(t.arrayBuffers[this.array.buffer._uuid]),n=new this.constructor(e,this.stride);return n.setUsage(this.usage),n}onUpload(t){return this.onUploadCallback=t,this}toJSON(t){return t.arrayBuffers===void 0&&(t.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=Ti()),t.arrayBuffers[this.array.buffer._uuid]===void 0&&(t.arrayBuffers[this.array.buffer._uuid]=Array.from(new Uint32Array(this.array.buffer))),{uuid:this.uuid,buffer:this.array.buffer._uuid,type:this.array.constructor.name,stride:this.stride}}}const _n=new N;class io{constructor(t,e,n,s=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=t,this.itemSize=e,this.offset=n,this.normalized=s}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(t){this.data.needsUpdate=t}applyMatrix4(t){for(let e=0,n=this.data.count;e<n;e++)_n.fromBufferAttribute(this,e),_n.applyMatrix4(t),this.setXYZ(e,_n.x,_n.y,_n.z);return this}applyNormalMatrix(t){for(let e=0,n=this.count;e<n;e++)_n.fromBufferAttribute(this,e),_n.applyNormalMatrix(t),this.setXYZ(e,_n.x,_n.y,_n.z);return this}transformDirection(t){for(let e=0,n=this.count;e<n;e++)_n.fromBufferAttribute(this,e),_n.transformDirection(t),this.setXYZ(e,_n.x,_n.y,_n.z);return this}getComponent(t,e){let n=this.array[t*this.data.stride+this.offset+e];return this.normalized&&(n=si(n,this.array)),n}setComponent(t,e,n){return this.normalized&&(n=Le(n,this.array)),this.data.array[t*this.data.stride+this.offset+e]=n,this}setX(t,e){return this.normalized&&(e=Le(e,this.array)),this.data.array[t*this.data.stride+this.offset]=e,this}setY(t,e){return this.normalized&&(e=Le(e,this.array)),this.data.array[t*this.data.stride+this.offset+1]=e,this}setZ(t,e){return this.normalized&&(e=Le(e,this.array)),this.data.array[t*this.data.stride+this.offset+2]=e,this}setW(t,e){return this.normalized&&(e=Le(e,this.array)),this.data.array[t*this.data.stride+this.offset+3]=e,this}getX(t){let e=this.data.array[t*this.data.stride+this.offset];return this.normalized&&(e=si(e,this.array)),e}getY(t){let e=this.data.array[t*this.data.stride+this.offset+1];return this.normalized&&(e=si(e,this.array)),e}getZ(t){let e=this.data.array[t*this.data.stride+this.offset+2];return this.normalized&&(e=si(e,this.array)),e}getW(t){let e=this.data.array[t*this.data.stride+this.offset+3];return this.normalized&&(e=si(e,this.array)),e}setXY(t,e,n){return t=t*this.data.stride+this.offset,this.normalized&&(e=Le(e,this.array),n=Le(n,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=n,this}setXYZ(t,e,n,s){return t=t*this.data.stride+this.offset,this.normalized&&(e=Le(e,this.array),n=Le(n,this.array),s=Le(s,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=n,this.data.array[t+2]=s,this}setXYZW(t,e,n,s,r){return t=t*this.data.stride+this.offset,this.normalized&&(e=Le(e,this.array),n=Le(n,this.array),s=Le(s,this.array),r=Le(r,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=n,this.data.array[t+2]=s,this.data.array[t+3]=r,this}clone(t){if(t===void 0){console.log("THREE.InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");const e=[];for(let n=0;n<this.count;n++){const s=n*this.data.stride+this.offset;for(let r=0;r<this.itemSize;r++)e.push(this.data.array[s+r])}return new Ve(new this.array.constructor(e),this.itemSize,this.normalized)}else return t.interleavedBuffers===void 0&&(t.interleavedBuffers={}),t.interleavedBuffers[this.data.uuid]===void 0&&(t.interleavedBuffers[this.data.uuid]=this.data.clone(t)),new io(t.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(t){if(t===void 0){console.log("THREE.InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");const e=[];for(let n=0;n<this.count;n++){const s=n*this.data.stride+this.offset;for(let r=0;r<this.itemSize;r++)e.push(this.data.array[s+r])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:e,normalized:this.normalized}}else return t.interleavedBuffers===void 0&&(t.interleavedBuffers={}),t.interleavedBuffers[this.data.uuid]===void 0&&(t.interleavedBuffers[this.data.uuid]=this.data.toJSON(t)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}}class Ei extends Vi{constructor(t){super(),this.isSpriteMaterial=!0,this.type="SpriteMaterial",this.color=new Jt(16777215),this.map=null,this.alphaMap=null,this.rotation=0,this.sizeAttenuation=!0,this.transparent=!0,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.alphaMap=t.alphaMap,this.rotation=t.rotation,this.sizeAttenuation=t.sizeAttenuation,this.fog=t.fog,this}}let Ls;const wr=new N,Us=new N,zs=new N,Ns=new Pt,br=new Pt,uh=new Pe,Ma=new N,Tr=new N,ya=new N,O0=new Pt,Jo=new Pt,B0=new Pt;class ki extends Ze{constructor(t=new Ei){if(super(),this.isSprite=!0,this.type="Sprite",Ls===void 0){Ls=new Ye;const e=new Float32Array([-.5,-.5,0,0,0,.5,-.5,0,1,0,.5,.5,0,1,1,-.5,.5,0,0,1]),n=new q1(e,5);Ls.setIndex([0,1,2,0,2,3]),Ls.setAttribute("position",new io(n,3,0,!1)),Ls.setAttribute("uv",new io(n,2,3,!1))}this.geometry=Ls,this.material=t,this.center=new Pt(.5,.5)}raycast(t,e){t.camera===null&&console.error('THREE.Sprite: "Raycaster.camera" needs to be set in order to raycast against sprites.'),Us.setFromMatrixScale(this.matrixWorld),uh.copy(t.camera.matrixWorld),this.modelViewMatrix.multiplyMatrices(t.camera.matrixWorldInverse,this.matrixWorld),zs.setFromMatrixPosition(this.modelViewMatrix),t.camera.isPerspectiveCamera&&this.material.sizeAttenuation===!1&&Us.multiplyScalar(-zs.z);const n=this.material.rotation;let s,r;n!==0&&(r=Math.cos(n),s=Math.sin(n));const a=this.center;Sa(Ma.set(-.5,-.5,0),zs,a,Us,s,r),Sa(Tr.set(.5,-.5,0),zs,a,Us,s,r),Sa(ya.set(.5,.5,0),zs,a,Us,s,r),O0.set(0,0),Jo.set(1,0),B0.set(1,1);let o=t.ray.intersectTriangle(Ma,Tr,ya,!1,wr);if(o===null&&(Sa(Tr.set(-.5,.5,0),zs,a,Us,s,r),Jo.set(0,1),o=t.ray.intersectTriangle(Ma,ya,Tr,!1,wr),o===null))return;const l=t.ray.origin.distanceTo(wr);l<t.near||l>t.far||e.push({distance:l,point:wr.clone(),uv:Yn.getInterpolation(wr,Ma,Tr,ya,O0,Jo,B0,new Pt),face:null,object:this})}copy(t,e){return super.copy(t,e),t.center!==void 0&&this.center.copy(t.center),this.material=t.material,this}}function Sa(i,t,e,n,s,r){Ns.subVectors(i,e).addScalar(.5).multiply(n),s!==void 0?(br.x=r*Ns.x-s*Ns.y,br.y=s*Ns.x+r*Ns.y):br.copy(Ns),i.copy(t),i.x+=br.x,i.y+=br.y,i.applyMatrix4(uh)}class Y1 extends vn{constructor(t=null,e=1,n=1,s,r,a,o,l,h=Dn,f=Dn,m,u){super(null,a,o,l,h,f,s,r,m,u),this.isDataTexture=!0,this.image={data:t,width:e,height:n},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class k0 extends Ve{constructor(t,e,n,s=1){super(t,e,n),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=s}copy(t){return super.copy(t),this.meshPerAttribute=t.meshPerAttribute,this}toJSON(){const t=super.toJSON();return t.meshPerAttribute=this.meshPerAttribute,t.isInstancedBufferAttribute=!0,t}}const Fs=new Pe,H0=new Pe,wa=[],G0=new ms,$1=new Pe,Er=new K,Ar=new Kn;class ba extends K{constructor(t,e,n){super(t,e),this.isInstancedMesh=!0,this.instanceMatrix=new k0(new Float32Array(n*16),16),this.instanceColor=null,this.morphTexture=null,this.count=n,this.boundingBox=null,this.boundingSphere=null;for(let s=0;s<n;s++)this.setMatrixAt(s,$1)}computeBoundingBox(){const t=this.geometry,e=this.count;this.boundingBox===null&&(this.boundingBox=new ms),t.boundingBox===null&&t.computeBoundingBox(),this.boundingBox.makeEmpty();for(let n=0;n<e;n++)this.getMatrixAt(n,Fs),G0.copy(t.boundingBox).applyMatrix4(Fs),this.boundingBox.union(G0)}computeBoundingSphere(){const t=this.geometry,e=this.count;this.boundingSphere===null&&(this.boundingSphere=new Kn),t.boundingSphere===null&&t.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let n=0;n<e;n++)this.getMatrixAt(n,Fs),Ar.copy(t.boundingSphere).applyMatrix4(Fs),this.boundingSphere.union(Ar)}copy(t,e){return super.copy(t,e),this.instanceMatrix.copy(t.instanceMatrix),t.morphTexture!==null&&(this.morphTexture=t.morphTexture.clone()),t.instanceColor!==null&&(this.instanceColor=t.instanceColor.clone()),this.count=t.count,t.boundingBox!==null&&(this.boundingBox=t.boundingBox.clone()),t.boundingSphere!==null&&(this.boundingSphere=t.boundingSphere.clone()),this}getColorAt(t,e){e.fromArray(this.instanceColor.array,t*3)}getMatrixAt(t,e){e.fromArray(this.instanceMatrix.array,t*16)}getMorphAt(t,e){const n=e.morphTargetInfluences,s=this.morphTexture.source.data.data,r=n.length+1,a=t*r+1;for(let o=0;o<n.length;o++)n[o]=s[a+o]}raycast(t,e){const n=this.matrixWorld,s=this.count;if(Er.geometry=this.geometry,Er.material=this.material,Er.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),Ar.copy(this.boundingSphere),Ar.applyMatrix4(n),t.ray.intersectsSphere(Ar)!==!1))for(let r=0;r<s;r++){this.getMatrixAt(r,Fs),H0.multiplyMatrices(n,Fs),Er.matrixWorld=H0,Er.raycast(t,wa);for(let a=0,o=wa.length;a<o;a++){const l=wa[a];l.instanceId=r,l.object=this,e.push(l)}wa.length=0}}setColorAt(t,e){this.instanceColor===null&&(this.instanceColor=new k0(new Float32Array(this.instanceMatrix.count*3).fill(1),3)),e.toArray(this.instanceColor.array,t*3)}setMatrixAt(t,e){e.toArray(this.instanceMatrix.array,t*16)}setMorphAt(t,e){const n=e.morphTargetInfluences,s=n.length+1;this.morphTexture===null&&(this.morphTexture=new Y1(new Float32Array(s*this.count),s,this.count,wc,fi));const r=this.morphTexture.source.data.data;let a=0;for(let h=0;h<n.length;h++)a+=n[h];const o=this.geometry.morphTargetsRelative?1:1-a,l=s*t;r[l]=o,r.set(n,l+1)}updateMorphTargets(){}dispose(){return this.dispatchEvent({type:"dispose"}),this.morphTexture!==null&&(this.morphTexture.dispose(),this.morphTexture=null),this}}class hh extends Vi{constructor(t){super(),this.isLineBasicMaterial=!0,this.type="LineBasicMaterial",this.color=new Jt(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.linewidth=t.linewidth,this.linecap=t.linecap,this.linejoin=t.linejoin,this.fog=t.fog,this}}const so=new N,ro=new N,V0=new Pe,Cr=new vo,Ta=new Kn,Qo=new N,W0=new N;class K1 extends Ze{constructor(t=new Ye,e=new hh){super(),this.isLine=!0,this.type="Line",this.geometry=t,this.material=e,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}computeLineDistances(){const t=this.geometry;if(t.index===null){const e=t.attributes.position,n=[0];for(let s=1,r=e.count;s<r;s++)so.fromBufferAttribute(e,s-1),ro.fromBufferAttribute(e,s),n[s]=n[s-1],n[s]+=so.distanceTo(ro);t.setAttribute("lineDistance",new Ce(n,1))}else console.warn("THREE.Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}raycast(t,e){const n=this.geometry,s=this.matrixWorld,r=t.params.Line.threshold,a=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),Ta.copy(n.boundingSphere),Ta.applyMatrix4(s),Ta.radius+=r,t.ray.intersectsSphere(Ta)===!1)return;V0.copy(s).invert(),Cr.copy(t.ray).applyMatrix4(V0);const o=r/((this.scale.x+this.scale.y+this.scale.z)/3),l=o*o,h=this.isLineSegments?2:1,f=n.index,u=n.attributes.position;if(f!==null){const d=Math.max(0,a.start),c=Math.min(f.count,a.start+a.count);for(let v=d,p=c-1;v<p;v+=h){const x=f.getX(v),w=f.getX(v+1),b=Ea(this,t,Cr,l,x,w);b&&e.push(b)}if(this.isLineLoop){const v=f.getX(c-1),p=f.getX(d),x=Ea(this,t,Cr,l,v,p);x&&e.push(x)}}else{const d=Math.max(0,a.start),c=Math.min(u.count,a.start+a.count);for(let v=d,p=c-1;v<p;v+=h){const x=Ea(this,t,Cr,l,v,v+1);x&&e.push(x)}if(this.isLineLoop){const v=Ea(this,t,Cr,l,c-1,d);v&&e.push(v)}}}updateMorphTargets(){const e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){const s=e[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,a=s.length;r<a;r++){const o=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=r}}}}}function Ea(i,t,e,n,s,r){const a=i.geometry.attributes.position;if(so.fromBufferAttribute(a,s),ro.fromBufferAttribute(a,r),e.distanceSqToSegment(so,ro,Qo,W0)>n)return;Qo.applyMatrix4(i.matrixWorld);const l=t.ray.origin.distanceTo(Qo);if(!(l<t.near||l>t.far))return{distance:l,point:W0.clone().applyMatrix4(i.matrixWorld),index:s,face:null,faceIndex:null,barycoord:null,object:i}}const X0=new N,q0=new N;class Z1 extends K1{constructor(t,e){super(t,e),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){const t=this.geometry;if(t.index===null){const e=t.attributes.position,n=[];for(let s=0,r=e.count;s<r;s+=2)X0.fromBufferAttribute(e,s),q0.fromBufferAttribute(e,s+1),n[s]=s===0?0:n[s-1],n[s+1]=n[s]+X0.distanceTo(q0);t.setAttribute("lineDistance",new Ce(n,1))}else console.warn("THREE.LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}}class fh extends Vi{constructor(t){super(),this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new Jt(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.alphaMap=t.alphaMap,this.size=t.size,this.sizeAttenuation=t.sizeAttenuation,this.fog=t.fog,this}}const Y0=new Pe,fc=new vo,Aa=new Kn,Ca=new N;class ao extends Ze{constructor(t=new Ye,e=new fh){super(),this.isPoints=!0,this.type="Points",this.geometry=t,this.material=e,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}raycast(t,e){const n=this.geometry,s=this.matrixWorld,r=t.params.Points.threshold,a=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),Aa.copy(n.boundingSphere),Aa.applyMatrix4(s),Aa.radius+=r,t.ray.intersectsSphere(Aa)===!1)return;Y0.copy(s).invert(),fc.copy(t.ray).applyMatrix4(Y0);const o=r/((this.scale.x+this.scale.y+this.scale.z)/3),l=o*o,h=n.index,m=n.attributes.position;if(h!==null){const u=Math.max(0,a.start),d=Math.min(h.count,a.start+a.count);for(let c=u,v=d;c<v;c++){const p=h.getX(c);Ca.fromBufferAttribute(m,p),$0(Ca,p,l,s,t,e,this)}}else{const u=Math.max(0,a.start),d=Math.min(m.count,a.start+a.count);for(let c=u,v=d;c<v;c++)Ca.fromBufferAttribute(m,c),$0(Ca,c,l,s,t,e,this)}}updateMorphTargets(){const e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){const s=e[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,a=s.length;r<a;r++){const o=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=r}}}}}function $0(i,t,e,n,s,r,a){const o=fc.distanceSqToPoint(i);if(o<e){const l=new N;fc.closestPointToPoint(i,l),l.applyMatrix4(n);const h=s.ray.origin.distanceTo(l);if(h<s.near||h>s.far)return;r.push({distance:h,distanceToRay:Math.sqrt(o),point:l,index:t,face:null,faceIndex:null,barycoord:null,object:a})}}class gs extends vn{constructor(t,e,n,s,r,a,o,l,h){super(t,e,n,s,r,a,o,l,h),this.isCanvasTexture=!0,this.needsUpdate=!0}}class Ri{constructor(){this.type="Curve",this.arcLengthDivisions=200}getPoint(){return console.warn("THREE.Curve: .getPoint() not implemented."),null}getPointAt(t,e){const n=this.getUtoTmapping(t);return this.getPoint(n,e)}getPoints(t=5){const e=[];for(let n=0;n<=t;n++)e.push(this.getPoint(n/t));return e}getSpacedPoints(t=5){const e=[];for(let n=0;n<=t;n++)e.push(this.getPointAt(n/t));return e}getLength(){const t=this.getLengths();return t[t.length-1]}getLengths(t=this.arcLengthDivisions){if(this.cacheArcLengths&&this.cacheArcLengths.length===t+1&&!this.needsUpdate)return this.cacheArcLengths;this.needsUpdate=!1;const e=[];let n,s=this.getPoint(0),r=0;e.push(0);for(let a=1;a<=t;a++)n=this.getPoint(a/t),r+=n.distanceTo(s),e.push(r),s=n;return this.cacheArcLengths=e,e}updateArcLengths(){this.needsUpdate=!0,this.getLengths()}getUtoTmapping(t,e){const n=this.getLengths();let s=0;const r=n.length;let a;e?a=e:a=t*n[r-1];let o=0,l=r-1,h;for(;o<=l;)if(s=Math.floor(o+(l-o)/2),h=n[s]-a,h<0)o=s+1;else if(h>0)l=s-1;else{l=s;break}if(s=l,n[s]===a)return s/(r-1);const f=n[s],u=n[s+1]-f,d=(a-f)/u;return(s+d)/(r-1)}getTangent(t,e){let s=t-1e-4,r=t+1e-4;s<0&&(s=0),r>1&&(r=1);const a=this.getPoint(s),o=this.getPoint(r),l=e||(a.isVector2?new Pt:new N);return l.copy(o).sub(a).normalize(),l}getTangentAt(t,e){const n=this.getUtoTmapping(t);return this.getTangent(n,e)}computeFrenetFrames(t,e){const n=new N,s=[],r=[],a=[],o=new N,l=new Pe;for(let d=0;d<=t;d++){const c=d/t;s[d]=this.getTangentAt(c,new N)}r[0]=new N,a[0]=new N;let h=Number.MAX_VALUE;const f=Math.abs(s[0].x),m=Math.abs(s[0].y),u=Math.abs(s[0].z);f<=h&&(h=f,n.set(1,0,0)),m<=h&&(h=m,n.set(0,1,0)),u<=h&&n.set(0,0,1),o.crossVectors(s[0],n).normalize(),r[0].crossVectors(s[0],o),a[0].crossVectors(s[0],r[0]);for(let d=1;d<=t;d++){if(r[d]=r[d-1].clone(),a[d]=a[d-1].clone(),o.crossVectors(s[d-1],s[d]),o.length()>Number.EPSILON){o.normalize();const c=Math.acos(un(s[d-1].dot(s[d]),-1,1));r[d].applyMatrix4(l.makeRotationAxis(o,c))}a[d].crossVectors(s[d],r[d])}if(e===!0){let d=Math.acos(un(r[0].dot(r[t]),-1,1));d/=t,s[0].dot(o.crossVectors(r[0],r[t]))>0&&(d=-d);for(let c=1;c<=t;c++)r[c].applyMatrix4(l.makeRotationAxis(s[c],d*c)),a[c].crossVectors(s[c],r[c])}return{tangents:s,normals:r,binormals:a}}clone(){return new this.constructor().copy(this)}copy(t){return this.arcLengthDivisions=t.arcLengthDivisions,this}toJSON(){const t={metadata:{version:4.6,type:"Curve",generator:"Curve.toJSON"}};return t.arcLengthDivisions=this.arcLengthDivisions,t.type=this.type,t}fromJSON(t){return this.arcLengthDivisions=t.arcLengthDivisions,this}}class dh extends Ri{constructor(t=0,e=0,n=1,s=1,r=0,a=Math.PI*2,o=!1,l=0){super(),this.isEllipseCurve=!0,this.type="EllipseCurve",this.aX=t,this.aY=e,this.xRadius=n,this.yRadius=s,this.aStartAngle=r,this.aEndAngle=a,this.aClockwise=o,this.aRotation=l}getPoint(t,e=new Pt){const n=e,s=Math.PI*2;let r=this.aEndAngle-this.aStartAngle;const a=Math.abs(r)<Number.EPSILON;for(;r<0;)r+=s;for(;r>s;)r-=s;r<Number.EPSILON&&(a?r=0:r=s),this.aClockwise===!0&&!a&&(r===s?r=-s:r=r-s);const o=this.aStartAngle+t*r;let l=this.aX+this.xRadius*Math.cos(o),h=this.aY+this.yRadius*Math.sin(o);if(this.aRotation!==0){const f=Math.cos(this.aRotation),m=Math.sin(this.aRotation),u=l-this.aX,d=h-this.aY;l=u*f-d*m+this.aX,h=u*m+d*f+this.aY}return n.set(l,h)}copy(t){return super.copy(t),this.aX=t.aX,this.aY=t.aY,this.xRadius=t.xRadius,this.yRadius=t.yRadius,this.aStartAngle=t.aStartAngle,this.aEndAngle=t.aEndAngle,this.aClockwise=t.aClockwise,this.aRotation=t.aRotation,this}toJSON(){const t=super.toJSON();return t.aX=this.aX,t.aY=this.aY,t.xRadius=this.xRadius,t.yRadius=this.yRadius,t.aStartAngle=this.aStartAngle,t.aEndAngle=this.aEndAngle,t.aClockwise=this.aClockwise,t.aRotation=this.aRotation,t}fromJSON(t){return super.fromJSON(t),this.aX=t.aX,this.aY=t.aY,this.xRadius=t.xRadius,this.yRadius=t.yRadius,this.aStartAngle=t.aStartAngle,this.aEndAngle=t.aEndAngle,this.aClockwise=t.aClockwise,this.aRotation=t.aRotation,this}}class j1 extends dh{constructor(t,e,n,s,r,a){super(t,e,n,n,s,r,a),this.isArcCurve=!0,this.type="ArcCurve"}}function zc(){let i=0,t=0,e=0,n=0;function s(r,a,o,l){i=r,t=o,e=-3*r+3*a-2*o-l,n=2*r-2*a+o+l}return{initCatmullRom:function(r,a,o,l,h){s(a,o,h*(o-r),h*(l-a))},initNonuniformCatmullRom:function(r,a,o,l,h,f,m){let u=(a-r)/h-(o-r)/(h+f)+(o-a)/f,d=(o-a)/f-(l-a)/(f+m)+(l-o)/m;u*=f,d*=f,s(a,o,u,d)},calc:function(r){const a=r*r,o=a*r;return i+t*r+e*a+n*o}}}const Ra=new N,tl=new zc,el=new zc,nl=new zc;class Nc extends Ri{constructor(t=[],e=!1,n="centripetal",s=.5){super(),this.isCatmullRomCurve3=!0,this.type="CatmullRomCurve3",this.points=t,this.closed=e,this.curveType=n,this.tension=s}getPoint(t,e=new N){const n=e,s=this.points,r=s.length,a=(r-(this.closed?0:1))*t;let o=Math.floor(a),l=a-o;this.closed?o+=o>0?0:(Math.floor(Math.abs(o)/r)+1)*r:l===0&&o===r-1&&(o=r-2,l=1);let h,f;this.closed||o>0?h=s[(o-1)%r]:(Ra.subVectors(s[0],s[1]).add(s[0]),h=Ra);const m=s[o%r],u=s[(o+1)%r];if(this.closed||o+2<r?f=s[(o+2)%r]:(Ra.subVectors(s[r-1],s[r-2]).add(s[r-1]),f=Ra),this.curveType==="centripetal"||this.curveType==="chordal"){const d=this.curveType==="chordal"?.5:.25;let c=Math.pow(h.distanceToSquared(m),d),v=Math.pow(m.distanceToSquared(u),d),p=Math.pow(u.distanceToSquared(f),d);v<1e-4&&(v=1),c<1e-4&&(c=v),p<1e-4&&(p=v),tl.initNonuniformCatmullRom(h.x,m.x,u.x,f.x,c,v,p),el.initNonuniformCatmullRom(h.y,m.y,u.y,f.y,c,v,p),nl.initNonuniformCatmullRom(h.z,m.z,u.z,f.z,c,v,p)}else this.curveType==="catmullrom"&&(tl.initCatmullRom(h.x,m.x,u.x,f.x,this.tension),el.initCatmullRom(h.y,m.y,u.y,f.y,this.tension),nl.initCatmullRom(h.z,m.z,u.z,f.z,this.tension));return n.set(tl.calc(l),el.calc(l),nl.calc(l)),n}copy(t){super.copy(t),this.points=[];for(let e=0,n=t.points.length;e<n;e++){const s=t.points[e];this.points.push(s.clone())}return this.closed=t.closed,this.curveType=t.curveType,this.tension=t.tension,this}toJSON(){const t=super.toJSON();t.points=[];for(let e=0,n=this.points.length;e<n;e++){const s=this.points[e];t.points.push(s.toArray())}return t.closed=this.closed,t.curveType=this.curveType,t.tension=this.tension,t}fromJSON(t){super.fromJSON(t),this.points=[];for(let e=0,n=t.points.length;e<n;e++){const s=t.points[e];this.points.push(new N().fromArray(s))}return this.closed=t.closed,this.curveType=t.curveType,this.tension=t.tension,this}}function K0(i,t,e,n,s){const r=(n-t)*.5,a=(s-e)*.5,o=i*i,l=i*o;return(2*e-2*n+r+a)*l+(-3*e+3*n-2*r-a)*o+r*i+e}function J1(i,t){const e=1-i;return e*e*t}function Q1(i,t){return 2*(1-i)*i*t}function t2(i,t){return i*i*t}function Hr(i,t,e,n){return J1(i,t)+Q1(i,e)+t2(i,n)}function e2(i,t){const e=1-i;return e*e*e*t}function n2(i,t){const e=1-i;return 3*e*e*i*t}function i2(i,t){return 3*(1-i)*i*i*t}function s2(i,t){return i*i*i*t}function Gr(i,t,e,n,s){return e2(i,t)+n2(i,e)+i2(i,n)+s2(i,s)}class r2 extends Ri{constructor(t=new Pt,e=new Pt,n=new Pt,s=new Pt){super(),this.isCubicBezierCurve=!0,this.type="CubicBezierCurve",this.v0=t,this.v1=e,this.v2=n,this.v3=s}getPoint(t,e=new Pt){const n=e,s=this.v0,r=this.v1,a=this.v2,o=this.v3;return n.set(Gr(t,s.x,r.x,a.x,o.x),Gr(t,s.y,r.y,a.y,o.y)),n}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this.v3.copy(t.v3),this}toJSON(){const t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t.v3=this.v3.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this.v3.fromArray(t.v3),this}}class a2 extends Ri{constructor(t=new N,e=new N,n=new N,s=new N){super(),this.isCubicBezierCurve3=!0,this.type="CubicBezierCurve3",this.v0=t,this.v1=e,this.v2=n,this.v3=s}getPoint(t,e=new N){const n=e,s=this.v0,r=this.v1,a=this.v2,o=this.v3;return n.set(Gr(t,s.x,r.x,a.x,o.x),Gr(t,s.y,r.y,a.y,o.y),Gr(t,s.z,r.z,a.z,o.z)),n}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this.v3.copy(t.v3),this}toJSON(){const t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t.v3=this.v3.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this.v3.fromArray(t.v3),this}}class o2 extends Ri{constructor(t=new Pt,e=new Pt){super(),this.isLineCurve=!0,this.type="LineCurve",this.v1=t,this.v2=e}getPoint(t,e=new Pt){const n=e;return t===1?n.copy(this.v2):(n.copy(this.v2).sub(this.v1),n.multiplyScalar(t).add(this.v1)),n}getPointAt(t,e){return this.getPoint(t,e)}getTangent(t,e=new Pt){return e.subVectors(this.v2,this.v1).normalize()}getTangentAt(t,e){return this.getTangent(t,e)}copy(t){return super.copy(t),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){const t=super.toJSON();return t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}}class l2 extends Ri{constructor(t=new N,e=new N){super(),this.isLineCurve3=!0,this.type="LineCurve3",this.v1=t,this.v2=e}getPoint(t,e=new N){const n=e;return t===1?n.copy(this.v2):(n.copy(this.v2).sub(this.v1),n.multiplyScalar(t).add(this.v1)),n}getPointAt(t,e){return this.getPoint(t,e)}getTangent(t,e=new N){return e.subVectors(this.v2,this.v1).normalize()}getTangentAt(t,e){return this.getTangent(t,e)}copy(t){return super.copy(t),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){const t=super.toJSON();return t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}}class c2 extends Ri{constructor(t=new Pt,e=new Pt,n=new Pt){super(),this.isQuadraticBezierCurve=!0,this.type="QuadraticBezierCurve",this.v0=t,this.v1=e,this.v2=n}getPoint(t,e=new Pt){const n=e,s=this.v0,r=this.v1,a=this.v2;return n.set(Hr(t,s.x,r.x,a.x),Hr(t,s.y,r.y,a.y)),n}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){const t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}}class ph extends Ri{constructor(t=new N,e=new N,n=new N){super(),this.isQuadraticBezierCurve3=!0,this.type="QuadraticBezierCurve3",this.v0=t,this.v1=e,this.v2=n}getPoint(t,e=new N){const n=e,s=this.v0,r=this.v1,a=this.v2;return n.set(Hr(t,s.x,r.x,a.x),Hr(t,s.y,r.y,a.y),Hr(t,s.z,r.z,a.z)),n}copy(t){return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this}toJSON(){const t=super.toJSON();return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t}fromJSON(t){return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this}}class u2 extends Ri{constructor(t=[]){super(),this.isSplineCurve=!0,this.type="SplineCurve",this.points=t}getPoint(t,e=new Pt){const n=e,s=this.points,r=(s.length-1)*t,a=Math.floor(r),o=r-a,l=s[a===0?a:a-1],h=s[a],f=s[a>s.length-2?s.length-1:a+1],m=s[a>s.length-3?s.length-1:a+2];return n.set(K0(o,l.x,h.x,f.x,m.x),K0(o,l.y,h.y,f.y,m.y)),n}copy(t){super.copy(t),this.points=[];for(let e=0,n=t.points.length;e<n;e++){const s=t.points[e];this.points.push(s.clone())}return this}toJSON(){const t=super.toJSON();t.points=[];for(let e=0,n=this.points.length;e<n;e++){const s=this.points[e];t.points.push(s.toArray())}return t}fromJSON(t){super.fromJSON(t),this.points=[];for(let e=0,n=t.points.length;e<n;e++){const s=t.points[e];this.points.push(new Pt().fromArray(s))}return this}}var h2=Object.freeze({__proto__:null,ArcCurve:j1,CatmullRomCurve3:Nc,CubicBezierCurve:r2,CubicBezierCurve3:a2,EllipseCurve:dh,LineCurve:o2,LineCurve3:l2,QuadraticBezierCurve:c2,QuadraticBezierCurve3:ph,SplineCurve:u2});class li extends Ye{constructor(t=1,e=32,n=0,s=Math.PI*2){super(),this.type="CircleGeometry",this.parameters={radius:t,segments:e,thetaStart:n,thetaLength:s},e=Math.max(3,e);const r=[],a=[],o=[],l=[],h=new N,f=new Pt;a.push(0,0,0),o.push(0,0,1),l.push(.5,.5);for(let m=0,u=3;m<=e;m++,u+=3){const d=n+m/e*s;h.x=t*Math.cos(d),h.y=t*Math.sin(d),a.push(h.x,h.y,h.z),o.push(0,0,1),f.x=(a[u]/t+1)/2,f.y=(a[u+1]/t+1)/2,l.push(f.x,f.y)}for(let m=1;m<=e;m++)r.push(m,m+1,0);this.setIndex(r),this.setAttribute("position",new Ce(a,3)),this.setAttribute("normal",new Ce(o,3)),this.setAttribute("uv",new Ce(l,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new li(t.radius,t.segments,t.thetaStart,t.thetaLength)}}class Re extends Ye{constructor(t=1,e=1,n=1,s=32,r=1,a=!1,o=0,l=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:t,radiusBottom:e,height:n,radialSegments:s,heightSegments:r,openEnded:a,thetaStart:o,thetaLength:l};const h=this;s=Math.floor(s),r=Math.floor(r);const f=[],m=[],u=[],d=[];let c=0;const v=[],p=n/2;let x=0;w(),a===!1&&(t>0&&b(!0),e>0&&b(!1)),this.setIndex(f),this.setAttribute("position",new Ce(m,3)),this.setAttribute("normal",new Ce(u,3)),this.setAttribute("uv",new Ce(d,2));function w(){const C=new N,V=new N;let D=0;const A=(e-t)/n;for(let y=0;y<=r;y++){const rt=[],S=y/r,z=S*(e-t)+t;for(let nt=0;nt<=s;nt++){const q=nt/s,j=q*l+o,Y=Math.sin(j),W=Math.cos(j);V.x=z*Y,V.y=-S*n+p,V.z=z*W,m.push(V.x,V.y,V.z),C.set(Y,A,W).normalize(),u.push(C.x,C.y,C.z),d.push(q,1-S),rt.push(c++)}v.push(rt)}for(let y=0;y<s;y++)for(let rt=0;rt<r;rt++){const S=v[rt][y],z=v[rt+1][y],nt=v[rt+1][y+1],q=v[rt][y+1];t>0&&(f.push(S,z,q),D+=3),e>0&&(f.push(z,nt,q),D+=3)}h.addGroup(x,D,0),x+=D}function b(C){const V=c,D=new Pt,A=new N;let y=0;const rt=C===!0?t:e,S=C===!0?1:-1;for(let nt=1;nt<=s;nt++)m.push(0,p*S,0),u.push(0,S,0),d.push(.5,.5),c++;const z=c;for(let nt=0;nt<=s;nt++){const j=nt/s*l+o,Y=Math.cos(j),W=Math.sin(j);A.x=rt*W,A.y=p*S,A.z=rt*Y,m.push(A.x,A.y,A.z),u.push(0,S,0),D.x=Y*.5+.5,D.y=W*.5*S+.5,d.push(D.x,D.y),c++}for(let nt=0;nt<s;nt++){const q=V+nt,j=z+nt;C===!0?f.push(j,j+1,q):f.push(j+1,j,q),y+=3}h.addGroup(x,y,C===!0?1:2),x+=y}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Re(t.radiusTop,t.radiusBottom,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}}class oo extends Re{constructor(t=1,e=1,n=32,s=1,r=!1,a=0,o=Math.PI*2){super(0,t,e,n,s,r,a,o),this.type="ConeGeometry",this.parameters={radius:t,height:e,radialSegments:n,heightSegments:s,openEnded:r,thetaStart:a,thetaLength:o}}static fromJSON(t){return new oo(t.radius,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}}class _o extends Ye{constructor(t=[],e=[],n=1,s=0){super(),this.type="PolyhedronGeometry",this.parameters={vertices:t,indices:e,radius:n,detail:s};const r=[],a=[];o(s),h(n),f(),this.setAttribute("position",new Ce(r,3)),this.setAttribute("normal",new Ce(r.slice(),3)),this.setAttribute("uv",new Ce(a,2)),s===0?this.computeVertexNormals():this.normalizeNormals();function o(w){const b=new N,C=new N,V=new N;for(let D=0;D<e.length;D+=3)d(e[D+0],b),d(e[D+1],C),d(e[D+2],V),l(b,C,V,w)}function l(w,b,C,V){const D=V+1,A=[];for(let y=0;y<=D;y++){A[y]=[];const rt=w.clone().lerp(C,y/D),S=b.clone().lerp(C,y/D),z=D-y;for(let nt=0;nt<=z;nt++)nt===0&&y===D?A[y][nt]=rt:A[y][nt]=rt.clone().lerp(S,nt/z)}for(let y=0;y<D;y++)for(let rt=0;rt<2*(D-y)-1;rt++){const S=Math.floor(rt/2);rt%2===0?(u(A[y][S+1]),u(A[y+1][S]),u(A[y][S])):(u(A[y][S+1]),u(A[y+1][S+1]),u(A[y+1][S]))}}function h(w){const b=new N;for(let C=0;C<r.length;C+=3)b.x=r[C+0],b.y=r[C+1],b.z=r[C+2],b.normalize().multiplyScalar(w),r[C+0]=b.x,r[C+1]=b.y,r[C+2]=b.z}function f(){const w=new N;for(let b=0;b<r.length;b+=3){w.x=r[b+0],w.y=r[b+1],w.z=r[b+2];const C=p(w)/2/Math.PI+.5,V=x(w)/Math.PI+.5;a.push(C,1-V)}c(),m()}function m(){for(let w=0;w<a.length;w+=6){const b=a[w+0],C=a[w+2],V=a[w+4],D=Math.max(b,C,V),A=Math.min(b,C,V);D>.9&&A<.1&&(b<.2&&(a[w+0]+=1),C<.2&&(a[w+2]+=1),V<.2&&(a[w+4]+=1))}}function u(w){r.push(w.x,w.y,w.z)}function d(w,b){const C=w*3;b.x=t[C+0],b.y=t[C+1],b.z=t[C+2]}function c(){const w=new N,b=new N,C=new N,V=new N,D=new Pt,A=new Pt,y=new Pt;for(let rt=0,S=0;rt<r.length;rt+=9,S+=6){w.set(r[rt+0],r[rt+1],r[rt+2]),b.set(r[rt+3],r[rt+4],r[rt+5]),C.set(r[rt+6],r[rt+7],r[rt+8]),D.set(a[S+0],a[S+1]),A.set(a[S+2],a[S+3]),y.set(a[S+4],a[S+5]),V.copy(w).add(b).add(C).divideScalar(3);const z=p(V);v(D,S+0,w,z),v(A,S+2,b,z),v(y,S+4,C,z)}}function v(w,b,C,V){V<0&&w.x===1&&(a[b]=w.x-1),C.x===0&&C.z===0&&(a[b]=V/2/Math.PI+.5)}function p(w){return Math.atan2(w.z,-w.x)}function x(w){return Math.atan2(-w.y,Math.sqrt(w.x*w.x+w.z*w.z))}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new _o(t.vertices,t.indices,t.radius,t.details)}}class Fc extends _o{constructor(t=1,e=0){const n=(1+Math.sqrt(5))/2,s=1/n,r=[-1,-1,-1,-1,-1,1,-1,1,-1,-1,1,1,1,-1,-1,1,-1,1,1,1,-1,1,1,1,0,-s,-n,0,-s,n,0,s,-n,0,s,n,-s,-n,0,-s,n,0,s,-n,0,s,n,0,-n,0,-s,n,0,-s,-n,0,s,n,0,s],a=[3,11,7,3,7,15,3,15,13,7,19,17,7,17,6,7,6,15,17,4,8,17,8,10,17,10,6,8,0,16,8,16,2,8,2,10,0,12,1,0,1,18,0,18,16,6,10,2,6,2,13,6,13,15,2,16,18,2,18,3,2,3,13,18,1,9,18,9,11,18,11,3,4,14,12,4,12,0,4,0,8,11,9,5,11,5,19,11,19,7,19,5,14,19,14,4,19,4,17,1,12,14,1,14,5,1,5,9];super(r,a,t,e),this.type="DodecahedronGeometry",this.parameters={radius:t,detail:e}}static fromJSON(t){return new Fc(t.radius,t.detail)}}class Mo extends _o{constructor(t=1,e=0){const n=(1+Math.sqrt(5))/2,s=[-1,n,0,1,n,0,-1,-n,0,1,-n,0,0,-1,n,0,1,n,0,-1,-n,0,1,-n,n,0,-1,n,0,1,-n,0,-1,-n,0,1],r=[0,11,5,0,5,1,0,1,7,0,7,10,0,10,11,1,5,9,5,11,4,11,10,2,10,7,6,7,1,8,3,9,4,3,4,2,3,2,6,3,6,8,3,8,9,4,9,5,2,4,11,6,2,10,8,6,7,9,8,1];super(s,r,t,e),this.type="IcosahedronGeometry",this.parameters={radius:t,detail:e}}static fromJSON(t){return new Mo(t.radius,t.detail)}}class ur extends Ye{constructor(t=.5,e=1,n=32,s=1,r=0,a=Math.PI*2){super(),this.type="RingGeometry",this.parameters={innerRadius:t,outerRadius:e,thetaSegments:n,phiSegments:s,thetaStart:r,thetaLength:a},n=Math.max(3,n),s=Math.max(1,s);const o=[],l=[],h=[],f=[];let m=t;const u=(e-t)/s,d=new N,c=new Pt;for(let v=0;v<=s;v++){for(let p=0;p<=n;p++){const x=r+p/n*a;d.x=m*Math.cos(x),d.y=m*Math.sin(x),l.push(d.x,d.y,d.z),h.push(0,0,1),c.x=(d.x/e+1)/2,c.y=(d.y/e+1)/2,f.push(c.x,c.y)}m+=u}for(let v=0;v<s;v++){const p=v*(n+1);for(let x=0;x<n;x++){const w=x+p,b=w,C=w+n+1,V=w+n+2,D=w+1;o.push(b,C,D),o.push(C,V,D)}}this.setIndex(o),this.setAttribute("position",new Ce(l,3)),this.setAttribute("normal",new Ce(h,3)),this.setAttribute("uv",new Ce(f,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new ur(t.innerRadius,t.outerRadius,t.thetaSegments,t.phiSegments,t.thetaStart,t.thetaLength)}}class Ci extends Ye{constructor(t=1,e=32,n=16,s=0,r=Math.PI*2,a=0,o=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:t,widthSegments:e,heightSegments:n,phiStart:s,phiLength:r,thetaStart:a,thetaLength:o},e=Math.max(3,Math.floor(e)),n=Math.max(2,Math.floor(n));const l=Math.min(a+o,Math.PI);let h=0;const f=[],m=new N,u=new N,d=[],c=[],v=[],p=[];for(let x=0;x<=n;x++){const w=[],b=x/n;let C=0;x===0&&a===0?C=.5/e:x===n&&l===Math.PI&&(C=-.5/e);for(let V=0;V<=e;V++){const D=V/e;m.x=-t*Math.cos(s+D*r)*Math.sin(a+b*o),m.y=t*Math.cos(a+b*o),m.z=t*Math.sin(s+D*r)*Math.sin(a+b*o),c.push(m.x,m.y,m.z),u.copy(m).normalize(),v.push(u.x,u.y,u.z),p.push(D+C,1-b),w.push(h++)}f.push(w)}for(let x=0;x<n;x++)for(let w=0;w<e;w++){const b=f[x][w+1],C=f[x][w],V=f[x+1][w],D=f[x+1][w+1];(x!==0||a>0)&&d.push(b,C,D),(x!==n-1||l<Math.PI)&&d.push(C,V,D)}this.setIndex(d),this.setAttribute("position",new Ce(c,3)),this.setAttribute("normal",new Ce(v,3)),this.setAttribute("uv",new Ce(p,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Ci(t.radius,t.widthSegments,t.heightSegments,t.phiStart,t.phiLength,t.thetaStart,t.thetaLength)}}class Rn extends Ye{constructor(t=1,e=.4,n=12,s=48,r=Math.PI*2){super(),this.type="TorusGeometry",this.parameters={radius:t,tube:e,radialSegments:n,tubularSegments:s,arc:r},n=Math.floor(n),s=Math.floor(s);const a=[],o=[],l=[],h=[],f=new N,m=new N,u=new N;for(let d=0;d<=n;d++)for(let c=0;c<=s;c++){const v=c/s*r,p=d/n*Math.PI*2;m.x=(t+e*Math.cos(p))*Math.cos(v),m.y=(t+e*Math.cos(p))*Math.sin(v),m.z=e*Math.sin(p),o.push(m.x,m.y,m.z),f.x=t*Math.cos(v),f.y=t*Math.sin(v),u.subVectors(m,f).normalize(),l.push(u.x,u.y,u.z),h.push(c/s),h.push(d/n)}for(let d=1;d<=n;d++)for(let c=1;c<=s;c++){const v=(s+1)*d+c-1,p=(s+1)*(d-1)+c-1,x=(s+1)*(d-1)+c,w=(s+1)*d+c;a.push(v,p,w),a.push(p,x,w)}this.setIndex(a),this.setAttribute("position",new Ce(o,3)),this.setAttribute("normal",new Ce(l,3)),this.setAttribute("uv",new Ce(h,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Rn(t.radius,t.tube,t.radialSegments,t.tubularSegments,t.arc)}}class yo extends Ye{constructor(t=new ph(new N(-1,-1,0),new N(-1,1,0),new N(1,1,0)),e=64,n=1,s=8,r=!1){super(),this.type="TubeGeometry",this.parameters={path:t,tubularSegments:e,radius:n,radialSegments:s,closed:r};const a=t.computeFrenetFrames(e,r);this.tangents=a.tangents,this.normals=a.normals,this.binormals=a.binormals;const o=new N,l=new N,h=new Pt;let f=new N;const m=[],u=[],d=[],c=[];v(),this.setIndex(c),this.setAttribute("position",new Ce(m,3)),this.setAttribute("normal",new Ce(u,3)),this.setAttribute("uv",new Ce(d,2));function v(){for(let b=0;b<e;b++)p(b);p(r===!1?e:0),w(),x()}function p(b){f=t.getPointAt(b/e,f);const C=a.normals[b],V=a.binormals[b];for(let D=0;D<=s;D++){const A=D/s*Math.PI*2,y=Math.sin(A),rt=-Math.cos(A);l.x=rt*C.x+y*V.x,l.y=rt*C.y+y*V.y,l.z=rt*C.z+y*V.z,l.normalize(),u.push(l.x,l.y,l.z),o.x=f.x+n*l.x,o.y=f.y+n*l.y,o.z=f.z+n*l.z,m.push(o.x,o.y,o.z)}}function x(){for(let b=1;b<=e;b++)for(let C=1;C<=s;C++){const V=(s+1)*(b-1)+(C-1),D=(s+1)*b+(C-1),A=(s+1)*b+C,y=(s+1)*(b-1)+C;c.push(V,D,y),c.push(D,A,y)}}function w(){for(let b=0;b<=e;b++)for(let C=0;C<=s;C++)h.x=b/e,h.y=C/s,d.push(h.x,h.y)}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}toJSON(){const t=super.toJSON();return t.path=this.parameters.path.toJSON(),t}static fromJSON(t){return new yo(new h2[t.path.type]().fromJSON(t.path),t.tubularSegments,t.radius,t.radialSegments,t.closed)}}class f2 extends Ke{constructor(t){super(t),this.isRawShaderMaterial=!0,this.type="RawShaderMaterial"}}class he extends Vi{constructor(t){super(),this.isMeshStandardMaterial=!0,this.defines={STANDARD:""},this.type="MeshStandardMaterial",this.color=new Jt(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new Jt(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=Yu,this.normalScale=new Pt(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new wn,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.defines={STANDARD:""},this.color.copy(t.color),this.roughness=t.roughness,this.metalness=t.metalness,this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.emissive.copy(t.emissive),this.emissiveMap=t.emissiveMap,this.emissiveIntensity=t.emissiveIntensity,this.bumpMap=t.bumpMap,this.bumpScale=t.bumpScale,this.normalMap=t.normalMap,this.normalMapType=t.normalMapType,this.normalScale.copy(t.normalScale),this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.roughnessMap=t.roughnessMap,this.metalnessMap=t.metalnessMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapRotation.copy(t.envMapRotation),this.envMapIntensity=t.envMapIntensity,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.flatShading=t.flatShading,this.fog=t.fog,this}}class mh extends he{constructor(t){super(),this.isMeshPhysicalMaterial=!0,this.defines={STANDARD:"",PHYSICAL:""},this.type="MeshPhysicalMaterial",this.anisotropyRotation=0,this.anisotropyMap=null,this.clearcoatMap=null,this.clearcoatRoughness=0,this.clearcoatRoughnessMap=null,this.clearcoatNormalScale=new Pt(1,1),this.clearcoatNormalMap=null,this.ior=1.5,Object.defineProperty(this,"reflectivity",{get:function(){return un(2.5*(this.ior-1)/(this.ior+1),0,1)},set:function(e){this.ior=(1+.4*e)/(1-.4*e)}}),this.iridescenceMap=null,this.iridescenceIOR=1.3,this.iridescenceThicknessRange=[100,400],this.iridescenceThicknessMap=null,this.sheenColor=new Jt(0),this.sheenColorMap=null,this.sheenRoughness=1,this.sheenRoughnessMap=null,this.transmissionMap=null,this.thickness=0,this.thicknessMap=null,this.attenuationDistance=1/0,this.attenuationColor=new Jt(1,1,1),this.specularIntensity=1,this.specularIntensityMap=null,this.specularColor=new Jt(1,1,1),this.specularColorMap=null,this._anisotropy=0,this._clearcoat=0,this._dispersion=0,this._iridescence=0,this._sheen=0,this._transmission=0,this.setValues(t)}get anisotropy(){return this._anisotropy}set anisotropy(t){this._anisotropy>0!=t>0&&this.version++,this._anisotropy=t}get clearcoat(){return this._clearcoat}set clearcoat(t){this._clearcoat>0!=t>0&&this.version++,this._clearcoat=t}get iridescence(){return this._iridescence}set iridescence(t){this._iridescence>0!=t>0&&this.version++,this._iridescence=t}get dispersion(){return this._dispersion}set dispersion(t){this._dispersion>0!=t>0&&this.version++,this._dispersion=t}get sheen(){return this._sheen}set sheen(t){this._sheen>0!=t>0&&this.version++,this._sheen=t}get transmission(){return this._transmission}set transmission(t){this._transmission>0!=t>0&&this.version++,this._transmission=t}copy(t){return super.copy(t),this.defines={STANDARD:"",PHYSICAL:""},this.anisotropy=t.anisotropy,this.anisotropyRotation=t.anisotropyRotation,this.anisotropyMap=t.anisotropyMap,this.clearcoat=t.clearcoat,this.clearcoatMap=t.clearcoatMap,this.clearcoatRoughness=t.clearcoatRoughness,this.clearcoatRoughnessMap=t.clearcoatRoughnessMap,this.clearcoatNormalMap=t.clearcoatNormalMap,this.clearcoatNormalScale.copy(t.clearcoatNormalScale),this.dispersion=t.dispersion,this.ior=t.ior,this.iridescence=t.iridescence,this.iridescenceMap=t.iridescenceMap,this.iridescenceIOR=t.iridescenceIOR,this.iridescenceThicknessRange=[...t.iridescenceThicknessRange],this.iridescenceThicknessMap=t.iridescenceThicknessMap,this.sheen=t.sheen,this.sheenColor.copy(t.sheenColor),this.sheenColorMap=t.sheenColorMap,this.sheenRoughness=t.sheenRoughness,this.sheenRoughnessMap=t.sheenRoughnessMap,this.transmission=t.transmission,this.transmissionMap=t.transmissionMap,this.thickness=t.thickness,this.thicknessMap=t.thicknessMap,this.attenuationDistance=t.attenuationDistance,this.attenuationColor.copy(t.attenuationColor),this.specularIntensity=t.specularIntensity,this.specularIntensityMap=t.specularIntensityMap,this.specularColor.copy(t.specularColor),this.specularColorMap=t.specularColorMap,this}}class Oc extends Ze{constructor(t,e=1){super(),this.isLight=!0,this.type="Light",this.color=new Jt(t),this.intensity=e}dispose(){}copy(t,e){return super.copy(t,e),this.color.copy(t.color),this.intensity=t.intensity,this}toJSON(t){const e=super.toJSON(t);return e.object.color=this.color.getHex(),e.object.intensity=this.intensity,this.groundColor!==void 0&&(e.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(e.object.distance=this.distance),this.angle!==void 0&&(e.object.angle=this.angle),this.decay!==void 0&&(e.object.decay=this.decay),this.penumbra!==void 0&&(e.object.penumbra=this.penumbra),this.shadow!==void 0&&(e.object.shadow=this.shadow.toJSON()),this.target!==void 0&&(e.object.target=this.target.uuid),e}}class gh extends Oc{constructor(t,e,n){super(t,n),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(Ze.DEFAULT_UP),this.updateMatrix(),this.groundColor=new Jt(e)}copy(t,e){return super.copy(t,e),this.groundColor.copy(t.groundColor),this}}const il=new Pe,Z0=new N,j0=new N;class vh{constructor(t){this.camera=t,this.intensity=1,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new Pt(512,512),this.map=null,this.mapPass=null,this.matrix=new Pe,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new Pc,this._frameExtents=new Pt(1,1),this._viewportCount=1,this._viewports=[new Fe(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(t){const e=this.camera,n=this.matrix;Z0.setFromMatrixPosition(t.matrixWorld),e.position.copy(Z0),j0.setFromMatrixPosition(t.target.matrixWorld),e.lookAt(j0),e.updateMatrixWorld(),il.multiplyMatrices(e.projectionMatrix,e.matrixWorldInverse),this._frustum.setFromProjectionMatrix(il),n.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),n.multiply(il)}getViewport(t){return this._viewports[t]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(t){return this.camera=t.camera.clone(),this.intensity=t.intensity,this.bias=t.bias,this.radius=t.radius,this.mapSize.copy(t.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){const t={};return this.intensity!==1&&(t.intensity=this.intensity),this.bias!==0&&(t.bias=this.bias),this.normalBias!==0&&(t.normalBias=this.normalBias),this.radius!==1&&(t.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(t.mapSize=this.mapSize.toArray()),t.camera=this.camera.toJSON(!1).object,delete t.camera.matrix,t}}const J0=new Pe,Rr=new N,sl=new N;class d2 extends vh{constructor(){super(new Pn(90,1,.5,500)),this.isPointLightShadow=!0,this._frameExtents=new Pt(4,2),this._viewportCount=6,this._viewports=[new Fe(2,1,1,1),new Fe(0,1,1,1),new Fe(3,1,1,1),new Fe(1,1,1,1),new Fe(3,0,1,1),new Fe(1,0,1,1)],this._cubeDirections=[new N(1,0,0),new N(-1,0,0),new N(0,0,1),new N(0,0,-1),new N(0,1,0),new N(0,-1,0)],this._cubeUps=[new N(0,1,0),new N(0,1,0),new N(0,1,0),new N(0,1,0),new N(0,0,1),new N(0,0,-1)]}updateMatrices(t,e=0){const n=this.camera,s=this.matrix,r=t.distance||n.far;r!==n.far&&(n.far=r,n.updateProjectionMatrix()),Rr.setFromMatrixPosition(t.matrixWorld),n.position.copy(Rr),sl.copy(n.position),sl.add(this._cubeDirections[e]),n.up.copy(this._cubeUps[e]),n.lookAt(sl),n.updateMatrixWorld(),s.makeTranslation(-Rr.x,-Rr.y,-Rr.z),J0.multiplyMatrices(n.projectionMatrix,n.matrixWorldInverse),this._frustum.setFromProjectionMatrix(J0)}}class us extends Oc{constructor(t,e,n=0,s=2){super(t,e),this.isPointLight=!0,this.type="PointLight",this.distance=n,this.decay=s,this.shadow=new d2}get power(){return this.intensity*4*Math.PI}set power(t){this.intensity=t/(4*Math.PI)}dispose(){this.shadow.dispose()}copy(t,e){return super.copy(t,e),this.distance=t.distance,this.decay=t.decay,this.shadow=t.shadow.clone(),this}}class p2 extends vh{constructor(){super(new Dc(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}}class rs extends Oc{constructor(t,e){super(t,e),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(Ze.DEFAULT_UP),this.updateMatrix(),this.target=new Ze,this.shadow=new p2}dispose(){this.shadow.dispose()}copy(t){return super.copy(t),this.target=t.target.clone(),this.shadow=t.shadow.clone(),this}}class m2{constructor(t=!0){this.autoStart=t,this.startTime=0,this.oldTime=0,this.elapsedTime=0,this.running=!1}start(){this.startTime=Q0(),this.oldTime=this.startTime,this.elapsedTime=0,this.running=!0}stop(){this.getElapsedTime(),this.running=!1,this.autoStart=!1}getElapsedTime(){return this.getDelta(),this.elapsedTime}getDelta(){let t=0;if(this.autoStart&&!this.running)return this.start(),0;if(this.running){const e=Q0();t=(e-this.oldTime)/1e3,this.oldTime=e,this.elapsedTime+=t}return t}}function Q0(){return performance.now()}const tu=new Pe;class xh{constructor(t,e,n=0,s=1/0){this.ray=new vo(t,e),this.near=n,this.far=s,this.camera=null,this.layers=new Rc,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(t,e){this.ray.set(t,e)}setFromCamera(t,e){e.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(e.matrixWorld),this.ray.direction.set(t.x,t.y,.5).unproject(e).sub(this.ray.origin).normalize(),this.camera=e):e.isOrthographicCamera?(this.ray.origin.set(t.x,t.y,(e.near+e.far)/(e.near-e.far)).unproject(e),this.ray.direction.set(0,0,-1).transformDirection(e.matrixWorld),this.camera=e):console.error("THREE.Raycaster: Unsupported camera type: "+e.type)}setFromXRController(t){return tu.identity().extractRotation(t.matrixWorld),this.ray.origin.setFromMatrixPosition(t.matrixWorld),this.ray.direction.set(0,0,-1).applyMatrix4(tu),this}intersectObject(t,e=!0,n=[]){return dc(t,this,n,e),n.sort(eu),n}intersectObjects(t,e=!0,n=[]){for(let s=0,r=t.length;s<r;s++)dc(t[s],this,n,e);return n.sort(eu),n}}function eu(i,t){return i.distance-t.distance}function dc(i,t,e,n){let s=!0;if(i.layers.test(t.layers)&&i.raycast(t,e)===!1&&(s=!1),s===!0&&n===!0){const r=i.children;for(let a=0,o=r.length;a<o;a++)dc(r[a],t,e,!0)}}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:xc}}));typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=xc);const nu=`
  varying vec3 vDir;
  void main() {
    vDir = normalize(position);
    vec4 mv = modelViewMatrix * vec4(position, 1.0);
    gl_Position = projectionMatrix * mv;
  }
`,iu=`
  precision highp float;
  varying vec3 vDir;
  uniform vec3 uSunDir;
  uniform vec3 uSunColor;
  uniform vec3 uHorizon;
  uniform vec3 uZenith;
  uniform float uTime;
  uniform float uCloudCover;
  uniform float uSunIntensity;

  float hash21(vec2 p) {
    p = fract(p * vec2(123.34, 456.21));
    p += dot(p, p + 45.32);
    return fract(p.x * p.y);
  }
  float noise(vec2 p) {
    vec2 i = floor(p), f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = hash21(i), b = hash21(i + vec2(1.0, 0.0));
    float c = hash21(i + vec2(0.0, 1.0)), d = hash21(i + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
  }
  float fbm(vec2 p) {
    float v = 0.0, a = 0.5;
    mat2 rot = mat2(0.86, 0.5, -0.5, 0.86);
    for (int i = 0; i < 6; i++) {
      v += a * noise(p);
      p = rot * p * 2.03 + 11.7;
      a *= 0.5;
    }
    return v;
  }

  void main() {
    vec3 d = normalize(vDir);
    float h = d.y;
    float sunDot = max(dot(d, uSunDir), 0.0);

    // ---- base gradient: dusty horizon -> cool zenith
    float grad = pow(clamp(h, 0.0, 1.0), 0.48);
    vec3 col = mix(uHorizon, uZenith, grad);

    // ---- horizon haze band (thick dust)
    float haze = pow(1.0 - clamp(abs(h) * 3.0, 0.0, 1.0), 5.0);
    col = mix(col, uHorizon * 1.10, haze * 0.52);

    // ---- ground hemisphere (slightly warm bounce, avoids black void)
    if (h < 0.0) {
      float g = clamp(-h * 4.0, 0.0, 1.0);
      col = mix(uHorizon * 0.52, vec3(0.045, 0.04, 0.036), g);
    }

    // ---- sun disk + halo
    float disk = pow(sunDot, 4200.0);
    float halo = pow(sunDot, 30.0) * 0.14 + pow(sunDot, 5.0) * 0.05;
    col += uSunColor * (disk * 6.5 + halo) * uSunIntensity;

    // ---- clouds (only above horizon)
    if (h > 0.008) {
      vec2 p = d.xz / (h + 0.10) * 0.62;
      p += vec2(uTime * 0.0035, uTime * 0.0015);
      float base = fbm(p * 1.05);
      float detail = fbm(p * 2.7 + 4.0);
      float cover = smoothstep(0.37, 0.64, base * 1.05 - 0.12 + detail * 0.28);
      cover *= smoothstep(0.008, 0.16, h) * uCloudCover;
      float lit = smoothstep(0.15, 0.9, (base * 0.7 + detail * 0.3) + sunDot * 0.35);
      vec3 cloudShadow = mix(vec3(0.20, 0.20, 0.22), uHorizon * 0.8, 0.45);
      vec3 cloudLit = mix(uSunColor * 0.82, vec3(0.86, 0.82, 0.78), 0.35);
      vec3 cc = mix(cloudShadow, cloudLit, lit);
      cc += uSunColor * pow(sunDot, 9.0) * 0.55 * cover;
      // silver lining toward the sun
      cc += uSunColor * pow(sunDot, 3.0) * 0.07 * cover;
      col = mix(col, cc, cover * 0.92);
    }

    // ---- subtle vertical dust motes / aerial perspective in sky
    col += uHorizon * 0.03 * pow(1.0 - abs(h), 12.0);

    gl_FragColor = vec4(max(col, 0.0), 1.0);
  }
`;function g2(i,t={}){const e=new N(.12,.185,-.975).normalize(),n={uSunDir:{value:e.clone()},uSunColor:{value:new Jt(1,.79,.55)},uHorizon:{value:new Jt(.56,.395,.225)},uZenith:{value:new Jt(.038,.072,.14)},uTime:{value:0},uCloudCover:{value:t.cloudCover??1},uSunIntensity:{value:t.sunIntensity??1}},s=new Ci(1500,48,32),r=new Ke({vertexShader:nu,fragmentShader:iu,uniforms:n,side:fn,depthWrite:!1,depthTest:!1,fog:!1}),a=new K(s,r);a.frustumCulled=!1,a.renderOrder=-1e3,a.name="sky";let o=null;try{const l=new uc(i);l.compileEquirectangularShader();const h=new Uc,f=new K(new Ci(500,32,20),new Ke({vertexShader:nu,fragmentShader:iu,uniforms:n,side:fn,depthWrite:!1}));h.add(f);const m=new K(new li(480,32),new Bn({color:new Jt(.16,.14,.11)}));m.rotation.x=-Math.PI/2,m.position.y=-8,h.add(m),o=l.fromScene(h,.02,.1,2e3).texture,l.dispose()}catch(l){console.warn("PMREM env generation failed",l)}return{dome:a,sunDir:e,sunColor:new Jt(1,.86,.68),envTexture:o,update(l){n.uTime.value=l},dispose(){s.dispose(),r.dispose()}}}const _h={name:"CopyShader",uniforms:{tDiffuse:{value:null},opacity:{value:1}},vertexShader:`

		varying vec2 vUv;

		void main() {

			vUv = uv;
			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		uniform float opacity;

		uniform sampler2D tDiffuse;

		varying vec2 vUv;

		void main() {

			vec4 texel = texture2D( tDiffuse, vUv );
			gl_FragColor = opacity * texel;


		}`};class mr{constructor(){this.isPass=!0,this.enabled=!0,this.needsSwap=!0,this.clear=!1,this.renderToScreen=!1}setSize(){}render(){console.error("THREE.Pass: .render() must be implemented in derived pass.")}dispose(){}}const v2=new Dc(-1,1,1,-1,0,1);class x2 extends Ye{constructor(){super(),this.setAttribute("position",new Ce([-1,3,0,-1,-1,0,3,-1,0],3)),this.setAttribute("uv",new Ce([0,2,0,0,2,0],2))}}const _2=new x2;class Bc{constructor(t){this._mesh=new K(_2,t)}dispose(){this._mesh.geometry.dispose()}render(t){t.render(this._mesh,v2)}get material(){return this._mesh.material}set material(t){this._mesh.material=t}}class Mh extends mr{constructor(t,e){super(),this.textureID=e!==void 0?e:"tDiffuse",t instanceof Ke?(this.uniforms=t.uniforms,this.material=t):t&&(this.uniforms=Yr.clone(t.uniforms),this.material=new Ke({name:t.name!==void 0?t.name:"unspecified",defines:Object.assign({},t.defines),uniforms:this.uniforms,vertexShader:t.vertexShader,fragmentShader:t.fragmentShader})),this.fsQuad=new Bc(this.material)}render(t,e,n){this.uniforms[this.textureID]&&(this.uniforms[this.textureID].value=n.texture),this.fsQuad.material=this.material,this.renderToScreen?(t.setRenderTarget(null),this.fsQuad.render(t)):(t.setRenderTarget(e),this.clear&&t.clear(t.autoClearColor,t.autoClearDepth,t.autoClearStencil),this.fsQuad.render(t))}dispose(){this.material.dispose(),this.fsQuad.dispose()}}class su extends mr{constructor(t,e){super(),this.scene=t,this.camera=e,this.clear=!0,this.needsSwap=!1,this.inverse=!1}render(t,e,n){const s=t.getContext(),r=t.state;r.buffers.color.setMask(!1),r.buffers.depth.setMask(!1),r.buffers.color.setLocked(!0),r.buffers.depth.setLocked(!0);let a,o;this.inverse?(a=0,o=1):(a=1,o=0),r.buffers.stencil.setTest(!0),r.buffers.stencil.setOp(s.REPLACE,s.REPLACE,s.REPLACE),r.buffers.stencil.setFunc(s.ALWAYS,a,4294967295),r.buffers.stencil.setClear(o),r.buffers.stencil.setLocked(!0),t.setRenderTarget(n),this.clear&&t.clear(),t.render(this.scene,this.camera),t.setRenderTarget(e),this.clear&&t.clear(),t.render(this.scene,this.camera),r.buffers.color.setLocked(!1),r.buffers.depth.setLocked(!1),r.buffers.color.setMask(!0),r.buffers.depth.setMask(!0),r.buffers.stencil.setLocked(!1),r.buffers.stencil.setFunc(s.EQUAL,1,4294967295),r.buffers.stencil.setOp(s.KEEP,s.KEEP,s.KEEP),r.buffers.stencil.setLocked(!0)}}class M2 extends mr{constructor(){super(),this.needsSwap=!1}render(t){t.state.buffers.stencil.setLocked(!1),t.state.buffers.stencil.setTest(!1)}}class y2{constructor(t,e){if(this.renderer=t,this._pixelRatio=t.getPixelRatio(),e===void 0){const n=t.getSize(new Pt);this._width=n.width,this._height=n.height,e=new $n(this._width*this._pixelRatio,this._height*this._pixelRatio,{type:pi}),e.texture.name="EffectComposer.rt1"}else this._width=e.width,this._height=e.height;this.renderTarget1=e,this.renderTarget2=e.clone(),this.renderTarget2.texture.name="EffectComposer.rt2",this.writeBuffer=this.renderTarget1,this.readBuffer=this.renderTarget2,this.renderToScreen=!0,this.passes=[],this.copyPass=new Mh(_h),this.copyPass.material.blending=bi,this.clock=new m2}swapBuffers(){const t=this.readBuffer;this.readBuffer=this.writeBuffer,this.writeBuffer=t}addPass(t){this.passes.push(t),t.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}insertPass(t,e){this.passes.splice(e,0,t),t.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}removePass(t){const e=this.passes.indexOf(t);e!==-1&&this.passes.splice(e,1)}isLastEnabledPass(t){for(let e=t+1;e<this.passes.length;e++)if(this.passes[e].enabled)return!1;return!0}render(t){t===void 0&&(t=this.clock.getDelta());const e=this.renderer.getRenderTarget();let n=!1;for(let s=0,r=this.passes.length;s<r;s++){const a=this.passes[s];if(a.enabled!==!1){if(a.renderToScreen=this.renderToScreen&&this.isLastEnabledPass(s),a.render(this.renderer,this.writeBuffer,this.readBuffer,t,n),a.needsSwap){if(n){const o=this.renderer.getContext(),l=this.renderer.state.buffers.stencil;l.setFunc(o.NOTEQUAL,1,4294967295),this.copyPass.render(this.renderer,this.writeBuffer,this.readBuffer,t),l.setFunc(o.EQUAL,1,4294967295)}this.swapBuffers()}su!==void 0&&(a instanceof su?n=!0:a instanceof M2&&(n=!1))}}this.renderer.setRenderTarget(e)}reset(t){if(t===void 0){const e=this.renderer.getSize(new Pt);this._pixelRatio=this.renderer.getPixelRatio(),this._width=e.width,this._height=e.height,t=this.renderTarget1.clone(),t.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}this.renderTarget1.dispose(),this.renderTarget2.dispose(),this.renderTarget1=t,this.renderTarget2=t.clone(),this.writeBuffer=this.renderTarget1,this.readBuffer=this.renderTarget2}setSize(t,e){this._width=t,this._height=e;const n=this._width*this._pixelRatio,s=this._height*this._pixelRatio;this.renderTarget1.setSize(n,s),this.renderTarget2.setSize(n,s);for(let r=0;r<this.passes.length;r++)this.passes[r].setSize(n,s)}setPixelRatio(t){this._pixelRatio=t,this.setSize(this._width,this._height)}dispose(){this.renderTarget1.dispose(),this.renderTarget2.dispose(),this.copyPass.dispose()}}class yh extends mr{constructor(t,e,n=null,s=null,r=null){super(),this.scene=t,this.camera=e,this.overrideMaterial=n,this.clearColor=s,this.clearAlpha=r,this.clear=!0,this.clearDepth=!1,this.needsSwap=!1,this._oldClearColor=new Jt}render(t,e,n){const s=t.autoClear;t.autoClear=!1;let r,a;this.overrideMaterial!==null&&(a=this.scene.overrideMaterial,this.scene.overrideMaterial=this.overrideMaterial),this.clearColor!==null&&(t.getClearColor(this._oldClearColor),t.setClearColor(this.clearColor,t.getClearAlpha())),this.clearAlpha!==null&&(r=t.getClearAlpha(),t.setClearAlpha(this.clearAlpha)),this.clearDepth==!0&&t.clearDepth(),t.setRenderTarget(this.renderToScreen?null:n),this.clear===!0&&t.clear(t.autoClearColor,t.autoClearDepth,t.autoClearStencil),t.render(this.scene,this.camera),this.clearColor!==null&&t.setClearColor(this._oldClearColor),this.clearAlpha!==null&&t.setClearAlpha(r),this.overrideMaterial!==null&&(this.scene.overrideMaterial=a),t.autoClear=s}}const S2={uniforms:{tDiffuse:{value:null},luminosityThreshold:{value:1},smoothWidth:{value:1},defaultColor:{value:new Jt(0)},defaultOpacity:{value:0}},vertexShader:`

		varying vec2 vUv;

		void main() {

			vUv = uv;

			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		uniform sampler2D tDiffuse;
		uniform vec3 defaultColor;
		uniform float defaultOpacity;
		uniform float luminosityThreshold;
		uniform float smoothWidth;

		varying vec2 vUv;

		void main() {

			vec4 texel = texture2D( tDiffuse, vUv );

			float v = luminance( texel.xyz );

			vec4 outputColor = vec4( defaultColor.rgb, defaultOpacity );

			float alpha = smoothstep( luminosityThreshold, luminosityThreshold + smoothWidth, v );

			gl_FragColor = mix( outputColor, texel, alpha );

		}`};class hr extends mr{constructor(t,e,n,s){super(),this.strength=e!==void 0?e:1,this.radius=n,this.threshold=s,this.resolution=t!==void 0?new Pt(t.x,t.y):new Pt(256,256),this.clearColor=new Jt(0,0,0),this.renderTargetsHorizontal=[],this.renderTargetsVertical=[],this.nMips=5;let r=Math.round(this.resolution.x/2),a=Math.round(this.resolution.y/2);this.renderTargetBright=new $n(r,a,{type:pi}),this.renderTargetBright.texture.name="UnrealBloomPass.bright",this.renderTargetBright.texture.generateMipmaps=!1;for(let m=0;m<this.nMips;m++){const u=new $n(r,a,{type:pi});u.texture.name="UnrealBloomPass.h"+m,u.texture.generateMipmaps=!1,this.renderTargetsHorizontal.push(u);const d=new $n(r,a,{type:pi});d.texture.name="UnrealBloomPass.v"+m,d.texture.generateMipmaps=!1,this.renderTargetsVertical.push(d),r=Math.round(r/2),a=Math.round(a/2)}const o=S2;this.highPassUniforms=Yr.clone(o.uniforms),this.highPassUniforms.luminosityThreshold.value=s,this.highPassUniforms.smoothWidth.value=.01,this.materialHighPassFilter=new Ke({uniforms:this.highPassUniforms,vertexShader:o.vertexShader,fragmentShader:o.fragmentShader}),this.separableBlurMaterials=[];const l=[3,5,7,9,11];r=Math.round(this.resolution.x/2),a=Math.round(this.resolution.y/2);for(let m=0;m<this.nMips;m++)this.separableBlurMaterials.push(this.getSeperableBlurMaterial(l[m])),this.separableBlurMaterials[m].uniforms.invSize.value=new Pt(1/r,1/a),r=Math.round(r/2),a=Math.round(a/2);this.compositeMaterial=this.getCompositeMaterial(this.nMips),this.compositeMaterial.uniforms.blurTexture1.value=this.renderTargetsVertical[0].texture,this.compositeMaterial.uniforms.blurTexture2.value=this.renderTargetsVertical[1].texture,this.compositeMaterial.uniforms.blurTexture3.value=this.renderTargetsVertical[2].texture,this.compositeMaterial.uniforms.blurTexture4.value=this.renderTargetsVertical[3].texture,this.compositeMaterial.uniforms.blurTexture5.value=this.renderTargetsVertical[4].texture,this.compositeMaterial.uniforms.bloomStrength.value=e,this.compositeMaterial.uniforms.bloomRadius.value=.1;const h=[1,.8,.6,.4,.2];this.compositeMaterial.uniforms.bloomFactors.value=h,this.bloomTintColors=[new N(1,1,1),new N(1,1,1),new N(1,1,1),new N(1,1,1),new N(1,1,1)],this.compositeMaterial.uniforms.bloomTintColors.value=this.bloomTintColors;const f=_h;this.copyUniforms=Yr.clone(f.uniforms),this.blendMaterial=new Ke({uniforms:this.copyUniforms,vertexShader:f.vertexShader,fragmentShader:f.fragmentShader,blending:cn,depthTest:!1,depthWrite:!1,transparent:!0}),this.enabled=!0,this.needsSwap=!1,this._oldClearColor=new Jt,this.oldClearAlpha=1,this.basic=new Bn,this.fsQuad=new Bc(null)}dispose(){for(let t=0;t<this.renderTargetsHorizontal.length;t++)this.renderTargetsHorizontal[t].dispose();for(let t=0;t<this.renderTargetsVertical.length;t++)this.renderTargetsVertical[t].dispose();this.renderTargetBright.dispose();for(let t=0;t<this.separableBlurMaterials.length;t++)this.separableBlurMaterials[t].dispose();this.compositeMaterial.dispose(),this.blendMaterial.dispose(),this.basic.dispose(),this.fsQuad.dispose()}setSize(t,e){let n=Math.round(t/2),s=Math.round(e/2);this.renderTargetBright.setSize(n,s);for(let r=0;r<this.nMips;r++)this.renderTargetsHorizontal[r].setSize(n,s),this.renderTargetsVertical[r].setSize(n,s),this.separableBlurMaterials[r].uniforms.invSize.value=new Pt(1/n,1/s),n=Math.round(n/2),s=Math.round(s/2)}render(t,e,n,s,r){t.getClearColor(this._oldClearColor),this.oldClearAlpha=t.getClearAlpha();const a=t.autoClear;t.autoClear=!1,t.setClearColor(this.clearColor,0),r&&t.state.buffers.stencil.setTest(!1),this.renderToScreen&&(this.fsQuad.material=this.basic,this.basic.map=n.texture,t.setRenderTarget(null),t.clear(),this.fsQuad.render(t)),this.highPassUniforms.tDiffuse.value=n.texture,this.highPassUniforms.luminosityThreshold.value=this.threshold,this.fsQuad.material=this.materialHighPassFilter,t.setRenderTarget(this.renderTargetBright),t.clear(),this.fsQuad.render(t);let o=this.renderTargetBright;for(let l=0;l<this.nMips;l++)this.fsQuad.material=this.separableBlurMaterials[l],this.separableBlurMaterials[l].uniforms.colorTexture.value=o.texture,this.separableBlurMaterials[l].uniforms.direction.value=hr.BlurDirectionX,t.setRenderTarget(this.renderTargetsHorizontal[l]),t.clear(),this.fsQuad.render(t),this.separableBlurMaterials[l].uniforms.colorTexture.value=this.renderTargetsHorizontal[l].texture,this.separableBlurMaterials[l].uniforms.direction.value=hr.BlurDirectionY,t.setRenderTarget(this.renderTargetsVertical[l]),t.clear(),this.fsQuad.render(t),o=this.renderTargetsVertical[l];this.fsQuad.material=this.compositeMaterial,this.compositeMaterial.uniforms.bloomStrength.value=this.strength,this.compositeMaterial.uniforms.bloomRadius.value=this.radius,this.compositeMaterial.uniforms.bloomTintColors.value=this.bloomTintColors,t.setRenderTarget(this.renderTargetsHorizontal[0]),t.clear(),this.fsQuad.render(t),this.fsQuad.material=this.blendMaterial,this.copyUniforms.tDiffuse.value=this.renderTargetsHorizontal[0].texture,r&&t.state.buffers.stencil.setTest(!0),this.renderToScreen?(t.setRenderTarget(null),this.fsQuad.render(t)):(t.setRenderTarget(n),this.fsQuad.render(t)),t.setClearColor(this._oldClearColor,this.oldClearAlpha),t.autoClear=a}getSeperableBlurMaterial(t){const e=[];for(let n=0;n<t;n++)e.push(.39894*Math.exp(-.5*n*n/(t*t))/t);return new Ke({defines:{KERNEL_RADIUS:t},uniforms:{colorTexture:{value:null},invSize:{value:new Pt(.5,.5)},direction:{value:new Pt(.5,.5)},gaussianCoefficients:{value:e}},vertexShader:`varying vec2 vUv;
				void main() {
					vUv = uv;
					gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
				}`,fragmentShader:`#include <common>
				varying vec2 vUv;
				uniform sampler2D colorTexture;
				uniform vec2 invSize;
				uniform vec2 direction;
				uniform float gaussianCoefficients[KERNEL_RADIUS];

				void main() {
					float weightSum = gaussianCoefficients[0];
					vec3 diffuseSum = texture2D( colorTexture, vUv ).rgb * weightSum;
					for( int i = 1; i < KERNEL_RADIUS; i ++ ) {
						float x = float(i);
						float w = gaussianCoefficients[i];
						vec2 uvOffset = direction * invSize * x;
						vec3 sample1 = texture2D( colorTexture, vUv + uvOffset ).rgb;
						vec3 sample2 = texture2D( colorTexture, vUv - uvOffset ).rgb;
						diffuseSum += (sample1 + sample2) * w;
						weightSum += 2.0 * w;
					}
					gl_FragColor = vec4(diffuseSum/weightSum, 1.0);
				}`})}getCompositeMaterial(t){return new Ke({defines:{NUM_MIPS:t},uniforms:{blurTexture1:{value:null},blurTexture2:{value:null},blurTexture3:{value:null},blurTexture4:{value:null},blurTexture5:{value:null},bloomStrength:{value:1},bloomFactors:{value:null},bloomTintColors:{value:null},bloomRadius:{value:0}},vertexShader:`varying vec2 vUv;
				void main() {
					vUv = uv;
					gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
				}`,fragmentShader:`varying vec2 vUv;
				uniform sampler2D blurTexture1;
				uniform sampler2D blurTexture2;
				uniform sampler2D blurTexture3;
				uniform sampler2D blurTexture4;
				uniform sampler2D blurTexture5;
				uniform float bloomStrength;
				uniform float bloomRadius;
				uniform float bloomFactors[NUM_MIPS];
				uniform vec3 bloomTintColors[NUM_MIPS];

				float lerpBloomFactor(const in float factor) {
					float mirrorFactor = 1.2 - factor;
					return mix(factor, mirrorFactor, bloomRadius);
				}

				void main() {
					gl_FragColor = bloomStrength * ( lerpBloomFactor(bloomFactors[0]) * vec4(bloomTintColors[0], 1.0) * texture2D(blurTexture1, vUv) +
						lerpBloomFactor(bloomFactors[1]) * vec4(bloomTintColors[1], 1.0) * texture2D(blurTexture2, vUv) +
						lerpBloomFactor(bloomFactors[2]) * vec4(bloomTintColors[2], 1.0) * texture2D(blurTexture3, vUv) +
						lerpBloomFactor(bloomFactors[3]) * vec4(bloomTintColors[3], 1.0) * texture2D(blurTexture4, vUv) +
						lerpBloomFactor(bloomFactors[4]) * vec4(bloomTintColors[4], 1.0) * texture2D(blurTexture5, vUv) );
				}`})}}hr.BlurDirectionX=new Pt(1,0);hr.BlurDirectionY=new Pt(0,1);const w2={name:"OutputShader",uniforms:{tDiffuse:{value:null},toneMappingExposure:{value:1}},vertexShader:`
		precision highp float;

		uniform mat4 modelViewMatrix;
		uniform mat4 projectionMatrix;

		attribute vec3 position;
		attribute vec2 uv;

		varying vec2 vUv;

		void main() {

			vUv = uv;
			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`
	
		precision highp float;

		uniform sampler2D tDiffuse;

		#include <tonemapping_pars_fragment>
		#include <colorspace_pars_fragment>

		varying vec2 vUv;

		void main() {

			gl_FragColor = texture2D( tDiffuse, vUv );

			// tone mapping

			#ifdef LINEAR_TONE_MAPPING

				gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );

			#elif defined( REINHARD_TONE_MAPPING )

				gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );

			#elif defined( CINEON_TONE_MAPPING )

				gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );

			#elif defined( ACES_FILMIC_TONE_MAPPING )

				gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );

			#elif defined( AGX_TONE_MAPPING )

				gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );

			#elif defined( NEUTRAL_TONE_MAPPING )

				gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );

			#endif

			// color space

			#ifdef SRGB_TRANSFER

				gl_FragColor = sRGBTransferOETF( gl_FragColor );

			#endif

		}`};class b2 extends mr{constructor(){super();const t=w2;this.uniforms=Yr.clone(t.uniforms),this.material=new f2({name:t.name,uniforms:this.uniforms,vertexShader:t.vertexShader,fragmentShader:t.fragmentShader}),this.fsQuad=new Bc(this.material),this._outputColorSpace=null,this._toneMapping=null}render(t,e,n){this.uniforms.tDiffuse.value=n.texture,this.uniforms.toneMappingExposure.value=t.toneMappingExposure,(this._outputColorSpace!==t.outputColorSpace||this._toneMapping!==t.toneMapping)&&(this._outputColorSpace=t.outputColorSpace,this._toneMapping=t.toneMapping,this.material.defines={},Ie.getTransfer(this._outputColorSpace)===He&&(this.material.defines.SRGB_TRANSFER=""),this._toneMapping===Iu?this.material.defines.LINEAR_TONE_MAPPING="":this._toneMapping===Lu?this.material.defines.REINHARD_TONE_MAPPING="":this._toneMapping===Uu?this.material.defines.CINEON_TONE_MAPPING="":this._toneMapping===_c?this.material.defines.ACES_FILMIC_TONE_MAPPING="":this._toneMapping===zu?this.material.defines.AGX_TONE_MAPPING="":this._toneMapping===Nu&&(this.material.defines.NEUTRAL_TONE_MAPPING=""),this.material.needsUpdate=!0),this.renderToScreen===!0?(t.setRenderTarget(null),this.fsQuad.render(t)):(t.setRenderTarget(e),this.clear&&t.clear(t.autoClearColor,t.autoClearDepth,t.autoClearStencil),this.fsQuad.render(t))}dispose(){this.material.dispose(),this.fsQuad.dispose()}}const T2={uniforms:{tDiffuse:{value:null},uResolution:{value:new Pt(1,1)},uTime:{value:0},uSunScreen:{value:new Pt(.5,.8)},uSunColor:{value:new Jt(1,.82,.6)},uSunVisible:{value:1},uGodrays:{value:1},uGrain:{value:.028},uCA:{value:.0016},uVignette:{value:.45},uContrast:{value:1.1},uSaturation:{value:.9},uLift:{value:new Jt(.017,.021,.03)},uGain:{value:new Jt(1.06,1,.935)},uSprint:{value:0},uDamage:{value:0},uHitFlash:{value:0},uSharpness:{value:.2},uLowHealth:{value:0},uOpacity:{value:1}},vertexShader:`
    varying vec2 vUv;
    void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }
  `,fragmentShader:`
    precision highp float;
    uniform sampler2D tDiffuse;
    uniform vec2 uResolution;
    uniform float uTime;
    uniform vec2 uSunScreen;
    uniform vec3 uSunColor;
    uniform float uSunVisible, uGodrays, uGrain, uCA, uVignette;
    uniform float uContrast, uSaturation, uSprint, uDamage, uHitFlash, uSharpness, uLowHealth, uOpacity;
    uniform vec3 uLift, uGain;
    varying vec2 vUv;

    float hash(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123); }

    vec3 sampleC(vec2 uv){ return texture2D(tDiffuse, clamp(uv, vec2(0.0005), vec2(0.9995))).rgb; }

    void main(){
      vec2 uv = vUv;
      vec2 centered = uv - 0.5;
      float r2 = dot(centered, centered);

      // ---------- sprint zoom blur (radial, cheap) ----------
      vec3 c;
      if (uSprint > 0.001) {
        c = vec3(0.0);
        float total = 0.0;
        for (int i = 0; i < 5; i++) {
          float t = float(i) / 4.0;
          vec2 off = centered * (t * 0.030 * uSprint);
          float w = 1.0 - t * 0.55;
          c += sampleC(uv - off) * w;
          total += w;
        }
        c /= total;
      } else {
        c = sampleC(uv);
      }

      // ---------- chromatic aberration (radial) ----------
      float ca = uCA * (0.35 + r2 * 2.0);
      c.r = mix(c.r, sampleC(uv + centered * ca).r, 0.85);
      c.b = mix(c.b, sampleC(uv - centered * ca).b, 0.85);

      // ---------- screen space god rays ----------
      if (uGodrays > 0.001 && uSunVisible > 0.001) {
        vec2 delta = (uSunScreen - uv) * (0.90 / 14.0);
        vec2 suv = uv;
        float illum = 0.0;
        for (int i = 0; i < 14; i++) {
          vec3 s = sampleC(suv);
          float lum = dot(s, vec3(0.30, 0.55, 0.15));
          illum += max(0.0, lum - 0.80);
          suv += delta;
        }
        illum *= uSunVisible / 14.0;
        float edge = smoothstep(0.0, 0.22, min(min(uv.x, 1.0 - uv.x), min(uv.y, 1.0 - uv.y)));
        c += uSunColor * illum * uGodrays * 0.85 * edge;
      }

      // ---------- lens: sun glow + anamorphic streak ----------
      if (uSunVisible > 0.001) {
        vec2 sp = uSunScreen;
        vec2 dv = (uv - sp) * vec2(1.0, 1.55);
        float d2 = dot(dv, dv);
        float glow = exp(-d2 * 70.0) * 0.07 + exp(-d2 * 900.0) * 0.11;
        float streak = exp(-abs(uv.y - sp.y) * 130.0) * exp(-abs(uv.x - sp.x) * 2.2) * 0.05;
        c += uSunColor * uSunVisible * (glow + streak);
      }

      // ---------- grade ----------
      c = max(c, 0.0);
      // contrast around mid grey
      c = (c - 0.5) * uContrast + 0.5;
      // lift / gain
      c = c * uGain + uLift * (1.0 - c);
      // soft highlight shoulder: roll off clipped whites instead of hard clipping
      c -= max(c - 0.86, 0.0) * 0.45;
      // split tone: cool shadows, warm highlights
      float lum = dot(c, vec3(0.2126, 0.7152, 0.0722));
      c *= mix(vec3(0.925, 1.0, 1.085), vec3(1.055, 1.0, 0.925), smoothstep(0.10, 0.80, lum));
      // saturation
      c = mix(vec3(lum), c, uSaturation);

      // ---------- unsharp mask (counteract TAA/AA softness) ----------
      if (uSharpness > 0.001) {
        vec2 px = 1.0 / uResolution;
        vec3 blur = (
          sampleC(uv + vec2(px.x, 0.0)) + sampleC(uv - vec2(px.x, 0.0)) +
          sampleC(uv + vec2(0.0, px.y)) + sampleC(uv - vec2(0.0, px.y))
        ) * 0.25;
        c += (c - blur) * uSharpness;
      }

      // ---------- vignette ----------
      float vig = smoothstep(1.30, 0.28, length(centered * vec2(1.02, 0.86)) * 1.32);
      c *= mix(1.0, vig, uVignette);

      // ---------- low health pulse ----------
      if (uLowHealth > 0.001) {
        float pulse = 0.5 + 0.5 * sin(uTime * 5.2);
        c *= 1.0 - uLowHealth * (0.18 + pulse * 0.20) * smoothstep(0.05, 0.85, r2 * 2.2);
        c.r += uLowHealth * 0.045 * pulse;
      }

      // ---------- damage vignette ----------
      if (uDamage > 0.001) {
        float edge = smoothstep(0.06, 0.62, r2 * 2.0);
        c.r = mix(c.r, min(1.25, c.r * 1.9 + 0.10), edge * uDamage * 0.85);
        c.g *= 1.0 - edge * uDamage * 0.42;
        c.b *= 1.0 - edge * uDamage * 0.48;
      }
      // ---------- hit flash ----------
      c += vec3(1.0, 0.95, 0.86) * uHitFlash * 0.07;

      // ---------- film grain (luma weighted, animated) ----------
      float g = hash(gl_FragCoord.xy + vec2(uTime * 91.7, uTime * 47.3)) - 0.5;
      float gl = hash(gl_FragCoord.xy * 0.5 + vec2(uTime * 13.1, uTime * 7.7)) - 0.5;
      float grainAmt = uGrain * (0.45 + 0.55 * (1.0 - smoothstep(0.05, 0.9, lum)));
      c += g * grainAmt;
      c += gl * grainAmt * 0.45;

      gl_FragColor = vec4(c, 1.0 * uOpacity);
    }
  `};function E2(i,t,e,n="high"){const s=Vr(n),r=i.getDrawingBufferSize(new Pt),a=new $n(r.x,r.y,{type:pi,samples:s.msaa,colorSpace:ii,depthBuffer:!0}),o=new y2(i,a);o.setPixelRatio(i.getPixelRatio());const l=new yh(t,e);o.addPass(l);const h=new hr(new Pt(r.x,r.y),s.bloomStrength,.58,1.15);h.enabled=s.bloom,o.addPass(h);const f=new b2;o.addPass(f);const m=new Mh(T2);m.uniforms.uGrain.value=s.grain,m.uniforms.uGodrays.value=s.godrays,m.uniforms.uCA.value=s.ca,m.renderToScreen=!0,o.addPass(m);const u={quality:n,q:s};function d(c,v,p){o.setPixelRatio(p),o.setSize(c,v),h.setSize(c*p,v*p),m.uniforms.uResolution.value.set(c*p,v*p)}return d(window.innerWidth,window.innerHeight,i.getPixelRatio()),{composer:o,bloom:h,finalPass:m,renderPass:l,uniforms:m.uniforms,resize:d,render(c){m.uniforms.uTime.value+=c,o.render(c)},applyQuality(c){const v=Vr(c);return u.quality=c,u.q=v,h.enabled=v.bloom,h.strength=v.bloomStrength,m.uniforms.uGrain.value=v.grain,m.uniforms.uGodrays.value=v.godrays,m.uniforms.uCA.value=v.ca,o.setPixelRatio(i.getPixelRatio()),o.setSize(window.innerWidth,window.innerHeight),h.setSize(window.innerWidth*i.getPixelRatio(),window.innerHeight*i.getPixelRatio()),m.uniforms.uResolution.value.set(window.innerWidth*i.getPixelRatio(),window.innerHeight*i.getPixelRatio()),v},get quality(){return u.quality}}}function Vr(i){switch(i){case"low":return{msaa:0,bloom:!0,bloomStrength:.28,godrays:0,grain:.02,ca:0,shadows:1024,pixelRatio:1};case"medium":return{msaa:2,bloom:!0,bloomStrength:.38,godrays:.5,grain:.024,ca:.001,shadows:2048,pixelRatio:1};case"ultra":return{msaa:4,bloom:!0,bloomStrength:.46,godrays:1.25,grain:.034,ca:.002,shadows:4096,pixelRatio:2};case"high":default:return{msaa:4,bloom:!0,bloomStrength:.4,godrays:1,grain:.028,ca:.0016,shadows:2048,pixelRatio:1.5}}}const mi=512;function We(i){return function(){i|=0,i=i+1831565813|0;let t=Math.imul(i^i>>>15,1|i);return t=t+Math.imul(t^t>>>7,61|t)^t,((t^t>>>14)>>>0)/4294967296}}function A2(i){const t=We(i),e=new Uint8Array(512),n=new Float32Array(256);for(let a=0;a<256;a++)e[a]=a,n[a]=t();for(let a=255;a>0;a--){const o=t()*(a+1)|0,l=e[a];e[a]=e[o],e[o]=l}for(let a=0;a<256;a++)e[a+256]=e[a];function s(a,o,l){return a=(a%l+l)%l,o=(o%l+l)%l,n[e[e[a&255]+o&255]&255]}function r(a){return a*a*(3-2*a)}return function(o,l,h){const f=Math.floor(o),m=Math.floor(l),u=r(o-f),d=r(l-m),c=s(f,m,h),v=s(f+1,m,h),p=s(f,m+1,h),x=s(f+1,m+1,h);return(c*(1-u)+v*u)*(1-d)+(p*(1-u)+x*u)*d}}function xn(i){const t=A2(i);return function(n,s,r=5,a=4,o=.5){let l=0,h=1,f=0,m=a;for(let u=0;u<r;u++)l+=t(n*m,s*m,m)*h,f+=h,h*=o,m*=2;return l/f}}const C2=i=>i<0?0:i>1?1:i,di=(i,t,e)=>{const n=C2((e-i)/(t-i));return n*n*(3-2*n)};function Be(i=mi){const t=document.createElement("canvas");return t.width=t.height=i,t}function Me(i,{srgb:t=!1,aniso:e=8,repeat:n=1}={}){const s=new gs(i);return s.wrapS=s.wrapT=ds,s.colorSpace=t?pn:ii,s.anisotropy=e,s.repeat.set(n,n),s.needsUpdate=!0,s}function Pi(i,t,e=2.2){const n=Be(t),s=n.getContext("2d",{willReadFrequently:!0}),r=s.createImageData(t,t),a=r.data,o=(l,h)=>i[(h+t)%t*t+(l+t)%t]/255;for(let l=0;l<t;l++)for(let h=0;h<t;h++){const f=(o(h+1,l)-o(h-1,l))*e,m=(o(h,l+1)-o(h,l-1))*e;let u=-f,d=-m,c=1;const v=Math.hypot(u,d,c);u/=v,d/=v,c/=v;const p=(l*t+h)*4;a[p]=(u*.5+.5)*255,a[p+1]=(d*.5+.5)*255,a[p+2]=(c*.5+.5)*255,a[p+3]=255}return s.putImageData(r,0,0),n}function vs(i,t){const e=Be(t),n=e.getContext("2d",{willReadFrequently:!0}),s=n.createImageData(t,t);for(let r=0;r<t*t;r++){const a=i[r];s.data[r*4]=a,s.data[r*4+1]=a,s.data[r*4+2]=a,s.data[r*4+3]=255}return n.putImageData(s,0,0),e}function ru(i,{tint:t=[128,124,116],stains:e=.5,cracks:n=.55,size:s=mi}={}){const r=xn(i),a=We(i+91),o=new Uint8Array(s*s),l=Be(s),h=l.getContext("2d",{willReadFrequently:!0}),f=h.createImageData(s,s),m=f.data;for(let v=0;v<s;v++)for(let p=0;p<s;p++){const x=p/s,w=v/s,b=r(x,w,5,4,.55),C=r(x,w,4,16,.5),V=a()*.1;let D=.58+(b-.5)*.42+(C-.5)*.22+(V-.05)*.34;D=Math.max(.3,Math.min(.96,D));const A=(v*s+p)*4,y=D*(.8+C*.3);m[A]=t[0]*y,m[A+1]=t[1]*y,m[A+2]=t[2]*y,m[A+3]=255,o[v*s+p]=Math.min(255,D*255)}h.putImageData(f,0,0),h.lineCap="round";const u=Math.floor(6+n*14);for(let v=0;v<u;v++){let p=a()*s,x=a()*s,w=a()*Math.PI*2;const b=30+a()*150;h.beginPath(),h.moveTo(p,x);for(let C=0;C<b;C+=4)w+=(a()-.5)*.7,p+=Math.cos(w)*4,x+=Math.sin(w)*4,h.lineTo(p,x);h.strokeStyle=`rgba(20,18,16,${.22+a()*.34})`,h.lineWidth=.6+a()*1.3,h.stroke(),h.strokeStyle="rgba(0,0,0,0.42)",h.lineWidth=1.8,h.stroke()}for(let v=0;v<30;v++){const p=a()*s,x=a()*s,w=12+a()*80,b=h.createRadialGradient(p,x,0,p,x,w),C=a()>.4;b.addColorStop(0,C?`rgba(28,24,20,${.14*e})`:`rgba(196,190,176,${.09*e})`),b.addColorStop(1,"rgba(0,0,0,0)"),h.fillStyle=b,h.beginPath(),h.arc(p,x,w,0,7),h.fill()}for(let v=0;v<5200;v++){const p=a()*s,x=a()*s,w=.03+a()*.07;h.fillStyle=a()>.55?`rgba(232,228,216,${w})`:`rgba(12,11,10,${w})`,h.fillRect(p,x,.7+a()*1.3,.7+a()*1.3)}const d=h.getImageData(0,0,s,s).data;for(let v=0;v<s*s;v++)o[v]=d[v*4]*.32+d[v*4+1]*.5+d[v*4+2]*.18;const c=new Uint8Array(s*s);for(let v=0;v<s*s;v++)c[v]=176+(255-o[v])*.24;return{map:Me(l,{srgb:!0}),normalMap:Me(Pi(o,s,1.25)),roughnessMap:Me(vs(c,s))}}function R2(i){const t=xn(i),e=We(i+3),n=mi,s=new Uint8Array(n*n),r=new Uint8Array(n*n),a=Be(n),o=a.getContext("2d",{willReadFrequently:!0}),l=o.createImageData(n,n),h=l.data;for(let d=0;d<n;d++)for(let c=0;c<n;c++){const v=c/n,p=d/n,x=t(v,p,4,3,.55),w=t(v,p,3,13,.5),b=t(v,p,2,46,.5),C=di(.5,.78,t(v,p,2,2,.6));let V=.5+(x-.5)*.3+(w-.5)*.17+(b-.5)*.1;V=Math.max(.3,Math.min(.9,V));const D=(d*n+c)*4;let A=(104+C*50)*V,y=(100+C*44)*V,rt=(94+C*36)*V;h[D]=A,h[D+1]=y,h[D+2]=rt,h[D+3]=255,s[d*n+c]=Math.min(255,V*200+C*20),r[d*n+c]=228+(1-x)*22-C*14+(w-.5)*8}o.putImageData(l,0,0);for(let d=0;d<26e3;d++){const c=e()*n,v=e()*n,p=.35+e()*.95,x=.035+e()*.11;o.fillStyle=e()>.62?`rgba(196,190,178,${x})`:`rgba(10,10,9,${x})`,o.beginPath(),o.arc(c,v,p,0,7),o.fill()}for(let d=0;d<900;d++){const c=e()*n,v=e()*n,p=1.1+e()*1.6;o.fillStyle=e()>.5?`rgba(168,162,150,${.05+e()*.07})`:`rgba(14,13,12,${.08+e()*.1})`,o.beginPath(),o.arc(c,v,p,0,7),o.fill()}for(let d=0;d<4;d++){const c=e()*n,v=e()*n,p=40+e()*110,x=24+e()*90;o.fillStyle=`rgba(34,33,31,${.16+e()*.18})`,o.fillRect(c,v,p,x),o.strokeStyle=`rgba(20,19,18,${.28})`,o.lineWidth=1.4,o.strokeRect(c+1,v+1,p-2,x-2);for(let w=0;w<p*x;w+=7){const b=Math.floor(c+w%p),C=Math.floor(v+(w/p|0));if(b<n&&C<n){const V=C*n+b;r[V]=Math.max(160,r[V]-20)}}}o.lineCap="round";for(let d=0;d<7;d++){let c=e()*n,v=e()*n,p=e()*7;o.beginPath(),o.moveTo(c,v);for(let x=0;x<90+e()*200;x+=6)p+=(e()-.5)*.42,c+=Math.cos(p)*6,v+=Math.sin(p)*6,o.lineTo(c,v);o.strokeStyle="rgba(12,11,10,.62)",o.lineWidth=1.2+e()*2.2,o.stroke(),o.strokeStyle="rgba(58,55,50,.16)",o.lineWidth=3.6,o.stroke()}for(let d=0;d<16;d++){let c=e()*n,v=e()*n,p=e()*7;o.beginPath(),o.moveTo(c,v);for(let x=0;x<20+e()*60;x+=3)p+=(e()-.5)*.9,c+=Math.cos(p)*3,v+=Math.sin(p)*3,o.lineTo(c,v);o.strokeStyle=`rgba(16,15,14,${.3+e()*.25})`,o.lineWidth=.6+e()*.8,o.stroke()}const f=(d,c,v,p)=>{const x=o.createRadialGradient(d,c,0,d,c,v);x.addColorStop(0,`rgba(20,20,22,${p})`),x.addColorStop(.55,`rgba(26,25,26,${p*.7})`),x.addColorStop(1,"rgba(0,0,0,0)"),o.fillStyle=x,o.beginPath(),o.arc(d,c,v,0,7),o.fill();for(let w=0;w<120;w++){const b=e()*7,C=Math.sqrt(e())*v,V=Math.round(d+Math.cos(b)*C),D=Math.round(c+Math.sin(b)*C);if(V<0||D<0||V>=n||D>=n)continue;const A=D*n+V;r[A]=Math.max(120,r[A]-58)}};for(let d=0;d<7;d++){const c=e()*n,v=e()*n,p=22+e()*54;f(c,v,p,.22+e()*.24);for(let x=0;x<3;x++)f(c+(e()-.5)*p*1.6,v+(e()-.5)*p*1.6,p*(.3+e()*.4),.14+e()*.16)}const m=o.createRadialGradient(n*.62,n*.35,2,n*.62,n*.35,70);m.addColorStop(0,"rgba(60,70,86,.10)"),m.addColorStop(.7,"rgba(38,40,44,.05)"),m.addColorStop(1,"rgba(0,0,0,0)"),o.fillStyle=m,o.beginPath(),o.arc(n*.62,n*.35,70,0,7),o.fill();const u=o.getImageData(0,0,n,n).data;for(let d=0;d<n*n;d++)s[d]=u[d*4]*.55+u[d*4+1]*.45,r[d]=Math.max(238,r[d]);return{map:Me(a,{srgb:!0}),normalMap:Me(Pi(s,n,.22)),roughnessMap:Me(vs(r,n))}}function Os(i,{base:t=[156,146,128],warm:e=1,chipped:n=.5}={}){const s=mi,r=xn(i),a=We(i+29),o=Be(s),l=o.getContext("2d",{willReadFrequently:!0}),h=l.createImageData(s,s),f=h.data,m=new Uint8Array(s*s);for(let c=0;c<s;c++)for(let v=0;v<s;v++){const p=v/s,x=c/s,w=r(p,x,4,3,.6),b=r(p,x,4,17,.5),C=r(p,x,2,60,.5);let V=.9+(w-.5)*.17+(b-.5)*.1+(C-.5)*.045;const D=(c*s+v)*4;f[D]=t[0]*V*e,f[D+1]=t[1]*V,f[D+2]=t[2]*V*(2-e),f[D+3]=255,m[c*s+v]=Math.min(255,120+(w-.5)*30+(b-.5)*60+(C-.5)*40)}l.putImageData(h,0,0);for(let c=0;c<22;c++){const v=a()*s,p=a()*s,x=30+a()*120,w=20+a()*80;l.fillStyle=a()>.5?"rgba(220,210,192,.055)":"rgba(96,88,76,.06)",l.beginPath(),l.ellipse(v,p,x*.5,w*.5,a()*.4,0,7),l.fill(),l.strokeStyle="rgba(60,54,44,.07)",l.lineWidth=1,l.stroke()}for(let c=0;c<26;c++){const v=a()*s,p=a()*s,x=16+a()*90,w=l.createRadialGradient(v,p,0,v,p,x);w.addColorStop(0,`rgba(58,52,42,${.07+a()*.1})`),w.addColorStop(1,"rgba(0,0,0,0)"),l.fillStyle=w,l.beginPath(),l.arc(v,p,x,0,7),l.fill()}for(let c=0;c<20*n;c++){const v=a()*s,p=a()*s,x=2+a()*9;l.fillStyle=`rgba(${t[0]*.62},${t[1]*.6},${t[2]*.58},.28)`,l.beginPath();for(let w=0;w<7;w++){const b=w/7*Math.PI*2,C=x*(.55+a()*.7),V=v+Math.cos(b)*C,D=p+Math.sin(b)*C;w?l.lineTo(V,D):l.moveTo(V,D)}l.closePath(),l.fill(),l.strokeStyle="rgba(40,36,30,.22)",l.lineWidth=.8,l.stroke()}l.lineCap="round";for(let c=0;c<12;c++){let v=a()*s,p=a()*s,x=a()*7;l.beginPath(),l.moveTo(v,p);for(let w=0;w<40+a()*120;w+=4)x+=(a()-.5)*.55,v+=Math.cos(x)*4,p+=Math.sin(x)*4,l.lineTo(v,p);l.strokeStyle=`rgba(52,46,38,${.16+a()*.18})`,l.lineWidth=.7+a()*.8,l.stroke()}for(let c=0;c<18;c++){const v=a()*s,p=l.createLinearGradient(0,0,0,s);p.addColorStop(0,`rgba(44,40,34,${.04+a()*.08})`),p.addColorStop(.7,"rgba(44,40,34,.02)"),p.addColorStop(1,"rgba(44,40,34,0)"),l.fillStyle=p,l.fillRect(v,0,1.5+a()*5,s)}for(let c=0;c<6e3;c++){const v=a()*s,p=a()*s,x=.02+a()*.05;l.fillStyle=a()>.5?`rgba(255,250,236,${x})`:`rgba(20,18,16,${x})`,l.fillRect(v,p,.7+a()*1.4,.7+a()*1.4)}const u=l.getImageData(0,0,s,s).data;for(let c=0;c<s*s;c++){const v=u[c*4]*.35+u[c*4+1]*.45+u[c*4+2]*.2;m[c]=Math.min(255,m[c]*.55+v*.45)}const d=new Uint8Array(s*s);for(let c=0;c<s*s;c++)d[c]=214+(255-m[c])*.1;return{map:Me(o,{srgb:!0}),normalMap:Me(Pi(m,s,1.05)),roughnessMap:Me(vs(d,s))}}function Pa(i,t={}){const{base:e=[126,120,108],floors:n=2,cols:s=3,litChance:r=.16,windowColor:a=[16,21,26],trim:o=[150,144,130],boardChance:l=.05,acChance:h=.28,balconyChance:f=.22,brokenChance:m=.1}=t,u=mi,d=xn(i),c=We(i+17),v=Be(u),p=v.getContext("2d",{willReadFrequently:!0}),x=Be(u),w=x.getContext("2d",{willReadFrequently:!0});w.fillStyle="#8a8a8a",w.fillRect(0,0,u,u);const b=p.createImageData(u,u),C=b.data;for(let q=0;q<u;q++)for(let j=0;j<u;j++){const Y=j/u,W=q/u,ht=d(Y,W,5,4,.55),lt=d(Y,W,4,24,.5);let Dt=.88+(ht-.5)*.26+(lt-.5)*.12+(c()-.5)*.04;Dt=Math.max(.58,Math.min(1.1,Dt));const yt=(q*u+j)*4;C[yt]=e[0]*Dt,C[yt+1]=e[1]*Dt,C[yt+2]=e[2]*Dt,C[yt+3]=255}p.putImageData(b,0,0);const V=u/s,D=u/n,A=V*.46,y=D*.45;for(let q=0;q<n;q++){for(let j=0;j<s;j++){const Y=j*V+(V-A)/2,W=q*D+D*.2,ht=c()<r,lt=c()<l,Dt=c()<m;if(p.fillStyle="rgba(24,20,16,.62)",p.fillRect(Y-7,W-7,A+14,y+14),p.fillStyle="rgba(120,112,98,.30)",p.fillRect(Y-7,W+y+5,A+14,3),p.fillStyle=`rgba(${o[0]},${o[1]},${o[2]},.92)`,p.fillRect(Y-9,W+y+2,A+18,8),p.fillStyle="rgba(0,0,0,.30)",p.fillRect(Y-9,W+y+10,A+18,3),p.fillStyle=`rgba(${o[0]+12},${o[1]+12},${o[2]+10},.55)`,p.fillRect(Y-5,W-8,A+10,2),lt){p.fillStyle="rgba(34,30,25,1)",p.fillRect(Y,W,A,y);for(let yt=0;yt<4;yt++){const dt=W+4+yt*(y-8)/4;p.fillStyle=`rgba(${92+c()*26},${72+c()*22},${48+c()*16},.92)`,p.fillRect(Y-4,dt,A+8,(y-8)/4*.72),p.fillStyle="rgba(30,22,14,.5)",p.fillRect(Y-4,dt+(y-8)/4*.72,A+8,2)}}else if(ht){const yt=p.createLinearGradient(Y,W,Y+A*.6,W+y);yt.addColorStop(0,"rgba(255,206,140,.88)"),yt.addColorStop(.6,"rgba(226,158,86,.82)"),yt.addColorStop(1,"rgba(150,96,48,.85)"),p.fillStyle=yt,p.fillRect(Y,W,A,y),p.fillStyle="rgba(72,44,24,.55)",p.fillRect(Y+A*.72,W,A*.28,y),p.fillRect(Y,W,A*.12,y),p.fillStyle="rgba(80,54,30,.5)",p.fillRect(Y+A*.24,W+y*.42,A*.22,y*.58)}else if(Dt){p.fillStyle="rgba(6,7,8,1)",p.fillRect(Y,W,A,y),p.fillStyle="rgba(150,164,172,.16)",p.beginPath(),p.moveTo(Y,W),p.lineTo(Y+A*.42,W+y*.34),p.lineTo(Y+A*.18,W+y),p.lineTo(Y,W+y),p.closePath(),p.fill(),p.strokeStyle="rgba(190,205,212,.30)",p.lineWidth=1;for(let yt=0;yt<4;yt++)p.beginPath(),p.moveTo(Y+c()*A,W+c()*y),p.lineTo(Y+c()*A,W+c()*y),p.stroke()}else{const yt=p.createLinearGradient(Y,W,Y+A,W+y);if(yt.addColorStop(0,`rgba(${a[0]+22},${a[1]+26},${a[2]+28},1)`),yt.addColorStop(.55,`rgba(${a[0]+4},${a[1]+8},${a[2]+8},1)`),yt.addColorStop(1,"rgba(8,11,13,1)"),p.fillStyle=yt,p.fillRect(Y,W,A,y),p.fillStyle="rgba(196,208,214,.10)",p.beginPath(),p.moveTo(Y,W+y),p.lineTo(Y+A*.5,W),p.lineTo(Y+A*.76,W),p.lineTo(Y+A*.22,W+y),p.closePath(),p.fill(),c()<.35){p.fillStyle=`rgba(${86+c()*30},${76+c()*26},${58+c()*20},.72)`;const dt=A*(.22+c()*.3);p.fillRect(Y+(c()>.5?0:A-dt),W,dt,y)}}if(p.fillStyle="rgba(44,40,34,.92)",p.fillRect(Y+A/2-1.6,W,3.2,y),p.fillRect(Y,W+2,2.4,y),p.fillRect(Y+A-2.4,W+2,2.4,y),p.fillRect(Y,W+1,A,2.2),p.fillStyle="rgba(52,47,40,.86)",p.fillRect(Y,W+y*.3,A,2.6),c()<f){p.strokeStyle="rgba(26,24,21,.85)",p.lineWidth=2;const yt=W+y*.6;p.beginPath(),p.moveTo(Y-12,yt),p.lineTo(Y+A+12,yt),p.stroke();for(let dt=0;dt<9;dt++){const et=Y-10+dt*(A+20)/8;p.beginPath(),p.moveTo(et,yt),p.lineTo(et,W+y+6),p.stroke()}}if(c()<h){const yt=Math.min(A*.7,54),dt=26,et=Y+(A-yt)/2,Lt=W+y+14;p.fillStyle="rgba(128,126,116,.9)",p.fillRect(et,Lt,yt,dt),p.fillStyle="rgba(52,52,48,.8)";for(let at=0;at<5;at++)p.fillRect(et+3,Lt+4+at*4.4,yt-6,1.6);p.fillStyle="rgba(20,18,16,.35)",p.fillRect(et,Lt+dt,yt,4);const k=p.createLinearGradient(0,Lt+dt,0,Lt+dt+26);k.addColorStop(0,"rgba(86,46,22,.22)"),k.addColorStop(1,"rgba(86,46,22,0)"),p.fillStyle=k,p.fillRect(et+yt*.3,Lt+dt,2,26)}for(let yt=0;yt<4;yt++){const dt=Y+c()*A,et=p.createLinearGradient(0,W+y+10,0,W+y+34+c()*40);et.addColorStop(0,"rgba(32,28,22,.22)"),et.addColorStop(1,"rgba(32,28,22,0)"),p.fillStyle=et,p.fillRect(dt,W+y+10,1.5+c()*3,36)}w.fillStyle=lt?"#7a7a7a":"#262626",w.fillRect(Y,W,A,y),w.fillStyle="#9a9a9a",w.fillRect(Y+A/2-2,W,3,y),w.fillStyle="#d0d0d0",w.fillRect(Y-9,W+y+2,A+18,8)}p.fillStyle="rgba(255,250,240,.05)",p.fillRect(0,q*D+D-4,u,3),p.fillStyle="rgba(0,0,0,.16)",p.fillRect(0,q*D+D-1,u,2),w.fillStyle="#a4a4a4",w.fillRect(0,q*D+D-4,u,3)}for(let q=0;q<40;q++){const j=c()*u,Y=c()*u,W=8+c()*60,ht=p.createRadialGradient(j,Y,0,j,Y,W);ht.addColorStop(0,`rgba(26,22,17,${.09+c()*.13})`),ht.addColorStop(1,"rgba(0,0,0,0)"),p.fillStyle=ht,p.beginPath(),p.arc(j,Y,W,0,7),p.fill()}for(let q=0;q<10;q++){const j=c()*u,Y=c()*u,W=6+c()*40,ht=4+c()*22;p.fillStyle=`rgba(${e[0]-30},${e[1]-28},${e[2]-26},.55)`,p.beginPath(),p.ellipse(j,Y,W,ht,c()*3,0,7),p.fill()}for(let q=0;q<16;q++){const j=c()*u,Y=p.createLinearGradient(0,0,0,u);Y.addColorStop(0,`rgba(30,26,20,${.04+c()*.09})`),Y.addColorStop(1,"rgba(30,26,20,0)"),p.fillStyle=Y,p.fillRect(j,0,2+c()*6,u)}for(let q=0;q<4e3;q++){const j=c()*u,Y=c()*u,W=.02+c()*.05;p.fillStyle=c()>.5?`rgba(255,250,240,${W})`:`rgba(0,0,0,${W})`,p.fillRect(j,Y,1,1+c()*1.5)}const rt=p.getImageData(0,0,u,u).data,S=w.getImageData(0,0,u,u).data,z=new Uint8Array(u*u);for(let q=0;q<u*u;q++)z[q]=S[q*4];const nt=new Uint8Array(u*u);for(let q=0;q<u*u;q++){const j=rt[q*4]*.3+rt[q*4+1]*.59+rt[q*4+2]*.11;nt[q]=Math.min(255,206+(150-j)*.18)}return{map:Me(v,{srgb:!0}),normalMap:Me(Pi(z,u,2.2)),roughnessMap:Me(vs(nt,u))}}function rl(i,{base:t=[70,78,62],rust:e=.5,painted:n=!0}={}){const s=mi,r=xn(i),a=We(i+5),o=Be(s),l=o.getContext("2d",{willReadFrequently:!0}),h=l.createImageData(s,s),f=h.data;for(let c=0;c<s;c++)for(let v=0;v<s;v++){const p=v/s,x=c/s,w=r(p,x,5,5,.55),b=r(p,x,4,20,.5),C=.8+(w-.5)*.35+(b-.5)*.18,V=(c*s+v)*4;f[V]=t[0]*C,f[V+1]=t[1]*C,f[V+2]=t[2]*C,f[V+3]=255}if(l.putImageData(h,0,0),n)for(let c=0;c<140;c++){const v=a()*s,p=a()*s,x=1+a()*6;l.fillStyle=`rgba(${110+a()*40},${58+a()*20},${22+a()*14},${.5+a()*.45})`,l.beginPath(),l.ellipse(v,p,x,x*(.5+a()),a()*3,0,7),l.fill()}for(let c=0;c<16*e;c++){const v=a()*s,p=a()*s,x=8+a()*46,w=l.createRadialGradient(v,p,0,v,p,x);w.addColorStop(0,`rgba(122,62,24,${.28+a()*.3})`),w.addColorStop(.6,`rgba(88,46,20,${.18})`),w.addColorStop(1,"rgba(0,0,0,0)"),l.fillStyle=w,l.beginPath(),l.arc(v,p,x,0,7),l.fill()}for(let c=0;c<70;c++){const v=a()*s,p=a()*s,x=4+a()*40,w=a()*7;l.strokeStyle=`rgba(${190+a()*40},${190+a()*40},${190+a()*30},${.03+a()*.1})`,l.lineWidth=a()*1.2,l.beginPath(),l.moveTo(v,p),l.lineTo(v+Math.cos(w)*x,p+Math.sin(w)*x),l.stroke()}l.strokeStyle="rgba(0,0,0,.18)",l.lineWidth=2,l.beginPath(),l.moveTo(0,s*.5),l.lineTo(s,s*.5),l.stroke();const m=l.getImageData(0,0,s,s).data,u=new Uint8Array(s*s),d=new Uint8Array(s*s);for(let c=0;c<s*s;c++){const v=m[c*4]*.3+m[c*4+1]*.5+m[c*4+2]*.2;u[c]=v;const p=m[c*4]/255,x=m[c*4+1]/255;d[c]=110+p*90+(p-x)*120}return{map:Me(o,{srgb:!0}),normalMap:Me(Pi(u,s,1.2)),roughnessMap:Me(vs(d,s))}}function P2(i){const t=mi,e=We(i),n=xn(i+7),s=Be(t),r=s.getContext("2d",{willReadFrequently:!0}),a=r.createImageData(t,t),o=a.data,l=new Uint8Array(t*t),h=15;for(let c=0;c<t;c++){const p=c%h/h,x=.74+Math.sin(p*Math.PI)*.2-di(.75,1,p)*.24;for(let w=0;w<t;w++){const b=n(w/t,c/t,3,9,.5),C=x*(.92+(b-.5)*.16),V=(c*t+w)*4;o[V]=102*C,o[V+1]=106*C,o[V+2]=98*C,o[V+3]=255,l[c*t+w]=Math.min(255,90+Math.sin(p*Math.PI)*110)}}r.putImageData(a,0,0),r.strokeStyle="rgba(10,9,8,.5)",r.lineWidth=2;for(let c=0;c<t;c+=h*11)r.beginPath(),r.moveTo(0,c),r.lineTo(t,c),r.stroke();for(let c=0;c<10;c++){const v=e()*t,p=e()*t,x=10+e()*34,w=r.createRadialGradient(v-x*.3,p-x*.3,1,v,p,x);w.addColorStop(0,"rgba(200,200,190,.14)"),w.addColorStop(.55,"rgba(30,30,28,.20)"),w.addColorStop(1,"rgba(0,0,0,0)"),r.fillStyle=w,r.beginPath(),r.arc(v,p,x,0,7),r.fill()}for(let c=0;c<12;c++){const v=e()*t,p=r.createLinearGradient(0,0,0,t);p.addColorStop(0,"rgba(96,52,22,0)"),p.addColorStop(1,`rgba(96,52,22,${.12+e()*.2})`),r.fillStyle=p,r.fillRect(v,0,2+e()*8,t)}const f=r.createLinearGradient(0,t*.62,0,t);f.addColorStop(0,"rgba(80,46,20,0)"),f.addColorStop(1,"rgba(80,46,20,.42)"),r.fillStyle=f,r.fillRect(0,0,t,t);for(let c=0;c<16;c++){const v=e()*t,p=e()*t;r.fillStyle="rgba(232,226,210,.62)",r.beginPath(),r.arc(v,p,1.6+e()*1.8,0,7),r.fill(),r.fillStyle="rgba(18,17,16,.86)",r.beginPath(),r.arc(v,p,2.2+e()*2.4,0,7),r.fill(),r.fillStyle="rgba(210,200,180,.30)",r.beginPath(),r.arc(v-1,p-1,.9,0,7),r.fill()}const m=r.createLinearGradient(0,0,0,t);m.addColorStop(0,"rgba(20,18,15,.10)"),m.addColorStop(.6,"rgba(20,18,15,0)"),m.addColorStop(1,"rgba(20,18,15,.26)"),r.fillStyle=m,r.fillRect(0,0,t,t);const u=r.getImageData(0,0,t,t).data,d=new Uint8Array(t*t);for(let c=0;c<t*t;c++){const v=u[c*4]*.4+u[c*4+1]*.4+u[c*4+2]*.2;l[c]=Math.min(255,l[c]*.7+v*.3),d[c]=96+(255-v)*.35}return{map:Me(s,{srgb:!0}),normalMap:Me(Pi(l,t,2.4)),roughnessMap:Me(vs(d,t))}}function al(i,{bg:t=[46,74,68],fg:e=[222,214,190],accent:n=[176,82,48]}={}){const r=We(i);xn(i+3);const a=Be(256),o=a.getContext("2d",{willReadFrequently:!0});o.fillStyle=`rgb(${t[0]},${t[1]},${t[2]})`,o.fillRect(0,0,256,256);const l=o.getImageData(0,0,256,256),h=l.data;for(let u=0;u<256*256;u++){const d=.86+(r()-.5)*.18;h[u*4]*=d,h[u*4+1]*=d,h[u*4+2]*=d}o.putImageData(l,0,0),o.strokeStyle=`rgba(${e[0]},${e[1]},${e[2]},.75)`,o.lineWidth=6,o.strokeRect(8,8,240,240);const f=2;for(let u=0;u<f;u++){const d=256*(.34+u*.34);let c=26;for(;c<230;){const v=13+r()*26;o.fillStyle=r()<.82?`rgba(${e[0]},${e[1]},${e[2]},.92)`:`rgba(${n[0]},${n[1]},${n[2]},.9)`;const p=r();p<.34?o.fillRect(c,d-5,v,9):p<.62?(o.fillRect(c,d-16,6,26),o.fillRect(c,d+4,v*.7,7)):p<.82?(o.beginPath(),o.arc(c+v*.3,d,8,0,7),o.fill(),o.fillRect(c+v*.62,d-12,5,22)):(o.fillRect(c,d-2,v,5),o.beginPath(),o.arc(c+v*.2,d-14,3.2,0,7),o.fill(),o.beginPath(),o.arc(c+v*.5,d-14,3.2,0,7),o.fill(),o.beginPath(),o.arc(c+v*.8,d-14,3.2,0,7),o.fill()),c+=v+10+r()*8}}for(let u=0;u<150;u++){const d=r()*256,c=r()*256,v=1+r()*8;o.fillStyle=`rgba(${t[0]+26},${t[1]+24},${t[2]+20},${.4+r()*.5})`,o.beginPath(),o.ellipse(d,c,v,v*(.4+r()),r()*3,0,7),o.fill()}for(let u=0;u<16;u++){const d=r()*256,c=o.createLinearGradient(0,0,0,256);c.addColorStop(0,`rgba(96,54,24,${.1+r()*.18})`),c.addColorStop(1,"rgba(96,54,24,0)"),o.fillStyle=c,o.fillRect(d,0,1.5+r()*6,256)}const m=o.createLinearGradient(0,0,0,256);return m.addColorStop(0,"rgba(16,14,12,.16)"),m.addColorStop(1,"rgba(16,14,12,.34)"),o.fillStyle=m,o.fillRect(0,0,256,256),{map:Me(a,{srgb:!0})}}function D2(i,{a:t=[158,149,128],b:e=[116,101,82]}={}){const s=We(i);xn(i+5);const r=Be(256),a=r.getContext("2d",{willReadFrequently:!0}),o=32;for(let m=0;m<256;m++){const d=Math.floor(m/o)%2?e:t,c=m%o/o,v=.88+Math.sin(c*Math.PI)*.12;a.fillStyle=`rgb(${d[0]*v|0},${d[1]*v|0},${d[2]*v|0})`,a.fillRect(m,0,1,256)}const l=a.getImageData(0,0,256,256),h=l.data;for(let m=0;m<256*256;m++){const u=.85+(s()-.5)*.24;h[m*4]*=u,h[m*4+1]*=u,h[m*4+2]*=u}a.putImageData(l,0,0);for(let m=0;m<22;m++){const u=s()*256,d=s()*256,c=8+s()*46,v=a.createRadialGradient(u,d,0,u,d,c);v.addColorStop(0,`rgba(46,36,22,${.1+s()*.16})`),v.addColorStop(1,"rgba(0,0,0,0)"),a.fillStyle=v,a.beginPath(),a.arc(u,d,c,0,7),a.fill()}const f=a.createLinearGradient(0,0,0,256);return f.addColorStop(0,"rgba(30,24,16,.10)"),f.addColorStop(.5,"rgba(30,24,16,.02)"),f.addColorStop(1,"rgba(30,24,16,.28)"),a.fillStyle=f,a.fillRect(0,0,256,256),{map:Me(r,{srgb:!0})}}function I2(i){const e=We(i),n=xn(i+11),s=Be(256),r=s.getContext("2d",{willReadFrequently:!0}),a=r.createImageData(256,256),o=a.data;for(let u=0;u<256;u++)for(let d=0;d<256;d++){const c=d/256,v=u/256,p=n(c,v,4,6,.55),x=n(c,v,2,30,.5),w=146+(p-.5)*36+(x-.5)*30,b=(u*256+d)*4;o[b]=w,o[b+1]=w*.985,o[b+2]=w*.94,o[b+3]=255}r.putImageData(a,0,0);for(let u=0;u<14;u++){const d=e()*256,c=e()*256,v=10+e()*46,p=r.createRadialGradient(d,c,0,d,c,v);p.addColorStop(0,`rgba(44,42,38,${.12+e()*.2})`),p.addColorStop(1,"rgba(0,0,0,0)"),r.fillStyle=p,r.beginPath(),r.arc(d,c,v,0,7),r.fill()}const l=Be(256),h=l.getContext("2d",{willReadFrequently:!0}),f=h.createImageData(256,256),m=f.data;for(let u=0;u<256;u++)for(let d=0;d<256;d++){const c=d/256,v=u/256,p=n(c,v,4,8,.6),x=n(c,v,2,3,.5);let w=di(.4,.66,p*.7+x*.42)*.72;w*=.35+.65*di(.3,.68,n(c,v,2,5,.5));const b=(u*256+d)*4,C=w*255;m[b]=m[b+1]=m[b+2]=C,m[b+3]=255}return h.putImageData(f,0,0),{map:Me(s,{srgb:!0}),alpha:Me(l)}}function L2(i){const e=xn(i+13),n=Be(256),s=n.getContext("2d",{willReadFrequently:!0});s.clearRect(0,0,256,256);const r=s.createImageData(256,256),a=r.data;for(let o=0;o<256;o++)for(let l=0;l<256;l++){const h=l/256,f=o/256,m=.5+Math.sin(f*7.3)*.05,u=Math.exp(-Math.pow((h-m)/.19,2)),d=.62+.38*(Math.sin(f*62)*.5+.5),c=e(h,f,3,9,.5);let v=u*d*(.55+c*.7);v*=di(0,.08,f)*di(1,.9,f);const p=(o*256+l)*4;a[p]=12,a[p+1]=12,a[p+2]=13,a[p+3]=Math.min(255,v*235)}return s.putImageData(r,0,0),{map:Me(n,{srgb:!0})}}function U2(i){const e=We(i);xn(i+3);const n=Be(128),s=n.getContext("2d",{willReadFrequently:!0});s.clearRect(0,0,128,128),s.save(),s.translate(128/2,128/2);const r=13;s.beginPath();for(let a=0;a<r;a++){const o=a/r*Math.PI*2,l=128*(.3+e()*.13),h=Math.cos(o)*l,f=Math.sin(o)*l*.8;a?s.lineTo(h,f):s.moveTo(h,f)}s.closePath(),s.fillStyle="rgba(206,199,182,.96)",s.fill(),s.clip();for(let a=0;a<90;a++)s.fillStyle=`rgba(${40+e()*40},${40+e()*40},${40+e()*36},${.05+e()*.12})`,s.fillRect(-128/2+e()*128,-128/2+e()*128,1+e()*9,1+e()*3);for(let a=0;a<8;a++)s.fillStyle=`rgba(120,110,96,${.08+e()*.1})`,s.beginPath(),s.arc(-128/2+e()*128,-128/2+e()*128,2+e()*8,0,7),s.fill();return s.restore(),{map:Me(n,{srgb:!0})}}function z2(i){const e=We(i),n=Be(128),s=n.getContext("2d",{willReadFrequently:!0});s.clearRect(0,0,128,128);for(let r=0;r<26;r++){const a=128*(.5+(e()-.5)*.5),o=(e()-.5)*.9,l=128*(.35+e()*.6),h=1.1+e()*2.2,f=e();s.strokeStyle=f>.6?`rgba(${132+e()*30},${122+e()*24},${76+e()*20},.95)`:`rgba(${96+e()*26},${92+e()*22},${58+e()*18},.95)`,s.lineWidth=h,s.beginPath(),s.moveTo(a,128);for(let m=.1;m<=1;m+=.1){const u=a+o*l*m*m,d=128-l*m;s.lineTo(u,d)}s.stroke()}return{map:Me(n,{srgb:!0})}}function N2(i){const e=We(i),n=Be(512),s=n.getContext("2d",{willReadFrequently:!0});s.clearRect(0,0,512,512);const r=["rgba(196,66,58,.82)","rgba(72,96,138,.80)","rgba(210,196,86,.74)","rgba(84,120,92,.78)"];for(let a=0;a<3;a++){const o=512*(.22+a*.3),l=512*(.3+e()*.45),h=r[e()*r.length|0];s.save(),s.translate(o,l),s.rotate((e()-.5)*.35),s.strokeStyle=h,s.lineWidth=7+e()*7,s.lineJoin="round",s.lineCap="round";let f=-512*.1;s.beginPath(),s.moveTo(f,0);for(let m=0;m<9;m++){f+=512*(.02+e()*.028);const u=(e()-.5)*512*.11;s.lineTo(f,u),e()<.3&&s.lineTo(f+512*.01,u+512*.05)}s.stroke();for(let m=0;m<70;m++){const u=e()*7,d=Math.sqrt(e())*512*.12;s.fillStyle=h,s.globalAlpha=.1+e()*.2,s.fillRect(Math.cos(u)*d,Math.sin(u)*d*.5,1.5,1.5)}s.globalAlpha=1,s.restore()}return{map:Me(n,{srgb:!0})}}function F2(i){const e=We(i),n=Be(512),s=n.getContext("2d",{willReadFrequently:!0});s.fillStyle="#8b8272",s.fillRect(0,0,512,512);const r=16,a=512/r,o=512/8,l=new Uint8Array(512*512);for(let f=0;f<r;f++){const m=f%2*o*.5;for(let u=-1;u<9;u++){const d=u*o+m+2,c=f*a+2,v=o-4,p=a-4,x=.72+e()*.42;s.fillStyle=`rgb(${118*x|0},${82*x|0},${66*x|0})`,s.fillRect(d,c,v,p);for(let w=0;w<22;w++)s.fillStyle=e()>.5?`rgba(255,240,220,${.02+e()*.05})`:`rgba(20,12,8,${.03+e()*.07})`,s.fillRect(d+e()*v,c+e()*p,1+e()*4,1+e()*2);e()<.16&&(s.fillStyle="rgba(150,140,120,.85)",s.beginPath(),s.moveTo(d+v,c),s.lineTo(d+v-6,c),s.lineTo(d+v,c+6),s.closePath(),s.fill())}}for(let f=0;f<24;f++){const m=e()*512,u=e()*512,d=10+e()*70,c=s.createRadialGradient(m,u,0,m,u,d);c.addColorStop(0,`rgba(38,30,22,${.1+e()*.16})`),c.addColorStop(1,"rgba(0,0,0,0)"),s.fillStyle=c,s.beginPath(),s.arc(m,u,d,0,7),s.fill()}const h=s.getImageData(0,0,512,512).data;for(let f=0;f<512*512;f++){const m=h[f*4]*.4+h[f*4+1]*.4+h[f*4+2]*.2;l[f]=Math.min(255,m)}return{map:Me(n,{srgb:!0}),normalMap:Me(Pi(l,512,1.6))}}function au(i,{base:t=[122,106,78],weave:e=1,stains:n=.5}={}){const s=mi,r=xn(i),a=We(i+11),o=Be(s),l=o.getContext("2d",{willReadFrequently:!0}),h=l.createImageData(s,s),f=h.data;for(let c=0;c<s;c++)for(let v=0;v<s;v++){const p=v/s,x=c/s,w=r(p,x,4,8,.5),b=(Math.sin(v*1.9)*.5+.5)*(Math.sin(c*1.9)*.5+.5),C=.78+(w-.5)*.32+(b-.25)*.16*e+(a()-.5)*.06,V=(c*s+v)*4;f[V]=t[0]*C,f[V+1]=t[1]*C,f[V+2]=t[2]*C,f[V+3]=255}l.putImageData(h,0,0);for(let c=0;c<22;c++){const v=a()*s,p=a()*s,x=10+a()*50,w=l.createRadialGradient(v,p,0,v,p,x);w.addColorStop(0,`rgba(42,34,22,${.16*n})`),w.addColorStop(1,"rgba(0,0,0,0)"),l.fillStyle=w,l.beginPath(),l.arc(v,p,x,0,7),l.fill()}const m=l.getImageData(0,0,s,s).data,u=new Uint8Array(s*s),d=new Uint8Array(s*s);for(let c=0;c<s*s;c++){const v=m[c*4]*.4+m[c*4+1]*.4+m[c*4+2]*.2;u[c]=v,d[c]=225}return{map:Me(o,{srgb:!0}),normalMap:Me(Pi(u,s,1.1)),roughnessMap:Me(vs(d,s))}}function ou(i){const t=mi,e=We(i),n=Be(t),s=n.getContext("2d",{willReadFrequently:!0});s.fillStyle="#8d7a55",s.fillRect(0,0,t,t);const r=s.getImageData(0,0,t,t),a=r.data;for(let o=0;o<t*t;o++){const l=.8+(e()-.5)*.3;a[o*4]*=l,a[o*4+1]*=l,a[o*4+2]*=l}s.putImageData(r,0,0);for(let o=0;o<8e3;o++){const l=e()*t,h=e()*t;s.fillStyle=e()>.5?"rgba(230,218,190,.10)":"rgba(40,32,20,.12)",s.fillRect(l,h,1+e()*3,1)}return{map:Me(n,{srgb:!0})}}function lu(i){const t=mi,e=We(i);xn(i+2);const n=Be(t),s=n.getContext("2d",{willReadFrequently:!0}),r=new Uint8Array(t*t),a=5,o=t/a;for(let h=0;h<a;h++){const f=.82+e()*.3;s.fillStyle=`rgb(${104*f|0},${76*f|0},${46*f|0})`,s.fillRect(h*o,0,o,t);for(let m=0;m<46;m++){const u=h*o+e()*o;s.strokeStyle=e()>.5?`rgba(${42+e()*30},${28+e()*20},${14+e()*14},${.1+e()*.22})`:`rgba(${190+e()*40},${150+e()*30},${100+e()*26},${.04+e()*.1})`,s.lineWidth=.7+e()*1.8,s.beginPath();let d=0,c=u;for(s.moveTo(c,d);d<t;)d+=12+e()*26,c+=(e()-.5)*3,s.lineTo(c,d);s.stroke()}if(e()<.6){const m=h*o+o*(.3+e()*.4),u=t*e();for(let d=10;d>1;d-=2.4)s.strokeStyle=`rgba(44,28,14,${.2+e()*.2})`,s.lineWidth=1.4,s.beginPath(),s.ellipse(m,u,d,d*1.7,0,0,7),s.stroke()}s.fillStyle="rgba(14,9,5,.72)",s.fillRect(h*o-1.2,0,2.4,t),s.fillStyle="rgba(220,190,150,.08)",s.fillRect(h*o+1.2,0,1.4,t);for(let m=0;m<3;m++){const u=h*o+6+e()*(o-12),d=14+m*(t/3);s.fillStyle="rgba(28,26,24,.85)",s.beginPath(),s.arc(u,d,2.4,0,7),s.fill(),s.fillStyle="rgba(180,176,164,.35)",s.beginPath(),s.arc(u-.7,d-.7,1.1,0,7),s.fill()}}for(let h=0;h<22;h++){const f=e()*t,m=e()*t,u=10+e()*70,d=s.createRadialGradient(f,m,0,f,m,u);d.addColorStop(0,`rgba(22,16,10,${.06+e()*.14})`),d.addColorStop(1,"rgba(0,0,0,0)"),s.fillStyle=d,s.beginPath(),s.arc(f,m,u,0,7),s.fill()}const l=s.getImageData(0,0,t,t).data;for(let h=0;h<t*t;h++){const f=l[h*4]*.4+l[h*4+1]*.4+l[h*4+2]*.2;r[h]=Math.min(255,f*1.05)}return{map:Me(n,{srgb:!0}),normalMap:Me(Pi(r,t,1.1))}}function O2(i){const e=We(i),n=xn(i+4),s=Be(256),r=s.getContext("2d",{willReadFrequently:!0});r.clearRect(0,0,256,256);for(let l=0;l<34;l++){const h=e()*256,f=2+e()*22,m=e()*256*.5,u=256*(.3+e()*.7),d=r.createLinearGradient(0,m,0,m+u);d.addColorStop(0,`rgba(22,19,15,${.12+e()*.3})`),d.addColorStop(.55,`rgba(22,19,15,${.05+e()*.12})`),d.addColorStop(1,"rgba(22,19,15,0)"),r.fillStyle=d,r.fillRect(h,m,f,u)}for(let l=0;l<12;l++){const h=e()*256,f=e()*256*.7,m=10+e()*40,u=r.createRadialGradient(h,f,0,h,f,m);u.addColorStop(0,`rgba(18,16,13,${.1+e()*.14})`),u.addColorStop(1,"rgba(18,16,13,0)"),r.fillStyle=u,r.beginPath(),r.arc(h,f,m,0,7),r.fill()}const a=r.getImageData(0,0,256,256),o=a.data;for(let l=0;l<256;l++)for(let h=0;h<256;h++){const f=(l*256+h)*4,m=n(h/256,l/256,3,7,.55),u=di(0,.1,h/256)*di(1,.9,h/256)*di(0,.08,l/256)*di(1,.86,l/256);o[f+3]=o[f+3]*(.25+m*.9)*u}return r.putImageData(a,0,0),{map:Me(s,{srgb:!0})}}function B2(i){const e=We(i),n=Be(256),s=n.getContext("2d",{willReadFrequently:!0});s.clearRect(0,0,256,256),s.strokeStyle="rgba(104,96,64,.95)",s.lineWidth=3,s.beginPath(),s.moveTo(4,256/2),s.lineTo(252,256/2),s.stroke();for(let r=0;r<46;r++){const a=r/46,o=8+a*240,l=256*.46*Math.sin(Math.PI*Math.pow(a,.75))*(.8+e()*.3),h=.7+e()*.5;s.strokeStyle=`rgba(${92*h|0},${88*h|0},${48*h|0},${.85+e()*.15})`,s.lineWidth=1.6+e()*1.6;for(const f of[-1,1])s.beginPath(),s.moveTo(o,256/2),s.quadraticCurveTo(o+l*.35,256/2+f*l*.55,o+l*.62,256/2+f*l),s.stroke()}return{map:Me(n,{srgb:!0})}}function pc(i,t){const e=Be(i),n=e.getContext("2d",{willReadFrequently:!0}),s=n.createRadialGradient(i/2,i/2,0,i/2,i/2,i/2);for(const[r,a]of t)s.addColorStop(r,a);return n.fillStyle=s,n.fillRect(0,0,i,i),e}function k2(){const t=Be(128),e=t.getContext("2d",{willReadFrequently:!0}),n=xn(77),s=e.createImageData(128,128),r=s.data;for(let a=0;a<128;a++)for(let o=0;o<128;o++){const l=o/128,h=a/128,f=n(l,h,5,4,.55),m=l-.5,u=h-.5,d=Math.hypot(m,u)*2,c=Math.max(0,1-d)**1.7*(.35+f*.9),v=(a*128+o)*4;r[v]=255,r[v+1]=250,r[v+2]=244,r[v+3]=Math.min(255,c*300)}return e.putImageData(s,0,0),t}function H2(){const t=Be(256),e=t.getContext("2d",{willReadFrequently:!0});e.translate(256/2,256/2);for(let s=0;s<9;s++){e.save(),e.rotate(s/9*Math.PI*2+.2);const r=256*(.22+s%3*.12),a=e.createLinearGradient(0,0,r,0);a.addColorStop(0,"rgba(255,250,225,1)"),a.addColorStop(.4,"rgba(255,196,90,.85)"),a.addColorStop(1,"rgba(255,120,30,0)"),e.fillStyle=a,e.beginPath(),e.moveTo(0,-6),e.lineTo(r,0),e.lineTo(0,6),e.closePath(),e.fill(),e.restore()}const n=e.createRadialGradient(0,0,0,0,0,256*.3);return n.addColorStop(0,"rgba(255,255,245,1)"),n.addColorStop(.25,"rgba(255,214,140,.95)"),n.addColorStop(.6,"rgba(255,140,40,.45)"),n.addColorStop(1,"rgba(255,90,10,0)"),e.fillStyle=n,e.beginPath(),e.arc(0,0,256*.3,0,7),e.fill(),t}function G2(){const t=Be(128),e=t.getContext("2d",{willReadFrequently:!0}),n=xn(9),s=e.createImageData(128,128),r=s.data;for(let a=0;a<128;a++)for(let o=0;o<128;o++){const l=o/128,h=a/128,f=l-.5,m=h-.5,u=Math.hypot(f,m)*2,d=Math.atan2(m,f),c=n(l,h,4,6,.6),v=.34+c*.16+Math.sin(d*9)*.03;let p=0,x=0;u<v?(p=1,x=6+c*12):u<v+.28&&(p=(1-(u-v)/.28)*(.55+c*.4),x=30+c*55);const w=(a*128+o)*4;r[w]=r[w+1]=r[w+2]=x,r[w+3]=Math.min(255,p*255)}return e.putImageData(s,0,0),t}function V2(){const t=Be(128),e=t.getContext("2d",{willReadFrequently:!0}),n=We(31);for(let s=0;s<26;s++){const r=n()*7,a=n()*128*.42,o=128/2+Math.cos(r)*a,l=128/2+Math.sin(r)*a,h=2+n()*13*(1-a/(128*.6)),f=e.createRadialGradient(o,l,0,o,l,h);f.addColorStop(0,"rgba(92,8,8,.95)"),f.addColorStop(.7,"rgba(66,5,5,.7)"),f.addColorStop(1,"rgba(40,2,2,0)"),e.fillStyle=f,e.beginPath(),e.arc(o,l,h,0,7),e.fill()}return t}function W2(){return pc(64,[[0,"rgba(255,70,50,1)"],[.2,"rgba(255,40,26,.9)"],[.45,"rgba(255,30,20,.35)"],[1,"rgba(255,20,10,0)"]])}function X2(i=8){const t=(W,ht={},lt=1)=>{const Dt=new he({...W,...ht});for(const yt of["map","normalMap","roughnessMap","alphaMap"])Dt[yt]&&(Dt[yt].anisotropy=i,Dt[yt].repeat.set(lt,lt));return Dt},e=ru(1201,{tint:[136,132,121]}),n=ru(3102,{tint:[94,92,86],stains:.85}),s=R2(555),r=Os(1401,{base:[158,148,128],warm:1.02}),a=Os(1402,{base:[139,140,136],warm:.99,chipped:.8}),o=Os(1403,{base:[160,132,104],warm:1.05}),l=Pa(701,{base:[138,128,108],floors:2,cols:3,litChance:.2}),h=Pa(1502,{base:[120,122,120],floors:2,cols:4,litChance:.07,trim:[132,132,126],acChance:.35}),f=Pa(2203,{base:[148,120,98],floors:2,cols:3,litChance:.14,trim:[162,144,122],balconyChance:.3}),m=Pa(2704,{base:[112,108,104],floors:3,cols:3,litChance:.09,trim:[120,116,110],brokenChance:.16,boardChance:.07}),u=P2(881),d=rl(990,{base:[64,74,58],rust:.25}),c=rl(991,{base:[124,104,70],rust:.15}),v=rl(992,{base:[96,62,40],rust:1,painted:!1}),p=typeof au=="function"?au(993,{base:[124,108,78]}):Os(1993,{base:[124,108,78],warm:.75,chipped:.7}),x=typeof ou=="function"?ou(994):Os(1994,{base:[142,122,86],warm:.7,chipped:.6}),w=typeof lu=="function"?lu(995):Os(1995,{base:[112,84,52],warm:.9,chipped:.5}),b=D2(1201),C=al(2101,{bg:[38,60,56],fg:[212,204,180],accent:[150,74,48]}),V=al(2102,{bg:[92,46,40],fg:[214,202,176],accent:[58,70,58]}),D=al(2103,{bg:[168,154,122],fg:[52,48,40],accent:[128,58,40]}),A=I2(3301),y=L2(3302),rt=U2(3303),S=z2(3304),z=N2(3305),nt=F2(3306),q=O2(3401),j=B2(3402),Y={concrete:t(e,{roughness:.97,metalness:0,envMapIntensity:.32}),concreteDark:t(n,{roughness:.98,metalness:0,envMapIntensity:.28}),asphalt:t(s,{roughness:1,metalness:0,envMapIntensity:.05}),brick:t(nt,{roughness:.95,metalness:0,envMapIntensity:.45}),plasterA:t(r,{roughness:.92,metalness:0,envMapIntensity:.5}),plasterB:t(a,{roughness:.94,metalness:0,envMapIntensity:.45}),plasterC:t(o,{roughness:.92,metalness:0,envMapIntensity:.5}),facadeA:t(l,{roughness:.91,metalness:0,envMapIntensity:.5}),facadeB:t(h,{roughness:.93,metalness:0,envMapIntensity:.45}),facadeC:t(f,{roughness:.91,metalness:0,envMapIntensity:.5}),facadeD:t(m,{roughness:.93,metalness:0,envMapIntensity:.45}),shop:t(u,{roughness:.66,metalness:.5,envMapIntensity:.7}),metal:t(d,{roughness:.48,metalness:.8,envMapIntensity:1}),metalTan:t(c,{roughness:.6,metalness:.5,envMapIntensity:.9}),rust:t(v,{roughness:.82,metalness:.55,envMapIntensity:.7}),sandbag:t(p,{roughness:.95,metalness:0,envMapIntensity:.35}),burlap:t(x,{roughness:.96,metalness:0,envMapIntensity:.3}),wood:t(w,{roughness:.88,metalness:0,envMapIntensity:.4}),awning:t(b,{roughness:.93,metalness:0,envMapIntensity:.4,side:ln}),signA:t(C,{roughness:.72,metalness:.15,envMapIntensity:.6}),signB:t(V,{roughness:.72,metalness:.15,envMapIntensity:.6}),signC:t(D,{roughness:.78,metalness:.1,envMapIntensity:.5}),dirt:new he({color:4537136,roughness:1,metalness:0}),windowGlass:new he({color:2372412,roughness:.18,metalness:.45,envMapIntensity:1.3}),windowLit:new he({color:2364936,roughness:.55,metalness:0,emissive:16753756,emissiveIntensity:1.35,envMapIntensity:.2}),windowLitDim:new he({color:1774090,roughness:.6,metalness:0,emissive:14710836,emissiveIntensity:.55,envMapIntensity:.2}),interior:new he({color:592395,roughness:1,metalness:0,envMapIntensity:.06,side:fn}),glass:new he({color:1582124,roughness:.08,metalness:.35,envMapIntensity:2,transparent:!0,opacity:.9}),glassBroken:new he({color:857112,roughness:.35,metalness:.2,envMapIntensity:1.2,side:ln}),paint:(()=>{const W=new he({map:A.map,alphaMap:A.alpha,transparent:!1,alphaTest:.42,roughness:.95,metalness:0,envMapIntensity:.18,color:9143412,polygonOffset:!0,polygonOffsetFactor:-2,polygonOffsetUnits:-2});return W.map.anisotropy=i,W.alphaMap.anisotropy=i,W.userData.noShadow=!0,W.userData.noBullet=!0,W})(),skid:(()=>{const W=new he({map:y.map,transparent:!0,depthWrite:!1,roughness:.82,metalness:0,color:723724,opacity:.68,envMapIntensity:.2,polygonOffset:!0,polygonOffsetFactor:-3,polygonOffsetUnits:-3});return W.map.anisotropy=i,W.userData.noShadow=!0,W.userData.noBullet=!0,W})(),paper:(()=>{const W=new he({map:rt.map,alphaTest:.5,roughness:.95,metalness:0,side:ln,envMapIntensity:.4,color:13222574});return W.map.anisotropy=i,W.userData.noShadow=!0,W.userData.noBullet=!0,W})(),weed:(()=>{const W=new he({map:S.map,alphaTest:.45,roughness:.96,metalness:0,side:ln,envMapIntensity:.35,color:9276008});return W.map.anisotropy=i,W.userData.noShadow=!0,W.userData.noBullet=!0,W})(),graffiti:(()=>{const W=new he({map:z.map,transparent:!0,depthWrite:!1,roughness:.85,metalness:0,opacity:.92,envMapIntensity:.3,side:ln,polygonOffset:!0,polygonOffsetFactor:-3,polygonOffsetUnits:-3});return W.map.anisotropy=i,W.userData.noShadow=!0,W.userData.noBullet=!0,W})(),puddle:(()=>{const W=new he({color:659218,roughness:.22,metalness:.18,envMapIntensity:.55,transparent:!0,opacity:.85});return W.userData.noShadow=!0,W.userData.noBullet=!0,W})(),grime:(()=>{const W=new he({map:q.map,color:2761757,transparent:!0,depthWrite:!1,roughness:1,metalness:0,opacity:.72,side:ln,polygonOffset:!0,polygonOffsetFactor:-3,polygonOffsetUnits:-3});return W.map.anisotropy=i,W.userData.noShadow=!0,W.userData.noBullet=!0,W})(),frond:(()=>{const W=new he({map:j.map,alphaTest:.42,roughness:.9,metalness:0,side:ln,envMapIntensity:.3,color:11249270,emissive:1841936,emissiveIntensity:.6});return W.map.anisotropy=i,W.userData.noShadow=!0,W.userData.noBullet=!0,W})(),patch:new he({color:2368287,roughness:.97,metalness:.02,envMapIntensity:.15}),gunMetal:new he({color:2829616,roughness:.34,metalness:.92,envMapIntensity:1.25}),gunMetalWorn:new he({color:3816768,roughness:.46,metalness:.88,envMapIntensity:1.1}),polymer:new he({color:1974306,roughness:.72,metalness:.08,envMapIntensity:.6}),polymerTan:new he({color:7166524,roughness:.74,metalness:.05,envMapIntensity:.55}),rubber:new he({color:1316118,roughness:.95,metalness:0}),lens:new mh({color:660504,roughness:.05,metalness:.1,transmission:.25,transparent:!0,opacity:.9,envMapIntensity:2.4,clearcoat:1,clearcoatRoughness:.03}),reticleDot:new Bn({color:16724770,toneMapped:!1}),glove:new he({color:2762272,roughness:.82,metalness:.02}),gloveTan:new he({color:7035458,roughness:.85,metalness:.02}),sleeve:new he({color:4868668,roughness:.94,metalness:0}),uniform:new he({color:4934202,roughness:.93,metalness:.02}),uniformDark:new he({color:3487277,roughness:.95,metalness:.02}),vest:new he({color:3881518,roughness:.88,metalness:.05}),helmetMat:new he({color:4145204,roughness:.82,metalness:.12}),skin:new he({color:7164224,roughness:.72,metalness:0}),goggle:new he({color:1316892,roughness:.25,metalness:.6,envMapIntensity:1.4})};Y.asphalt.castShadow=!1,Y.windowGlass.userData.noShadow=!0,Y.windowLit.userData.noShadow=!0,Y.windowLitDim.userData.noShadow=!0,Y.interior.userData.noShadow=!0,Y.interior.userData.noBullet=!0,Y.glass.userData.noShadow=!0,Y.glassBroken.userData.noShadow=!0,Y.dirt.userData.noShadow=!0,Y.sprites={smoke:Me(k2(),{srgb:!0}),flash:Me(H2(),{srgb:!0}),hole:Me(G2(),{srgb:!0}),blood:Me(V2(),{srgb:!0}),laser:Me(W2(),{srgb:!0}),spark:Me(pc(64,[[0,"rgba(255,255,235,1)"],[.35,"rgba(255,200,90,.9)"],[1,"rgba(255,110,20,0)"]]),{srgb:!0}),glow:Me(pc(128,[[0,"rgba(255,255,255,.9)"],[.45,"rgba(255,255,255,.25)"],[1,"rgba(255,255,255,0)"]]),{srgb:!0})};for(const W in Y.sprites){const ht=Y.sprites[W];ht.wrapS=ht.wrapT=Si,ht.needsUpdate=!0}return Y}function q2(i,t="high"){const e=Vr(t),n=new X1({canvas:i,antialias:!1,powerPreference:"high-performance",stencil:!1,alpha:!1});n.setPixelRatio(Math.min(window.devicePixelRatio||1,e.pixelRatio)),n.setSize(window.innerWidth,window.innerHeight,!1),n.shadowMap.enabled=!0,n.shadowMap.type=Pu,n.toneMapping=_c,n.toneMappingExposure=1.08,n.outputColorSpace=pn,n.info.autoReset=!1;const s=new Uc,r=new Jt(7825498);s.fog=new Lc(r,.0082),s.background=null;const a=new Pn(78,window.innerWidth/window.innerHeight,.04,4e3);a.position.set(0,1.7,34),a.rotation.order="YXZ";const o=g2(n);s.add(o.dome),o.envTexture&&(s.environment=o.envTexture,s.environmentIntensity=1.35);const l=new rs(16762778,2.75);l.position.copy(o.sunDir).multiplyScalar(70),l.castShadow=!0,l.shadow.mapSize.set(e.shadows,e.shadows),l.shadow.camera.near=1,l.shadow.camera.far=220;const h=52;l.shadow.camera.left=-h,l.shadow.camera.right=h,l.shadow.camera.top=h,l.shadow.camera.bottom=-h,l.shadow.bias=-2e-4,l.shadow.normalBias=.06,l.shadow.radius=1.7,s.add(l),s.add(l.target);const f=new rs(8230315,.85);f.position.set(-o.sunDir.x*40,24,-o.sunDir.z*40),s.add(f);const m=new gh(9413045,6048824,.95);s.add(m);const u=n.capabilities.getMaxAnisotropy(),d=X2(Math.min(8,u)),c=E2(n,s,a,t),v={quality:t,fps:60,frame:0};function p(){const y=window.innerWidth,rt=window.innerHeight;n.setPixelRatio(Math.min(window.devicePixelRatio||1,Vr(v.quality).pixelRatio)),n.setSize(y,rt,!1),a.aspect=y/rt,a.updateProjectionMatrix(),c.resize(y,rt,n.getPixelRatio())}window.addEventListener("resize",p);const x=new N,w=new N,b=new N;function C(y,rt,S=!1){if(v.frame++,o.update(performance.now()/1e3),rt){const q=h*2/l.shadow.mapSize.x,j=Math.round(rt.x/q)*q,Y=Math.round(rt.z/q)*q;l.target.position.set(j,0,Y),l.position.set(j+o.sunDir.x*70,o.sunDir.y*70,Y+o.sunDir.z*70),l.target.updateMatrixWorld()}x.copy(o.sunDir).multiplyScalar(800).add(a.position),b.copy(x).project(a);const z=b.z>0&&b.x>-1.2&&b.x<1.2&&b.y>-1.2&&b.y<1.2;a.getWorldDirection(w);const nt=Math.max(0,w.dot(o.sunDir));c.uniforms.uSunScreen.value.set(b.x*.5+.5,b.y*.5+.5),c.uniforms.uSunVisible.value=z&&!S?Math.pow(nt,2.2):0,c.uniforms.uSunColor.value.copy(o.sunColor)}function V(y){n.info.reset(),c.render(y)}function D(y){const rt=Vr(y);v.quality=y,n.setPixelRatio(Math.min(window.devicePixelRatio||1,rt.pixelRatio)),n.setSize(window.innerWidth,window.innerHeight,!1),a.aspect=window.innerWidth/window.innerHeight,a.updateProjectionMatrix(),l.shadow.mapSize.set(rt.shadows,rt.shadows),l.shadow.map&&(l.shadow.map.dispose(),l.shadow.map=null),c.applyQuality(y)}function A(y,rt){const S=new yh(y,rt);return S.clear=!1,S.clearDepth=!0,c.composer.insertPass(S,1),S}return{renderer:n,scene:s,camera:a,sky:o,sun:l,fill:f,mats:d,post:c,state:v,addOverlay:A,update:C,render:V,setQuality:D,onResize:p,get quality(){return v.quality},resize:p}}function Sh(i,t=!1){const e=i[0].index!==null,n=new Set(Object.keys(i[0].attributes)),s=new Set(Object.keys(i[0].morphAttributes)),r={},a={},o=i[0].morphTargetsRelative,l=new Ye;let h=0;for(let f=0;f<i.length;++f){const m=i[f];let u=0;if(e!==(m.index!==null))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+f+". All geometries must have compatible attributes; make sure index attribute exists among all geometries, or in none of them."),null;for(const d in m.attributes){if(!n.has(d))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+f+'. All geometries must have compatible attributes; make sure "'+d+'" attribute exists among all geometries, or in none of them.'),null;r[d]===void 0&&(r[d]=[]),r[d].push(m.attributes[d]),u++}if(u!==n.size)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+f+". Make sure all geometries have the same number of attributes."),null;if(o!==m.morphTargetsRelative)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+f+". .morphTargetsRelative must be consistent throughout all geometries."),null;for(const d in m.morphAttributes){if(!s.has(d))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+f+".  .morphAttributes must be consistent throughout all geometries."),null;a[d]===void 0&&(a[d]=[]),a[d].push(m.morphAttributes[d])}if(t){let d;if(e)d=m.index.count;else if(m.attributes.position!==void 0)d=m.attributes.position.count;else return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+f+". The geometry must have either an index or a position attribute"),null;l.addGroup(h,d,f),h+=d}}if(e){let f=0;const m=[];for(let u=0;u<i.length;++u){const d=i[u].index;for(let c=0;c<d.count;++c)m.push(d.getX(c)+f);f+=i[u].attributes.position.count}l.setIndex(m)}for(const f in r){const m=cu(r[f]);if(!m)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+f+" attribute."),null;l.setAttribute(f,m)}for(const f in a){const m=a[f][0].length;if(m===0)break;l.morphAttributes=l.morphAttributes||{},l.morphAttributes[f]=[];for(let u=0;u<m;++u){const d=[];for(let v=0;v<a[f].length;++v)d.push(a[f][v][u]);const c=cu(d);if(!c)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+f+" morphAttribute."),null;l.morphAttributes[f].push(c)}}return l}function cu(i){let t,e,n,s=-1,r=0;for(let h=0;h<i.length;++h){const f=i[h];if(t===void 0&&(t=f.array.constructor),t!==f.array.constructor)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.array must be of consistent array types across matching attributes."),null;if(e===void 0&&(e=f.itemSize),e!==f.itemSize)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.itemSize must be consistent across matching attributes."),null;if(n===void 0&&(n=f.normalized),n!==f.normalized)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.normalized must be consistent across matching attributes."),null;if(s===-1&&(s=f.gpuType),s!==f.gpuType)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.gpuType must be consistent across matching attributes."),null;r+=f.count*e}const a=new t(r),o=new Ve(a,e,n);let l=0;for(let h=0;h<i.length;++h){const f=i[h];if(f.isInterleavedBufferAttribute){const m=l/e;for(let u=0,d=f.count;u<d;u++)for(let c=0;c<e;c++){const v=f.getComponent(u,c);o.setComponent(u+m,c,v)}}else a.set(f.array,l);l+=f.count*e}return s!==void 0&&(o.gpuType=s),o}const Pr=new N;function Vn(i,t,e,n,s,r){const a=2*Math.PI*s/4,o=Math.max(r-2*s,0),l=Math.PI/4;Pr.copy(t),Pr[n]=0,Pr.normalize();const h=.5*a/(a+o),f=1-Pr.angleTo(i)/l;return Math.sign(Pr[e])===1?f*h:o/(a+o)+h+h*(1-f)}class kc extends Rt{constructor(t=1,e=1,n=1,s=2,r=.1){if(s=s*2+1,r=Math.min(t/2,e/2,n/2,r),super(1,1,1,s,s,s),s===1)return;const a=this.toNonIndexed();this.index=null,this.attributes.position=a.attributes.position,this.attributes.normal=a.attributes.normal,this.attributes.uv=a.attributes.uv;const o=new N,l=new N,h=new N(t,e,n).divideScalar(2).subScalar(r),f=this.attributes.position.array,m=this.attributes.normal.array,u=this.attributes.uv.array,d=f.length/6,c=new N,v=.5/s;for(let p=0,x=0;p<f.length;p+=3,x+=2)switch(o.fromArray(f,p),l.copy(o),l.x-=Math.sign(l.x)*v,l.y-=Math.sign(l.y)*v,l.z-=Math.sign(l.z)*v,l.normalize(),f[p+0]=h.x*Math.sign(o.x)+l.x*r,f[p+1]=h.y*Math.sign(o.y)+l.y*r,f[p+2]=h.z*Math.sign(o.z)+l.z*r,m[p+0]=l.x,m[p+1]=l.y,m[p+2]=l.z,Math.floor(p/d)){case 0:c.set(1,0,0),u[x+0]=Vn(c,l,"z","y",r,n),u[x+1]=1-Vn(c,l,"y","z",r,e);break;case 1:c.set(-1,0,0),u[x+0]=1-Vn(c,l,"z","y",r,n),u[x+1]=1-Vn(c,l,"y","z",r,e);break;case 2:c.set(0,1,0),u[x+0]=1-Vn(c,l,"x","z",r,t),u[x+1]=Vn(c,l,"z","x",r,n);break;case 3:c.set(0,-1,0),u[x+0]=1-Vn(c,l,"x","z",r,t),u[x+1]=1-Vn(c,l,"z","x",r,n);break;case 4:c.set(0,0,1),u[x+0]=1-Vn(c,l,"x","y",r,t),u[x+1]=1-Vn(c,l,"y","x",r,e);break;case 5:c.set(0,0,-1),u[x+0]=Vn(c,l,"x","y",r,t),u[x+1]=1-Vn(c,l,"y","x",r,e);break}}}function an(i,t=1){const e=i.attributes.position,n=i.attributes.normal,s=i.attributes.uv;for(let r=0;r<e.count;r++){const a=e.getX(r),o=e.getY(r),l=e.getZ(r),h=Math.abs(n.getX(r)),f=Math.abs(n.getY(r)),m=Math.abs(n.getZ(r));let u,d;h>=f&&h>=m?(u=l,d=o):f>=h&&f>=m?(u=a,d=l):(u=a,d=o),s.setXY(r,u/t,d/t)}return s.needsUpdate=!0,i}function Js(i,{castShadow:t=!0,receiveShadow:e=!0}={}){i.updateMatrixWorld(!0);const n=new Map,s=[];i.traverse(a=>{if(!a.isMesh||a.userData.noMerge){a.isMesh&&s.push(a);return}let o=a.geometry.index?a.geometry.toNonIndexed():a.geometry.clone();o.applyMatrix4(a.matrixWorld);for(const h of Object.keys(o.attributes))["position","normal","uv"].includes(h)||o.deleteAttribute(h);if(!o.attributes.uv){const h=o.attributes.position.count;o.setAttribute("uv",new Ve(new Float32Array(h*2),2))}const l=a.material.uuid;n.has(l)||n.set(l,{mat:a.material,geos:[]}),n.get(l).geos.push(o)});const r=new xe;for(const{mat:a,geos:o}of n.values()){try{const l=Sh(o,!1);if(!l)continue;const h=new K(l,a);h.castShadow=t,h.receiveShadow=e,h.matrixAutoUpdate=!1,r.add(h)}catch(l){console.warn("merge failed for material",a.name,l)}for(const l of o)l.dispose()}for(const a of s)r.add(a);return r}const ce=9.85,ns=.5,Bs=ce+ns,as=6.9,Y2=ce-as,$2=(as+ce)/2;function K2(i){const{mats:t}=i,e=i.scene,n=new xe,s=new xe,r=new xe,a=new xe;n.add(s,a,r),e.add(n);const o=[],l=[],h=[],f=[],m=[],u=We(20261018);let d=0;const c=(I,G)=>I+u()*(G-I),v=I=>I[u()*I.length|0],p=2.4;function x(I,G=s){return G.add(I),I}function w(I,G,X,H){o.push({x0:I,x1:G,z0:X,z1:H})}function b(I,G,X,H,_=0){w(I-X/2-_,I+X/2+_,G-H/2-_,G+H/2+_)}function C(I,G,X,H,_=0,R=.05){const T=Math.abs(Math.cos(_)),O=Math.abs(Math.sin(_));b(I,G,X*T+H*O,X*O+H*T,R)}const V=new Map;function D(I,G,X,H,_=1.4){const R=`${I.toFixed(3)}|${G.toFixed(3)}|${X.toFixed(3)}|${H}|${_}`;if(!V.has(R)){const T=new kc(I,G,X,2,Math.min(H,Math.min(I,G,X)*.48));an(T,_),V.set(R,T)}return V.get(R).clone()}function A(I,G,X,H=.9,_=.9){const R=new Rt(I,G,X),T=R.attributes.position;for(let O=0;O<T.count;O++)T.getY(O)>G*.49&&(T.setX(O,T.getX(O)*H),T.setZ(O,T.getZ(O)*_));return T.needsUpdate=!0,R.computeVertexNormals(),R}function y(I,G,X,H,_,R,T,O=0,F={}){const g=new Rt(I,G,X);an(g,F.uv??p);const M=new K(g,H);return M.position.set(_,R,T),M.rotation.set(F.rx||0,O,F.rz||0),M.castShadow=F.cast!==!1,M.receiveShadow=F.recv!==!1,x(M,F.group||s),F.collide&&C(_,T,I,X,O,F.pad??.04),M}function rt(I,G,X,H,_,R,T,O,F=0,g={}){const M=D(I,G,X,H,g.uv??1.4),U=new K(M,_);return U.position.set(R,T,O),U.rotation.set(g.rx||0,F,g.rz||0),U.castShadow=g.cast!==!1,U.receiveShadow=g.recv!==!1,x(U,g.group||s),g.collide&&C(R,O,I,X,F,g.pad??.04),U}function S(I,G,X,H,_,R,T,O,F={}){const g=new Re(I,G,X,H,1,!!F.open),M=new K(g,_);return M.position.set(R,T,O),M.rotation.set(F.rx||0,F.ry||0,F.rz||0),M.castShadow=F.cast!==!1,M.receiveShadow=F.recv!==!1,x(M,F.group||s),M}function z(I,G,X,H,_,R,T={}){const O=new ue(I,G,T.seg||1,T.seg||1);if(T.uvScale){const g=O.attributes.uv;for(let M=0;M<g.count;M++)g.setXY(M,g.getX(M)*I/T.uvScale,g.getY(M)*G/T.uvScale)}const F=new K(O,X);return F.position.set(H,_,R),F.rotation.set(T.rx||0,T.ry||0,T.rz||0),F.castShadow=!!T.cast,F.receiveShadow=T.recv!==!1,x(F,T.group||s),F}function nt(I,G,X,H,_,R,T,O,F,g,M,U={}){const E=new ue(I,G,1,1),L=E.attributes.uv;for(let st=0;st<L.count;st++)L.setXY(st,L.getX(st)*(I/X)+_,L.getY(st)*(G/H)+R);const J=new K(E,T);return J.position.set(O,F,g),J.rotation.y=M,J.castShadow=!1,J.receiveShadow=!0,x(J,U.group||s),J}const q=new Bn({map:t.sprites.glow,color:0,transparent:!0,opacity:.42,depthWrite:!1,polygonOffset:!0,polygonOffsetFactor:-4,polygonOffsetUnits:-4});q.userData.noShadow=!0,q.userData.noBullet=!0;const j=new Bn({map:t.sprites.glow,color:16743476,transparent:!0,opacity:.42,blending:cn,depthWrite:!1});j.userData.noShadow=!0,j.userData.noBullet=!0;const Y=new Map,W=new Map;function ht(I,G,X,H,_=.44,R=0,T=.013){const O=_.toFixed(2);if(!Y.has(O)){const g=q.clone();g.opacity=_,Y.set(O,g)}const F=new K(new ue(X*2,H*2),Y.get(O));return F.rotation.set(-Math.PI/2,0,R),F.position.set(I,T,G),F.renderOrder=2,s.add(F),F}function lt(I,G,X,H=.4,_=null){const R=H.toFixed(2)+(_||"");if(!W.has(R)){const O=j.clone();O.opacity=H,_&&(O.color=new Jt(_)),W.set(R,O)}const T=new K(new li(X,18),W.get(R));return T.rotation.x=-Math.PI/2,T.position.set(I,.016,G),T.renderOrder=3,s.add(T),T}function Dt(){const I=new K(new ue(90,210),t.dirt);I.rotation.x=-Math.PI/2,I.position.y=-.06,I.receiveShadow=!0,s.add(I);const G=as*2,X=152,H=new ue(G,X,1,1);H.rotateX(-Math.PI/2),H.translate(0,0,-6);const _=H.attributes.position,R=H.attributes.uv;for(let g=0;g<_.count;g++)R.setXY(g,_.getX(g)/2.6,_.getZ(g)/2.6);const T=new K(H,t.asphalt);T.receiveShadow=!0,s.add(T);for(const g of[-1,1]){for(let M=-72;M<58;M+=5.3){const E=.155+(u()-.5)*.012,L=new K(new Rt(Y2,E,5.265),t.concrete);an(L.geometry,2.2),L.position.set(g*$2,E/2-.005,M+5.265/2),L.rotation.y=(u()-.5)*.004,L.rotation.z=(u()-.5)*.003,L.castShadow=!1,L.receiveShadow=!0,s.add(L)}for(let M=-72;M<58;M+=2){const U=new K(new Rt(.24,.2,1.94),t.concrete);an(U.geometry,1.6),U.position.set(g*(as+.03),.1,M+.98),U.castShadow=!1,U.receiveShadow=!0,s.add(U);const E=new K(new Rt(.26,.035,1.96),t.concreteDark);an(E.geometry,1.4),E.position.set(g*(as+.03),.2,M+.98),E.castShadow=!1,E.receiveShadow=!0,s.add(E)}z(.62,130,t.patch,g*(as-.36),.006,-7,{rx:-Math.PI/2,uvScale:2.2,recv:!0})}for(const g of[-1,1])for(const M of[38,14,-12,-38,-58]){const U=g*(as-.22);y(.44,.06,.86,t.metal,U,.028,M,0,{uv:.8,cast:!1}),y(.5,.05,.94,t.concreteDark,U,.012,M,0,{uv:1,cast:!1});for(let E=0;E<4;E++)y(.36,.03,.07,t.rubber,U,.062,M-.28+E*.19,0,{cast:!1})}for(const[g,M]of[[1.9,15.5],[-2.7,-21],[4.4,-46],[-4.2,35]]){const U=new K(new ur(.42,.58,22),t.concreteDark);U.rotation.x=-Math.PI/2,U.position.set(g,.011,M),s.add(U);const E=new K(new Re(.44,.44,.03,20),t.rust);an(E.geometry,.9),E.position.set(g,.02,M),E.receiveShadow=!0,s.add(E);for(let L=0;L<5;L++)y(.58,.012,.045,t.metal,g,.037,M-.15+L*.075,0,{uv:.5,cast:!1});y(.34,.014,.34,t.patch,g,.038,M,0,{uv:.5,cast:!1})}const O=t.paint;for(let g=52;g>-60;g-=7.4)z(.15,2.9,O,0,.014,g,{rx:-Math.PI/2,uvScale:1.05,cast:!1});for(let g=0;g<9;g++){const M=-5+g*1.25;z(.44,3,O,M+(u()-.5)*.09,.015,17.4+(u()-.5)*.1,{rx:-Math.PI/2,rz:(u()-.5)*.012,uvScale:.95,cast:!1})}z(5.6,.3,O,-3.2,.014,15.1,{rx:-Math.PI/2,uvScale:.9,cast:!1});for(const g of[-1,1])for(let M=0;M<4;M++)z(.08,7.5,O,g*6.45,.013,44-M*26,{rx:-Math.PI/2,uvScale:1.2,cast:!1});{z(.3,2.1,O,3.1,.014,5.5,{rx:-Math.PI/2,uvScale:1.1,cast:!1});const U=new K(new li(.46,3),O);U.rotation.set(-Math.PI/2,0,Math.PI),U.scale.set(.66,1,1),U.position.set(3.1,.014,5.5-1.36),s.add(U)}for(let g=0;g<9;g++){const M=c(-5.6,5.6),U=c(-56,48),E=c(.3,.95),L=new K(new li(E,11),t.patch);L.scale.y=c(.5,.95),L.rotation.set(-Math.PI/2,0,c(0,3)),L.position.set(M,.0095,U),L.receiveShadow=!0,s.add(L),y(.1,.01,.1,t.rubber,M+c(-.2,.2),.011,U+c(-.2,.2),0,{cast:!1})}for(let g=0;g<17;g++){const M=c(-6.2,6.2),U=c(-58,50),E=c(.5,1.9),L=new li(E,9),J=L.attributes.position;for(let it=1;it<J.count;it++)J.setX(it,J.getX(it)*c(.72,1.3)),J.setY(it,J.getY(it)*c(.72,1.3));L.rotateX(-Math.PI/2);const st=new K(L,t.patch);st.position.set(M,.008,U),st.rotation.y=u()*6,st.receiveShadow=!0,s.add(st)}for(let g=0;g<26;g++){let M=c(-6,6),U=c(-55,50),E=u()*6.28;for(let L=0;L<5;L++){const J=c(.5,1.5);z(.09,J,t.patch,M,.009,U,{rx:-Math.PI/2,rz:0,ry:0,cast:!1}).rotation.set(-Math.PI/2,0,E),M+=Math.cos(E)*J,U+=Math.sin(E)*J,E+=c(-.7,.7)}}const F=[[-3.6,12.5,1.7,.62],[4.9,-9,1.25,.5],[.4,27.5,1,.4],[-5.2,-31,1.45,.55],[5.6,41,1.1,.45],[-1.8,-52,1.3,.5],[-13.5,2.2,.9,.45]];for(const[g,M,U,E]of F){const L=new li(U,30),J=L.attributes.position;for(let pt=1;pt<J.count;pt++){const ot=J.getX(pt),xt=J.getY(pt),ut=Math.atan2(xt,ot),It=Math.hypot(ot,xt)/U;J.setZ(pt,Math.sin(ut*5+g)*.006*It+Math.cos(ut*3+M)*.004*It),J.setY(pt,xt*E+Math.sin(ut*2)*U*.06)}L.computeVertexNormals(),L.rotateX(-Math.PI/2);const st=new K(L,t.puddle);st.position.set(g,.009,M),st.receiveShadow=!0,s.add(st);const it=new K(new ur(U*.94,U*1.14,28),t.patch);it.rotation.x=-Math.PI/2,it.scale.y=E,it.position.set(g,.006,M),it.receiveShadow=!0,s.add(it)}yt([[-4.6,26],[-4.2,22],[-3.2,18.5],[-2.2,16]],.34),yt([[-3.9,26],[-3.4,22.2],[-2.4,19]],.3),yt([[5.4,-4],[4.4,-8],[3.4,-12],[3.6,-16]],.36),yt([[6,6],[5.2,2],[4.6,-2]],.3),yt([[-1.2,-36],[-1.6,-40],[-1,-44]],.34),w(-30,-22,-80,80),w(22,30,-80,80),w(-30,30,-80,-66),w(-30,30,54,80)}function yt(I,G){const X=I.length,H=[],_=[],R=[];let T=0;for(let g=0;g<X;g++){const[M,U]=I[g],[E,L]=I[Math.min(g+1,X-1)],[J,st]=I[Math.max(g-1,0)];let it=E-J,pt=L-st;const ot=Math.hypot(it,pt)||1;it/=ot,pt/=ot;const xt=-pt*G*.5,ut=it*G*.5;if(g>0&&(T+=Math.hypot(M-I[g-1][0],U-I[g-1][1])),H.push(M-xt,.012,U-ut,M+xt,.012,U+ut),_.push(0,T/2.2,1,T/2.2),g<X-1){const It=g*2;R.push(It,It+1,It+2,It+1,It+3,It+2)}}const O=new Ye;O.setAttribute("position",new Ce(H,3)),O.setAttribute("uv",new Ce(_,2)),O.setIndex(R),O.computeVertexNormals();const F=new K(O,t.skid);F.receiveShadow=!1,s.add(F)}const dt={A:{mat:"facadeA",cols:3,floors:2,modW:3.05,floorH:3.25},B:{mat:"facadeB",cols:4,floors:2,modW:3.05,floorH:3.25},C:{mat:"facadeC",cols:3,floors:2,modW:3.05,floorH:3.25},D:{mat:"facadeD",cols:3,floors:3,modW:3.05,floorH:3.25}};function et(I){const{side:G,z0:X,z1:H,depth:_,h:R}=I,T=H-X,O=(X+H)/2,F=I.gh??(I.detail==="high"?4.35:4.1),g=I.plaster||t.plasterA,M=G<0?-(Bs+_):Bs,U=G<0?-Bs:Bs+_,E=new K(new Rt(_,R,T),g);an(E.geometry,3.6),E.position.set(G*(Bs+_/2),R/2,O),E.castShadow=!0,E.receiveShadow=!0,s.add(E),w(M,U,X,H),y(_+.22,.26,T+.2,t.concreteDark,G*(Bs+_/2),R+.06,O,0,{uv:2.2,cast:!1});const L=Math.max(2,Math.round(T/3.15));if(I.detail==="high")Lt(G,X,H,F,R,g,I);else{const J=dt[I.facade||"A"]||dt.A,st=J.cols*J.modW,it=J.floors*J.floorH,pt=u()*1.7,ot=u()*1.3,xt=R-F-.15;nt(T,xt,st,it,pt,ot+F/it,t[J.mat],G*(ce+.47),F+xt/2+.15,O,-G*Math.PI/2);const ut=G*(ce+.47);y(.62,.42,T,t.concreteDark,G*(ce+.28),F+.21,O,0,{uv:2.2}),y(.5,.3,T+.1,t.concrete,G*(ce+.34),R-.5,O,0,{uv:2.2});for(const Ht of[X+.35,H-.35])for(let le=0;le<Math.floor((R-F)/1.25);le++){const ee=le%2?.95:.65;y(.34,.34,ee,t.concrete,G*(ce+.34),F+.5+le*1.25,Ht,0,{uv:1.6})}const It=Math.max(3,Math.round(T/3.6));for(let Ht=0;Ht<=It;Ht++){const le=X+Ht/It*T;y(.42,R-F-.55,.4,t.concrete,G*(ce+.27),F+(R-F)/2,le,0,{uv:2,cast:!1}),y(.5,.14,.52,t.concreteDark,G*(ce+.24),F+.1,le,0,{uv:1.4,cast:!1})}for(let Ht=1;Ht<=2;Ht++){const le=F+Ht*((R-F)/3);y(.34,.13,T,t.concreteDark,G*(ce+.34),le,O,0,{uv:1.8,cast:!1})}for(let Ht=0;Ht<5;Ht++){const le=F+c(1.6,Math.max(2.2,R-F-2.2)),ee=O+c(-T*.44,T*.44);y(.36,.48,.7,t.metal,G*(ce+.28),le,ee,0,{uv:1,cast:!1}),Xt(G,G*(ce+.45),le-.55,ee,.62,1.2)}const Nt=I.balconies??(u()<.5?1:2);for(let Ht=0;Ht<Nt;Ht++){const le=F+3+Ht*6.6;if(le>R-2)break;const ee=O+(u()-.5)*(T-4),$t=Math.min(3.1,T*.32);y(.95,.14,$t,t.concreteDark,ut,le,ee,0,{uv:1.2}),y(.1,.34,$t,t.concrete,ut-G*.45,le+.24,ee,0,{uv:1,cast:!1});for(let Ue=0;Ue<8;Ue++)y(.045,.88,.045,t.rust,ut-G*.48,le+.5,ee-$t/2+Ue*($t/7),0,{uv:.8,cast:!1});y(.06,.06,$t,t.rust,ut-G*.48,le+.94,ee,0,{uv:.8,cast:!1}),u()<.6&&qt(ut-G*.5,le+.92,ee+c(-.6,.6),G)}u()<.6&&Et(G,O+c(-T*.3,T*.3),F+2.6,1.2,.55,v([t.signA,t.signC]))}at(G,X,H,F,L,I),gt(G,X,H,R,I),Bt(G,X,H,R,F)}function Lt(I,G,X,H,_,R,T){const O=X-G,F=(G+X)/2,g=Math.max(2,Math.round((_-H-.7)/3.3)),M=(_-H-.35)/g,U=T.bays||Math.max(2,Math.round(O/3.15)),E=O/U,L=Math.min(.7,E*.24),J=I*(ce+ns/2),st=ot=>I*(ce-ot),it=ot=>I*(ce+ot),pt=-I*Math.PI/2;for(let ot=0;ot<g;ot++){const xt=H+ot*M,ut=Math.min(1.82,M*.56),It=Math.min(1.5,Math.max(1.05,E-L-.34)),Nt=xt+M*.3,Ht=Nt-xt,le=xt+M-(Nt+ut);y(ns,Ht,O,R,J,xt+Ht/2,F,0,{uv:3.6,cast:!1}),y(ns,le,O,R,J,Nt+ut+le/2,F,0,{uv:3.6,cast:!1});for(let ee=0;ee<=U;ee++){const $t=ee===0?G+L/2:ee===U?X-L/2:G+ee*E;y(ns,ut,L,R,J,Nt+ut/2,$t,0,{uv:3.6,cast:!1})}ot>0&&(y(.66,.16,O+.02,t.concrete,I*(ce+.2),xt-.08,F,0,{uv:2.4,cast:!1}),y(.58,.06,O+.02,t.concreteDark,st(.02),xt-.2,F,0,{uv:2.4,cast:!1}),Zt(I,G,X,xt-.26,.5));for(let ee=0;ee<U;ee++){const $t=G+(ee+.5)*E,_e=(E-L-It)/2;_e>.01&&(y(ns,ut,_e,R,J,Nt+ut/2,$t-It/2-_e/2,0,{uv:3.2,cast:!1}),y(ns,ut,_e,R,J,Nt+ut/2,$t+It/2+_e/2,0,{uv:3.2,cast:!1})),k(I,$t,Nt,It,ut,ot,ee,T,{xf:st,xin:it,faceRot:pt})}}y(.78,.34,O+.14,t.concrete,I*(ce+.2),_-.55,F,0,{uv:2.2}),y(.6,.12,O+.18,t.concreteDark,st(.06),_-.34,F,0,{uv:2.2,cast:!1}),Zt(I,G+.4,X-.4,_-.95,.42)}function k(I,G,X,H,_,R,T,O,F){const{xf:g,xin:M,faceRot:U}=F,E=u()<.17,L=!E&&u()<.12,J=!E&&u()<.09,st=!E&&u()<.1,it=.46,pt=new K(new Rt(it,_,H),t.interior);if(pt.position.set(M(it/2+.02),X+_/2,G),pt.castShadow=!1,pt.receiveShadow=!1,s.add(pt),J)for(let ut=0;ut<4;ut++){const It=c(.12,.3),Nt=c(.1,.35),Ht=new K(new ue(It,Nt),t.glassBroken);Ht.position.set(M(.33),X+(ut<2?_-Nt*.6-.04:.06+Nt*.4),G+c(-H*.4,H*.4)),Ht.rotation.set(0,U,c(-.5,.5)),Ht.castShadow=!1,s.add(Ht)}else{const ut=new K(new ue(H-.08,_-.08),E?t.windowLit:L?t.windowLitDim:t.windowGlass);if(ut.position.set(M(.35),X+_/2,G),ut.rotation.y=U,ut.castShadow=!1,ut.receiveShadow=!0,s.add(ut),!E&&!L&&u()<.3){const It=new K(new ue(H*.34,_-.12),t.burlap);It.position.set(M(.39),X+_/2,G+(u()>.5?-1:1)*(H/2-H*.17)),It.rotation.y=U,It.castShadow=!1,s.add(It)}}const ot=t.metal,xt=M(.07);for(const ut of[-1,1])y(.1,_+.06,.075,ot,xt,X+_/2,G+ut*(H/2+.01),0,{uv:.7,cast:!1});if(y(.1,.075,H+.14,ot,xt,X+_+.02,G,0,{uv:.7,cast:!1}),y(.09,.07,H+.14,ot,xt,X-.01,G,0,{uv:.7,cast:!1}),y(.075,_,.05,ot,M(.1),X+_/2,G,0,{uv:.7,cast:!1}),_>1.3&&y(.07,.045,H,ot,M(.11),X+_*.62,G,0,{uv:.7,cast:!1}),R<1&&u()<.4){for(let ut=0;ut<4;ut++)y(.03,_-.05,.03,t.rust,g(.05),X+_/2,G-H*.36+ut*H*.24,0,{uv:.4,cast:!1});y(.035,.035,H*.9,t.rust,g(.05),X+_*.55,G,0,{uv:.4,cast:!1})}if(y(.24,.11,H+.3,t.concrete,g(.09),X-.055,G,0,{uv:1.1}),y(.2,.045,H+.34,t.concreteDark,g(.11),X-.13,G,0,{uv:.9,cast:!1}),Xt(I,g(.03),X-.2,G,H*1.15,.9),st)for(const ut of[-1,1])y(.05,_*.96,H*.46,t.wood,g(.04),X+_/2,G+ut*H*.235,0,{uv:.9,cast:!1});if(u()<.32&&X>2.6){const ut=G+(u()>.5?1:-1)*H*.32,It=X-.44;y(.38,.5,.74,t.metal,g(.19),It,ut,0,{uv:1}),y(.44,.05,.8,t.metalTan,g(.19),It+.27,ut,0,{uv:.8,cast:!1}),y(.06,.06,.86,t.rust,g(.02),It-.3,ut,0,{uv:.6,cast:!1}),Xt(I,g(.02),It-.5,ut,.55,1.3),S(.02,.02,.4,4,t.rubber,g(.24),It-.5,ut+.3,{cast:!1})}if(R>=1&&u()<.3){const ut=Math.min(2.4,H+.6);y(.95,.12,ut,t.concreteDark,g(.5),X-.16,G,0,{uv:1.2});for(const It of[-1,1]){const Nt=new K(new Rt(.62,.06,.06),t.rust);Nt.position.set(g(.32),X-.36,G+It*(ut/2-.25)),Nt.rotation.z=I*.75,s.add(Nt)}y(.12,.5,ut,t.concrete,g(.96),X-.02,G,0,{uv:1,cast:!1});for(let It=0;It<9;It++)y(.04,.86,.04,t.rust,g(.98),X+.5,G-ut/2+It*(ut/8),0,{uv:.6,cast:!1});y(.06,.06,ut,t.rust,g(.98),X+.94,G,0,{uv:.6,cast:!1}),u()<.6&&qt(g(.96),X+.95,G+c(-.7,.7),I),u()<.4&&(y(.42,.06,.42,t.polymerTan,g(.55),X+.28,G+c(-.5,.5),0,{uv:.6}),y(.42,.42,.05,t.polymerTan,g(.55),X+.5,G+c(-.5,.5),0,{uv:.6}))}}function at(I,G,X,H,_,R){const T=X-G,O=T/_,F=U=>I*(ce-U),g=U=>I*(ce+U),M=-I*Math.PI/2;y(.66,.56,T,t.concreteDark,I*(ce+.2),.28,G+T/2,0,{uv:1.8,cast:!1}),y(.74,.5,T+.04,t.concrete,I*(ce+.19),H-.25,G+T/2,0,{uv:2.2}),y(.72,.07,T+.06,t.concreteDark,F(.03),H-.53,G+T/2,0,{uv:2.2,cast:!1});for(let U=0;U<_;U++){const E=G+(U+.5)*O,L=O-.62;let J=R.ground||"wall";if(J==="shop"&&_>2&&U===_-1&&(J="door"),J==="shutter"&&U===0&&(J="cafe"),J==="door"&&U!==_-1&&(J=u()<.5?"shutter":"wall"),J==="shutter"&&u()<.34&&(J="cafe"),J==="wall"&&u()<.3&&(J="cafe"),R.detail==="ruin"&&(J="ruin"),J==="shop"){const st=H-.95,it=new K(new Rt(.6,st,L),t.interior);it.position.set(g(.3),st/2+.3,E),it.castShadow=!1,it.receiveShadow=!1,s.add(it),y(.72,.55,L+.1,t.concreteDark,g(.3),.28,E,0,{uv:1.8});for(const ot of[-1,1])y(.18,st,.1,t.metal,g(.3),.3+st/2,E+ot*(L/2-.05),0,{uv:.9});if(y(.18,.1,L,t.metal,g(.3),.3+st-.05,E,0,{uv:.9}),u()<.55){const ot=new K(new ue(L-.24,st-.24),t.windowGlass);if(ot.position.set(g(.44),.3+st/2,E),ot.rotation.y=M,ot.castShadow=!1,ot.receiveShadow=!0,s.add(ot),u()<.45)for(let xt=0;xt<5;xt++){const ut=new K(new ue(c(.15,.4),c(.12,.35)),t.glassBroken);ut.position.set(g(.42),c(.5,.3+st),E+c(-L*.42,L*.42)),ut.rotation.set(0,M,c(-.6,.6)),ut.castShadow=!1,s.add(ut)}}else{y(.36,.06,L-.5,t.wood,g(.34),1.25,E,0,{uv:1,cast:!1}),y(.36,.06,L-.5,t.wood,g(.34),1.95,E,0,{uv:1,cast:!1}),y(.3,.03,L-.6,t.wood,g(.36),2.6,E,0,{uv:1,cast:!1});const ot=new K(new ue(L*.55,.9),t.windowLitDim);if(ot.position.set(g(.55),2.35,E),ot.rotation.y=M,s.add(ot),y(.5,.9,L*.5,t.wood,g(.3),.75,E+L*.18,0,{uv:1.2}),lt(I*(ce-1),E,1.5,.18),d<3&&u()<.3){d++;const xt=new us(16752725,3.2,6.5,2);xt.position.set(I*(ce-.7),2.3,E),r.add(xt)}}if(u()<.6){y(.34,.5,L+.16,t.shop,F(.05),H-.72,E,0,{uv:1.6});const ot=c(.5,1.8);y(.06,ot,L,t.shop,F(.1),H-.95-ot/2,E,0,{uv:1.2})}if(u()<.55){const ot=u()<.62?t.awning:t.burlap,xt=c(.95,1.25),ut=c(.14,.22),It=y(xt,.06,L+.35,ot,F(xt*.52),H-.72,E,0,{uv:.95,rz:I*ut,cast:!0});It.position.y=H-.78,y(.05,c(.18,.28),L+.35,t.burlap,F(xt-.04),H-1.02,E,0,{uv:.8,cast:!1}),y(.05,.05,L+.35,t.rust,F(xt-.04),H-.86,E,0,{uv:.5,cast:!1});for(const Nt of[-1,1]){y(xt*.85,.05,.05,t.rust,F(xt*.45),H-.9,E+Nt*(L/2-.25),0,{uv:.5,cast:!1});const Ht=new K(new Rt(xt*1,.04,.04),t.rust);Ht.position.set(F(xt*.46),H-1.02,E+Nt*(L/2-.28)),Ht.rotation.z=I*.75,s.add(Ht)}Xt(I,F(.05),H-1.25,E,L*.9,.55)}const pt=v([t.signA,t.signB,t.signC]);Mt(I,E,H-.05,Math.min(L,3.4),.8,pt,.12),y(.2,.06,L+.24,t.metalTan,F(.13),H+.4,E,0,{uv:1.2,cast:!1}),Xt(I,F(.06),H+.36,E,L*.9,.5),y(.9,.14,L+.4,t.concrete,F(.35),.07,E,0,{uv:1.4,cast:!1}),u()<.5&&zt(E+c(-1,1),I)}else if(J==="shutter"){y(.1,2.95,L,t.shop,F(.09),1.55,E,0,{uv:1.9}),y(.26,.36,L+.2,t.shop,F(.08),H-.78,E,0,{uv:1.6});for(const it of[-1,1])y(.16,3.1,.13,t.rust,F(.06),1.55,E+it*(L/2+.06),0,{uv:.9,cast:!1});Mt(I,E,H-.05,Math.min(L,3.2),.82,v([t.signB,t.signC]),.12),u()<.4&&(y(1.05,.06,L+.25,t.awning,F(.5),H-1.42,E,0,{uv:.95,rz:I*.17}),y(.05,.2,L+.25,t.burlap,F(1),H-1.62,E,0,{uv:.8,cast:!1}));const st=new K(new ue(L*.8,1.4),t.graffiti);st.position.set(F(.05),1.35,E),st.rotation.set(0,M,c(-.06,.06)),s.add(st),u()<.6&&zt(E,I)}else if(J==="cafe"){const it=new K(new Rt(.55,2.75,L),t.interior);it.position.set(g(.29),2.75/2+.2,E),it.castShadow=!1,s.add(it),y(.5,.5,L+.1,t.concreteDark,g(.28),.25,E,0,{uv:1.6});const pt=new K(new ue(L*.66,1.15),t.windowLitDim);pt.position.set(g(.53),1.95,E),pt.rotation.y=M,s.add(pt),y(.42,.95,L*.62,t.wood,g(.3),.78,E,0,{uv:1.1}),y(.36,.06,L*.62,t.wood,g(.3),1.28,E,0,{uv:1,cast:!1});for(const ot of[-1,1])y(.2,2.75,.14,t.metal,g(.27),2.75/2+.2,E+ot*(L/2-.07),0,{uv:.9});y(.6,.12,L+.1,t.metalTan,g(.24),2.75+.16,E,0,{uv:.9,cast:!1}),y(1.1,.06,L+.3,t.awning,F(.5),2.75+.05,E,0,{uv:.9,rz:I*.2}),y(.05,.22,L+.3,t.burlap,F(1.02),2.75-.14,E,0,{uv:.8,cast:!1});for(const ot of[-1,1])y(.95,.045,.045,t.rust,F(.5),2.75-.12,E+ot*(L/2-.2),0,{uv:.5,cast:!1});if(Mt(I,E,2.75+.62,Math.min(L,2.8),.62,v([t.signA,t.signC]),.1),lt(I*(ce-1.1),E,1.6,.2),d<4&&u()<.5){d++;const ot=new us(16752725,3.4,7,2);ot.position.set(I*(ce-.85),2.4,E),r.add(ot)}u()<.7&&(ct(E*0+I*(ce-1.35),E-L*.32,.55,u(),.16),ct(I*(ce-1.55),E+L*.28,.48,u(),.14)),u()<.6&&zt(E+L*.42,I,.9)}else if(J==="door"){const it=new K(new Rt(.34,2.5,1.5),t.interior);it.position.set(g(.17),2.5/2+.3,E),it.castShadow=!1,s.add(it),y(.1,2.25,1.2,t.metal,g(.28),1.42,E,0,{uv:1});for(let pt=0;pt<4;pt++)y(.11,.28,1.22,t.metalTan,g(.28),.4+pt*.55,E,0,{uv:.8,cast:!1});y(.14,.1,1.36,t.concreteDark,g(.24),2.58,E,0,{uv:.8,cast:!1}),y(1.05,.13,1.85,t.concrete,F(.28),.065,E,0,{uv:1.2,cast:!1}),y(.55,.13,1.5,t.concrete,F(.55),.19,E,0,{uv:1,cast:!1}),y(.55,.12,1.6,t.concreteDark,F(.28),.28,E,0,{uv:1,cast:!1}),y(.95,.09,1.5,t.metal,F(.38),3.05,E,0,{uv:1,rz:I*.12}),y(.24,.16,.14,t.metalTan,F(.14),2.95,E+.95,0,{uv:.7}),y(.34,.46,.22,t.metal,F(.1),1.5,E-1.05,0,{uv:.8}),S(.03,.03,3,5,t.rubber,F(.08),1.5,E-1.2,{cast:!1}),Xt(I,F(.05),2.6,E,1.5,.7),u()<.5&&kt(E-1.4,I,2,2)}else if(J==="ruin"){y(.35,3.6,L,t.brick,I*(ce+.32),1.8,E,0,{uv:1.6});for(let st=0;st<5;st++)y(.4,c(.25,.8),c(.3,.9),t.concreteDark,I*(ce+.28),c(.2,2.3),E+c(-L*.4,L*.4),c(-.3,.3),{uv:1.2});te(E,I*9.3,1.6,18)}else{for(let it=0;it<3;it++){const pt=new K(new ue(c(.42,.7),c(.55,.9)),it===1?t.paper:v([t.signC,t.signA,t.signB]));pt.position.set(F(.04),c(1.5,2.3),E+c(-1.1,1.1)),pt.rotation.set(0,M,c(-.08,.08)),pt.castShadow=!1,s.add(pt)}for(let it=0;it<2;it++){const pt=new K(new ue(c(.2,.34),c(.26,.4)),t.paper);pt.position.set(F(.03),c(.7,1.1),E+c(-1.2,1.2)),pt.rotation.set(0,M,c(-.25,.25)),s.add(pt)}const st=new K(new ue(L*.7,1.1),t.graffiti);st.position.set(F(.03),1.15,E),st.rotation.set(0,M,c(-.1,.1)),s.add(st),S(.05,.05,3.2,6,t.rust,F(.06),1.6,E+L*.35,{cast:!1}),Xt(I,F(.02),1,E,L*.8,1.6),u()<.5&&St(I*9.3,E+c(-1,1),3)}}if(u()<.5){const U=G+T*c(.25,.75);Et(I,U,H+1.35,1.3,.6,v([t.signA,t.signB,t.signC]))}}function gt(I,G,X,H,_){const R=X-G,T=(G+X)/2,O=.36,F=_.detail==="ruin",g=Math.max(2,Math.round(R/2.6));for(let M=0;M<g;M++){const U=G+(M+.5)*(R/g);if(F&&u()<.55)continue;const L=.82+(u()-.5)*.22;y(O,L,R/g-.03,t.concreteDark,I*(ce+.26),H+L/2,U,0,{uv:1.8}),y(O+.16,.1,R/g-.03,t.concrete,I*(ce+.26),H+L+.04,U,0,{uv:1.4,cast:!1})}for(const M of[G+.18,X-.18])y(2.4,.6,O,t.concreteDark,I*(ce+1.3),H+.3,M,0,{uv:1.6,cast:!1});if(u()<.8&&!F){const M=I*(ce+c(2.4,3.6)),U=T+c(-R*.25,R*.25);if(y(2.3,2.35,2.6,t.plasterB,M,H+1.17,U,c(-.1,.1),{uv:3}),y(2.5,.14,2.8,t.concreteDark,M,H+2.4,U,0,{uv:1.6,cast:!1}),y(.08,1.7,.85,t.metal,M-I*1.17,H+.85,U,0,{uv:.9,cast:!1}),y(.1,1.1,.7,t.metalTan,M+I*.2,H+1.5,U+1.31,0,{uv:.8,cast:!1}),u()<.6){const E=I*(ce+c(5.2,6.6)),L=T+c(-R*.3,R*.3);S(.82,.86,1.55,12,t.metal,E,H+.95,L),S(.05,.92,.5,12,t.metalTan,E,H+1.95,L);for(let J=0;J<4;J++){const st=J/4*Math.PI*2+.4;y(.09,.5,.09,t.rust,E+Math.cos(st)*.6,H+.25,L+Math.sin(st)*.6,0,{uv:.6,cast:!1})}S(.03,.03,2.2,4,t.rust,E+.4,H+.6,L,{cast:!1})}}for(let M=0;M<2;M++){const U=I*(ce+c(1.4,4.5)),E=T+c(-R*.35,R*.35);y(.8,.72,1.05,t.metal,U,H+.36,E,c(0,1.5),{uv:1.2});const L=new K(new Rn(.26,.035,5,12),t.rust);L.rotation.y=Math.PI/2,L.position.set(U+I*.42,H+.38,E),s.add(L)}if(u()<.7){const M=I*(ce+c(1.8,3.5)),U=T+c(-R*.3,R*.3),E=new K(new Ci(.55,12,6,0,Math.PI*2,0,Math.PI*.42),t.metalTan);E.rotation.set(Math.PI*.62,c(0,6),0),E.position.set(M,H+.85,U),E.castShadow=!0,s.add(E),S(.04,.05,1,5,t.rust,M,H+.5,U,{cast:!1})}if(S(.025,.04,c(2.5,4.5),5,t.metal,I*(ce+c(2,4)),H+1.2,T+c(-R*.3,R*.3),{cast:!1}),!F&&u()<.55){const M=T+c(-R*.25,R*.25),U=I*(ce+1.1),E=I*(ce+4.2),L=H+1.9;ne(new N(U,L,M),new N(E,L-.15,M+c(-1,1)),.25,.012);for(let J=0;J<3;J++)qt((U+E)/2+c(-1.2,1.2),L-.04,M+c(-.3,.3),I,!0)}if(!F&&u()<.5)for(let M=0;M<4;M++)rt(.62,.24,.34,.09,t.sandbag,I*(ce+.55),H+.98+M%2*.2,T+c(-R*.3,R*.3),c(-.2,.2),{uv:.8});if(F){for(let M=0;M<7;M++){const U=c(1,3.4);S(.018,.018,U,4,t.rust,I*(ce-.3+c(-.4,.4)),H-U/2+.1,T+c(-R*.45,R*.45),{rx:c(-.3,.3),rz:c(-.35,.35),cast:!1})}for(let M=0;M<4;M++)y(c(2,4),.22,c(1.4,2.6),t.concreteDark,I*(ce+c(1.5,4)),H+.2+M*0,T+c(-R*.4,R*.4),c(-.4,.4),{uv:1.8})}}function Mt(I,G,X,H,_,R,T=.12){y(.1,_+.08,H+.1,t.metalTan,I*(ce-T+.02),X,G,0,{uv:.9,cast:!1});const O=new K(new ue(H,_),R);return O.position.set(I*(ce-T-.04),X,G),O.rotation.y=-I*Math.PI/2,O.castShadow=!1,s.add(O),O}function Et(I,G,X,H,_,R){const T=I*(ce-H/2-.15);y(H,_+.07,.09,t.metalTan,T,X,G,0,{uv:.9,cast:!0});for(const O of[-.052,.052]){const F=new K(new ue(H-.08,_-.04),R);F.position.set(T,X,G+O),O<0&&(F.rotation.y=Math.PI),s.add(F)}y(H*.7,.05,.05,t.rust,I*(ce-H*.35-.05),X+_/2+.06,G,0,{uv:.5,cast:!1}),y(.05,.34,.05,t.rust,I*(ce-.05),X+_/2-.1,G,0,{uv:.5,cast:!1})}function Bt(I,G,X,H,_,R){const T=X-G,O=F=>I*(ce-F);for(const F of[G+.22,X-.22]){S(.046,.046,H-.4,6,t.rust,O(.07),(H-.4)/2,F,{cast:!1}),S(.06,.052,.24,6,t.rust,O(.075),.72,F,{cast:!1});for(let g=0;g<Math.floor(H/4);g++)y(.07,.06,.2,t.metal,O(.06),2.5+g*4.2,F,0,{uv:.5,cast:!1})}S(.045,.045,T-.6,6,t.rust,O(.09),_+.55,G+T/2,{rz:Math.PI/2,cast:!1});for(let F=0;F<Math.floor(T/5);F++)S(.028,.028,H*.55,5,t.rubber,O(.07),H*.5,G+1.4+F*4.6,{cast:!1});for(let F=0;F<2;F++){const g=G+c(1.5,T-1.5);y(.2,.3,.24,t.metalTan,O(.1),_+c(.8,2.2),g,0,{uv:.6,cast:!1})}Zt(I,G+.3,X-.3,.55,.75);for(let F=0;F<3;F++)Xt(I,O(.02),c(2,H-2),G+c(1,T-1),c(.7,1.6),c(1.5,3.5));if(u()<.5){const F=G+T*c(.2,.8);y(.5,.06,.06,t.rust,O(.25),_+.9,F,0,{uv:.5,cast:!1}),y(.3,.14,.2,t.metalTan,O(.5),_+.83,F,0,{uv:.6})}}function Zt(I,G,X,H,_){const R=X-G;if(R<.4)return;const T=new K(new ue(R,_),t.grime);T.position.set(I*(ce-.012),H+_/2,G+R/2),T.rotation.y=-I*Math.PI/2,T.castShadow=!1,s.add(T)}function Xt(I,G,X,H,_,R){const T=new K(new ue(_,R),t.grime);T.position.set(G,X,H),T.rotation.y=-I*Math.PI/2,T.castShadow=!1,s.add(T)}function ie(){y(13,.12,6,t.concreteDark,-16.3,.06,3,0,{uv:2,cast:!1}),y(.32,.06,5.6,t.patch,-16.3,.13,3,0,{uv:1,cast:!1});for(let g=0;g<7;g++)y(.26,.03,.05,t.metal,-16.3,.17,.5+g*.8,0,{cast:!1});const H=new K(new Rt(.5,4.2,6),t.plasterB);an(H.geometry,3),H.position.set(-22.6,2.1,3),H.castShadow=!0,H.receiveShadow=!0,s.add(H),b(-22.6,3,.5,6),y(.08,2.4,1.4,t.metal,-22.6+.3,1.25,2.1,0,{uv:1});const _=new K(new ue(1.1,1.7),t.windowLitDim);_.position.set(-22.6+.34,1.35,4.4),_.rotation.y=Math.PI/2,s.add(_),lt(-22.6+.9,4.4,1.6,.22);const R=new us(16752725,2.6,7,2);R.position.set(-22.6+.8,1.8,4.4),r.add(R),y(.12,2,1.25,t.metal,-22.6+.31,1.25,4.4,0,{uv:.9,cast:!1});for(let g=0;g<3;g++)y(1.6,.16,1.1,t.concrete,-21.2+g*.2,.08+g*.15,4.6,0,{uv:1,cast:!1});for(let g=0;g<4;g++){const M=new K(new ue(c(1.2,2.2),c(1,1.8)),t.graffiti),U=g%2?0+.03:6-.03;M.position.set(c(-21,-11),c(.8,2.5),U),M.rotation.set(0,g%2?0:Math.PI,c(-.1,.1)),s.add(M)}S(.07,.07,12,6,t.rust,-12.5,3.2,0+.14,{rx:Math.PI/2,cast:!1}),S(.05,.05,12,6,t.rubber,-13,4.6,6-.14,{rx:Math.PI/2,cast:!1});for(let g=0;g<3;g++)y(.5,.42,.62,t.metal,-12-g*3.2,5.4,6-.35,0,{uv:1,cast:!1}),Xt(-1,-12-g*3.2,4.6,6-.4,.7,1.6);for(const g of[.18,.86])S(.028,.028,3.1,5,t.rust,-11.65,4.1,0+g,{cast:!1});for(let g=0;g<9;g++)y(.05,.035,.7,t.rust,-11.65,2.62+g*.33,0+.52,0,{uv:.4,cast:!1});const T=0+.07;y(1,2,.1,t.metal,-12.2,1.15,T,0,{uv:.9}),y(1.35,.9,.06,t.windowLitDim,-12.2,1.75,T+.02,0,{uv:.6,cast:!1}),y(1.5,.06,.06,t.metal,-12.2,2.22,T+.03,0,{uv:.5,cast:!1}),y(2.2,.07,1.05,t.awning,-12.2,2.72,T+.5,0,{uv:.9,rx:.17}),y(2.2,.2,.05,t.burlap,-12.2,2.52,T+1,0,{uv:.8,cast:!1}),y(1.9,.5,.08,v([t.signA,t.signC]),-12.2,2.95,T+.02,0,{uv:.8}),y(1.7,.12,.7,t.concrete,-12.2,.07,T+.4,0,{uv:1,cast:!1}),lt(-12,1.1,1.5,.2),y(.42,.05,.05,t.rust,-12.2,3.35,T+.3,0,{uv:.5,cast:!1}),y(.3,.16,.22,t.metalTan,-12.2,3.2,T+.52,0,{uv:.6});const O=new K(new ue(.2,.13),t.windowLit);O.rotation.x=Math.PI/2,O.position.set(-12.2,3.11,T+.52),s.add(O),lt(-12.2,T+.9,1.6,.24),y(.45,.06,.06,t.rust,-11.9,3.25,T+.25,0,{uv:.5,cast:!1}),y(.26,.12,.18,t.metalTan,-11.9,3.16,T+.5,0,{uv:.6}),y(.7,.55,.12,t.metal,-15.6,2.3,T+.1,0,{uv:.8,cast:!1});for(let g=0;g<3;g++){const M=new K(new ue(c(.4,.62),c(.5,.8)),g===1?t.paper:v([t.signC,t.signB]));M.position.set(-10.9-g*.7,c(1.5,2.2),T+.04),M.rotation.set(0,0,c(-.06,.06)),s.add(M)}bt(-10.7,1.15,1.62),mt(-12.9,.9,.7),wt(-19.9,1.1),zt(1.2,-1,1.1),zt(4.9,-1,1.2),ne(new N(-11.5,4.15,2.2),new N(-20.6,3.9,3.3),.32,.014,t.burlap);for(let g=0;g<4;g++){const M=2.4+g*.28;qt(-13.2-g*1.7,3.82,M,-1,!0)}bt(-15.2,4.9,1.55),zt(2.7,-1,1.4),mt(-17.6,1.4,1.2),ct(-18.8,2.4,.9,.4),ct(-19.4,3.1,.7,1.1,.75),Ot(-12.8,1.2,3),te(-18.6,5.2,1.5,22),St(-20.5,1.4,3),St(-11.5,4.6,3),re([[-14.2,2.2,1.1,.55],[-19.4,4.6,.8,.5]]),y(.1,2,1,t.metal,-12.4,1.1,0+.06,0,{uv:.9,cast:!1}),y(.2,.12,1.2,t.concreteDark,-12.4,2.16,0+.06,0,{uv:.8,cast:!1});for(const[g,M]of[[-14.2,4.6],[-16.4,7.4],[-18.6,4.7]]){const U=new K(new Rt(.34,1.2,1),t.interior);U.position.set(g,M,0-.17),s.add(U);const E=new K(new ue(.92,1.1),t.windowGlass);E.position.set(g,M,0-.05),s.add(E);for(const L of[-.4,0,.4])y(.035,1.2,.035,t.rust,g+L,M,0+.03,0,{uv:.4,cast:!1});y(1.2,.09,.2,t.concrete,g,M-.66,0+.05,0,{uv:.8,cast:!1}),y(1.2,.1,.18,t.concreteDark,g,M+.68,0+.05,0,{uv:.8,cast:!1}),Xt(-1,g,M-1,0+.005,1.1,.9)}const F=new K(new ue(2.6,1.5),t.signC);F.position.set(-15.6,2.5,0+.035),s.add(F),S(.045,.045,8.5,6,t.rust,-14.8,.9,0+.09,{rz:Math.PI/2,cast:!1});for(const g of[-12.8,-17.8])S(.045,.045,2.6,6,t.rust,g,1.3,0+.09,{cast:!1})}function $(){for(const _ of[-1,1]){const R=_*10.5,T=9,O=new K(new Rt(T,15,10),t.plasterB);an(O.geometry,3.4),O.position.set(R,15/2,-70),O.castShadow=!0,O.receiveShadow=!0,s.add(O),b(R,-70,T,10);for(const F of[-1,1])y(T+.2,.8,.34,t.concreteDark,R,15+.4,-70+F*4.8,0,{uv:1.6});nt(T-.2,15-1.2,9.15,9.75,u()*1.4,.1,t.facadeD,R,15/2+.3,-70+5.02,0);for(const F of[4.2,7.6,11.2])for(let g=0;g<2;g++)y(1.35,.55,.36,t.interior,R-2.4+g*4.8,F,-70+5.16,0,{uv:.6,cast:!1}),y(1.5,.12,.5,t.concreteDark,R-2.4+g*4.8,F-.34,-70+5.2,0,{uv:.6,cast:!1});for(let F=0;F<7;F++)rt(.62,.25,.34,.09,t.sandbag,R-2.4+F%4*.64,15+.92+Math.floor(F/4)*.22,-70+4.55,u()*.2,{uv:.8})}const X=new K(new Rt(12.4,1.3,3.6),t.concreteDark);an(X.geometry,2.6),X.position.set(0,8.4,-70),X.castShadow=!0,X.receiveShadow=!0,s.add(X),b(0,-70,12.4,3.6);for(const _ of[-1.55,1.55])y(12.4,.95,.3,t.concreteDark,0,9.5,-70+_,0,{uv:1.4}),y(12.4,.1,.4,t.concrete,0,10.02,-70+_,0,{uv:1.4,cast:!1});for(const _ of[-1,1])y(.8,5.2,.8,t.concrete,_*5.4,2.6,-70+1.7,0,{uv:1.2});y(11.6,.85,.9,t.concrete,0,5.35,-70+1.7,0,{uv:1.2});for(const _ of[-1,1]){const T=new xe;for(let F=0;F<7;F++){const g=new K(new Re(.042,.042,3.9,5),t.rust);g.position.set(-_*(.25+F*(4-.5)/6),2.1,0),g.castShadow=!1,T.add(g)}for(const F of[1.15,3.55]){const g=new K(new Rt(4,.1,.1),t.rust);g.position.set(-_*4/2,F,0),T.add(g)}const O=new K(new Rt(4*1.05,.07,.07),t.rust);O.position.set(-_*4/2,2.35,0),O.rotation.z=_*.38,T.add(O),T.position.set(_*5.2,0,-70+1.7),T.rotation.y=_*(_<0?1.15:.55),s.add(T)}for(const[_,R,T,O]of[[3.6,3.6,1.5,.7],[-4.2,3.6,1.2,.62]]){const F=new K(new ue(T,O),t.signB);F.position.set(_,R,-70+2.35),F.castShadow=!1,s.add(F),y(T+.08,O+.06,.05,t.metalTan,_,R,-70+2.4,0,{uv:.7,cast:!1})}for(let _=0;_<4;_++)rt(.62,.25,.34,.09,t.sandbag,-5+_%2*.62,.13+Math.floor(_/2)*.24,-70+3.2,u()*.2,{uv:.8});for(let _=0;_<9;_++){const R=1.2+u()*3.2,T=new K(new Re(.019,.019,R,4),t.rust);T.position.set(-4.8+_*1.2,7.7-R/2,-70+2.1),T.rotation.z=(u()-.5)*.3,T.castShadow=!1,s.add(T)}y(2,2.6,2.2,t.plasterA,4.6,1.3,-61.6,.12,{uv:2.2,collide:!0}),y(2.3,.14,2.5,t.concreteDark,4.6,2.68,-61.6,.12,{uv:1.4,cast:!1}),y(1,.9,.06,t.windowGlass,4.1,1.85,-60.45,.12,{uv:1,cast:!1}),y(.1,1,1,t.windowGlass,3.62,1.85,-61.6,0,{uv:1,cast:!1}),y(.16,.1,.16,t.rust,-1.6,.65,-59.5,0,{uv:.5}),y(.1,.1,4,t.metalTan,-1.6,1.05,-57.6,0,{uv:.8,rz:-.06});for(let _=0;_<5;_++)y(.12,.2,.4,t.rubber,-1.6,1.12,-56.2-_*.8,0,{uv:.5,cast:!1});y(.12,1.8,1.1,t.signB,-4.2,1.7,-58.4,0,{uv:.9}),y(.1,.1,1.3,t.rust,-4.2,1,-58.4,0,{uv:.5,rx:Math.PI/2});for(const[_,R,T]of[[-3.2,-64.5,.2],[2.2,-64.2,-.14],[-7.6,-65.5,.5]])B(_,R,T);for(const[_,R]of[[-3.6,-62.4],[3.4,-62.8],[-.6,-63.6]]){for(let T=0;T<3;T++){const O=new K(new Rt(.09,.09,1.5),t.rust);O.position.set(_,.55,R),O.rotation.set(.75,T*Math.PI/3,.75*(T%2?-1:1)),O.castShadow=!0,s.add(O)}b(_,R,1.2,1.2,.05)}y(.1,.1,.35,t.metal,0,4.6,-66.4,0,{uv:.5,cast:!1});const H=new K(new ue(.34,.22),t.windowLit);H.position.set(0,4.45,-66.4),s.add(H),lt(0,-64.6,2.2,.2),te(0,-64.5,3.4,34),te(-7,-63.5,2.6,20);for(let _=0;_<3;_++){const R=new K(new ue(3.6,2.2),t.burlap);R.position.set(-4+_*4,8.9-_*.1,-70+2.15),R.rotation.set(c(-.1,.1),0,c(-.08,.08)),s.add(R)}wt(-4.4,-66.5,{fire:!0,noLight:!0}),wt(4,-67.2,{fire:!0,noLight:!0})}function wt(I,G,{fire:X=!1,y:H=0,noLight:_=!1}={}){const R=new xe,T=new K(new Re(.37,.39,.94,14,1),t.rust);T.position.y=.47,T.castShadow=!0,T.receiveShadow=!0,R.add(T);for(const O of[.2,.74]){const F=new K(new Rn(.385,.028,6,16),t.metal);F.rotation.x=Math.PI/2,F.position.y=O,F.castShadow=!1,R.add(F)}return S(.39,.39,.05,14,t.metal,0,.95,0,{group:R,cast:!1}),R.position.set(I,H,G),R.rotation.y=u()*6,s.add(R),b(I,G,.85,.85,.05),ht(I,G,.62,.62,.42),X&&At(I,H+.95,G,{light:!_}),R}function At(I,G,X,H={}){const _=H.light!==!1;let R=null;_&&(R=new us(16742956,14,15,2),R.position.set(I,G+.3,X),R.castShadow=!1,r.add(R));const T=new K(new li(.3,14),new Bn({color:16738846,toneMapped:!1}));T.rotation.x=-Math.PI/2,T.position.set(I,G+.01,X),r.add(T);const O=[];for(let g=0;g<5;g++){const M=new ki(new Ei({map:t.sprites.glow,color:new Jt(16747578),transparent:!0,blending:cn,depthWrite:!1,opacity:.55})),U=.55+u()*.5;M.scale.set(U,U*1.4,1),M.position.set(I+(u()-.5)*.3,G+.1+u()*.5,X+(u()-.5)*.3),r.add(M),O.push({sp:M,phase:u()*10,s:U})}const F=[];for(let g=0;g<6;g++){const M=new ki(new Ei({map:t.sprites.smoke,color:new Jt(3814444),transparent:!0,depthWrite:!1,opacity:.18}));M.scale.setScalar(1.7),M.position.set(I,G+.5,X),r.add(M),F.push({sp:M,t:u(),seed:u()*10})}m.push({light:R,sprites:O,smoke:F,base:new N(I,G,X),intensity:14,glow:T}),lt(I,X,1.9,.22)}function ct(I,G,X=1.1,H=0,_=0){const R=new xe,T=new K(D(X,X*.84,X*.92,.03,1.1),t.wood);T.position.y=X*.42,T.castShadow=!0,T.receiveShadow=!0,R.add(T);for(const O of[-1,1])for(let F=0;F<3;F++){const g=new K(new Rt(X*1.01,X*.14,.05),t.wood);g.position.set(0,X*(.16+F*.24),O*X*.46),g.castShadow=!1,R.add(g)}return R.position.set(I,_,G),R.rotation.y=H,s.add(R),C(I,G,X,X*.92,H,.03),ht(I,G,X*.62,X*.58,.38,-H),R}function Ct(I,G,X=3){ct(I,G,1.15,.2),X>1&&ct(I+1.12,G-.18,.95,-.3),X>2&&ct(I+.52,G-.03,.9,.7,.97),X>3&&ct(I-.24,G-1.05,.82,1.4)}function jt(I,G,X=0,H=4,_=6,R=t.burlap){const T=new xe,O=D(.62,.25,.34,.1,.8);for(let F=0;F<H;F++)for(let g=0;g<_;g++){const M=new K(O,u()<.4?t.burlap:R),U=F%2*.31,E=u()<.12?.72:1;M.position.set(-_*.31+g*.62+U,.125+F*.235,(u()-.5)*.08),M.rotation.set((u()-.5)*.09,(u()-.5)*.2,(u()-.5)*.09),M.scale.set(1,E,1+(u()-.5)*.08),M.castShadow=!0,M.receiveShadow=!0,T.add(M)}return T.position.set(I,0,G),T.rotation.y=X,s.add(T),C(I,G,_*.62+.1,.6,X,.1),ht(I,G,_*.33,.42,.4,-X),T}function kt(I,G,X,H,_){jt(I,G+-.1,Math.PI-.02,X,H,t.sandbag)}function B(I,G,X=0){const H=new xe,_=[[.68,.26,.13,t.concreteDark],[.56,.26,.39,t.concrete],[.42,.24,.64,t.concrete],[.3,.24,.88,t.concrete]];for(const[F,g,M,U]of _){const E=new K(new Rt(F,g,2.5),U);an(E.geometry,1.15),E.position.y=M,E.castShadow=!0,E.receiveShadow=!0,H.add(E)}const R=new K(new Rt(.7,.1,2.52),t.patch);R.position.y=.05,H.add(R);const T=new K(new Rt(.14,.16,.4),t.concreteDark);T.position.set(.16,1,c(-.9,.9)),T.rotation.z=.5,T.rotation.y=.3,H.add(T);const O=new K(new Re(.015,.015,.5,4),t.rust);return O.position.set(.02,1.12,.9),O.rotation.z=.8,H.add(O),H.position.set(I,0,G),H.rotation.y=X,s.add(H),C(I,G,.72,2.5,X,.05),ht(I,G,.52,1.32,.42,-X),H}function P(I,G,X=0,H=!0){const _=new xe,R=H?t.rust:t.metalTan,T=new K(D(1.82,.66,4.45,.13,1.25),R);T.position.y=.62,T.castShadow=!0,T.receiveShadow=!0,_.add(T);const O=A(1.74,.3,1.25,.9,.93);an(O,1.2);const F=new K(O,R);F.position.set(0,.9,1.48),F.castShadow=!0,F.receiveShadow=!0,_.add(F);const g=A(1.74,.28,1.02,.9,.94);an(g,1.2);const M=new K(g,R);M.position.set(0,.89,-1.62),M.castShadow=!0,M.receiveShadow=!0,_.add(M);const U=new K(D(1.66,.68,2.2,.09,1),t.windowGlass);U.position.set(0,1.2,-.12),U.castShadow=!0,U.receiveShadow=!0,_.add(U);const E=new K(D(1.52,.13,1.88,.04,1),R);E.position.set(0,1.56,-.14),E.castShadow=!0,_.add(E),y(1.74,.05,2.26,t.metalTan,0,1.44,-.12,0,{group:_,uv:.6,cast:!1}),y(1.52,.04,1.9,t.rust,0,1.58,-.14,0,{group:_,uv:.6,cast:!1});for(const ot of[-.8,.8])y(.055,.46,.09,t.metalTan,ot,1.21,-.12,0,{group:_,uv:.5,cast:!1});for(const[ot,xt]of[[.94,-.34],[-1.06,.3]])for(const ut of[-.76,.76]){const It=new K(A(.09,.62,.14,.8,.7),R);It.position.set(ut,1.16,ot),It.rotation.x=xt,It.castShadow=!1,_.add(It)}for(const ot of[-.81,.81]){const xt=new K(new Rt(.07,.58,.09),R);xt.position.set(ot,1.16,-.12),xt.castShadow=!1,_.add(xt)}for(const ot of[-.82,.82]){const xt=new K(new Rt(.04,.4,1.7),t.interior);xt.position.set(ot,1.16,-.12),_.add(xt);for(let ut=0;ut<5;ut++){const It=new K(new ue(c(.1,.26),c(.08,.24)),t.glassBroken);It.position.set(ot+(ot>0?.035:-.035),1.02+c(0,.26),c(-1,.86)),It.rotation.set(c(-.4,.4),Math.PI/2,c(-.6,.6)),_.add(It)}}const L=new K(new ue(1.4,.52),t.glassBroken);L.position.set(0,1.2,.98),L.rotation.x=-.62,_.add(L);const J=new K(new ue(1.35,.46),t.glassBroken);J.position.set(0,1.19,-1.18),J.rotation.x=.6,J.rotation.y=Math.PI,_.add(J);for(const ot of[-.93,.93]){if(H&&ot>0){const It=new K(new Rt(.05,.1,1.12),t.metal);It.position.set(ot,1.4,.08),_.add(It);const Nt=new K(new Rt(.34,.44,.46),t.gunMetalWorn);Nt.position.set(ot-.24,.9,-.2),_.add(Nt);continue}const xt=new K(A(.08,.56,1.12,.95,.98),R);xt.position.set(ot,.72,.08),xt.castShadow=!0,_.add(xt);const ut=new K(new Rt(.06,.04,.17),t.metal);ut.position.set(ot+(ot>0?.035:-.035),.84,-.32),_.add(ut)}const st=[[-1,1.42,1],[1,1.42,.66],[-1,-1.47,.6],[1,-1.47,1]];for(const[ot,xt,ut]of st){const It=new K(new Rt(.1,.26,1),t.rubber);It.position.set(ot*.94,.66,xt),_.add(It);const Nt=new K(new Rn(.46,.06,5,10,Math.PI),R);if(Nt.rotation.y=Math.PI/2,Nt.position.set(ot*.92,.52,xt),Nt.scale.set(1,1,1.45),Nt.castShadow=!1,_.add(Nt),ut<.6){const ee=new K(new Re(.16,.16,.24,8),t.metal);ee.rotation.z=Math.PI/2,ee.position.set(ot,.3,xt),_.add(ee);continue}const Ht=new K(new Re(.36,.36,.26,16),t.rubber);Ht.rotation.z=Math.PI/2,Ht.position.set(ot,ut<.85?.24:.35,xt),Ht.scale.set(1,ut<.85?.6:.95,1),Ht.castShadow=!0,_.add(Ht);const le=new K(new Re(.15,.15,.275,8),t.metal);le.rotation.z=Math.PI/2,le.position.set(ot,Ht.position.y,xt),_.add(le)}const it=new K(new Rt(1.84,.16,.15),t.metal);it.position.set(0,.5,2.24),it.rotation.z=H?.05:0,it.castShadow=!0,_.add(it);const pt=new K(new Rt(1.8,.14,.13),t.metal);pt.position.set(.12,.44,-2.24),pt.rotation.set(.14,0,-.26),_.add(pt);for(const ot of[-.6,.6]){const xt=new K(new Rt(.3,.15,.05),t.glassBroken);xt.position.set(ot,.79,2.19),_.add(xt);const ut=new K(new Rt(.24,.11,.05),t.rubber);ut.position.set(ot,.79,-2.17),_.add(ut)}y(.34,.13,.03,t.metalTan,0,.54,-2.28,0,{group:_,uv:.4,cast:!1});for(const ot of[-1,1]){const xt=new K(new Rt(.14,.04,.04),t.metal);xt.position.set(ot,1.02,.9),_.add(xt);const ut=new K(new Rt(.06,.14,.19),H?t.rust:t.metalTan);ut.position.set(ot+(ot>0?.07:-.07),1.02,.9),_.add(ut)}for(const ot of[-.4,.4]){const xt=new K(new Rt(.42,.36,.44),t.gunMetalWorn);xt.position.set(ot,.86,-.36),_.add(xt)}return _.position.set(I,.02,G),_.rotation.y=X,_.rotation.z=(u()-.5)*.04,s.add(_),C(I,G,2.05,4.55,X,.05),ht(I,G,1.24,2.36,.52,-X,Math.abs(I)>6.9?.176:.012),_}function tt(I,G,X=0,H=!1){const _=new xe,R=H?t.rust:t.metalTan,T=new K(D(1.98,.62,4.95,.13,1.25),R);T.position.y=.74,T.castShadow=!0,T.receiveShadow=!0,_.add(T);const O=A(1.9,.28,1.35,.9,.94);an(O,1.25);const F=new K(O,R);F.position.set(0,1,1.75),F.castShadow=!0,_.add(F);const g=new K(D(1.86,.86,1.95,.1,1),t.windowGlass);g.position.set(0,1.48,.55),g.castShadow=!0,_.add(g);const M=new K(D(1.7,.11,1.78,.05,1),R);M.position.set(0,1.92,.52),M.castShadow=!0,_.add(M),y(1.9,.055,1.98,t.metalTan,0,1.82,.52,0,{group:_,uv:.6,cast:!1});for(const st of[-.93,.93])y(.06,.56,.09,t.metalTan,st,1.5,.52,0,{group:_,uv:.5,cast:!1});for(const[st,it]of[[1.5,-.34],[-.4,.28]])for(const pt of[-.86,.86]){const ot=new K(A(.1,.82,.16,.8,.7),R);ot.position.set(pt,1.43,st),ot.rotation.x=it,_.add(ot)}for(const st of[-.92,.92]){const it=new K(new Rt(.04,.52,1.5),t.interior);it.position.set(st,1.42,.52),_.add(it);for(let pt=0;pt<3;pt++){const ot=new K(new ue(c(.1,.24),c(.08,.2)),t.glassBroken);ot.position.set(st+(st>0?.035:-.035),1.2+c(0,.3),c(-.2,1.2)),ot.rotation.set(c(-.4,.4),Math.PI/2,c(-.6,.6)),_.add(ot)}}const U=new K(new ue(1.6,.6),t.glassBroken);U.position.set(0,1.52,1.55),U.rotation.x=-.5,_.add(U);const E=new K(new Rt(1.78,.1,2.15),t.metal);E.position.set(0,1,-1.55),_.add(E);for(const st of[-.88,.88]){const it=new K(A(.1,.56,2.18,.9,.98),R);it.position.set(st,1.28,-1.55),it.castShadow=!0,_.add(it)}const L=new K(new Rt(1.8,.56,.1),R);L.position.set(0,1.28,-.45),_.add(L);const J=new K(D(1.2,.5,1,.1,.8),t.burlap);J.position.set(-.2,1.35,-1.5),J.rotation.y=.2,J.castShadow=!0,_.add(J);for(let st=0;st<2;st++){const it=new K(new Rn(.34,.13,7,14),t.rubber);it.rotation.x=Math.PI/2+.08,it.position.set(.45+st*.05,1.16+st*.2,-2.1),it.castShadow=!0,_.add(it)}for(const[st,it,pt]of[[-1.06,1.6,1],[1.06,1.6,1],[-1.06,-1.62,.82],[1.06,-1.62,.55]]){const ot=new K(new Rt(.1,.28,1.12),t.rubber);ot.position.set(st*.94,.8,it),_.add(ot);const xt=new K(new Rn(.52,.07,5,10,Math.PI),R);if(xt.rotation.y=Math.PI/2,xt.position.set(st*.92,.62,it),xt.scale.set(1,1,1.5),xt.castShadow=!1,_.add(xt),pt<.6)continue;const ut=new K(new Re(.43,.43,.32,16),t.rubber);ut.rotation.z=Math.PI/2,ut.position.set(st,pt<.9?.28:.44,it),ut.scale.set(1,pt<.9?.6:.96,1),ut.castShadow=!0,_.add(ut);const It=new K(new Re(.18,.18,.34,8),t.metal);It.rotation.z=Math.PI/2,It.position.set(st,ut.position.y,it),_.add(It)}y(2.2,.18,.16,t.metal,0,.62,2.5,0,{group:_,uv:.8}),y(2.1,.14,.12,t.metal,.1,.58,-2.62,0,{group:_,uv:.8});for(const st of[-.66,.66]){const it=new K(new Rt(.34,.16,.05),t.glassBroken);it.position.set(st,.98,2.5),_.add(it)}for(const st of[-1.06,1.06]){const it=new K(new Rt(.16,.05,.05),t.metal);it.position.set(st,1.3,1.5),_.add(it);const pt=new K(new Rt(.07,.18,.24),R);pt.position.set(st+(st>0?.08:-.08),1.3,1.5),_.add(pt)}return _.position.set(I,.02,G),_.rotation.y=X,s.add(_),C(I,G,2.18,5.2,X,.05),ht(I,G,1.3,2.6,.52,-X,Math.abs(I)>6.9?.176:.012),_}function vt(I,G,X=0){const H=new xe,_=new K(D(2.2,1.75,2.2,.12,1.4),t.rust);_.position.set(0,1.28,2.55),_.castShadow=!0,_.receiveShadow=!0,H.add(_);const R=new K(new ue(1.9,.7),t.glassBroken);R.position.set(0,1.7,3.62),R.rotation.x=-.18,H.add(R);const T=new K(new Rt(2.35,2.35,4.3),t.rust);an(T.geometry,1.6),T.position.set(0,1.55,-.75),T.castShadow=!0,T.receiveShadow=!0,H.add(T);const O=new K(D(2.3,.28,4.2,.08,1.2),t.burlap);O.position.set(0,2.85,-.75),O.castShadow=!0,H.add(O);for(const g of[-1.19,1.19]){for(const U of[.75,1.5,2.25]){const E=new K(new Rt(.06,.12,4.15),t.metal);E.position.set(g,U,-.75),E.castShadow=!1,H.add(E)}const M=new K(new Rt(.07,.5,4.2),t.metal);M.position.set(g,.55,-.75),H.add(M);for(const U of[-.2,.2]){const E=new K(new Rt(.08,.1,.22),t.metalTan);E.position.set(g,1.4,-2.88+U*.5),H.add(E)}}for(const g of[-.58,.58]){const M=new K(new Rt(1.12,2.1,.07),t.rust);M.position.set(g,1.5,-2.93),M.castShadow=!0,H.add(M);const U=new K(new Rt(.07,.22,.05),t.metal);U.position.set(g+(g>0?-.48:.48),1.5,-2.9),H.add(U)}const F=new K(new Rt(2.34,.09,.09),t.metalTan);F.position.set(0,.55,-2.96),H.add(F);for(let g=0;g<5;g++){const M=new K(new Rt(.02,c(.3,.8),c(.4,.9)),t.rust);M.position.set(u()>.5?1.19:-1.19,c(.8,2.3),c(-2.7,1.2)),H.add(M)}for(const[g,M,U]of[[-1.14,2.4,1],[1.14,2.4,.5],[-1.14,-1.5,1],[1.14,-1.5,.9],[-1.14,-2.5,.65],[1.14,-2.5,1]]){const E=new K(new Re(.46,.46,.32,12),t.rubber);E.rotation.z=Math.PI/2,E.position.set(g,U<.7?.28:.46,M),E.scale.set(1,U<.7?.62:.96,1),E.castShadow=!0,H.add(E)}return y(2.3,.18,.18,t.metal,0,.55,3.7,0,{group:H,uv:.8}),H.position.set(I,.02,G),H.rotation.y=X,s.add(H),C(I,G,2.5,6.2,X,.05),ht(I,G,1.5,3.2,.55,-X,Math.abs(I)>6.9?.176:.012),H}function bt(I,G,X=0){const H=new xe,_=new K(D(1.45,1.1,2.05,.05,1.4),t.metal);_.position.y=.65,_.castShadow=!0,_.receiveShadow=!0,H.add(_);const R=new K(new Rt(1.5,.08,2.1),t.rust);R.position.set(0,1.22,-.08),R.rotation.x=-.24,R.castShadow=!0,H.add(R);for(const O of[-.6,.6])for(const F of[-.7,.7]){const g=new K(new Re(.09,.09,.07,8),t.rubber);g.rotation.z=Math.PI/2,g.position.set(O,.09,F),H.add(g)}const T=new K(new ue(1.2,.8),t.graffiti);T.position.set(.73,.8,0),T.rotation.y=Math.PI/2,H.add(T);for(let O=0;O<5;O++){const F=new K(D(c(.3,.5),c(.25,.4),c(.3,.5),.12,.6),t.burlap);F.position.set(c(-.7,.7),1.3+c(0,.2),c(-1,1)),F.castShadow=!0,H.add(F)}H.position.set(I,0,G),H.rotation.y=X,s.add(H),C(I,G,1.6,2.2,X,.06),ht(I,G,1,1.32,.45,-X)}function mt(I,G,X=0){const H=new xe;for(let _=0;_<5;_++){const R=new K(new Rt(1,.045,.13),t.wood);R.position.set(0,.15,-.44+_*.22),R.castShadow=!0,H.add(R)}for(let _=0;_<3;_++){const R=new K(new Rt(.12,.14,1),t.wood);R.position.set(-.4+_*.4,.07,0),R.castShadow=!0,H.add(R)}H.position.set(I,0,G),H.rotation.y=X,s.add(H)}function Ot(I,G,X=3){for(let H=0;H<X;H++){const _=new K(new Rn(.34,.14,7,14),t.rubber);_.rotation.set(Math.PI/2+c(-.15,.15),c(0,6),c(-.1,.1)),_.position.set(I+c(-.12,.12),.15+H*.28,G+c(-.12,.12)),_.castShadow=!0,s.add(_)}b(I,G,.9,.9,.02),ht(I,G,.5,.5,.38)}function Ut(I,G,X=0){const H=new K(new Rn(.34,.14,7,14),t.rubber);H.rotation.set(Math.PI/2+c(-.3,.3),X,c(-.2,.2)),H.position.set(I,.15,G),H.castShadow=!0,s.add(H)}function zt(I,G,X=1.4){const H=G*(ce-.55);for(let _=0;_<7;_++){const R=new K(D(c(.26,.44),c(.22,.38),c(.26,.46),.12,.6),u()<.5?t.burlap:t.metal);R.position.set(H+c(-.4,.4),.18,I+c(-X,X)),R.rotation.set(c(-.2,.2),c(0,6),c(-.2,.2)),R.castShadow=!0,R.receiveShadow=!0,s.add(R)}for(let _=0;_<3;_++){const R=new K(new ue(c(.4,.8),c(.5,1)),t.paper);R.rotation.set(-Math.PI/2+c(-.3,.3),c(0,6),0),R.position.set(H+c(-.7,.7),.08+_*.05,I+c(-X,X)),s.add(R)}b(H,I,.9,X*2,.05),ht(H,I,.5,X*.85,.32)}function te(I,G,X=2,H=26){const _=new Fc(1,0),R=new Mo(1,0);for(let T=0;T<H;T++){const O=u()*Math.PI*2,F=Math.pow(u(),.65)*X,g=.12+u()*(X*.24),M=(u()>.4?_:R).clone();an(M,g<.22?.5:1.6);const U=g<.22?t.brick:v([t.concrete,t.concreteDark,t.concrete]),E=new K(M,U),L=g*.55+Math.max(0,1-F/X)*.18;E.position.set(I+Math.cos(O)*F,L,G+Math.sin(O)*F),E.scale.set(g*c(.7,1.4),g*c(.5,1),g*c(.7,1.4)),E.rotation.set(u()*3,u()*6,u()*3),E.castShadow=!0,E.receiveShadow=!0,s.add(E)}for(let T=0;T<Math.min(8,H/3);T++){const O=.5+u()*1.4,F=new K(new Re(.016,.016,O,4),t.rust);F.position.set(I+(u()-.5)*X*1.6,O*.42,G+(u()-.5)*X*1.6),F.rotation.set((u()-.5)*1.4,u()*6,(u()-.5)*1.4),F.castShadow=!1,s.add(F)}for(let T=0;T<5;T++){const O=new K(new Rt(.24,.11,.12),t.brick);O.position.set(I+(u()-.5)*X*1.7,.08,G+(u()-.5)*X*1.7),O.rotation.set(u(),u()*6,u()),s.add(O)}X>=1.8&&b(I,G,X*1.1,X*1.1,.05)}function St(I,G,X=4,H=1){for(let _=0;_<X;_++){const R=c(.26,.55),T=I+c(-.35,.35),O=G+c(-.9,.9);for(let F=0;F<2;F++){const g=new ue(R*1.25,R),M=new K(g,t.weed);M.position.set(T,R*.46,O),M.rotation.set(c(-.08,.08),F*Math.PI/2+c(-.35,.35),c(-.12,.12)),M.castShadow=!1,s.add(M)}}}function Ft(I,G,X,H,_){for(let R=0;R<_;R++){const T=c(I,G),O=c(X,H),F=u();if(F<.55){const g=c(.14,.34),M=new K(new ue(g,g*c(.7,1.3)),t.paper);M.position.set(T,.02+u()*.02,O),M.rotation.set(-Math.PI/2+c(-.35,.35),c(0,6.3),c(-.2,.2)),s.add(M)}else if(F<.72){const g=c(.1,.24),M=new K(new Re(c(.035,.06),c(.035,.06),g,6),u()>.6?t.glassBroken:t.metalTan);M.position.set(T,g/2+.01,O),M.rotation.set(Math.PI/2+c(-.3,.3),c(0,6),c(-.4,.4)),s.add(M)}else if(F<.86){const g=new K(new Rt(c(.1,.24),c(.05,.1),c(.1,.2)),u()>.5?t.brick:t.concreteDark);g.position.set(T,.04,O),g.rotation.set(c(-.3,.3),c(0,6),c(-.3,.3)),s.add(g)}else for(let g=0;g<3;g++){const M=new K(new Re(.011,.011,.045,5),t.metalTan);M.position.set(T+c(-.12,.12),.012,O+c(-.12,.12)),M.rotation.set(Math.PI/2+c(-.2,.2),c(0,6),0),s.add(M)}}}function re(I){for(const[G,X,H,_]of I){const R=new li(H,26),T=R.attributes.position;for(let F=1;F<T.count;F++){const g=T.getX(F),M=T.getY(F),U=Math.atan2(M,g),E=Math.hypot(g,M)/H;T.setZ(F,Math.sin(U*6+G)*.005*E)}R.computeVertexNormals(),R.rotateX(-Math.PI/2);const O=new K(R,t.puddle);O.position.set(G,.012,X),s.add(O)}}function ne(I,G,X,H,_=t.rubber,R=10){const T=I.clone().lerp(G,.5);T.y-=X;const O=new Nc([I,T,G]),F=new yo(O,R,H,4,!1),g=new K(F,_);return g.castShadow=!1,g.receiveShadow=!1,s.add(g),g}function qt(I,G,X,H,_=!1){const R=c(.45,.85),T=c(.5,.95),O=new ue(R,T,3,3),F=O.attributes.position;for(let M=0;M<F.count;M++){const U=F.getX(M)/(R/2);F.setZ(M,Math.cos(U*1.4)*.06+Math.sin(F.getY(M)*3)*.02)}O.computeVertexNormals();const g=new K(O,u()<.5?t.burlap:t.sandbag);return g.position.set(I,G-T/2,X),g.rotation.y=_?c(-.4,.4):-H*Math.PI/2+c(-.2,.2),g.castShadow=!0,s.add(g),g}function Qt(I,G,X){const H=new K(new Re(.085,.12,9.2,8),t.concreteDark);an(H.geometry,1.2),H.position.set(I,4.6,G),H.castShadow=!0,s.add(H),y(.9,.042,.042,t.metal,I,8.45,G,0,{uv:.6,cast:!1}),y(.72,.04,.04,t.metal,I,7.95,G,0,{uv:.6,cast:!1});for(const _ of[-1,1]){const R=new K(new Rt(.34,.035,.035),t.metal);R.position.set(I+_*.4,8.28,G),R.rotation.z=_*.6,s.add(R)}for(const _ of[-.5,.5])S(.028,.036,.16,5,t.metal,I+_,8.35,G,{cast:!1});for(const _ of[-.4,.4])S(.026,.032,.14,5,t.metal,I+_,7.86,G,{cast:!1});return u()<.45&&S(.2,.2,.5,8,t.metal,I+X*.24,7.45,G,{cast:!1}),b(I,G,.4,.4,.03),ht(I,G,.34,.34,.32),{x:I,z:G}}function ae(I,G,X,H=!1){const R=new K(new Re(.06,.09,7.4,7),t.metal);R.position.set(I,7.4/2,G),R.rotation.z=H?X*.05:0,R.castShadow=!0,s.add(R);const T=1.55,O=new K(new Rt(T,.07,.07),t.metal);O.position.set(I-X*T/2,7.4-.15,G),O.rotation.z=H?X*.06:0,s.add(O);const F=new K(new Rt(.52,.16,.3),t.metalTan);F.position.set(I-X*T,7.4-.26,G),F.castShadow=!0,s.add(F),H||y(.34,.05,.2,t.metal,I-X*T,7.4-.35,G,0,{uv:.5,cast:!1}),b(I,G,.28,.28,.02),ht(I,G,.28,.28,.3)}function Ae(I,G,X=0){const H=new K(new Re(.045,.05,3.1,6),t.metal);H.position.set(I,1.55,G),H.rotation.z=.06,H.castShadow=!0,s.add(H);const _=new K(new Rt(.92,.55,.05),t.signC);_.position.set(I+.1,2.7,G),_.rotation.set(0,X,.09),_.castShadow=!0,s.add(_)}function Q(I,G,X=1){const H=new xe,_=7.2*X,R=8;let T=0,O=0;const F=c(-.18,.18),g=c(-.18,.18);for(let L=0;L<R;L++){const J=L/R,st=J*_,it=(.19-J*.08)*X,pt=new K(new Re(it*.92,it,_/R+.06,8),t.wood);T=F*X*J*J*3,O=g*X*J*J*3,pt.position.set(T,st+_/R/2,O),pt.rotation.z=-F*.5,pt.castShadow=!0,pt.receiveShadow=!0,H.add(pt)}const M=F*X*3,U=g*X*3,E=15;for(let L=0;L<E;L++){const J=L/E*Math.PI*2+c(-.12,.12),st=(2.3+u()*.9)*X,it=new ue(st,.62*X);it.rotateX(-Math.PI/2),it.translate(st/2,0,0);for(const pt of[0,1]){const ot=it.clone(),xt=new K(ot,t.frond);xt.position.set(M,_-.1-pt*.25,U),xt.rotation.y=J+pt*.3,xt.rotation.z=pt?-c(.75,1.15):-c(.2,.6),xt.scale.setScalar(pt?.78:1),xt.castShadow=!0,H.add(xt)}}for(let L=0;L<3;L++){const J=1.3*X,st=new ue(J,.4*X);st.rotateX(-Math.PI/2),st.translate(J/2,0,0);const it=new K(st,t.burlap);it.position.set(M,_-.15,U),it.rotation.y=c(0,6),it.rotation.z=-1.45,H.add(it)}H.position.set(I,0,G),s.add(H),b(I,G,.5,.5,.02),ht(I,G,.55,.55,.36)}function Yt(){const I=new he({color:5788745,roughness:1,metalness:0}),G=new he({color:4341560,roughness:1,metalness:0}),X=[];for(let it=0;it<34;it++){let pt=0,ot=0,xt=0;do pt=(u()-.5)*300,ot=-104-u()*155,xt++;while(xt<40&&Math.abs(pt)<34&&ot>-180);const ut=8+u()*24,It=8+u()*24;let Nt=10+u()*58;Math.abs(pt)<70&&(Nt=Math.min(Nt,30)),Math.abs(pt)<34&&(Nt=Math.min(Nt,16));const Ht=new Rt(ut,Nt,It);an(Ht,9);const le=new K(Ht,u()>.5?I:G);if(le.position.set(pt,Nt/2,ot),X.push(le),u()<.5){const ee=new Rt(ut*.45,3+u()*6,It*.45),$t=new K(ee,le.material);$t.position.set(pt+c(-ut*.2,ut*.2),Nt+2,ot+c(-It*.2,It*.2)),X.push($t)}}const H=new he({color:6051661,roughness:1}),_=new K(new Re(1.1,1.5,34,10),H);_.position.set(-9.5,17,-88),a.add(_);const R=new K(new Re(2,2,.8,10),H);R.position.set(-9.5,27,-88),a.add(R);const T=new K(new Re(1.6,1.6,.6,10),H);T.position.set(-9.5,20,-88),a.add(T);const O=new K(new oo(1.5,3.2,10),H);O.position.set(-9.5,35.6,-88),a.add(O);const F=new K(new Ci(5.2,14,8,0,Math.PI*2,0,Math.PI*.5),H);F.position.set(-20,11,-94),a.add(F);const g=new K(new Re(5.2,5.2,6,14),H);g.position.set(-20,8,-94),a.add(g);const M=new xe;for(const[it,pt]of[[-1.4,-1.4],[1.4,-1.4],[-1.4,1.4],[1.4,1.4]]){const ot=new K(new Re(.16,.2,22,6),H);ot.position.set(it,11,pt),M.add(ot)}const U=new K(new Re(3.4,3.4,5,12),H);U.position.y=24,M.add(U);const E=new K(new oo(3.6,2.6,12),H);E.position.y=27.8,M.add(E),M.position.set(27,0,-92),a.add(M);const L=new xe,J=new K(new Rt(1.2,46,1.2),H);J.position.y=23,L.add(J);const st=new K(new Rt(34,1,1),H);st.position.set(10,45,0),L.add(st),L.position.set(-52,0,-128),a.add(L);for(const it of X)a.add(it);for(const[it,pt,ot]of[[-52,-150,5],[40,-172,6],[6,-196,5],[-116,-136,4]])for(let xt=0;xt<ot;xt++){const ut=new ki(new Ei({map:t.sprites.smoke,color:new Jt(4866616),transparent:!0,opacity:.11,depthWrite:!1})),It=16+xt*8;ut.scale.set(It,It*1.3,1),ut.position.set(it+Math.sin(xt*.8)*9,8+xt*10,pt+Math.cos(xt)*7),r.add(ut)}}Dt();const _t=[{side:-1,z0:26,z1:54,depth:14,h:19,detail:"high",plaster:t.plasterB,ground:"wall",bays:7},{side:-1,z0:6,z1:26,depth:15,h:22,detail:"high",plaster:t.plasterA,ground:"shutter",bays:6},{side:-1,z0:-16,z1:0,depth:15,h:16,detail:"high",plaster:t.plasterC,ground:"shop",bays:5},{side:-1,z0:-36,z1:-16,depth:14,h:25,detail:"high",plaster:t.plasterB,ground:"shop",bays:6},{side:-1,z0:-54,z1:-36,depth:13,h:18,detail:"mid",plaster:t.plasterA,facade:"C",ground:"wall",balconies:2},{side:-1,z0:-66,z1:-54,depth:15,h:20,detail:"ruin",plaster:t.plasterB,ground:"wall"},{side:1,z0:30,z1:56,depth:15,h:22,detail:"high",plaster:t.plasterA,ground:"shutter",bays:7},{side:1,z0:12,z1:30,depth:16,h:15,detail:"high",plaster:t.plasterA,ground:"shop",bays:6},{side:1,z0:-6,z1:12,depth:15,h:24,detail:"high",plaster:t.plasterB,ground:"door",bays:6},{side:1,z0:-26,z1:-6,depth:14,h:18,detail:"high",plaster:t.plasterC,ground:"shop",bays:6},{side:1,z0:-46,z1:-26,depth:15,h:21,detail:"mid",plaster:t.plasterB,facade:"D",ground:"wall",balconies:2},{side:1,z0:-64,z1:-46,depth:14,h:13,detail:"ruin",plaster:t.plasterA,ground:"wall"}];for(const I of _t)et(I);ie(),$();function Tt(I,G,X,H){const _=R=>I*(ce-R);for(let R=0;R<X;R++){const T=4.6+R*H;y(.92,.09,3.2,t.rust,_(.48),T,G,0,{uv:1});for(let O=0;O<8;O++)y(.035,.86,.035,t.rust,_(.92),T+.48,G-1.5+O*.43,0,{uv:.5,cast:!1});if(y(.05,.05,3.2,t.rust,_(.92),T+.92,G,0,{uv:.5,cast:!1}),y(.05,.05,3.2,t.rust,_(.15),T+.92,G,0,{uv:.5,cast:!1}),R<X-1){for(const O of[-1,1]){const F=new K(new Rt(.05,3.9,.05),t.rust);F.position.set(_(.85+O*.12),T+H/2,G+O*.42),F.rotation.x=O*.25,s.add(F)}for(let O=0;O<8;O++)y(.05,.045,.82,t.rust,_(.85),T+.4+O*(H-.5)/8,G,0,{uv:.4,cast:!1})}}}Tt(-1,13.5,4,3.3),Tt(1,2.5,4,3.3),Tt(1,-18.5,3,3.1),P(-3.3,13.2,.34,!0),P(4.6,-10.5,-.22,!1),P(-1.4,-44.5,1.15,!0),tt(3.9,-32.5,.18,!1),tt(-6.9,-8.6,1.92,!0),vt(4.7,-24.8,1.44),vt(-5.9,-57.5,-.25),P(5.1,17.4,-.78,!0),P(-7.5,34.6,-.95,!1),B(-3.3,21.4,.1),B(-2.15,21.2,.06),B(3,-2.8,.7),B(-5,-8.6,1.45),B(-3.9,-8.2,1.42),B(-1.4,-13.2,.22),B(2.6,-14.6,-.34),Ot(-.4,-15.4,2),te(1.2,-17.2,1.3,10),ct(-3.2,-16.4,.72,.9),jt(-4.9,28,.06,4,7,t.burlap),jt(6.1,16.2,-.5,3,5,t.sandbag),jt(-6.4,-24.2,1.2,3,5,t.burlap),jt(5.6,-46.5,-.3,3,5,t.burlap),Ct(-11.6,4.7,3),Ct(6.3,-21.5,3),ct(-6.2,15.2,1,.4),ct(-2,-52.5,.9,.8),bt(-7.3,22.6,1.57),bt(7.4,-43.5,-1.5),bt(-14.2,4.7,1.55),At(-1.9,.95,-23.6),wt(5.55,18.6,{fire:!0}),wt(-6.25,-22.8,{fire:!0}),wt(-5.5,13.5),wt(6.35,-37.5),wt(-6.7,-49.2),Ut(-6.3,19.8,.4),Ut(-5.7,20.6,1.2),Ut(6.5,-6.4,.2),Ot(6.9,41.5,3),Ot(-6.9,-34.5,4),mt(-5.9,10.9,.6),mt(6.2,27.4,1.2),mt(-20.9,5.1,.4),Ae(6.85,22.4,.3),Ae(-6.9,-30.2,-.2),ae(7.3,33.5,1,!1),ae(-7.3,6.8,-1,!0),ae(7.3,-19.5,1,!1),ae(-7.3,-46.5,-1,!0);const Vt=[44,26,12,-10,-28,-46,-62].map(I=>Qt(-7.55,I,-1)),Wt=[36,18,0,-18,-36,-54].map(I=>Qt(7.55,I,1));for(let I=1;I<Vt.length;I++)for(const G of[-.5,.5])ne(new N(-7.55+G,8.55,Vt[I-1].z),new N(-7.55+G,8.55,Vt[I].z),.5+Math.abs(Vt[I].z-Vt[I-1].z)*.006,.02);for(let I=1;I<Wt.length;I++)for(const G of[-.55,.55])ne(new N(7.55+G,8.45,Wt[I-1].z),new N(7.55+G,8.45,Wt[I].z),.45+Math.abs(Wt[I].z-Wt[I-1].z)*.006,.018);for(const[I,G,X]of[[20,8.9,2.1],[2.4,7.6,1.7],[-16,9.4,2.3],[-38,8.2,2],[-56,7.4,1.6]]){const H=I+c(-1.5,1.5),_=G+c(-.3,.3);ne(new N(-9.6,G,I),new N(9.6,_,H),X,.013),ne(new N(-9.6,G-.5,I+.5),new N(9.6,_-.3,H+.7),X*.9,.009);for(const R of[-1,1])y(.14,.14,.2,t.rust,R*(ce-.07),G-.25,R<0?I:H,0,{uv:.4,cast:!1})}for(const I of[10.5,-12.5])ne(new N(-9.4,6.4,I),new N(9.4,6.7,I+1.2),1.1,.01);Q(-8.6,33.5,1.05),Q(8.7,-34.5,.95),Q(-8.9,-51.5,1.1),Ft(-9.3,-7,-62,52,90),Ft(7,9.3,-62,52,90),Ft(-6.4,6.4,-62,52,50),Ft(-21.5,-10.5,.3,5.7,40);for(const I of[38,29,20,11,2,-7,-16,-25,-34,-43,-52])St(-9.62,I,2),St(9.62,I,2);for(const I of[34,17,-4,-26,-48])St(-6.86,I,1),St(6.86,I,1);te(-6.5,40.5,2.7,26),te(7.4,7.4,2,18),te(-7.7,-46.5,2.4,20),te(6.8,28.5,1.5,12),te(-7,19.5,1.25,10),te(-4.2,-31.5,1.8,14),zt(21.6,-1,1.6),zt(-12.5,-1,1.3),zt(-31.4,1,1.2),zt(46.2,1,1.2),Yt();const ge=1200,Ee=new Ye,ke=new Float32Array(ge*3),me=new Float32Array(ge);for(let I=0;I<ge;I++)ke[I*3]=(u()-.5)*34,ke[I*3+1]=.2+Math.pow(u(),.7)*12,ke[I*3+2]=(u()-.5)*110,me[I]=u()*100;Ee.setAttribute("position",new Ve(ke,3));const je=new fh({size:.04,map:t.sprites.glow,color:16770756,transparent:!0,opacity:.45,depthWrite:!1,blending:cn,sizeAttenuation:!0}),nn=new ao(Ee,je);nn.frustumCulled=!1,r.add(nn);const bn=Js(s);bn.traverse(I=>{if(!I.isMesh)return;const G=I.material&&I.material.userData||{};I.castShadow=!G.noShadow,I.receiveShadow=!0}),n.add(bn),s.clear();const oi=Js(a,{castShadow:!1,receiveShadow:!1});n.add(oi),a.clear(),l.length=0,bn.traverse(I=>{if(!I.isMesh)return;(I.material&&I.material.userData||{}).noBullet||l.push(I)}),h.push({x:0,z:-61},{x:-4,z:-58},{x:4.5,z:-60},{x:-7.2,z:-46},{x:6.8,z:-40},{x:-6,z:-31},{x:6.4,z:-18},{x:-7.4,z:-4},{x:7.2,z:4},{x:-6.8,z:14},{x:6.6,z:24},{x:0,z:-48},{x:-15.5,z:3.2}),f.push({x:-3.3,z:15.6,h:!0},{x:4.9,z:-8,h:!1},{x:-1.8,z:26.4,h:!1},{x:2.6,z:.6,h:!0},{x:-5.2,z:-7,h:!1},{x:5.5,z:17,h:!1},{x:-6,z:-21.6,h:!1},{x:5.4,z:-30.4,h:!0},{x:-6.9,z:-34.5,h:!0},{x:6.2,z:-46.5,h:!1},{x:-14.2,z:2.2,h:!0},{x:.9,z:-27.2,h:!0});let sn=0;const Tn=nn.geometry.attributes.position;function jn(I,G){sn+=I;for(const X of m){const H=.78+Math.sin(sn*17.3+X.base.x)*.1+Math.sin(sn*7.1)*.08+Math.pow(Math.random(),3)*.25;X.light&&(X.light.intensity=X.intensity*H);for(const _ of X.sprites){_.phase+=I*(2.2+_.s*2);const R=Math.sin(_.phase)*.12;_.sp.position.x=X.base.x+R,_.sp.position.z=X.base.z+Math.cos(_.phase*1.3)*.1,_.sp.position.y=X.base.y+.2+_.phase*.35%1.2;const T=_.s*(1+Math.sin(_.phase*3)*.12);_.sp.scale.set(T*.8,T*1.5,1),_.sp.material.opacity=.34+Math.sin(_.phase*4)*.12}for(const _ of X.smoke){_.t+=I*.14,_.t>1&&(_.t-=1,_.seed=Math.random()*10);const R=_.t*7;_.sp.position.set(X.base.x+Math.sin(_.seed+_.t*4)*(.4+_.t*1.4)+_.t*1,X.base.y+.8+R,X.base.z+Math.cos(_.seed*.7+_.t*3)*(.3+_.t*1.2)),_.sp.scale.setScalar(1+_.t*4.5),_.sp.material.opacity=.16*(1-_.t)*Math.min(1,_.t*5)}}for(let X=0;X<ge;X++){const H=me[X];Tn.array[X*3+1]+=(Math.sin(sn*.6+H)*.05+.012)*I,Tn.array[X*3]+=Math.cos(sn*.35+H*1.7)*.09*I,Tn.array[X*3+1]>13&&(Tn.array[X*3+1]=.2)}Tn.needsUpdate=!0}return{root:n,colliders:o,bulletTargets:l,spawnPoints:h,coverPoints:f,bounds:{x0:-22,x1:22,z0:-64,z1:52},update:jn,fires:m}}const Kr=256;function Wi(i=Kr){const t=document.createElement("canvas");return t.width=t.height=i,t}function Zn(i,{srgb:t=!1,repeat:e=1,aniso:n=8}={}){const s=new gs(i);return s.wrapS=s.wrapT=ds,s.colorSpace=t?pn:ii,s.anisotropy=n,s.repeat.set(e,e),s.needsUpdate=!0,s}function Zr(i,t,e=2){const n=Wi(t),s=n.getContext("2d",{willReadFrequently:!0}),r=s.createImageData(t,t),a=r.data,o=(l,h)=>i[(h+t)%t*t+(l+t)%t]/255;for(let l=0;l<t;l++)for(let h=0;h<t;h++){const f=(o(h+1,l)-o(h-1,l))*e,m=(o(h,l+1)-o(h,l-1))*e;let u=-f,d=-m,c=1;const v=Math.hypot(u,d,c);u/=v,d/=v,c/=v;const p=(l*t+h)*4;a[p]=(u*.5+.5)*255,a[p+1]=(d*.5+.5)*255,a[p+2]=(c*.5+.5)*255,a[p+3]=255}return s.putImageData(r,0,0),n}function wh(i,t){const e=Wi(t),n=e.getContext("2d",{willReadFrequently:!0}),s=n.createImageData(t,t);for(let r=0;r<t*t;r++){const a=Math.max(0,Math.min(255,i[r]));s.data[r*4]=a,s.data[r*4+1]=a,s.data[r*4+2]=a,s.data[r*4+3]=255}return n.putImageData(s,0,0),e}const Z2=i=>i-Math.floor(i),ui=(i,t)=>Z2(Math.sin(i*127.1+t*311.7)*43758.5453);function j2(){const i=Kr,t=We(90210),e=Wi(i),n=e.getContext("2d",{willReadFrequently:!0}),s=n.createImageData(i,i),r=s.data,a=new Uint8Array(i*i);for(let h=0;h<i;h++)for(let f=0;f<i;f++){const m=f/i,u=h/i,d=ui(f*.71,h*.93),c=Math.sin(u*Math.PI*2*42+Math.sin(m*8)*.9)*.5+.5,v=Math.sin(m*11.3+1.7)*Math.sin(u*7.9)*.5+.5;let p=.175+d*.032+c*.022+v*.018;const x=(h*i+f)*4,w=Math.round(p*255);r[x]=w*.93,r[x+1]=w*.97,r[x+2]=w*1.02,r[x+3]=255,a[h*i+f]=150+d*26+c*12}n.putImageData(s,0,0);for(let h=0;h<210;h++){const f=t()*i,m=t()*i,u=1.5+t()*22,d=(t()>.55?Math.PI/2:0)+(t()-.5)*.6,c=.05+t()*.28;n.strokeStyle=`rgba(${168+t()*55},${172+t()*52},${176+t()*48},${c})`,n.lineWidth=.5+t()*1,n.beginPath(),n.moveTo(f,m),n.lineTo(f+Math.cos(d)*u,m+Math.sin(d)*u),n.stroke()}for(let h=0;h<18;h++){const f=t()*i,m=t()*i,u=6+t()*34,d=n.createRadialGradient(f,m,0,f,m,u);d.addColorStop(0,`rgba(0,0,0,${.1+t()*.16})`),d.addColorStop(1,"rgba(0,0,0,0)"),n.fillStyle=d,n.beginPath(),n.arc(f,m,u,0,7),n.fill()}const o=n.getImageData(0,0,i,i).data,l=new Uint8Array(i*i);for(let h=0;h<i*i;h++){const f=o[h*4]*.35+o[h*4+1]*.45+o[h*4+2]*.2;a[h]=Math.min(255,f*1.9),l[h]=126+(255-f)*.36}return{map:Zn(e,{srgb:!0,repeat:2}),normalMap:Zn(Zr(a,i,1.25)),roughnessMap:Zn(wh(l,i))}}function uu(i,t,e=1){const n=Kr,s=We(t),r=Wi(n),a=r.getContext("2d",{willReadFrequently:!0}),o=a.createImageData(n,n),l=o.data,h=new Uint8Array(n*n),f=8;for(let u=0;u<n;u++)for(let d=0;d<n;d++){const c=Math.floor(d/f),v=Math.floor(u/f),p=c*f+2+ui(c,v)*4,x=v*f+2+ui(v+17,c+3)*4,w=Math.hypot(d-p,u-x),b=Math.max(0,1-w/(2.1+e*.4)),C=ui(d*1.31,u*1.77),V=.8+C*.1-b*.1,D=(u*n+d)*4;l[D]=i[0]*V,l[D+1]=i[1]*V,l[D+2]=i[2]*V,l[D+3]=255,h[u*n+d]=120+b*95+C*10}a.putImageData(o,0,0);for(let u=0;u<60;u++){const d=s()*n,c=s()*n,v=3+s()*20,p=s()*6.28;a.strokeStyle=`rgba(${i[0]+42},${i[1]+40},${i[2]+34},${.05+s()*.14})`,a.lineWidth=.6+s()*1.1,a.beginPath(),a.moveTo(d,c),a.lineTo(d+Math.cos(p)*v,c+Math.sin(p)*v),a.stroke()}const m=new Uint8Array(n*n);for(let u=0;u<n;u++)for(let d=0;d<n;d++){const c=Math.floor(d/f),v=Math.floor(u/f),p=c*f+2+ui(c,v)*4,x=v*f+2+ui(v+17,c+3)*4,w=Math.max(0,1-Math.hypot(d-p,u-x)/(2.1+e*.4));m[u*n+d]=196+w*38+ui(d*1.31,u*1.77)*20}return{map:Zn(r,{srgb:!0,repeat:3}),normalMap:Zn(Zr(h,n,2.4)),roughnessMap:Zn(wh(m,n))}}function J2(i,t){const e=Kr,n=We(t),s=Wi(e),r=s.getContext("2d",{willReadFrequently:!0});r.fillStyle=`rgb(${i[0]},${i[1]},${i[2]})`,r.fillRect(0,0,e,e);const a=r.getImageData(0,0,e,e),o=a.data,l=new Uint8Array(e*e);for(let f=0;f<e;f++)for(let m=0;m<e;m++){const u=(f*e+m)*4,d=ui(m*.83,f*1.07),c=.8+d*.3;o[u]*=c,o[u+1]*=c,o[u+2]*=c,l[f*e+m]=100+d*70}r.putImageData(a,0,0);for(let f=0;f<130;f++){let m=n()*e,u=n()*e,d=n()*6.28;r.strokeStyle=`rgba(12,10,7,${.08+n()*.22})`,r.lineWidth=.6+n()*1.4,r.beginPath(),r.moveTo(m,u);const c=3+(n()*5|0);for(let v=0;v<c;v++)d+=(n()-.5)*1.1,m+=Math.cos(d)*(2+n()*6),u+=Math.sin(d)*(2+n()*6),r.lineTo(m,u);r.stroke()}for(let f=0;f<70;f++){const m=n()*e,u=n()*e,d=.8+n()*3;r.fillStyle=`rgba(${i[0]+40},${i[1]+36},${i[2]+26},${.05+n()*.16})`,r.beginPath(),r.arc(m,u,d,0,7),r.fill()}const h=r.getImageData(0,0,e,e).data;for(let f=0;f<e*e;f++){const m=h[f*4]*.4+h[f*4+1]*.4+h[f*4+2]*.2;l[f]=80+m*.5}return{map:Zn(s,{srgb:!0,repeat:2}),normalMap:Zn(Zr(l,e,1.9))}}function Q2(i,t,e=!0){const n=Kr,s=We(t),r=Wi(n),a=r.getContext("2d",{willReadFrequently:!0}),o=a.createImageData(n,n),l=o.data,h=new Uint8Array(n*n);for(let f=0;f<n;f++)for(let m=0;m<n;m++){const u=(Math.sin(m*2.3)*.5+.5)*(Math.sin(f*2.3)*.5+.5),d=ui(m*1.7,f*1.3),c=e&&(m%16<1.4||f%16<1.4)?-.1:0,v=.8+u*.16+d*.12+c,p=(f*n+m)*4;l[p]=i[0]*v,l[p+1]=i[1]*v,l[p+2]=i[2]*v,l[p+3]=255,h[f*n+m]=110+u*60+d*25+(c?-45:0)}a.putImageData(o,0,0);for(let f=0;f<26;f++){const m=s()*n,u=s()*n,d=8+s()*42,c=a.createRadialGradient(m,u,0,m,u,d);c.addColorStop(0,`rgba(84,70,48,${.04+s()*.12})`),c.addColorStop(1,"rgba(0,0,0,0)"),a.fillStyle=c,a.beginPath(),a.arc(m,u,d,0,7),a.fill()}return{map:Zn(r,{srgb:!0,repeat:2}),normalMap:Zn(Zr(h,n,1.3))}}function tv(i,t){const n=Wi(128),s=n.getContext("2d",{willReadFrequently:!0}),r=s.createImageData(128,128),a=r.data,o=new Uint8Array(128*128);for(let l=0;l<128;l++)for(let h=0;h<128;h++){const f=Math.sin(l*1.4)*.5+.5,m=Math.sin(h*3.1)*.5+.5,u=.72+f*.2+m*.16+ui(h,l)*.06,d=(l*128+h)*4;a[d]=i[0]*u,a[d+1]=i[1]*u,a[d+2]=i[2]*u,a[d+3]=255,o[l*128+h]=90+f*80+m*40}return s.putImageData(r,0,0),{map:Zn(n,{srgb:!0,repeat:3}),normalMap:Zn(Zr(o,128,1.8))}}function ev(){const t=Wi(256),e=t.getContext("2d");e.clearRect(0,0,256,256);const n=256/2,s=256/2;e.save(),e.shadowColor="rgba(255,46,26,0.95)",e.shadowBlur=10,e.strokeStyle="rgba(255,64,38,0.95)",e.lineWidth=256*.02,e.beginPath(),e.arc(n,s,256*.295,0,Math.PI*2),e.stroke(),e.restore(),e.strokeStyle="rgba(255,120,80,0.38)",e.lineWidth=256*.006,e.beginPath(),e.arc(n,s,256*.252,0,Math.PI*2),e.stroke();const r=e.createRadialGradient(n,s,0,n,s,256*.075);r.addColorStop(0,"rgba(255,255,255,1)"),r.addColorStop(.18,"rgba(255,120,80,1)"),r.addColorStop(.42,"rgba(255,34,18,0.85)"),r.addColorStop(1,"rgba(255,20,10,0)"),e.fillStyle=r,e.beginPath(),e.arc(n,s,256*.075,0,7),e.fill();const a=new gs(t);return a.colorSpace=pn,a.needsUpdate=!0,a}function nv(){const i=document.createElement("canvas");i.width=512,i.height=256;const t=i.getContext("2d");t.clearRect(0,0,512,256),t.fillStyle="rgba(216,212,196,0.62)",t.font='bold 62px "Courier New", monospace',t.fillText("M4A1",26,86),t.font='bold 30px "Courier New", monospace',t.fillText("CAL 5.56 MM",28,136),t.font='bold 22px "Courier New", monospace',t.fillStyle="rgba(210,206,190,0.45)",t.fillText("SN 66-102938",28,176);const e=We(5150);t.globalCompositeOperation="destination-out";for(let s=0;s<260;s++)t.fillStyle=`rgba(0,0,0,${.25+e()*.6})`,t.fillRect(e()*512,e()*256,1+e()*5,1+e()*3);t.globalCompositeOperation="source-over";const n=new gs(i);return n.colorSpace=pn,n.anisotropy=8,n.needsUpdate=!0,n}function iv(i,t=8){const e=j2(),n=uu([44,44,47],551,1),s=uu([116,98,68],552,1.1),r=J2([34,34,30],661),a=Q2([40,42,37],771,!1),o=tv([40,42,35]),l=q=>{const j=new he(q);return j.envMapIntensity=q.envMapIntensity??1.2,j},h=l({color:16777215,map:e.map,normalMap:e.normalMap,roughnessMap:e.roughnessMap,roughness:1,metalness:.82,normalScale:new Pt(.65,.65),envMapIntensity:1.4}),f=l({color:2566444,map:e.map,normalMap:e.normalMap,roughnessMap:e.roughnessMap,roughness:1,metalness:.04,normalScale:new Pt(.5,.5),envMapIntensity:.22}),m=l({color:9409947,metalness:.95,roughness:.56,envMapIntensity:1.2,normalMap:e.normalMap,normalScale:new Pt(.35,.35)}),u=l({color:8225674,metalness:.92,roughness:.55,envMapIntensity:1.25,normalMap:e.normalMap,normalScale:new Pt(.35,.35)}),d=l({color:2895924,metalness:.86,roughness:.62,envMapIntensity:.9,normalMap:e.normalMap,roughnessMap:e.roughnessMap,normalScale:new Pt(.85,.85)}),c=l({color:2434858,metalness:.92,roughness:.42,envMapIntensity:1.4}),v=l({color:16777215,map:n.map,normalMap:n.normalMap,roughness:.76,metalness:.08,normalScale:new Pt(.8,.8),envMapIntensity:.75}),p=l({color:16777215,map:s.map,normalMap:s.normalMap,roughness:.8,metalness:.05,normalScale:new Pt(.7,.7),envMapIntensity:.55}),x=l({color:1316119,roughness:.94,metalness:.02,envMapIntensity:.4,normalMap:n.normalMap,normalScale:new Pt(.35,.35)}),w=l({color:13619151,map:n.map,normalMap:n.normalMap,roughnessMap:n.roughnessMap,roughness:1,metalness:.04,normalScale:new Pt(1.1,1.1),envMapIntensity:.45}),b=l({color:1776928,metalness:.28,roughness:.92,normalMap:e.normalMap,normalScale:new Pt(.35,.35),envMapIntensity:.35}),C=l({color:2763044,normalMap:r.normalMap,roughness:.95,metalness:0,normalScale:new Pt(1.3,1.3),envMapIntensity:.12}),V=l({color:2040100,roughness:.72,metalness:.05,envMapIntensity:.5,normalMap:n.normalMap,normalScale:new Pt(.5,.5)}),D=l({color:1973529,normalMap:r.normalMap,roughness:.96,metalness:0,normalScale:new Pt(1.3,1.3),envMapIntensity:.1}),A=l({color:1841943,roughness:.96,metalness:0,normalMap:a.normalMap,normalScale:new Pt(1.4,1.4),envMapIntensity:.15}),y=l({color:16777215,map:a.map,normalMap:a.normalMap,roughness:.93,metalness:0,normalScale:new Pt(1.1,1.1),envMapIntensity:.4}),rt=l({color:16777215,map:o.map,normalMap:o.normalMap,roughness:.9,metalness:.02,normalScale:new Pt(.8,.8),envMapIntensity:.45}),S=new mh({color:659990,metalness:0,roughness:.06,transmission:0,ior:1.46,transparent:!0,opacity:.1,clearcoat:1,clearcoatRoughness:.02,envMapIntensity:2.2,depthWrite:!1,side:ln});i&&(S.envMap=i);const z=new he({map:nv(),transparent:!0,opacity:.7,roughness:.9,metalness:0,depthWrite:!1,polygonOffset:!0,polygonOffsetFactor:-2,polygonOffsetUnits:-2,envMapIntensity:.2}),nt=new Bn({map:ev(),transparent:!0,blending:cn,depthWrite:!1,depthTest:!0,toneMapped:!1,opacity:.95});return{receiver:h,receiverMatte:f,wornSteel:m,railWear:u,barrelSteel:d,blackSteel:c,polymer:v,polymerTan:p,rubber:x,stockPoly:w,hoodMatte:b,glove:C,glovePad:V,gloveDark:D,cuff:A,sleeve:y,sling:rt,glass:S,reticleMat:nt,stencil:z,furnitureFor(q){return q==="tan"?p:v}}}const ol=58,sv=48,rv=2.05,hu=2.7,fu=.68,du=new N(0,.088,-.0348),av=new N(.315,-.255,-.82),ll=new wn(.12,.22,-.1,"YXZ"),Da=new wn(.012,-.01,-.016,"YXZ"),ov=new N(0,-.012,.303),cl=new N(-.041,-.014,-.357),lo=new Map;function be(i,t,e,n=.004,s=2){const r=`b${i}|${t}|${e}|${n}|${s}`;let a=lo.get(r);return a||(a=new kc(i,t,e,s,Math.min(n,Math.min(i,t,e)*.48)),lo.set(r,a)),a}function on(i,t,e,n=12,s=!1){const r=`c${i}|${t}|${e}|${n}|${s}`;let a=lo.get(r);return a||(a=new Re(i,t,e,n,1,s),lo.set(r,a)),a}function Gt(i,t,e,n=0,s=0,r=0,a=0,o=0,l=0){const h=new K(t,e);return h.position.set(n,s,r),h.rotation.set(a,o,l),h.castShadow=!1,h.receiveShadow=!1,i.add(h),h}function ks(i,t,e,n){for(const s of n){const r=Gt(i,t,e,s.p[0],s.p[1],s.p[2],s.r?s.r[0]:0,s.r?s.r[1]:0,s.r?s.r[2]:0);s.s&&r.scale.set(s.s[0],s.s[1],s.s[2])}}const bh=new N(0,1,0);function Oi(i,t,e,n,s,r,a=.004){const o=new N().subVectors(n,e),l=Math.max(.001,o.length()),h=new K(be(s,l,r,Math.min(a,s*.45)),t);return h.position.copy(e).addScaledVector(o,.5),h.quaternion.setFromUnitVectors(bh,o.normalize()),i.add(h),h}function Hs(i,t,e,n,s,r,a=10){const o=new N().subVectors(n,e),l=Math.max(.001,o.length()),h=new K(on(r,s,l,a),t);return h.position.copy(e).addScaledVector(o,.5),h.quaternion.setFromUnitVectors(bh,o.normalize()),i.add(h),h}function De(i,t,e){return new N(i,t,e)}const Dr=(i,t,e)=>{const n=qe.clamp((e-i)/(t-i),0,1);return n*n*(3-2*n)},lv=i=>1-Math.pow(1-i,3),cv=i=>i*i*i;function uv(i,t){const e=new Uc;e.fog=null,t&&(e.environment=t,e.environmentIntensity=.95);const n=new Pn(ol,window.innerWidth/window.innerHeight,.008,4),s=new rs(16769728,2);s.position.set(-.9,1.8,1.2),e.add(s);const r=new rs(10339818,2.7);r.position.set(1.3,.9,-1.2),e.add(r);const a=new rs(16754800,.9);a.position.set(.2,-.8,.9),e.add(a);const o=new gh(11124438,2827291,.45);e.add(o);const l=new rs(13621474,1.3);l.position.set(.9,.4,1.5),e.add(l);const h=new rs(16764830,.75);h.position.set(-1.4,.2,1.1),e.add(h);const f=new us(16756838,0,1.6,2);e.add(f);const m=new xe;e.add(m);const u=new xe;u.rotation.order="YXZ",m.add(u);const d=iv(t,8),c=new xe;c.position.set(0,-.078,-.062),u.add(c);const v=new xe;let p=null,x=null,w=null,b=null;const C=new Ze;C.position.set(0,0,-.703),u.add(C);const V=[];function D(wt="black"){const At=d.furnitureFor(wt),ct=new xe,Ct=new xe;Gt(ct,be(.04,.052,.232,.006),d.receiver,0,0,-.108),Gt(ct,be(.038,.06,.168,.006),d.receiver,0,-.05,-.062),Gt(ct,be(.043,.036,.09,.005),d.receiver,0,-.088,-.074),Gt(ct,be(.042,.003,.082,.0015),d.receiver,0,-.105,-.074),Gt(ct,new Rt(.004,.024,.062),d.blackSteel,.0214,.008,-.078),Gt(ct,be(.0045,.032,.064,.0015),d.receiver,.0228,.008,-.078),Gt(ct,be(.006,.026,.028,.004),d.receiver,.024,.016,-.043),Gt(ct,on(.0072,.0072,.013,10),d.wornSteel,.0235,.021,-.026,0,0,Math.PI/2),Gt(ct,be(.006,.018,.024,.002),d.receiverMatte,-.0225,-.038,-.026),Gt(ct,on(.0072,.0072,.008,8),d.wornSteel,.0225,-.056,-.055,0,0,Math.PI/2),Gt(ct,on(.0058,.0058,.006,8),d.blackSteel,-.0235,-.046,-.038,0,0,Math.PI/2),Gt(ct,be(.006,.007,.028,.002),d.receiverMatte,-.0245,-.046,-.027,0,.25,0),Gt(ct,new Rn(.024,.0032,6,16,Math.PI*1.18),d.receiver,0,-.079,-.003,Math.PI/2,0,-.55),Gt(ct,be(.005,.021,.009,.002),d.wornSteel,0,-.075,-.006,-.28),Gt(ct,be(.028,.1,.044,.01,4),d.stockPoly,0,-.121,.048,-.34),Gt(ct,be(.029,.088,.012,.005,3),d.rubber,0,-.124,.069,-.34),Gt(ct,be(.03,.012,.048,.003),d.rubber,0,-.171,.063,-.34),Gt(Ct,on(.0165,.0165,.175,14),d.blackSteel,0,-.004,.095,Math.PI/2),Gt(Ct,on(.021,.021,.018,12),d.blackSteel,0,-.004,.024,Math.PI/2),Gt(Ct,be(.042,.074,.132,.014,4),d.stockPoly,0,-.016,.222),Gt(Ct,be(.036,.02,.098,.009,3),d.stockPoly,0,.028,.212),Gt(Ct,be(.046,.092,.014,.006,3),d.rubber,0,-.012,.294),Gt(Ct,new Rt(.038,.0014,.085),d.blackSteel,0,.0378,.212),Gt(Ct,be(.0025,.028,.062,.002),d.blackSteel,.0212,-.018,.215),Gt(Ct,be(.0018,.016,.03,.001),d.rubber,.0225,-.018,.215),Gt(Ct,be(.026,.011,.052,.004),d.blackSteel,0,-.058,.19),Gt(Ct,new Rn(.009,.0022,6,14),d.blackSteel,.026,-.002,.255,0,Math.PI/2,0),Gt(Ct,new Rt(.0012,.004,.1),d.blackSteel,-.0212,-.01,.22),Gt(Ct,new Rt(.0012,.004,.1),d.blackSteel,.0212,-.01,.22),Gt(ct,new Rt(.0012,.004,.15),d.blackSteel,-.0204,-.008,-.09),Gt(ct,new Rt(.0012,.004,.15),d.blackSteel,.0204,-.008,-.09),Gt(ct,new Rt(.0012,.028,.0014),d.blackSteel,-.0204,-.04,-.145),Gt(ct,new Rt(.0012,.028,.0014),d.blackSteel,.0204,-.04,-.145),Gt(ct,new Rt(.0012,.004,.2),d.blackSteel,-.0267,.008,-.365),Gt(ct,new Rt(.0012,.004,.2),d.blackSteel,.0267,.008,-.365),Gt(ct,new Rt(.0012,.0014,.224),d.receiverMatte,-.0197,.0262,-.108),Gt(ct,new Rt(.0012,.0014,.224),d.receiverMatte,.0197,.0262,-.108),Gt(ct,new Rt(.0016,.0018,.16),d.receiverMatte,-.0202,-.022,-.062),Gt(ct,new Rt(.0016,.0018,.16),d.receiverMatte,.0202,-.022,-.062),Gt(ct,new Rt(.043,.0012,.0022),d.receiverMatte,0,-.085,-.116),Gt(ct,new Rt(.0015,.002,.26),d.receiverMatte,-.0272,.026,-.365),Gt(ct,new Rt(.0015,.002,.26),d.receiverMatte,.0272,.026,-.365),Gt(ct,new Rt(.0015,.002,.26),d.receiverMatte,0,-.036,-.365),Gt(ct,on(.0265,.0275,.275,8,!1),At,0,-.002,-.365,Math.PI/2,0,Math.PI/8),Gt(ct,on(.029,.029,.012,8),d.receiverMatte,0,-.002,-.506,Math.PI/2,0,Math.PI/8),Gt(ct,be(.022,.006,.26,.002),d.receiver,0,-.0315,-.365);const jt=[];for(let Qt=0;Qt<5;Qt++){const ae=-.265-Qt*.048;jt.push({p:[-.0258,-.002,ae]}),jt.push({p:[.0258,-.002,ae]})}for(let Qt=0;Qt<4;Qt++)jt.push({p:[0,-.0305,-.29-Qt*.052],r:[0,0,Math.PI/2]});ks(ct,new Rt(.0045,.014,.03),d.blackSteel,jt),Gt(ct,new Rt(.024,.006,.52),d.receiver,0,.029,-.243);const kt=[];for(let Qt=0;Qt<25;Qt++)kt.push({p:[0,.0345,.008-Qt*.021]});ks(ct,new Rt(.026,.0042,.012),d.receiverMatte,kt),Gt(ct,on(.0093,.0102,.135,18),d.barrelSteel,0,0,-.573,Math.PI/2),Gt(ct,on(.0116,.0116,.007,16),d.blackSteel,0,0,-.545,Math.PI/2),Gt(ct,on(.0112,.0112,.006,16),d.blackSteel,0,0,-.6,Math.PI/2),Gt(ct,be(.024,.028,.042,.004),d.receiverMatte,0,.011,-.505),Gt(ct,on(.0035,.0035,.25,6),d.blackSteel,0,.024,-.38,Math.PI/2),Gt(ct,on(.0148,.0158,.07,16),d.barrelSteel,0,0,-.668,Math.PI/2),Gt(ct,on(.0165,.0165,.006,16),d.blackSteel,0,0,-.636,Math.PI/2),Gt(ct,on(.0152,.0152,.005,16),d.wornSteel,0,0,-.699,Math.PI/2);const B=[];for(let Qt=0;Qt<3;Qt++)B.push({p:[0,0,-.652-Qt*.016]});ks(ct,new Rt(.032,.013,.007),d.blackSteel,B),Gt(ct,on(.0095,.0095,.01,10),d.blackSteel,0,0,-.7035,Math.PI/2),Gt(ct,be(.028,.008,.036,.003),d.receiverMatte,0,.041,-.462),Gt(ct,be(.024,.006,.03,.002),d.receiverMatte,0,.048,-.466),Gt(ct,be(.042,.012,.1,.004),d.receiver,0,.041,-.068),Gt(ct,be(.05,.013,.028,.003),d.receiver,0,.034,-.068),Gt(ct,be(.005,.016,.03,.002),d.receiverMatte,.027,.049,-.06,.35,0,0),Gt(ct,new Rt(.046,.005,.056),d.hoodMatte,0,.0695,-.068),Gt(ct,new Rt(.046,.005,.056),d.hoodMatte,0,.1065,-.068),Gt(ct,new Rt(.005,.042,.056),d.hoodMatte,-.0195,.088,-.068),Gt(ct,new Rt(.005,.042,.056),d.hoodMatte,.0195,.088,-.068),Gt(ct,new Rt(.05,.006,.075),d.hoodMatte,0,.1125,-.079),Gt(ct,new Rt(.042,.0012,.068),d.hoodMatte,0,.1158,-.079);const P=Gt(ct,new ue(.033,.031),d.glass,0,.088,-.0362);P.renderOrder=3,P.userData.noMerge=!0;const tt=Gt(ct,new ue(.032,.03),d.glass,0,.088,-.0965);tt.renderOrder=2,tt.userData.noMerge=!0;const vt=Gt(ct,new ue(.026,.026),d.reticleMat,0,.088,-.0348);vt.renderOrder=5,vt.userData.noMerge=!0,w=vt,ks(ct,on(.0042,.0042,.005,8),d.rubber,[{p:[-.0245,.078,-.052],r:[0,0,Math.PI/2]},{p:[-.0245,.078,-.041],r:[0,0,Math.PI/2]}]),p=new xe;const bt=new K(be(.032,.011,.03,.003),d.receiver);bt.position.set(0,.021,.003);const mt=new K(be(.017,.008,.022,.002),d.receiverMatte);mt.position.set(.02,.021,.007),p.add(bt,mt),u.add(p),v.children.length=0;const Ot=new K(be(.026,.075,.062,.004),At);Ot.position.set(0,-.044,-.004),Ot.rotation.x=.02;const Ut=new K(be(.025,.07,.06,.004),At);Ut.position.set(0,-.104,-.018),Ut.rotation.x=.07;const zt=new K(be(.024,.052,.058,.004),At);zt.position.set(0,-.157,-.038),zt.rotation.x=.14;const te=new K(be(.028,.008,.062,.003),d.rubber);te.position.set(0,-.186,-.05),te.rotation.x=.16,v.add(Ot,Ut,zt,te);const St=[];for(let Qt=0;Qt<3;Qt++)St.push({p:[-.0128,-.07-Qt*.038,-.012-Qt*.01]}),St.push({p:[.0128,-.07-Qt*.038,-.012-Qt*.01]});ks(v,new Rt(.0015,.006,.05),d.rubber,St);const Ft=new Nc([De(.03,-.002,.255),De(.055,-.07,.15),De(.048,-.115,0),De(.012,-.1,-.22),De(-.032,-.04,-.36),De(-.04,-.028,-.43)]);Gt(ct,new yo(Ft,34,.0055,6,!1),d.sling),Gt(ct,new Rn(.008,.0021,6,12),d.wornSteel,.03,-.002,.255,0,Math.PI/2,0),Gt(ct,new Rn(.008,.0021,6,12),d.wornSteel,-.04,-.028,-.43,0,Math.PI/2,0),Gt(ct,be(.01,.018,.026,.002),d.blackSteel,.052,-.075,.105,.3);const re=Gt(ct,new ue(.062,.031),d.stencil,-.0214,-.006,.214,0,-Math.PI/2,0);re.renderOrder=4,re.userData.noMerge=!0;const ne=Gt(ct,new ue(.045,.0225),d.stencil,-.0224,-.098,-.072,0,-Math.PI/2,0);ne.renderOrder=4,ne.userData.noMerge=!0;const qt=[];for(const[Qt,ae,Ae]of[[.015,.051,-.108],[-.015,.051,-.108],[.015,.051,-.03],[-.015,.051,-.03],[-.024,0,-.3],[.024,0,-.3],[-.024,0,-.414],[.024,0,-.414],[.019,-.06,.19],[-.019,-.06,.19]])qt.push({p:[Qt,ae,Ae],r:[0,0,Math.PI/2]});return ks(ct,on(.0024,.0024,.003,6),d.blackSteel,qt),A(ct),{body:ct,stock:Ct}}function A(wt){const At=d.glove,ct=d.gloveDark,Ct=d.glovePad,jt=d.cuff,kt=d.sleeve;Gt(wt,be(.035,.078,.076,.014),At,.032,-.126,.06,-.26,.12,-.16),Gt(wt,be(.013,.056,.028,.007),Ct,.05,-.126,.072,-.2,.1,-.16),Hs(wt,At,De(.04,-.15,.074),De(.058,-.188,.118),.026,.029,9),Hs(wt,jt,De(.053,-.178,.108),De(.064,-.2,.134),.035,.038,10),Hs(wt,kt,De(.062,-.196,.128),De(.15,-.3,.235),.029,.039,12),[-.098,-.116,-.134,-.152].forEach((P,tt)=>{const vt=tt*.0035,bt=De(.045+vt,P,.035),mt=De(.018+vt*.6,P-.002,.024),Ot=De(0,P-.005,.008);Oi(wt,At,bt,mt,.018,.021,.007),Oi(wt,ct,mt,Ot,.0165,.019,.007),Gt(wt,be(.014,.016,.013,.006),Ct,.05+vt,P,.043,0,0,.18)}),Oi(wt,At,De(.004,-.101,.03),De(-.026,-.08,.024),.016,.016,.006),Oi(wt,ct,De(-.026,-.08,.024),De(-.03,-.06,.044),.0145,.014,.006)}function y(){const wt=new xe;wt.position.set(0,-.006,-.175);const At=d.glove,ct=d.gloveDark,Ct=d.glovePad,jt=d.cuff,kt=d.sleeve;Gt(wt,be(.03,.066,.08,.013),At,-.043,-.016,-.357,.06,.04,.28),Gt(wt,be(.013,.05,.05,.007),Ct,-.061,-.02,-.357,.06,.04,.28),[-.331,-.355,-.379,-.403].forEach(tt=>{const vt=De(-.033,.002,tt),bt=De(-.006,.031,tt+.002),mt=De(.019,.012,tt+.002);Oi(wt,At,vt,bt,.0185,.0215,.007),Oi(wt,ct,bt,mt,.017,.0195,.007),Gt(wt,be(.014,.013,.015,.006),Ct,.006,.0375,tt+.002)}),Oi(wt,At,De(-.028,.018,-.334),De(-.016,.042,-.306),.016,.016,.006),Oi(wt,ct,De(-.016,.042,-.306),De(0,.032,-.286),.0145,.014,.006),Hs(wt,At,De(-.052,-.046,-.33),De(-.076,-.088,-.292),.022,.025,9),Hs(wt,jt,De(-.07,-.078,-.3),De(-.086,-.104,-.272),.029,.032,10),Hs(wt,kt,De(-.086,-.104,-.272),De(-.29,-.26,-.2),.016,.024,12);const P=Js(wt);x=new xe,x.position.copy(cl),P.position.copy(cl).multiplyScalar(-1),x.add(P),u.add(x)}const rt=D("black"),S=Js(rt.body);S.name="rifle",u.add(S),b=Js(rt.stock),b.name="stock",u.add(b);const z=Js(v);c.add(z),y(),u.scale.setScalar(fu),u.traverse(wt=>{wt.isMesh&&wt.material===d.polymer&&V.push(wt)});const nt=i&&i.sprites?i.sprites:null,q=new Ei({map:nt?nt.flash:null,color:16773586,transparent:!0,blending:cn,depthWrite:!1,depthTest:!1,toneMapped:!1,opacity:0}),j=new ki(q);j.scale.setScalar(.34),j.position.copy(C.position),j.visible=!1,u.add(j);const Y=new Ei({map:nt?nt.glow:null,color:16756838,transparent:!0,blending:cn,depthWrite:!1,depthTest:!1,toneMapped:!1,opacity:0}),W=new ki(Y);W.scale.setScalar(.2),W.position.copy(C.position),W.visible=!1,u.add(W),f.position.copy(C.position),u.add(f);const ht=[];for(let wt=0;wt<2;wt++){const At=new ki(new Ei({map:nt?nt.smoke:null,color:12103842,transparent:!0,depthWrite:!1,toneMapped:!1,opacity:0}));At.visible=!1,e.add(At),ht.push({s:At,life:0,vel:new N})}const lt=new Re(.0034,.0041,.018,6),Dt=new he({color:11569726,metalness:.95,roughness:.28,envMapIntensity:1.4}),yt=[];for(let wt=0;wt<3;wt++){const At=new K(lt,Dt);At.visible=!1,At.rotation.z=Math.PI/2,e.add(At),yt.push({m:At,life:0,vel:new N,rot:new N})}const dt=new N(0,0,-.24).sub(du.clone().multiplyScalar(fu).applyEuler(Da)),et={time:0,ads:0,adsTarget:0,sprint:0,sprintTarget:0,dead:!1,deadAmt:0,bobT:0,speed:0,sway:new Pt,swayTarget:new Pt,recoilPos:new N,recoilVel:new N,recoilRot:new N,recoilRotVel:new N,reloading:!1,reloadT:0,reloadDur:rv,inspectT:0,inspectDur:hu,flashT:0,fov:ol},Lt=new N,k=new wn(0,0,0,"YXZ"),at=c.position.y;function gt(wt=1){if(et.reloading||et.dead)return;et.recoilVel.z+=.85*wt,et.recoilVel.y+=.2*wt,et.recoilVel.x+=(Math.random()-.5)*.12*wt,et.recoilRotVel.x+=1.55*wt,et.recoilRotVel.y+=(Math.random()-.5)*.7*wt,et.recoilRotVel.z+=(Math.random()-.5)*1*wt,et.flashT=.045,j.visible=!0,W.visible=!0,j.material.rotation=Math.random()*Math.PI*2;const At=.24+Math.random()*.14;j.scale.set(At*(.75+Math.random()*.6),At,1),W.scale.setScalar(At*.95),f.intensity=9+Math.random()*5;const ct=ht.find(kt=>kt.life<=0)||ht[0];ct.life=.7,ct.s.visible=!0,u.updateWorldMatrix(!0,!0),C.getWorldPosition(ct.s.position),ct.vel.set((Math.random()-.5)*.3,.08+Math.random()*.1,-.45),ct.s.scale.setScalar(.05),ct.s.material.opacity=.2;const Ct=yt.find(kt=>kt.life<=0)||yt[0];Ct.life=1,Ct.m.visible=!0;const jt=new N(.045,.03,-.07);u.localToWorld(jt),Ct.m.position.copy(jt),Ct.vel.set(1.25+Math.random()*.5,1+Math.random()*.5,.35+Math.random()*.4),Ct.rot.set(Math.random()*8,Math.random()*8,Math.random()*8)}function Mt(){et.reloading||et.dead||(et.reloading=!0,et.reloadT=0)}function Et(){et.inspectT>0||et.reloading||(et.inspectT=hu)}function Bt(wt){const At=d.furnitureFor(wt);for(const ct of V)ct.material=At}function Zt(wt){n.aspect=wt,n.updateProjectionMatrix()}function Xt(wt,At,ct,Ct,jt){At.addScaledVector(wt,-ct*jt),At.addScaledVector(At,-Ct*jt),wt.addScaledVector(At,jt)}function ie(wt,At={}){wt=Math.min(wt,.05),et.time+=wt,et.speed=At.speed??0,et.dead=!!At.dead,et.sprintTarget=At.sprinting?1:0,et.adsTarget=At.ads&&!At.sprinting&&!et.reloading&&!et.dead?1:0,et.reloading&&(et.reloadT+=wt,et.reloadT>=et.reloadDur&&(et.reloading=!1,et.reloadT=0)),et.inspectT>0&&(et.inspectT=Math.max(0,et.inspectT-wt)),et.ads+=(et.adsTarget-et.ads)*(1-Math.pow(35e-6,wt)),Math.abs(et.adsTarget-et.ads)<1e-4&&(et.ads=et.adsTarget),et.sprint+=(et.sprintTarget-et.sprint)*(1-Math.pow(2e-4,wt)),et.deadAmt+=((et.dead?1:0)-et.deadAmt)*(1-Math.pow(5e-4,wt)),At.lookDX!==void 0&&(et.swayTarget.x=qe.clamp(-At.lookDX*6e-4,-.05,.05),et.swayTarget.y=qe.clamp(At.lookDY*6e-4,-.05,.05)),et.sway.x+=(et.swayTarget.x-et.sway.x)*(1-Math.pow(.002,wt)),et.sway.y+=(et.swayTarget.y-et.sway.y)*(1-Math.pow(.002,wt)),et.swayTarget.multiplyScalar(1-wt*5);const ct=et.ads,Ct=ct*ct*(3-2*ct),jt=1-Ct,kt=et.sprint,B=et.deadAmt,P=qe.clamp(et.speed,0,1.4);et.bobT+=wt*(7.4+P*3.2);const tt=P*.0085*jt*(1+kt*.7),vt=Math.sin(et.bobT)*tt,bt=-Math.abs(Math.cos(et.bobT))*tt*.85,mt=et.time*1.35,Ot=.0024*jt*jt,Ut=Math.sin(mt)*Ot,zt=Math.sin(mt*.63+.9)*Ot*.6,te=et.sway.x*(1-.75*Ct),St=et.sway.y*(1-.75*Ct),Ft=.02*kt,re=-.055*kt,ne=.08*kt,qt=.2*kt,Qt=.5*kt,ae=-.3*kt;let Ae=0,Q=0,Yt=0,_t=0,Tt=0,Vt=0,Wt=0,ge=0,Ee=!0,ke=0,me=0;if(et.reloading){const I=qe.clamp(et.reloadT/et.reloadDur,0,1),G=Dr(0,.13,I)*(1-Dr(.86,1,I));if(_t=.32*G,Tt=-.4*G,Vt=.6*G,Ae=.03*G,Q=-.03*G,Yt=.055*G,I>=.16&&I<.36){const X=cv((I-.16)/.2);Wt=-.42*X,ge=-.7*X}else if(I>=.36&&I<.5)Wt=-.44,ge=-.8,Ee=!1;else if(I>=.5&&I<.74){const X=lv((I-.5)/.24);Wt=-.36*(1-X),ge=-.3*(1-X)}if(me=Dr(.1,.2,I)*(1-Dr(.68,.82,I)),I>.78&&I<.9){const X=(I-.78)/.12;ke=Math.sin(X*Math.PI)*.052}}c.position.y=at+Wt,c.rotation.x=ge;for(const I of c.children)I.visible=Ee;if(p&&(p.position.z=ke),x&&(x.position.copy(cl),x.position.x+=.035*me,x.position.y+=.012*me,x.position.z+=.3*me,x.rotation.set(.15*me,-.25*me,-.2*me)),b&&(b.visible=et.ads<.65),w){const I=et.ads>=.8;w.visible=I,d.reticleMat.opacity=I?.95*Dr(.8,.92,et.ads):0}let je=0,nn=0,bn=0,oi=0;if(et.inspectT>0){const I=1-et.inspectT/et.inspectDur,G=Math.pow(Math.sin(Math.PI*qe.clamp(I*1.04,0,1)),.75);nn=G*1.2,je=G*.36,bn=G*.3,oi=G*.022}const sn=wt>.02?2:1,Tn=wt/sn;for(let I=0;I<sn;I++)Xt(et.recoilPos,et.recoilVel,165,17,Tn),Xt(et.recoilRot,et.recoilRotVel,150,16,Tn);Lt.copy(av).lerp(dt,Ct),Lt.x+=vt+zt+te+Ft+Ae,Lt.y+=bt+Ut+St+re+Q+oi*.4-B*.22,Lt.z+=ne+Yt+B*.05,Lt.x+=et.recoilPos.x,Lt.y+=et.recoilPos.y,Lt.z+=et.recoilPos.z,k.set(qe.lerp(ll.x,Da.x,Ct)+St*1.5+qt+_t+je+et.recoilRot.x-B*.5,qe.lerp(ll.y,Da.y,Ct)+te*1.5+Qt+Tt+nn+et.recoilRot.y,qe.lerp(ll.z,Da.z,Ct)+ae+Vt+bn+et.recoilRot.z+B*.35),u.position.copy(Lt),u.rotation.copy(k);const jn=qe.lerp(ol,sv,Ct);if(Math.abs(jn-n.fov)>.01&&(n.fov=jn,n.updateProjectionMatrix()),et.fov=n.fov,et.flashT>0){et.flashT-=wt;const I=Math.max(0,et.flashT/.045);q.opacity=I,Y.opacity=I*.75,et.flashT<=0&&(j.visible=!1,W.visible=!1)}else j.visible=!1,W.visible=!1;f.intensity*=Math.pow(2e-5,wt),f.intensity<.05&&(f.intensity=0);for(const I of ht)I.life>0&&(I.life-=wt,I.s.position.addScaledVector(I.vel,wt),I.vel.y+=.3*wt,I.vel.multiplyScalar(1-wt*1.2),I.s.scale.setScalar(.05+(.7-I.life)*.14),I.s.material.opacity=Math.max(0,I.life/.7)*.18,I.life<=0&&(I.s.visible=!1));for(const I of yt)I.life>0&&(I.life-=wt,I.vel.y-=9.8*wt,I.m.position.addScaledVector(I.vel,wt),I.m.rotation.x+=I.rot.x*wt,I.m.rotation.y+=I.rot.y*wt,I.m.rotation.z+=I.rot.z*wt,I.life<=0&&(I.m.visible=!1))}function $(){let wt=0,At=0,ct=0;const Ct=new Set;e.traverse(St=>{St.isSprite&&At++,St.isMesh&&(wt++,St.material&&Ct.add(St.material.uuid),St.geometry&&St.geometry.index?ct+=St.geometry.index.count/3:St.geometry&&St.geometry.attributes.position&&(ct+=St.geometry.attributes.position.count/3))}),n.updateMatrixWorld(!0),u.updateWorldMatrix(!0,!0);const jt=du.clone().applyMatrix4(u.matrixWorld),kt=jt.clone().project(n),B=ov.clone().applyMatrix4(u.matrixWorld),P=new Pt(1e9,1e9),tt=new Pt(-1e9,-1e9),vt=new N,bt=new N,mt=new N;u.traverse(St=>{if(!St.isMesh||!St.geometry||!St.geometry.attributes.position)return;const Ft=St.geometry.attributes.position;for(let re=0;re<Ft.count;re++)vt.fromBufferAttribute(Ft,re).applyMatrix4(St.matrixWorld),bt.copy(vt).applyMatrix4(n.matrixWorldInverse),!(bt.z>-.03)&&(mt.copy(vt).project(n),!(mt.x<-1.4||mt.x>1.4||mt.y<-1.4||mt.y>1.4)&&(P.x=Math.min(P.x,mt.x),P.y=Math.min(P.y,mt.y),tt.x=Math.max(tt.x,mt.x),tt.y=Math.max(tt.y,mt.y)))});const Ot=St=>+((St+1)*50).toFixed(1),Ut=+((tt.x-P.x)*50).toFixed(1),zt=+((tt.y-P.y)*50).toFixed(1),te=P.x<0&&tt.x>0&&P.y<0&&tt.y>0;return{coverage:{widthPct:Ut,heightPct:zt,x:[Ot(P.x),Ot(tt.x)],y:[Ot(P.y),Ot(tt.y)]},coversCentre:te,meshes:wt,sprites:At,materialDraws:Ct.size,tris:Math.round(ct),ads:+et.ads.toFixed(4),fov:+n.fov.toFixed(2),reticleNDC:[+kt.x.toFixed(4),+kt.y.toFixed(4)],reticleZ:+jt.z.toFixed(4),stockZ:+B.z.toFixed(4),reticleVisible:w?w.visible:null,stockVisible:b?b.visible:null,gunPos:u.position.toArray().map(St=>+St.toFixed(4)),gunRot:[u.rotation.x,u.rotation.y,u.rotation.z].map(St=>+St.toFixed(4))}}return{scene:e,camera:n,root:m,gun:u,update:ie,fire:gt,startReload:Mt,inspect:Et,setWeapon:Bt,setAspect:Zt,state:et,get reloading(){return et.reloading},get adsAmount(){return et.ads},_debug:$,muzzleWorld(wt,At=new N){const ct=this.muzzleNDC(new Pt);wt.updateMatrixWorld(!0);const Ct=new N(ct.x,ct.y,.5).unproject(wt).sub(wt.position).normalize();return At.copy(wt.position).addScaledVector(Ct,1),At},muzzleNDC(wt=new Pt){u.updateWorldMatrix(!0,!0);const At=new N;return C.getWorldPosition(At),n.updateMatrixWorld(!0),At.project(n),wt.set(At.x,At.y),wt}}}const Ia=new N(44,16,44);function hv(i,t){const e=new xe;e.name="atmosphere",i.add(e);const n=i.fog,s=n?n.color:new Jt(6116939),r=n?n.density:.0092,a=new N(.42,.3,-.86).normalize(),o=new Jt(1,.86,.68);try{const A=window.__game;A&&A.engine&&A.engine.sky&&(A.engine.sky.sunDir&&a.copy(A.engine.sky.sunDir),A.engine.sky.sunColor&&o.copy(A.engine.sky.sunColor))}catch{}const l=1100,h=new Ye,f=new Float32Array(l*3),m=new Float32Array(l),u=new Float32Array(l);for(let A=0;A<l;A++)f[A*3]=(Math.random()-.5)*Ia.x,f[A*3+1]=Math.random()*Ia.y,f[A*3+2]=(Math.random()-.5)*Ia.z,m[A]=Math.random()*6.2831853,u[A]=.004+Math.pow(Math.random(),3)*.022;h.setAttribute("position",new Ve(f,3)),h.setAttribute("aPhase",new Ve(m,1)),h.setAttribute("aSize",new Ve(u,1)),h.boundingSphere=new Kn(new N,1e4);const d=new Ke({uniforms:{uTime:{value:0},uSunDir:{value:a.clone()},uSunColor:{value:o.clone()},uFogDensity:{value:r},uPixelRatio:{value:Math.min(window.devicePixelRatio||1,1.5)},uBox:{value:Ia.clone()}},vertexShader:`
      attribute float aPhase;
      attribute float aSize;
      uniform float uTime;
      uniform vec3 uSunDir;
      uniform vec3 uSunColor;
      uniform float uFogDensity;
      uniform float uPixelRatio;
      uniform vec3 uBox;
      varying vec3 vColor;
      varying float vAlpha;

      void main(){
        vec3 cam = cameraPosition;
        float ph = aPhase;
        vec3 p = position;
        // slow breeze + individual bob (world space, independent of camera)
        p.x += sin(uTime * 0.21 + ph * 1.7) * 0.85 + uTime * 0.11;
        p.y += sin(uTime * 0.14 + ph * 2.3) * 0.28 + uTime * 0.035;
        p.z += cos(uTime * 0.18 + ph * 1.1) * 0.85 + uTime * 0.06;

        // wrap around a grid locked to the camera so motes stay around the player
        vec3 rel = mod(p - cam + uBox * 0.5, uBox) - uBox * 0.5;
        vec3 world = cam + rel;

        vec4 mv = modelViewMatrix * vec4(world, 1.0);
        gl_Position = projectionMatrix * mv;
        float depth = max(0.15, -mv.z);
        float px = aSize * uPixelRatio * 450.0 * projectionMatrix[1][1] / depth;
        gl_PointSize = clamp(px, 0.9, 5.0);

        float dist = length(rel);
        float nearFade = smoothstep(0.7, 2.6, dist);
        float farFade = 1.0 - smoothstep(13.0, 21.0, dist);
        float twinkle = 0.55 + 0.45 * sin(uTime * 1.9 + ph * 3.7);
        vec3 viewDir = normalize(world - cam);
        float shaft = pow(max(0.0, dot(viewDir, uSunDir)), 6.0);
        float fogF = 1.0 - exp(-pow(uFogDensity * depth, 2.0));

        vAlpha = nearFade * farFade * twinkle * (0.10 + 0.85 * shaft) * (1.0 - fogF * 0.7);
        vColor = mix(vec3(0.86, 0.80, 0.70), uSunColor * 1.6, shaft);
      }`,fragmentShader:`
      varying vec3 vColor;
      varying float vAlpha;
      void main(){
        vec2 d = gl_PointCoord - 0.5;
        float r = length(d);
        float a = smoothstep(0.5, 0.02, r);
        a *= a;
        if (a * vAlpha < 0.002) discard;
        gl_FragColor = vec4(vColor, a * vAlpha);
      }`,transparent:!0,depthWrite:!1,depthTest:!0,blending:cn}),c=new ao(h,d);c.frustumCulled=!1,c.renderOrder=1,e.add(c);const v=46,p=30,x=new Re(v,v,p,64,1,!0);x.boundingSphere=new Kn(new N,1e4);const w=new Ke({uniforms:{uTime:{value:0},uSunDir:{value:a.clone()},uSunColor:{value:o.clone()},uDensity:{value:.085},uFogColor:{value:s.clone()}},vertexShader:`
      uniform float uTime;
      varying float vH;
      varying vec3 vWorld;
      varying float vAng;
      void main(){
        vec3 p = position;
        vec3 cam = cameraPosition;
        vec3 world = vec3(cam.x + p.x, (cam.y - 1.7) + (p.y + ${(p*.5).toFixed(1)}), cam.z + p.z);
        world.y += sin(uTime * 0.05) * 0.35;
        vWorld = world;
        vH = p.y + ${(p*.5).toFixed(1)};
        vAng = atan(p.x, p.z);
        gl_Position = projectionMatrix * viewMatrix * vec4(world, 1.0);
      }`,fragmentShader:`
      uniform float uTime;
      uniform vec3 uSunDir;
      uniform vec3 uSunColor;
      uniform float uDensity;
      uniform vec3 uFogColor;
      varying float vH;
      varying vec3 vWorld;
      varying float vAng;
      void main(){
        float h = max(vH, 0.0);
        // strata: broad density bands that breathe + fine heat waviness
        float band = 0.58 + 0.42 * sin(h * 0.52 + vAng * 1.4 - uTime * 0.05);
        band *= 0.88 + 0.12 * sin(h * 2.1 + vAng * 4.0 + uTime * 0.9);
        float low = exp(-h * 0.30);
        float vertical = smoothstep(0.0, 2.0, vH) * (1.0 - smoothstep(8.0, 23.0, vH));
        float a = uDensity * (0.30 + 1.05 * low) * band * vertical;
        vec3 dir = normalize(vWorld - cameraPosition);
        float sun = max(0.0, dot(dir, uSunDir));
        vec3 col = mix(uFogColor * 0.85, uSunColor * 1.35, pow(sun, 2.2));
        col += uSunColor * pow(sun, 10.0) * 0.5;
        gl_FragColor = vec4(col, a);
      }`,transparent:!0,depthWrite:!1,depthTest:!0,side:fn,blending:cn}),b=new K(x,w);b.frustumCulled=!1,b.renderOrder=1,e.add(b);let C=0;function V(A){C+=A,d.uniforms.uTime.value=C,w.uniforms.uTime.value=C,d.uniforms.uPixelRatio.value=Math.min(window.devicePixelRatio||1,1.5)}function D(A){w.uniforms.uDensity.value=.085*A}return{update:V,setIntensity:D,group:e,motes:c,haze:b}}const Wn=900,fv=224,La=30,ul=180,hl=48,fl=48,dv=4,pu=2,Ua=64,Nn={PUFF:0,STAR:1,GLOW:2,FIRE:3},ft=(i,t)=>i+Math.random()*(t-i),oe=()=>Math.random()*2-1,$e=new N,ei=new N,Mn=new N,An=new Jt,Gs=new In,Vs=new In,Xn=new Pe,Ws=new N,za=new N,mu=new N;new N(0,1,0);const gu=new N(0,0,1),Na=new N(0,1,0);function pv(){try{const i=window.__game;return i&&i.engine&&i.engine.camera||null}catch{return null}}function mv(i){const n=document.createElement("canvas");n.width=n.height=512;const s=n.getContext("2d");s.clearRect(0,0,512,512);const r=(d,c)=>{if(!c)return;const v=d%2*256,p=Math.floor(d/2)*256;s.save(),s.beginPath(),s.rect(v,p,256,256),s.clip(),s.drawImage(c,v,p,256,256),s.restore()},a=i.sprites||{};r(Nn.PUFF,a.smoke&&a.smoke.image),r(Nn.STAR,a.flash&&a.flash.image),r(Nn.GLOW,a.glow&&a.glow.image),r(Nn.FIRE,a.smoke&&a.smoke.image);const o=256,l=256,h=o+256*.5,f=l+256*.5,m=s.createRadialGradient(h,f,2,h,f,256*.33);m.addColorStop(0,"rgba(255,250,235,0.98)"),m.addColorStop(.34,"rgba(255,190,110,0.62)"),m.addColorStop(1,"rgba(255,110,30,0)"),s.save(),s.beginPath(),s.rect(o,l,256,256),s.clip(),s.fillStyle=m,s.beginPath(),s.arc(h,f,256*.33,0,Math.PI*2),s.fill(),s.globalCompositeOperation="destination-out";for(let d=0;d<7;d++){const c=Math.random()*Math.PI*2,v=Math.random()*256*.26,p=h+Math.cos(c)*v,x=f+Math.sin(c)*v,w=6+Math.random()*18,b=s.createRadialGradient(p,x,0,p,x,w);b.addColorStop(0,"rgba(0,0,0,0.55)"),b.addColorStop(1,"rgba(0,0,0,0)"),s.fillStyle=b,s.beginPath(),s.arc(p,x,w,0,Math.PI*2),s.fill()}s.restore(),s.globalCompositeOperation="source-over";const u=new gs(n);return u.colorSpace=pn,u.wrapS=u.wrapT=Si,u.minFilter=Fn,u.magFilter=Fn,u.generateMipmaps=!1,u.needsUpdate=!0,u}function gv(i,t){const e=new xe;e.name="fx",i.add(e);const n=i.fog,s=n?n.color:new Jt(6116939),r=n?n.density:.0092,a={res:{value:new Pt(1600,900)},fogColor:{value:s.clone()},fogDensity:{value:r}};mv(t);const o=new us(16757107,0,14,2);o.castShadow=!1,e.add(o);const l={light:o,t:0,dur:.06,peak:16},h=new us(16748357,0,30,2);h.castShadow=!1,e.add(h);const f={light:h,t:0,dur:.34,peak:120};function m(_,R){_.peak=R,_.t=_.dur,_.light.intensity=R}function u(_,R,T){const O=new Ye,F=new Float32Array(_*3),g=new Float32Array(_*3),M=new Float32Array(_),U=new Ve(F,3).setUsage(Hn),E=new Ve(g,3).setUsage(Hn),L=new Ve(M,1).setUsage(Hn);O.setAttribute("position",U),O.setAttribute("aColor",E),O.setAttribute("aSize",L),O.boundingSphere=new Kn(new N,1e4);const J=new Ke({uniforms:{uMap:{value:R},uResolution:a.res,uFogDensity:a.fogDensity},vertexShader:`
        attribute vec3 aColor;
        attribute float aSize;
        uniform vec2 uResolution;
        uniform float uFogDensity;
        varying vec3 vColor;
        void main(){
          vec4 mv = modelViewMatrix * vec4(position, 1.0);
          gl_Position = projectionMatrix * mv;
          float depth = max(0.05, -mv.z);
          gl_PointSize = clamp(aSize * 0.5 * uResolution.y * projectionMatrix[1][1] / depth, 1.0, 720.0);
          float fog = 1.0 - exp(-pow(uFogDensity * depth, 2.0));
          vColor = aColor * (1.0 - fog * 0.9);
        }`,fragmentShader:`
        uniform sampler2D uMap;
        varying vec3 vColor;
        void main(){
          vec4 t = texture2D(uMap, gl_PointCoord);
          float a = t.a;
          if (a < 0.004) discard;
          gl_FragColor = vec4(vColor * t.rgb, 1.0);
        }`,transparent:!0,depthWrite:!1,depthTest:!0,blending:cn}),st=new ao(O,J);st.frustumCulled=!1,st.renderOrder=T,e.add(st);const it=new Float32Array(_*3),pt=new Float32Array(_*3),ot=new Float32Array(_),xt=new Float32Array(_),ut=new Float32Array(_),It=new Float32Array(_),Nt=new Float32Array(_),Ht=new Float32Array(_),le=new Float32Array(_),ee=new Float32Array(_),$t=new Float32Array(_),Ue=new Float32Array(_);let _e=0;function Ln(de){const we=_e;_e=(_e+1)%_;const se=we*3;F[se]=de.x,F[se+1]=de.y,F[se+2]=de.z,it[se]=de.vx||0,it[se+1]=de.vy||0,it[se+2]=de.vz||0,ot[we]=xt[we]=de.life,ut[we]=de.size,It[we]=de.sizeEnd!==void 0?de.sizeEnd:de.size,Nt[we]=de.alpha!==void 0?de.alpha:.8,Ht[we]=de.fadeIn!==void 0?de.fadeIn:.08,le[we]=de.fadePow!==void 0?de.fadePow:1.2,ee[we]=de.drag!==void 0?de.drag:.8,$t[we]=de.rise!==void 0?de.rise:0,Ue[we]=de.grav!==void 0?de.grav:0,An.setHex(de.color!==void 0?de.color:16777215);const dn=de.intensity!==void 0?de.intensity:1;pt[se]=An.r*dn,pt[se+1]=An.g*dn,pt[se+2]=An.b*dn,g[se]=0,g[se+1]=0,g[se+2]=0,M[we]=de.size}function Di(de){for(let we=0;we<_;we++){if(ot[we]<=0)continue;const se=we*3;if(ot[we]-=de,ot[we]<=0){ot[we]=0,g[se]=0,g[se+1]=0,g[se+2]=0,M[we]=0;continue}const dn=1-ot[we]/xt[we],gr=1-(1-dn)*(1-dn);M[we]=ut[we]+(It[we]-ut[we])*gr;const En=Ht[we]>0?Math.min(1,dn/Ht[we]):1,Xi=Nt[we]*En*Math.pow(1-dn,le[we]);g[se]=pt[se]*Xi,g[se+1]=pt[se+1]*Xi,g[se+2]=pt[se+2]*Xi;const vr=Math.max(0,1-ee[we]*de);it[se]*=vr,it[se+1]=it[se+1]*vr+$t[we]*de,it[se+2]*=vr,it[se+1]-=Ue[we]*de,F[se]+=it[se]*de,F[se+1]+=it[se+1]*de,F[se+2]+=it[se+2]*de,F[se+1]<.015&&Ue[we]>0&&(F[se+1]=.015,it[se+1]*=-.25,it[se]*=.6,it[se+2]*=.6)}U.needsUpdate=!0,E.needsUpdate=!0,L.needsUpdate=!0}return{spawn:Ln,update:Di}}const d=72,c=[];for(let _=0;_<d;_++){const R=new Ei({map:t.sprites.smoke,color:9406588,transparent:!0,depthWrite:!1,opacity:0}),T=new ki(R);T.visible=!1,T.renderOrder=5,e.add(T),c.push({s:T,life:0,maxLife:1,size0:.1,size1:.4,op:.3,fadeIn:.12,fadePow:1.3,drag:1.4,rise:.3,grav:0,vel:new N})}let v=0;function p(_){const R=c[v];v=(v+1)%d,R.s.visible=!0,R.s.position.set(_.x,_.y,_.z),R.vel.set(_.vx||0,_.vy||0,_.vz||0),R.life=R.maxLife=_.life,R.size0=_.size,R.size1=_.sizeEnd!==void 0?_.sizeEnd:_.size,R.op=_.alpha!==void 0?_.alpha:.3,R.fadeIn=_.fadeIn!==void 0?_.fadeIn:.12,R.fadePow=_.fadePow!==void 0?_.fadePow:1.3,R.drag=_.drag!==void 0?_.drag:1.4,R.rise=_.rise!==void 0?_.rise:.3,R.grav=_.grav!==void 0?_.grav:0,R.s.material.color.setHex(_.color!==void 0?_.color:9406588),R.s.material.rotation=_.rot!==void 0?_.rot:Math.random()*6.2832,R.spin=_.spin!==void 0?_.spin:0,R.s.material.opacity=0,R.s.scale.setScalar(_.size)}function x(_){for(const R of c){if(R.life<=0)continue;if(R.life-=_,R.life<=0){R.life=0,R.s.visible=!1;continue}const T=1-R.life/R.maxLife,O=1-(1-T)*(1-T),F=R.size0+(R.size1-R.size0)*O;R.s.scale.setScalar(F),R.s.material.opacity=R.op*Math.min(1,T/R.fadeIn)*Math.pow(1-T,R.fadePow),R.s.material.rotation+=(R.spin||0)*_;const g=Math.max(0,1-R.drag*_);R.vel.multiplyScalar(g),R.vel.y+=R.rise*_-R.grav*_*.02,R.s.position.addScaledVector(R.vel,_),R.s.position.y<.02&&R.grav>0&&(R.s.position.y=.02,R.vel.y*=-.25)}}const w=u(40,t.sprites.flash,6),b=u(fv,t.sprites.smoke,6),C={spawn(_){_.atlas===Nn.STAR?w.spawn(_):b.spawn(_)},update(_){w.update(_),b.update(_)}},V={spawn(_){p(_)},update(_){x(_)}},D=new Ye,A=new Float32Array(Wn*3),y=new Float32Array(Wn*3),rt=new Float32Array(Wn),S=new Ve(A,3).setUsage(Hn),z=new Ve(y,3).setUsage(Hn),nt=new Ve(rt,1).setUsage(Hn);D.setAttribute("position",S),D.setAttribute("aColor",z),D.setAttribute("aSize",nt),D.boundingSphere=new Kn(new N,1e4);const q=new Ke({uniforms:{uResolution:a.res,uFogDensity:a.fogDensity},vertexShader:`
      attribute vec3 aColor;
      attribute float aSize;
      uniform vec2 uResolution;
      uniform float uFogDensity;
      varying vec3 vColor;
      void main(){
        vec4 mv = modelViewMatrix * vec4(position, 1.0);
        gl_Position = projectionMatrix * mv;
        float depth = max(0.05, -mv.z);
        gl_PointSize = clamp(aSize * 0.5 * uResolution.y * projectionMatrix[1][1] / depth, 1.0, 24.0);
        float fog = 1.0 - exp(-pow(uFogDensity * depth, 2.0));
        vColor = aColor * (1.0 - fog * 0.85);
      }`,fragmentShader:`
      varying vec3 vColor;
      void main(){
        vec2 d = gl_PointCoord - 0.5;
        float r = length(d);
        float core = smoothstep(0.5, 0.02, r);
        float a = core * core;
        if (a < 0.004) discard;
        vec3 col = vColor * (1.0 + 2.4 * smoothstep(0.22, 0.0, r));
        gl_FragColor = vec4(col, 1.0);
      }`,transparent:!0,depthWrite:!1,depthTest:!0,blending:cn}),j=new ao(D,q);j.frustumCulled=!1,j.renderOrder=7,e.add(j);const Y=new Float32Array(Wn*3),W=new Float32Array(Wn*3),ht=new Float32Array(Wn),lt=new Float32Array(Wn),Dt=new Float32Array(Wn),yt=new Float32Array(Wn),dt=new Uint8Array(Wn);let et=0;function Lt(_,R,T,O,F,g,M){M=M||{};const U=et;et=(et+1)%Wn;const E=U*3;A[E]=_,A[E+1]=R,A[E+2]=T,Y[E]=O,Y[E+1]=F,Y[E+2]=g;const L=M.life!==void 0?M.life:ft(.18,.42);ht[U]=lt[U]=L,rt[U]=(M.width!==void 0?M.width:.015)*2.6,Dt[U]=M.grav!==void 0?M.grav:9.8,yt[U]=M.drag!==void 0?M.drag:.5,dt[U]=M.bounce===!1?0:1,An.setHex(M.color!==void 0?M.color:16763778);const J=M.intensity!==void 0?M.intensity:1;W[E]=An.r*J,W[E+1]=An.g*J,W[E+2]=An.b*J}function k(_){for(let R=0;R<Wn;R++){if(ht[R]<=0)continue;const T=R*3;if(ht[R]-=_,ht[R]<=0){ht[R]=0,y[T]=0,y[T+1]=0,y[T+2]=0,rt[R]=0;continue}Y[T+1]-=Dt[R]*_;const O=Math.max(0,1-yt[R]*_);Y[T]*=O,Y[T+2]*=O,A[T]+=Y[T]*_,A[T+1]+=Y[T+1]*_,A[T+2]+=Y[T+2]*_,dt[R]&&A[T+1]<.02&&(A[T+1]=.02,Y[T+1]*=-.32,Y[T]*=.55,Y[T+2]*=.55);const F=ht[R]/lt[R],g=at(0,.12,1-F)*Math.pow(F,.6);y[T]=W[T]*g,y[T+1]=W[T+1]*g,y[T+2]=W[T+2]*g}S.needsUpdate=!0,z.needsUpdate=!0,nt.needsUpdate=!0}function at(_,R,T){const O=Math.max(0,Math.min(1,(T-_)/(R-_)));return O*O*(3-2*O)}const gt=new Ye,Mt=4,Et=new Float32Array(La*Mt*3),Bt=new Float32Array(La*Mt*3),Zt=new Ve(Et,3).setUsage(Hn),Xt=new Ve(Bt,3).setUsage(Hn);gt.setAttribute("position",Zt),gt.setAttribute("color",Xt),gt.setDrawRange(0,0),gt.boundingSphere=new Kn(new N,1e4);const ie=new hh({vertexColors:!0,transparent:!0,blending:cn,depthWrite:!1,fog:!1}),$=new Z1(gt,ie);$.frustumCulled=!1,$.renderOrder=7,e.add($);const wt=[];for(let _=0;_<La;_++)wt.push({fx:0,fy:0,fz:0,tx:0,ty:0,tz:0,life:0,max:1,r:1,g:1,b:1});let At=0;function ct(_,R,T){T=T||{};const O=wt[At];At=(At+1)%La,O.fx=_.x,O.fy=_.y,O.fz=_.z,O.tx=R.x,O.ty=R.y,O.tz=R.z;const F=T.life!==void 0?T.life:.07;O.life=O.max=F,An.setHex(T.color!==void 0?T.color:16766880);const g=T.intensity!==void 0?T.intensity:2.2;O.r=An.r*g,O.g=An.g*g,O.b=An.b*g}function Ct(_){let R=0;for(const T of wt){if(T.life<=0)continue;if(T.life-=_,T.life<=0){T.life=0;continue}const O=T.life/T.max,F=Math.min(1,(1-O)*8)*Math.pow(O,.5),g=R*Mt*3;Et[g]=T.fx,Et[g+1]=T.fy,Et[g+2]=T.fz,Et[g+3]=T.tx,Et[g+4]=T.ty,Et[g+5]=T.tz,Et[g+6]=T.fx+(T.tx-T.fx)*.62,Et[g+7]=T.fy+(T.ty-T.fy)*.62,Et[g+8]=T.fz+(T.tz-T.fz)*.62,Et[g+9]=T.tx,Et[g+10]=T.ty,Et[g+11]=T.tz;const M=.95*F,U=3.4*F;for(let E=0;E<6;E+=3)Bt[g+E]=T.r*M,Bt[g+E+1]=T.g*M,Bt[g+E+2]=T.b*M;for(let E=6;E<12;E+=3)Bt[g+E]=T.r*U,Bt[g+E+1]=T.g*U,Bt[g+E+2]=T.b*U;R++}gt.setDrawRange(0,R*Mt),Zt.needsUpdate=!0,Xt.needsUpdate=!0}const jt=new ue(1,1),kt=new Bn({map:t.sprites.hole,transparent:!0,depthWrite:!1,polygonOffset:!0,polygonOffsetFactor:-4,polygonOffsetUnits:-4}),B=new ba(jt,kt,ul);B.instanceMatrix.setUsage(Hn),B.frustumCulled=!1,B.renderOrder=2,e.add(B);let P=0;const tt=new Bn({map:t.sprites.glow,transparent:!0,depthWrite:!1,blending:cn,opacity:.55,polygonOffset:!0,polygonOffsetFactor:-5,polygonOffsetUnits:-5}),vt=new ba(jt,tt,fl);vt.instanceMatrix.setUsage(Hn),vt.frustumCulled=!1,vt.renderOrder=3,e.add(vt);let bt=0;const mt=new Bn({map:t.sprites.blood,transparent:!0,depthWrite:!1,polygonOffset:!0,polygonOffsetFactor:-4,polygonOffsetUnits:-4}),Ot=new ba(jt,mt,hl);Ot.instanceMatrix.setUsage(Hn),Ot.frustumCulled=!1,Ot.renderOrder=2,e.add(Ot);let Ut=0;const zt=new Jt(1,1,1);function te(_,R){Xn.makeScale(0,0,0);for(let T=0;T<R;T++)_.setMatrixAt(T,Xn),_.setColorAt(T,zt);_.instanceMatrix.needsUpdate=!0,_.instanceColor&&(_.instanceColor.needsUpdate=!0)}te(B,ul),te(vt,fl),te(Ot,hl);function St(_,R,T,O,F,g,M,U){za.copy(T).addScaledVector(O,.006),Gs.setFromUnitVectors(gu,O),Vs.setFromAxisAngle(O,U!==void 0?U:Math.random()*Math.PI*2),Gs.premultiply(Vs),Ws.set(F,g,1),Xn.compose(za,Gs,Ws),_.setMatrixAt(R,Xn),M&&(An.setHex(M),_.setColorAt(R,An),_.instanceColor&&(_.instanceColor.needsUpdate=!0)),_.instanceMatrix.needsUpdate=!0}function Ft(_,R,T,O){O=O||"hole";const F=R||Na;if(O==="blood"||O==="bloodfloor"){const g=Ut;Ut=(Ut+1)%hl,St(Ot,g,_,O==="bloodfloor"?Na:F,T*ft(.85,1.15),T*ft(.85,1.15),void 0,Math.random()*6.28)}else if(O==="scrape"){const g=bt;bt=(bt+1)%fl,Mn.copy(F).cross(Na),Mn.lengthSq()<.01&&Mn.set(1,0,0),Mn.normalize(),ei.copy(F).cross(Mn).normalize(),Gs.setFromUnitVectors(gu,F),Vs.setFromAxisAngle(F,Math.random()*Math.PI*2),Gs.premultiply(Vs),za.copy(_).addScaledVector(F,.008),Ws.set(T*ft(1.8,2.6),T*.35,1),Xn.compose(za,Gs,Ws),vt.setMatrixAt(g,Xn),vt.instanceMatrix.needsUpdate=!0}else{const g=P;P=(P+1)%ul,St(B,g,_,F,T,T,O==="metal"?13160664:O==="wood"?10254930:16777215,Math.random()*6.28)}}const re=new ur(.8,1,96,1);re.rotateX(-Math.PI/2);const ne=new ur(.35,1,72,1);ne.rotateX(-Math.PI/2);const qt=[];for(let _=0;_<dv;_++){const R=_>=2,T=new Ke({uniforms:{uColor:{value:new Jt(R?12168343:16767142)},uAlpha:{value:0},uInner:{value:R?.35:.8},uOuter:{value:1}},vertexShader:`
        varying float vR;
        void main(){ vR = length(position.xz); gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`,fragmentShader:`
        uniform vec3 uColor; uniform float uAlpha; uniform float uInner; uniform float uOuter;
        varying float vR;
        void main(){
          float band = (uOuter - uInner);
          float a = smoothstep(uInner, uInner + band * 0.45, vR) * (1.0 - smoothstep(uOuter - band * 0.55, uOuter, vR));
          if (a * uAlpha < 0.003) discard;
          gl_FragColor = vec4(uColor, a * uAlpha);
        }`,transparent:!0,depthWrite:!1,depthTest:!0,side:ln,blending:R?hs:cn}),O=new K(R?ne:re,T);O.visible=!1,O.frustumCulled=!1,O.renderOrder=4,e.add(O),qt.push({mesh:O,mat:T,life:0,max:1,r0:0,r1:1,a0:.5,y:0})}let Qt=0;function ae(_,R,T,O,F,g,M,U){const E=U?2:0;let L=null;for(let J=0;J<2;J++){const st=qt[E+(Qt+J)%2];if(!st||st.life<=0){L=st;break}}L&&(Qt=(Qt+1)%2,L.mesh.visible=!0,L.mesh.position.set(_,R,T),L.life=L.max=g,L.r0=O,L.r1=F,L.a0=M,L.mesh.scale.setScalar(O),L.mat.uniforms.uAlpha.value=M)}function Ae(_){for(const R of qt){if(R.life<=0)continue;if(R.life-=_,R.life<=0){R.life=0,R.mesh.visible=!1;continue}const T=1-R.life/R.max,O=1-Math.pow(1-T,2.4);R.mesh.scale.setScalar(R.r0+(R.r1-R.r0)*O),R.mat.uniforms.uAlpha.value=R.a0*Math.pow(1-T,1.8)*Math.min(1,T*12)}}const Q=new Ci(1,32,20),Yt=[];for(let _=0;_<pu;_++){const R=new Ke({uniforms:{uColor:{value:new Jt(16767406)},uAlpha:{value:0}},vertexShader:`
        varying vec3 vN; varying vec3 vV;
        void main(){
          vec4 mv = modelViewMatrix * vec4(position, 1.0);
          vN = normalize(normalMatrix * normal);
          vV = normalize(-mv.xyz);
          gl_Position = projectionMatrix * mv;
        }`,fragmentShader:`
        uniform vec3 uColor; uniform float uAlpha;
        varying vec3 vN; varying vec3 vV;
        void main(){
          float f = pow(1.0 - abs(dot(vN, vV)), 3.0);
          if (f * uAlpha < 0.003) discard;
          gl_FragColor = vec4(uColor, f * uAlpha);
        }`,transparent:!0,depthWrite:!1,depthTest:!0,blending:cn}),T=new K(Q,R);T.visible=!1,T.frustumCulled=!1,T.renderOrder=4,e.add(T),Yt.push({mesh:T,mat:R,life:0,max:1,r0:.3,r1:4,a0:.3})}let _t=0;function Tt(_,R,T,O,F,g,M){const U=Yt[_t];_t=(_t+1)%pu,U.mesh.visible=!0,U.mesh.position.set(_,R,T),U.life=U.max=g,U.r0=O,U.r1=F,U.a0=M,U.mesh.scale.setScalar(O),U.mat.uniforms.uAlpha.value=0}function Vt(_){for(const R of Yt){if(R.life<=0)continue;if(R.life-=_,R.life<=0){R.life=0,R.mesh.visible=!1;continue}const T=1-R.life/R.max,O=1-Math.pow(1-T,3);R.mesh.scale.setScalar(R.r0+(R.r1-R.r0)*O),R.mat.uniforms.uAlpha.value=R.a0*Math.pow(1-T,2.2)*Math.min(1,T*14)}}const Wt=new Mo(1,0),ge=new he({color:3814702,roughness:.95,metalness:.05}),Ee=new ba(Wt,ge,Ua);Ee.instanceMatrix.setUsage(Hn),Ee.frustumCulled=!1,Ee.castShadow=!1,Ee.receiveShadow=!1,e.add(Ee);const ke=[];for(let _=0;_<Ua;_++)ke.push({p:new N,v:new N,q:new In,av:new N,size:new N,life:0,max:1}),Xn.makeScale(0,0,0),Ee.setMatrixAt(_,Xn);Ee.instanceMatrix.needsUpdate=!0;let me=0;function je(_,R,T,O,F){const g=ke[me];me=(me+1)%Ua,g.p.set(_,R,T),$e.set(oe(),ft(.2,1),oe()).normalize().multiplyScalar(O*ft(.35,1)),g.v.copy($e).setY(Math.abs($e.y)*ft(.6,1.4)+ft(1,4)),g.q.setFromAxisAngle($e.set(oe(),oe(),oe()).normalize(),Math.random()*6.28),g.av.set(oe()*14,oe()*14,oe()*14);const M=F*ft(.4,1.3);g.size.set(M*ft(.6,1.6),M*ft(.4,1),M*ft(.6,1.4)),g.life=g.max=ft(1.1,2.4)}function nn(_){let R=!1;for(let T=0;T<Ua;T++){const O=ke[T];if(O.life<=0)continue;if(R=!0,O.life-=_,O.life<=0){Xn.makeScale(0,0,0),Ee.setMatrixAt(T,Xn);continue}O.v.y-=16*_,O.p.addScaledVector(O.v,_),O.p.y<.03&&(O.p.y=.03,O.v.y*=-.28,O.v.x*=.62,O.v.z*=.62,O.av.multiplyScalar(.6)),mu.copy(O.av).normalize(),Vs.setFromAxisAngle(mu,O.av.length()*_),O.q.premultiply(Vs);const F=Math.min(1,O.life/.35);Ws.copy(O.size).multiplyScalar(F),Xn.compose(O.p,O.q,Ws),Ee.setMatrixAt(T,Xn)}R&&(Ee.instanceMatrix.needsUpdate=!0)}let bn=null;try{bn=hv(i,t)}catch(_){console.warn("atmosphere init failed",_)}const oi=new N;function sn(_,R){R=R||{};const T=pv();$e.set(0,0,-1),T&&T.getWorldDirection($e);const O=R.scale!==void 0?R.scale:ft(.88,1.12),F=T?_.distanceTo(T.position)<3.2:!0;oi.copy(_),l.light.position.set(_.x,_.y,_.z),m(l,(F?7.5:6)*O),l.dur=.048,l.light.distance=F?8:11;const g=_.x,M=_.y,U=_.z;C.spawn({x:g,y:M,z:U,size:.052*O,sizeEnd:.072*O,life:.042,alpha:1,color:16774878,intensity:2.5,atlas:Nn.STAR,drag:9,fadeIn:.015,fadePow:.85}),C.spawn({x:g,y:M,z:U,size:.032*O,sizeEnd:.05*O,life:.056,alpha:.85,color:16751156,intensity:1.5,atlas:Nn.STAR,drag:9,fadeIn:.015,fadePow:1.05});for(let E=0;E<3;E++){const L=E*.01;C.spawn({x:g+$e.x*L,y:M+$e.y*L,z:U+$e.z*L,vx:$e.x*.35,vy:$e.y*.35+.05,vz:$e.z*.35,size:(.04+E*.011)*O,sizeEnd:(.052+E*.014)*O,life:.046+E*.008,alpha:.62-E*.08,color:E===0?16766602:16752700,intensity:1.15,atlas:Nn.FIRE,drag:9,fadeIn:.015,fadePow:1})}for(let E=0;E<3;E++){const L=ft(.01,.05);V.spawn({x:g+$e.x*L+oe()*.012,y:M+$e.y*L+ft(-.008,.02),z:U+$e.z*L+oe()*.012,vx:$e.x*ft(.25,.7)+oe()*.08,vy:ft(.05,.22),vz:$e.z*ft(.25,.7)+oe()*.08,size:ft(.022,.036)*O,sizeEnd:ft(.09,.16)*O,life:ft(.38,.72),alpha:ft(.1,.145),color:10130314,drag:ft(2,3),rise:ft(.12,.3),spin:oe()*.4,fadeIn:.05,fadePow:1.4})}for(let E=0;E<5;E++)Mn.set($e.x*ft(.55,1)+oe()*.3,$e.y*ft(.55,1)+oe()*.3+.1,$e.z*ft(.55,1)+oe()*.3).normalize(),Lt(g,M,U,Mn.x*ft(2.2,5.5),Mn.y*ft(2.2,5.5),Mn.z*ft(2.2,5.5),{width:ft(.0035,.007),life:ft(.08,.16),grav:5,drag:1.7,color:E===0?16773320:16755548})}function Tn(_,R,T,O){const F=R?$e.copy(R).normalize():$e.set(0,1,0),g=F.x,M=F.y,U=F.z,E=_.x+g*.02,L=_.y+M*.02,J=_.z+U*.02,st=O===void 0?1:O;ei.set(U,0,-g),ei.lengthSq()<1e-4&&ei.set(1,0,0),ei.normalize(),Mn.copy(F).cross(ei).normalize();const it=ei.x,pt=ei.y,ot=ei.z,xt=Mn.x;Mn.y;const ut=Mn.z;if(T==="flesh")return I(_,F,null);if(T==="metal"){const Nt=Math.round(20*st);for(let Ht=0;Ht<Nt;Ht++){const le=Math.random()<.35,ee=g*(le?.25:ft(.4,1))+it*oe()*.8+xt*oe()*.8,$t=M*(le?.8:ft(.4,1))+(le?ft(.2,.9):oe()*.8),Ue=U*(le?.25:ft(.4,1))+ot*oe()*.8+ut*oe()*.8,_e=ft(3.5,le?12:7.5)*(.7+st*.3);Lt(E,L,J,ee*_e,$t*_e,Ue*_e,{width:ft(.007,.016),life:le?ft(.35,.72):ft(.16,.4),grav:le?11:7,drag:le?.25:.9,color:Math.random()<.55?16774354:Math.random()<.6?16760938:16747054})}for(let Ht=0;Ht<2;Ht++)C.spawn({x:E,y:L,z:J,vx:g*ft(.4,1.2),vy:M*ft(.4,1.2)+.15,vz:U*ft(.4,1.2),size:ft(.05,.09),sizeEnd:ft(.16,.24),life:ft(.1,.2),alpha:.55,color:16756838,intensity:1.5,atlas:Nn.FIRE,drag:3,fadeIn:.02,fadePow:1.1});V.spawn({x:E,y:L,z:J,vx:g*.5+oe()*.2,vy:M*.4+.25,vz:U*.5+oe()*.2,size:.03,sizeEnd:ft(.14,.22),life:ft(.3,.55),alpha:.2,color:9276034,drag:2,rise:.2,fadeIn:.08}),Ft(_,F,ft(.05,.09)*jn(st),"metal"),Ft(_,F,ft(.05,.11)*jn(st),"scrape");return}if(T==="wood"){for(let Nt=0;Nt<7;Nt++){const Ht=ft(1.6,4.2);V.spawn({x:E,y:L,z:J,vx:(g*.6+it*oe()*.9+xt*oe()*.5)*Ht,vy:(M*.6+ft(.2,.8))*Ht,vz:(U*.6+ot*oe()*.9+ut*oe()*.5)*Ht,size:ft(.02,.035),sizeEnd:ft(.03,.05),life:ft(.35,.6),alpha:.95,color:7032624,grav:12,drag:1.2,spin:oe()*4,fadeIn:.01,fadePow:1})}for(let Nt=0;Nt<3;Nt++)V.spawn({x:E,y:L,z:J,vx:g*ft(.5,1.3)+oe()*.4,vy:M*ft(.4,1)+.2,vz:U*ft(.5,1.3)+oe()*.4,size:.05,sizeEnd:ft(.22,.36),life:ft(.3,.55),alpha:.3,color:10127468,drag:2.2,rise:.25,spin:oe()*.6,fadeIn:.08});for(let Nt=0;Nt<4;Nt++)Lt(E,L,J,(g*.6+it*oe())*ft(2,4),(M*.6+ft(.3,.8))*ft(2,4),(U*.6+ot*oe())*ft(2,4),{width:ft(.005,.01),life:ft(.1,.22),grav:9,drag:1.4,color:9069632});Ft(_,F,ft(.05,.09),"wood");return}for(let Nt=0;Nt<4;Nt++)V.spawn({x:E+it*ft(-.02,.02),y:L+pt*ft(-.02,.02),z:J+ot*ft(-.02,.02),vx:g*ft(.5,1.7)+it*oe()*.8+xt*oe()*.6,vy:M*ft(.5,1.7)+ft(.1,.55),vz:U*ft(.5,1.7)+ot*oe()*.8+ut*oe()*.6,size:ft(.05,.1)*(.8+st*.2),sizeEnd:ft(.3,.62)*(.8+st*.2),life:ft(.4,.85)*(.85+st*.15),alpha:ft(.3,.46),color:Nt%3===0?14077888:11840668,drag:ft(1.8,2.8),rise:ft(.15,.4),grav:.4,spin:oe()*.8,fadeIn:.07,fadePow:1.5});V.spawn({x:E,y:L,z:J,vx:g*1.6,vy:M*1.6+.2,vz:U*1.6,size:.035,sizeEnd:.14,life:ft(.22,.34),alpha:.55,color:14998991,drag:3.2,rise:.2,fadeIn:.03,fadePow:1.4});for(let Nt=0;Nt<5;Nt++){const Ht=ft(1.8,4.6);V.spawn({x:E,y:L,z:J,vx:(g*.5+it*oe()*.9+xt*oe()*.5)*Ht,vy:(M*.5+ft(.35,1))*Ht,vz:(U*.5+ot*oe()*.9+ut*oe()*.5)*Ht,size:ft(.014,.03),sizeEnd:ft(.018,.034),life:ft(.3,.55),alpha:.9,color:5064509,grav:13,drag:.9,spin:oe()*6,fadeIn:.01,fadePow:.8})}const It=Math.round(8*st);for(let Nt=0;Nt<It;Nt++){const Ht=ft(2.2,6);Lt(E,L,J,(g*.55+it*oe()*.8+xt*oe()*.5)*Ht,(M*.55+ft(.2,.9))*Ht,(U*.55+ot*oe()*.8+ut*oe()*.5)*Ht,{width:ft(.005,.012),life:ft(.14,.34),grav:9.8,drag:.8,color:Math.random()<.4?16773320:16757610})}Ft(_,F,ft(.06,.125)*jn(st),"hole")}function jn(_){return .85+(_-1)*.25}function I(_,R,T){const O=R?$e.copy(R).normalize():$e.set(0,1,0),F=T?ei.copy(T).normalize():ei.copy(O),g=_.x,M=_.y,U=_.z;for(let E=0;E<5;E++)V.spawn({x:g,y:M,z:U,vx:F.x*ft(.6,2.2)+oe()*.9,vy:F.y*ft(.6,2.2)+ft(.1,.9),vz:F.z*ft(.6,2.2)+oe()*.9,size:ft(.06,.12),sizeEnd:ft(.28,.52),life:ft(.3,.6),alpha:ft(.32,.5),color:E%2===0?3999752:2753797,drag:2.6,rise:.1,grav:2.5,spin:oe()*.6,fadeIn:.05,fadePow:1.6});for(let E=0;E<9;E++)V.spawn({x:g,y:M,z:U,vx:F.x*ft(1.2,3.5)+oe()*1.6,vy:F.y*ft(1.2,3.5)+ft(.2,1.8),vz:F.z*ft(1.2,3.5)+oe()*1.6,size:ft(.012,.026),sizeEnd:ft(.01,.02),life:ft(.35,.6),alpha:.95,color:5048328,grav:14,drag:.6,spin:oe()*5,fadeIn:.01,fadePow:.7});Ft(_,O,ft(.18,.3),"blood"),M>.45&&(Mn.set(g+oe()*.25,.017,U+oe()*.25),Ft(Mn,Na,ft(.35,.62),"bloodfloor"))}function G(_,R){const T=R||1,O=_.x,F=_.y,g=_.z;f.light.position.set(O,F+.35*T,g),m(f,105*T),f.dur=.3,f.light.distance=26*T,C.spawn({x:O,y:F+.2*T,z:g,size:.9*T,sizeEnd:1.6*T,life:.075,alpha:1,color:16777215,intensity:3.6,atlas:Nn.GLOW,drag:4,fadeIn:.01,fadePow:.8}),C.spawn({x:O,y:F+.2*T,z:g,size:1.4*T,sizeEnd:2.4*T,life:.05,alpha:.8,color:16773328,intensity:3,atlas:Nn.STAR,drag:4,fadeIn:.01,fadePow:.8});for(let M=0;M<16;M++){const U=Math.random()*Math.PI*2,E=Math.random(),L=Math.pow(Math.random(),.55)*.55*T,J=Math.cos(U)*Math.sqrt(1-E*.5),st=Math.sin(U)*Math.sqrt(1-E*.5),it=E*.75+.1,pt=M<5;C.spawn({x:O+J*L,y:F+it*L+.15*T,z:g+st*L,vx:J*ft(1.2,4.2)*T,vy:ft(.8,3.2)*T,vz:st*ft(1.2,4.2)*T,size:ft(.32,.62)*T,sizeEnd:ft(1.05,2.1)*T,life:ft(.24,.56)*(.8+T*.2),alpha:ft(.6,.95),color:pt?16773316:Math.random()<.5?16754756:16738844,intensity:pt?2.4:ft(1.3,1.9),atlas:Nn.FIRE,drag:ft(1.4,2.4),rise:ft(.8,2.2),fadeIn:.03,fadePow:1.1})}for(let M=0;M<13;M++){const U=Math.random()*Math.PI*2,E=Math.pow(Math.random(),.6)*.9*T,L=M/13;V.spawn({x:O+Math.cos(U)*E,y:F+ft(.1,.8)*T,z:g+Math.sin(U)*E,vx:Math.cos(U)*ft(.4,1.6),vy:ft(.7,1.9)*T,vz:Math.sin(U)*ft(.4,1.6),size:ft(.8,1.3)*T,sizeEnd:ft(3.4,5.8)*T,life:ft(2.2,3.8),alpha:ft(.72,.92),color:L<.45?4866616:3024930,drag:ft(.7,1.1),rise:ft(.9,1.5),spin:oe()*.5,fadeIn:.08,fadePow:1.35})}for(let M=0;M<9;M++){const U=Math.random()*Math.PI*2;V.spawn({x:O+Math.cos(U)*ft(.1,1)*T,y:Math.max(.06,F-.35*T)+ft(0,.2),z:g+Math.sin(U)*ft(.1,1)*T,vx:Math.cos(U)*ft(1.5,4.5)*T,vy:ft(.1,.9),vz:Math.sin(U)*ft(1.5,4.5)*T,size:ft(.5,.9)*T,sizeEnd:ft(2.4,4.2)*T,life:ft(1.2,2.2),alpha:ft(.42,.6),color:11774100,drag:ft(1,1.7),rise:.15,spin:oe()*.4,fadeIn:.06,fadePow:1.5})}for(let M=0;M<7;M++){const U=Math.random()*Math.PI*2;C.spawn({x:O+Math.cos(U)*ft(0,.7)*T,y:F+ft(.05,.6)*T,z:g+Math.sin(U)*ft(0,.7)*T,vx:Math.cos(U)*ft(.2,.8),vy:ft(.6,1.6),vz:Math.sin(U)*ft(.2,.8),size:ft(.25,.5)*T,sizeEnd:ft(.4,.8)*T,life:ft(.7,1.2),alpha:ft(.35,.6),color:Math.random()<.5?16742946:16756821,intensity:1.2,atlas:Nn.FIRE,drag:1.2,rise:.8,fadeIn:.05,fadePow:1.4})}for(let M=0;M<55;M++){const U=Math.random()*Math.PI*2,E=Math.pow(Math.random(),.7),L=ft(6,26)*T;Lt(O,F+.1,g,Math.cos(U)*L*(1-E*.5),E*L*.9+ft(0,5),Math.sin(U)*L*(1-E*.5),{width:ft(.008,.02),life:ft(.4,1.1),grav:10,drag:ft(.15,.5),color:Math.random()<.35?16773324:Math.random()<.6?16757852:16742948})}for(let M=0;M<16;M++)je(O,F+.15,g,ft(4,13)*T,.055*T);ae(O,Math.max(.06,F-.1),g,.4*T,7.5*T,.32,.75,!1),ae(O,.05,g,.3*T,5.2*T,.7,.5,!0),Tt(O,F+.25*T,g,.5*T,4.8*T,.3,.32)}let X=0;function H(_){X+=_;const R=Math.min(window.devicePixelRatio||1,1.5);if(a.res.value.set(window.innerWidth*R,window.innerHeight*R),k(_),C.update(_),V.update(_),Ct(_),Ae(_),Vt(_),nn(_),l.t>0){l.t-=_;const T=Math.max(0,l.t/l.dur);l.light.intensity=l.peak*T*T,l.t<=0&&(l.light.intensity=0)}if(f.t>0){f.t-=_;const T=Math.max(0,f.t/f.dur);f.light.intensity=f.peak*T*T,f.t<=0&&(f.light.intensity=0)}bn&&bn.update(_)}return{update:H,impact:Tn,blood:I,tracer:ct,muzzleFlash:sn,explosion:G,group:e,addDecal:Ft,atmosphere:bn,get lastMuzzle(){return oi.clone()},get time(){return X}}}function vv(){let i=null,t,e,n,s,r,a=!1,o=!1,l=null,h=null,f=null,m=!1;function u(){if(m)return;const dt=window.AudioContext||window.webkitAudioContext;if(!dt)return;i=new dt,m=!0,e=i.createDynamicsCompressor(),e.threshold.value=-18,e.knee.value=24,e.ratio.value=5,e.attack.value=.004,e.release.value=.22,t=i.createGain(),t.gain.value=.62,t.connect(e).connect(i.destination);const et=Math.floor(i.sampleRate*2.4),Lt=i.createBuffer(2,et,i.sampleRate);for(let gt=0;gt<2;gt++){const Mt=Lt.getChannelData(gt);for(let Et=0;Et<et;Et++){const Bt=Et/et,Zt=Math.pow(1-Bt,2.6),Xt=Et<i.sampleRate*.09?Math.random()>.985?1.4:.15:.25;Mt[Et]=(Math.random()*2-1)*Zt*Xt*.7}}n=i.createConvolver(),n.buffer=Lt,s=i.createGain(),s.gain.value=.3,s.connect(n).connect(t);const k=i.sampleRate*3;r=i.createBuffer(1,k,i.sampleRate);const at=r.getChannelData(0);for(let gt=0;gt<k;gt++)at[gt]=Math.random()*2-1;i.state==="suspended"&&i.resume()}function d(){return i?i.currentTime:0}function c(dt=0,et=.2,Lt=1){const k=i.createGain();k.gain.value=Lt;let at=k;if(dt!==0&&i.createStereoPanner){const gt=i.createStereoPanner();gt.pan.value=Math.max(-1,Math.min(1,dt)),k.connect(gt),at=gt}if(at.connect(t),et>0){const gt=i.createGain();gt.gain.value=et,at.connect(gt).connect(s)}return k}function v({dur:dt=.1,type:et="lowpass",f0:Lt=2e3,f1:k=500,Q:at=.8,gain:gt=.3,pan:Mt=0,send:Et=.15,delay:Bt=0,rate:Zt=1}){if(!i)return;const Xt=d()+Bt,ie=i.createBufferSource();ie.buffer=r,ie.playbackRate.value=Zt,ie.loop=!0;const $=i.createBiquadFilter();$.type=et,$.Q.value=at,$.frequency.setValueAtTime(Lt,Xt),$.frequency.exponentialRampToValueAtTime(Math.max(30,k),Xt+dt);const wt=c(Mt,Et,0);wt.gain.setValueAtTime(1e-4,Xt),wt.gain.exponentialRampToValueAtTime(Math.max(2e-4,gt),Xt+Math.min(.008,dt*.2)),wt.gain.exponentialRampToValueAtTime(1e-4,Xt+dt),ie.connect($).connect(wt),ie.start(Xt),ie.stop(Xt+dt+.02),ie.onended=()=>{try{ie.disconnect(),$.disconnect(),wt.disconnect()}catch{}}}function p({type:dt="sine",f0:et=200,f1:Lt=60,dur:k=.12,gain:at=.3,pan:gt=0,send:Mt=.1,delay:Et=0,curve:Bt=.012}){if(!i)return;const Zt=d()+Et,Xt=i.createOscillator();Xt.type=dt,Xt.frequency.setValueAtTime(et,Zt),Xt.frequency.exponentialRampToValueAtTime(Math.max(20,Lt),Zt+k);const ie=c(gt,Mt,0);ie.gain.setValueAtTime(1e-4,Zt),ie.gain.exponentialRampToValueAtTime(Math.max(2e-4,at),Zt+Bt),ie.gain.exponentialRampToValueAtTime(1e-4,Zt+k),Xt.connect(ie),Xt.start(Zt),Xt.stop(Zt+k+.02),Xt.onended=()=>{try{Xt.disconnect(),ie.disconnect()}catch{}}}function x(dt,et){return dt+Math.random()*(et-dt)}function w(dt=0){if(!i)return;const et=x(.9,1.1);v({dur:.085,type:"lowpass",f0:5200*et,f1:700,Q:.7,gain:.62,pan:dt,send:.42}),v({dur:.028,type:"highpass",f0:2400,f1:5200,Q:.5,gain:.3,pan:dt,send:.25,rate:1.4}),p({type:"sine",f0:130*et,f1:42,dur:.17,gain:.42,pan:dt,send:.18}),v({dur:.012,type:"highpass",f0:3200,f1:2600,gain:.13,pan:dt,send:.05,delay:.006}),v({dur:.34,type:"lowpass",f0:900,f1:180,gain:.11,pan:dt,send:.7,delay:.02})}function b(dt=0,et=40){if(!i)return;const Lt=Math.min(120,et),k=Math.max(.03,1-Lt/140)*.5,at=Math.min(.35,Lt/343);v({dur:.09,type:"lowpass",f0:3200,f1:420,gain:k*.55,pan:dt,send:.5,delay:at}),p({type:"sine",f0:110,f1:40,dur:.16,gain:k*.3,pan:dt,send:.2,delay:at}),v({dur:.25,type:"lowpass",f0:700,f1:150,gain:k*.14,pan:dt,send:.8,delay:at+.02})}function C(dt=0){v({dur:.13,type:"bandpass",f0:900,f1:2600,Q:6,gain:.14,pan:dt,send:.15,rate:1.2})}function V(dt="magOut"){if(i)switch(dt){case"magOut":v({dur:.035,type:"bandpass",f0:2600,f1:1400,Q:3,gain:.2,send:.1}),p({type:"square",f0:210,f1:90,dur:.045,gain:.05,send:.05});break;case"magIn":v({dur:.05,type:"bandpass",f0:1800,f1:900,Q:2.5,gain:.3,send:.18}),p({type:"sine",f0:160,f1:70,dur:.08,gain:.18,send:.08});break;case"charge":v({dur:.09,type:"bandpass",f0:3200,f1:1200,Q:4,gain:.24,send:.12}),v({dur:.04,type:"highpass",f0:4200,f1:3e3,gain:.1,send:.05,delay:.03});break;case"bolt":v({dur:.07,type:"bandpass",f0:2400,f1:900,Q:3,gain:.22,send:.1}),v({dur:.03,type:"highpass",f0:3600,f1:2800,gain:.12,send:.05,delay:.05});break}}function D(){i&&v({dur:.055,type:"bandpass",f0:5200,f1:3400,Q:8,gain:.09,pan:x(-.3,.3),send:.12,delay:x(.22,.4)})}function A(dt="concrete",et=0,Lt=1){i&&(dt==="metal"?(v({dur:.05,type:"bandpass",f0:4200,f1:2600,Q:4,gain:.13*Lt,pan:et,send:.2}),p({type:"triangle",f0:x(1800,2600),f1:900,dur:.09,gain:.05*Lt,pan:et,send:.1}),p({type:"sine",f0:x(900,1200),f1:500,dur:.16,gain:.035*Lt,pan:et,send:.1})):dt==="flesh"?(v({dur:.06,type:"lowpass",f0:900,f1:260,gain:.13*Lt,pan:et,send:.08}),p({type:"sine",f0:120,f1:60,dur:.07,gain:.09*Lt,pan:et,send:.05})):(v({dur:.045,type:"bandpass",f0:3e3,f1:1200,Q:1.2,gain:.14*Lt,pan:et,send:.2}),v({dur:.2,type:"lowpass",f0:700,f1:180,gain:.05*Lt,pan:et,send:.3})))}function y(dt=0){p({type:"sawtooth",f0:x(2400,3600),f1:x(600,900),dur:.3,gain:.05,pan:dt,send:.35})}function rt(dt=0,et=20){if(!i)return;const Lt=Math.max(.1,1-et/90);v({dur:1.1,type:"lowpass",f0:2200,f1:90,gain:.55*Lt,pan:dt,send:.8}),p({type:"sine",f0:78,f1:22,dur:.9,gain:.6*Lt,pan:dt,send:.4}),v({dur:.12,type:"highpass",f0:3600,f1:1200,gain:.22*Lt,pan:dt,send:.5})}function S(dt="concrete",et=1){if(!i)return;v({dur:.075,type:"lowpass",f0:dt==="metal"?2400:900,f1:200,gain:.075*et,pan:x(-.12,.12),send:.12}),dt==="metal"&&v({dur:.04,type:"bandpass",f0:2800,f1:1800,Q:3,gain:.04*et,send:.15})}function z(dt=!1){i&&(p({type:"square",f0:dt?1900:1300,f1:dt?1500:1e3,dur:.035,gain:.055,send:.02}),dt&&p({type:"sine",f0:2800,f1:2200,dur:.05,gain:.03,delay:.01,send:.02}))}function nt(){i&&(p({type:"sine",f0:190,f1:110,dur:.09,gain:.1,send:.08}),p({type:"triangle",f0:2400,f1:1800,dur:.05,gain:.028,send:.03,delay:.01}))}function q(){p({type:"sine",f0:620,f1:480,dur:.05,gain:.04,send:.02})}function j(){p({type:"sine",f0:480,f1:720,dur:.09,gain:.05,send:.05}),p({type:"sine",f0:960,f1:1200,dur:.07,gain:.02,delay:.05,send:.05})}function Y(){p({type:"sine",f0:90,f1:30,dur:1.4,gain:.35,send:.4}),v({dur:1.2,type:"lowpass",f0:900,f1:80,gain:.12,send:.5})}function W(){v({dur:.18,type:"lowpass",f0:500,f1:120,gain:.16,send:.1}),p({type:"sine",f0:70,f1:40,dur:.25,gain:.12,send:.1})}function ht(){if(!i||a)return;a=!0;const dt=i.createBufferSource();dt.buffer=r,dt.loop=!0;const et=i.createBiquadFilter();et.type="lowpass",et.frequency.value=420,et.Q.value=.4;const Lt=i.createGain();Lt.gain.value=.03,dt.connect(et).connect(Lt).connect(t),dt.start();const k=i.createOscillator();k.frequency.value=.07;const at=i.createGain();at.gain.value=.016,k.connect(at).connect(Lt.gain),k.start(),f=i.createOscillator(),f.type="sine",f.frequency.value=46;const gt=i.createGain();gt.gain.value=.016,f.connect(gt).connect(t),f.start();const Mt=()=>{if(!a)return;const Et=x(-.9,.9),Bt=1+Math.floor(Math.random()*3);for(let Zt=0;Zt<Bt;Zt++)setTimeout(()=>{i&&(v({dur:.07,type:"lowpass",f0:1400,f1:300,gain:.055,pan:Et,send:.9,delay:x(0,.05)}),p({type:"sine",f0:90,f1:35,dur:.22,gain:.035,pan:Et,send:.5}))},Zt*x(90,160));h=setTimeout(Mt,x(1800,5200))};h=setTimeout(Mt,900)}function lt(dt){if(i)if(dt&&!o){o=!0;const et=()=>{!o||!i||(p({type:"sine",f0:62,f1:34,dur:.16,gain:.16,send:.03}),setTimeout(()=>p({type:"sine",f0:54,f1:30,dur:.13,gain:.1,send:.03}),190),l=setTimeout(et,1150))};et()}else!dt&&o&&(o=!1,clearTimeout(l))}function Dt(){if(a=!1,clearTimeout(h),f){try{f.stop()}catch{}f=null}}function yt(dt){t&&(t.gain.value=dt)}return{init:u,gunshot:w,enemyShot:b,whiz:C,reload:V,shell:D,impact:A,ricochet:y,explosion:rt,footstep:S,hitmarker:z,ui:q,uiConfirm:j,death:Y,hurt:W,killConfirm:nt,ambient:ht,stopAmbient:Dt,setLowHealth:lt,setMasterVolume:yt,get ctx(){return i}}}const ze=i=>document.getElementById(i),vu=2,Ir=220,Lr=62,dl=i=>i<0?0:i>1?1:i,xu=i=>i>180?i-360:i<-180?i+360:i,Th='-apple-system, BlinkMacSystemFont, "Helvetica Neue", Arial, sans-serif',Eh='"SF Mono", ui-monospace, Menlo, Consolas, monospace',xv=`800 14px ${Th}`,_v=`700 10.5px ${Th}`,Mv=`500 8px ${Eh}`,yv=`700 9.5px ${Eh}`,Sv={0:"N",45:"NE",90:"E",135:"SE",180:"S",225:"SW",270:"W",315:"NW"};function wv(){const i={hud:ze("hud"),mission:ze("mission-label"),objective:ze("objective"),waveNum:ze("wave-num"),waveTotal:ze("wave-total"),waveBar:ze("wave-bar-fill"),killfeed:ze("killfeed"),score:ze("score"),kills:ze("kills"),crosshair:ze("crosshair"),hitmarker:ze("hitmarker"),headshot:ze("headshot-tag"),killtag:ze("kill-tag"),dmgDirs:ze("damage-dirs"),dmgFlash:ze("damage-flash"),lowhp:ze("lowhp"),armor:ze("armor-pips"),hpFill:ze("hp-fill"),hpNum:ze("hp-num"),weaponName:ze("weapon-name"),ammoMag:ze("ammo-mag"),ammoReserve:ze("ammo-reserve"),fireMode:ze("fire-mode"),grenades:ze("grenade-count"),magPips:ze("mag-pips"),reload:ze("reload-prompt"),hint:ze("hint"),compass:ze("compass"),vitals:document.querySelector("#hud .vitals")},t=i.crosshair.getContext("2d"),e=i.compass.getContext("2d"),n={hp:100,armor:2,maxHp:100,mag:30,magSize:30,reserve:180,spreadPx:10,spreadShown:6,ads:!1,firing:!1,heading:0,lowHp:!1,dmgAngle:0,dmgAlpha:0,flashAlpha:0,time:0,pings:[],kills:0};let s=[],r=0,a=0,o=56,l=0,h=!0,f=999,m=0,u=0;function d(){const k=Math.min(window.devicePixelRatio||1,vu),at=Math.max(1,Math.round(Ir*k));(r!==k||i.crosshair.width!==at)&&(r=k,i.crosshair.width=at,i.crosshair.height=at)}function c(){const k=Math.round(i.compass.clientWidth),at=Math.round(i.compass.clientHeight)||56,gt=Math.min(window.devicePixelRatio||1,vu);k<=0||(k!==a||at!==o||gt!==l)&&(a=k,o=at,l=gt,i.compass.width=Math.max(1,Math.round(k*gt)),i.compass.height=Math.max(1,Math.round(at*gt)),h=!0)}d(),window.addEventListener("resize",()=>{d(),c()});function v(k){k=Math.max(1,Math.min(60,k|0)),i.magPips.innerHTML="",s=[];for(let at=0;at<k;at++){const gt=document.createElement("i");i.magPips.appendChild(gt),s.push(gt)}p(n.mag)}function p(k){const at=s.length,gt=Math.max(0,Math.min(at,k));for(let Mt=0;Mt<at;Mt++){const Et=Mt>=gt;s[Mt].classList.toggle("spent",Et),s[Mt].classList.toggle("next",gt>0&&Mt===gt-1)}}v(30);function x(k=!0){i.hud.classList.toggle("hidden",!k)}function w(k,at=2){n.hp=Math.max(0,k),n.armor=Math.max(0,at|0);const gt=dl(n.hp/n.maxHp);i.hpFill.style.width=`${gt*100}%`,i.hpNum.textContent=String(Math.ceil(n.hp));const Mt=n.hp<45;i.hpFill.classList.toggle("low",Mt),i.vitals&&i.vitals.classList.toggle("critical",n.hp<35);const Et=i.armor.children;for(let Zt=0;Zt<Et.length;Zt++)Et[Zt].classList.toggle("off",Zt>=n.armor);const Bt=n.hp<40;Bt!==n.lowHp&&(n.lowHp=Bt,i.lowhp.style.opacity=Bt?"1":"0")}function b(k,at,gt,Mt="AUTO"){n.mag=Math.max(0,k|0),n.reserve=Math.max(0,at|0),s.length!==n.magSize&&v(n.magSize),i.ammoMag.textContent=String(n.mag),i.ammoReserve.textContent=String(n.reserve),i.ammoMag.classList.toggle("low",n.mag<=Math.max(3,Math.ceil(n.magSize*.2))),gt&&(i.weaponName.textContent=gt),Mt&&(i.fireMode.textContent=Mt),p(n.mag)}function C(k,at,gt){i.weaponName.textContent=k,n.magSize=Math.max(1,at|0),i.fireMode.textContent=gt||"AUTO",v(n.magSize),b(Math.min(n.mag,n.magSize),n.reserve,k,gt)}function V(k,at="∞"){i.waveNum.textContent=String(k),i.waveTotal.textContent=String(at)}function D(k){i.waveBar.style.width=`${dl(k)*100}%`}function A(k){k!=null&&(i.objective.textContent=String(k))}function y(k,at){i.score.textContent=String(k),at!==void 0&&(i.kills.textContent=String(at),n.kills=at)}function rt(k){i.grenades.textContent=String(k)}function S(k,at){k.classList.remove(at),k.offsetWidth,k.classList.add(at)}function z(k=!1,at=!1){k&&i.hitmarker.classList.add("hs"),S(i.hitmarker,"show"),k&&(S(i.headshot,"show"),clearTimeout(z._hs),z._hs=setTimeout(()=>i.hitmarker.classList.remove("hs"),260)),at&&(i.killtag.textContent=k?"+150":"+100",S(i.killtag,"show"))}function nt(k="HOSTILE",at=!1,gt="M4A1"){const Mt=document.createElement("div");Mt.className="kf-row";const Et=(Bt,Zt)=>{const Xt=document.createElement("span");Xt.className=Bt,Xt.textContent=Zt,Mt.appendChild(Xt)};for(Et("kf-you","YOU"),Et("kf-arrow","›"),Et("kf-weapon",gt),at&&Et("kf-hs","HEADSHOT"),Et("kf-target",k),i.killfeed.insertBefore(Mt,i.killfeed.firstChild);i.killfeed.children.length>5;)i.killfeed.lastChild.remove();setTimeout(()=>{Mt.classList.add("fade"),setTimeout(()=>Mt.remove(),480)},3800)}function q(k){n.dmgAngle=k,n.dmgAlpha=1,i.dmgDirs.style.transform=`rotate(${k}rad)`,i.dmgDirs.style.opacity="0.95"}function j(k=.55){n.flashAlpha=Math.max(n.flashAlpha,k)}function Y(k){i.reload.classList.toggle("show",!!k)}function W(k){if(k){const at=String(k);i.hint.textContent!==at&&(i.hint.textContent=at),i.hint.classList.add("show"),u=1.2}else u<=0&&i.hint.classList.remove("show")}function ht(k,at,gt=1.6){const Mt=k.x-at.position.x,Et=k.z-at.position.z,Bt=(Math.atan2(Mt,Et)*180/Math.PI+360)%360;n.pings.push({bearing:Bt,life:gt,max:gt}),n.pings.length>8&&n.pings.shift(),h=!0}function lt(k,at){n.spreadPx=Math.max(0,k),n.ads=!!at}function Dt(k,at,gt,Mt,Et){k.beginPath(),k.moveTo(at-Mt-Et,gt),k.lineTo(at-Mt,gt),k.moveTo(at+Mt,gt),k.lineTo(at+Mt+Et,gt),k.moveTo(at,gt-Mt-Et),k.lineTo(at,gt-Mt),k.moveTo(at,gt+Mt),k.lineTo(at,gt+Mt+Et),k.stroke()}function yt(){const k=t,at=r||1;k.setTransform(at,0,0,at,0,0),k.clearRect(0,0,Ir,Ir);const gt=Ir/2,Mt=Ir/2;if(n.ads)return;const Et=6.5+n.spreadShown,Bt=7.5;k.lineCap="butt",k.strokeStyle="rgba(0,0,0,.72)",k.lineWidth=4.6,Dt(k,gt,Mt,Et,Bt),k.strokeStyle="rgba(250,253,253,.98)",k.lineWidth=2,Dt(k,gt,Mt,Et,Bt),k.fillStyle="rgba(0,0,0,.7)",k.fillRect(gt-2.2,Mt-2.2,4.4,4.4),k.fillStyle="rgba(255,255,255,.99)",k.fillRect(gt-1.1,Mt-1.1,2.2,2.2)}function dt(){if(!a)return;const k=e,at=l||1,gt=a,Mt=o;k.setTransform(at,0,0,at,0,0),k.clearRect(0,0,gt,Mt);const Et=gt/2,Bt=gt/(Lr*2),Zt=(n.heading%360+360)%360,Xt=Mt*.66,ie=Mt*.33,$=Mt-7;k.textAlign="center",k.textBaseline="middle",k.lineJoin="round";const wt=(ct,Ct,jt,kt,B)=>{B&&(k.lineWidth=B,k.strokeStyle="rgba(3,5,7,.7)",k.strokeText(ct,Ct,jt)),k.fillStyle=kt,k.fillText(ct,Ct,jt)};k.fillStyle="rgba(2,4,6,.4)",k.fillRect(0,Xt-1,gt,2.5);const At=k.createLinearGradient(0,0,gt,0);At.addColorStop(0,"rgba(233,238,240,0)"),At.addColorStop(.16,"rgba(240,245,246,.44)"),At.addColorStop(.5,"rgba(246,250,251,.56)"),At.addColorStop(.84,"rgba(240,245,246,.44)"),At.addColorStop(1,"rgba(233,238,240,0)"),k.fillStyle=At,k.fillRect(0,Xt,gt,1);for(let ct=0;ct<360;ct+=5){const Ct=xu(ct-Zt);if(Math.abs(Ct)>Lr)continue;const jt=Math.round((Et+Ct*Bt)*2)/2,kt=1-Math.pow(Math.abs(Ct)/Lr,1.8);if(kt<=.02)continue;const B=ct%45===0,P=!B&&ct%15===0,tt=B?13:P?8:4.5,vt=B?1.5:1;k.fillStyle=`rgba(2,4,6,${(.42*kt).toFixed(3)})`,k.fillRect(jt-vt/2-.7,Xt-tt,vt+1.4,tt);const bt=(B?.98:P?.7:.44)*kt;if(k.fillStyle=`rgba(242,246,247,${bt.toFixed(3)})`,k.fillRect(jt-vt/2,Xt-tt,vt,tt),B){const mt=ct%90===0;k.font=mt?xv:_v,k.letterSpacing=mt?"1.4px":"0.8px",wt(Sv[ct],jt,ie,mt?`rgba(250,253,253,${(.99*kt).toFixed(3)})`:`rgba(242,246,247,${(.94*kt).toFixed(3)})`,mt?3.4:2.8),Math.abs(jt-Et)>22&&(k.font=Mv,k.letterSpacing="0.4px",wt(String(ct).padStart(3,"0"),jt,$,`rgba(240,245,246,${(.62*kt).toFixed(3)})`,2.2))}}for(const ct of n.pings){const Ct=xu(ct.bearing-Zt);if(Math.abs(Ct)>Lr)continue;const jt=Et+Ct*Bt,kt=dl(ct.life/.32),B=1-Math.abs(Ct)/Lr,P=kt*B;if(P<=0)continue;k.save(),k.shadowColor=`rgba(232,74,58,${.9*P})`,k.shadowBlur=9,k.fillStyle=`rgba(244,96,76,${(.97*P).toFixed(3)})`;const tt=Xt-15;k.beginPath(),k.moveTo(jt,tt+8),k.lineTo(jt-5,tt),k.lineTo(jt+5,tt),k.closePath(),k.fill(),k.fillRect(jt-.5,tt-6,1,6),k.restore()}k.fillStyle="rgba(227,178,106,.4)",k.fillRect(Math.round(Et)-.5,ie+9,1,Xt-ie-9),k.save(),k.shadowColor="rgba(227,178,106,.9)",k.shadowBlur=11,k.fillStyle="rgba(242,201,135,.99)",k.beginPath(),k.moveTo(Et,3),k.lineTo(Et-5.5,11),k.lineTo(Et+5.5,11),k.closePath(),k.fill(),k.restore(),k.font=yv,k.letterSpacing="1px",wt(String(Math.round(Zt)%360).padStart(3,"0"),Et,$,"rgba(242,201,135,.98)",2.6)}function et(k){n.time+=k,m++,r||d(),(a===0||!(m&15))&&c();const at=1-Math.exp(-16*k);n.spreadShown+=(n.spreadPx-n.spreadShown)*at,yt();const gt=(n.heading%360+360)%360;(h||n.pings.length>0||Math.abs(gt-f)>.02)&&(dt(),f=gt,h=!1),n.dmgAlpha>0&&(n.dmgAlpha=Math.max(0,n.dmgAlpha-k*1.9),i.dmgDirs.style.opacity=(n.dmgAlpha*.95).toFixed(3)),n.flashAlpha>0&&(n.flashAlpha=Math.max(0,n.flashAlpha-k*3.4),i.dmgFlash.style.opacity=n.flashAlpha.toFixed(3));for(let Mt=n.pings.length-1;Mt>=0;Mt--)n.pings[Mt].life-=k,n.pings[Mt].life<=0&&(n.pings.splice(Mt,1),h=!0);u>0&&(u=Math.max(0,u-k))}function Lt(){n.hp=100,n.armor=2,n.mag=30,n.magSize=30,n.reserve=180,n.spreadPx=6,n.spreadShown=6,n.ads=!1,n.heading=0,n.dmgAlpha=0,n.flashAlpha=0,n.lowHp=!1,n.kills=0,n.pings.length=0,i.killfeed.innerHTML="",i.dmgDirs.style.opacity="0",i.dmgFlash.style.opacity="0",i.lowhp.style.opacity="0",i.reload.classList.remove("show"),i.score.textContent="0",i.kills.textContent="0",i.magPips.innerHTML="",s=[],v(30),w(100,2),b(30,180,"M4A1","AUTO"),u=0,W(""),h=!0}return{el:i,show:x,update:et,reset:Lt,setHealth:w,setAmmo:b,setWeaponName:C,setWave:V,setWaveProgress:D,setObjective:A,setScore:y,setGrenades:rt,hit:z,addKillFeed:nt,setDamage:q,flashDamage:j,setReloadPrompt:Y,setHint:W,ping:ht,setSpread:lt,setHeading(k){n.heading=k},get state(){return n}}}function bv(i){const t=new Set,e=new Set,n={dx:0,dy:0,left:!1,right:!1,leftPressed:!1};let s=!1,r=1;const a={lock:[],unlock:[],key:[]};function o(v){if(!t.has(v.code)){e.add(v.code);for(const p of a.key)p(v.code,v)}t.add(v.code),["Space","Tab","ArrowUp","ArrowDown"].includes(v.code)&&v.preventDefault()}function l(v){t.delete(v.code)}function h(v){s&&(v.button===0&&(n.left=!0,n.leftPressed=!0),v.button===2&&(n.right=!0))}function f(v){v.button===0&&(n.left=!1),v.button===2&&(n.right=!1)}function m(v){s&&(n.dx+=v.movementX||0,n.dy+=v.movementY||0)}function u(v){v.preventDefault()}function d(){const v=s;if(s=document.pointerLockElement===i,s&&!v){n.left=n.right=!1;for(const p of a.lock)p()}if(!s&&v){t.clear(),n.left=n.right=!1;for(const p of a.unlock)p()}}return window.addEventListener("keydown",o),window.addEventListener("keyup",l),window.addEventListener("mousedown",h),window.addEventListener("mouseup",f),window.addEventListener("mousemove",m),window.addEventListener("contextmenu",u),document.addEventListener("pointerlockchange",d),window.addEventListener("blur",()=>{t.clear(),n.left=!1,n.right=!1}),{keys:t,mouse:n,listeners:a,get locked(){return s},get sensitivity(){return r},set sensitivity(v){r=v},down(v){return t.has(v)},pressedOnce(v){return e.has(v)},lock(){if(i.requestPointerLock){const v=i.requestPointerLock({unadjustedMovement:!0});v&&v.catch&&v.catch(()=>i.requestPointerLock())}},unlock(){document.pointerLockElement&&document.exitPointerLock()},consumeMouse(){const v={dx:n.dx,dy:n.dy,leftPressed:n.leftPressed};return n.dx=0,n.dy=0,n.leftPressed=!1,v},endFrame(){e.clear()},on(v,p){a[v]&&a[v].push(p)},dispose(){window.removeEventListener("keydown",o),window.removeEventListener("keyup",l),window.removeEventListener("mousedown",h),window.removeEventListener("mouseup",f),window.removeEventListener("mousemove",m),window.removeEventListener("contextmenu",u),document.removeEventListener("pointerlockchange",d)}}}function Tv(i,t,e,n){const s=new N(0,0,34),r=new N;let a=0,o=0,l=0,h=0,f=0,m=0,u=0,d=0,c=0,v=1.68,p=0,x=0,w=0,b=!0,C=0,V=0,D=!1,A=0;const y={walk:4.3,sprint:7,crouch:2.2,ads:2.9},rt=.36,S={speed:0,moving:!1,sprinting:!1,crouching:!1,ads:!1};function z(q,j){for(const Y of t){const W=qe.clamp(q,Y.x0,Y.x1),ht=qe.clamp(j,Y.z0,Y.z1),lt=q-W,Dt=j-ht;if(lt*lt+Dt*Dt<rt*rt)return!0}return q<e.x0||q>e.x1||j<e.z0||j>e.z1}function nt(q,j,Y={}){if(j){const{dx:te,dy:St}=j.consumeMouse();if(!D){const Ft=.00215*j.sensitivity*(1-u*.42);a-=te*Ft,o-=St*Ft,o=qe.clamp(o,-1.45,1.42)}}if(D){A=Math.min(1,A+q*1.6);const te=A*A*(3-2*A);v=qe.lerp(1.68,.34,te),i.position.set(s.x,v,s.z),i.rotation.set(qe.lerp(o,-.55,te),a,qe.lerp(0,.55,te));return}const W=!!Y.ads,ht=!!Y.sprinting&&!W,lt=!!Y.crouching;u+=((W?1:0)-u)*Math.min(1,q*9),d+=((ht?1:0)-d)*Math.min(1,q*6),c+=((lt?1:0)-c)*Math.min(1,q*8);let Dt=0,yt=0;j&&(j.down("KeyW")&&(yt+=1),j.down("KeyS")&&(yt-=1),j.down("KeyA")&&(Dt-=1),j.down("KeyD")&&(Dt+=1));const dt=Math.hypot(Dt,yt);dt>0&&(Dt/=dt,yt/=dt);const et=new N(-Math.sin(a),0,-Math.cos(a)),Lt=new N(Math.cos(a),0,-Math.sin(a)),k=new N().addScaledVector(et,yt).addScaledVector(Lt,Dt);let at=0;dt>0&&(at=ht?y.sprint:lt?y.crouch:W?y.ads:y.walk,at*=1-c*.25);const gt=b?dt>0?26:18:5,Mt=k.multiplyScalar(at);if(r.x+=(Mt.x-r.x)*Math.min(1,gt*q),r.z+=(Mt.z-r.z)*Math.min(1,gt*q),!dt){const te=Math.min(1,10*q);r.x*=1-te,r.z*=1-te}const Et=s.x+r.x*q;z(Et,s.z)?r.x=0:s.x=Et;const Bt=s.z+r.z*q;z(s.x,Bt)?r.z=0:s.z=Bt,s.x=qe.clamp(s.x,e.x0,e.x1),s.z=qe.clamp(s.z,e.z0,e.z1),Y.jump&&b&&!lt&&(C=4.4,b=!1),b||(C-=15.5*q,s.y+=C*q,s.y<=0&&(s.y=0,b=!0,C=0,V=Math.min(1,V+.22),n&&n.footstep("concrete",1.2))),S.speed=Math.hypot(r.x,r.z)/y.sprint,S.moving=dt>0&&S.speed>.08,S.sprinting=ht&&S.moving,S.crouching=lt,S.ads=W;const Zt=Math.hypot(r.x,r.z),Xt=8.2+Zt*.85;p+=q*Xt*(.55+Zt*.12);const ie=Math.min(1,Zt/y.walk)*(ht?1.55:1)*(1-u*.55);x+=(ie-x)*Math.min(1,q*6),w+=Zt*q,w>(ht?2.7:2.15)&&b&&(w=0,n&&n.footstep("concrete",.75+(ht?.5:0)));const wt=Math.sin(p*2)*.032*x,At=Math.cos(p)*.028*x,ct=Math.sin(performance.now()/1e3*1.1)*.006,Ct=17;f+=(-190*l-Ct*f)*q,l+=f*q,m+=(-190*h-Ct*m)*q,h+=m*q;const jt=qe.lerp(1.68,1.05,c);v+=(jt-v)*Math.min(1,q*12);const kt=v+wt*.55+ct+s.y;V=Math.max(0,V-q*1.6);const B=V*V,P=performance.now()/1e3,tt=Math.sin(P*47.3)*.014*B,vt=Math.cos(P*39.1)*.014*B,bt=Math.sin(P*31.7)*.012*B,Ot=-(r.dot(Lt)/y.walk)*.018-bt;i.position.set(s.x+At*.5+tt,kt,s.z),i.rotation.order="YXZ",i.rotation.set(o+l+wt*.35+vt,a+h+At*.25,Ot);const zt=qe.lerp(78+d*5.5,50,u);Math.abs(i.fov-zt)>.01&&(i.fov+=(zt-i.fov)*Math.min(1,q*12),i.updateProjectionMatrix())}return{pos:s,vel:r,state:S,update:nt,get yaw(){return a},get pitch(){return o},get adsAmount(){return u},get sprintAmount(){return d},get eyeHeight(){return v},get grounded(){return b},get dead(){return D},get speedAbs(){return Math.hypot(r.x,r.z)},setPosition(q,j,Y){s.set(q,j,Y)},setLook(q,j){a=q,o=j},kick(q,j){f+=q,m+=j},addShake(q){V=Math.min(1.2,V+q)},damageFeedback(){},die(){D=!0,A=0,r.set(0,0,0)},revive(q,j){D=!1,A=0,s.set(q,0,j),r.set(0,0,0),v=1.68,o=0,a=0,l=h=0,f=m=0,i.fov=78,i.updateProjectionMatrix()},get headingDeg(){let q=-a*180/Math.PI%360;return q<0&&(q+=360),q}}}const nr=Math.PI*2,Ev=new N(0,-1,0),So=.42;function mc(i){return function(){i|=0,i=i+1831565813|0;let t=Math.imul(i^i>>>15,1|i);return t=t+Math.imul(t^t>>>7,61|t)^t,((t^t>>>14)>>>0)/4294967296}}const co=new Pe,uo=new In,_u=new wn,Av=new N,Cv=new N;new N;function jr(i){return i.index?i.toNonIndexed():i}function Rv(i,t,e,n,s=So){const r=i.attributes.uv,a=[[n,e],[n,e],[t,n],[t,n],[t,e],[t,e]];for(let o=0;o<6;o++){const[l,h]=a[o];for(let f=0;f<6;f++){const m=o*6+f;r.setXY(m,r.getX(m)*l/s,r.getY(m)*h/s)}}r.needsUpdate=!0}function fe(i,t,e,n=So){const s=jr(new Rt(i,t,e));return Rv(s,i,t,e,n),s}function ve(i,t,e,n=.02){const s=new kc(i,t,e,2,Math.min(n,Math.min(i,t,e)*.45));return jr(s)}function Pv(i,t,e=6,n=20){return jr(new Rn(i,t,e,n))}function Xe(i,t,e,n=10,s=So,r=!1){const a=jr(new Re(i,t,e,n,1,r)),o=a.attributes.uv,l=nr*Math.max(i,t);for(let h=0;h<o.count;h++)o.setXY(h,o.getX(h)*l/s,o.getY(h)*e/s);return o.needsUpdate=!0,a}function os(i,t=12,e=0,n=Math.PI,s=So){const r=jr(new Ci(i,t,Math.max(5,t*.72|0),0,nr,e,n)),a=r.attributes.uv;for(let o=0;o<a.count;o++)a.setXY(o,a.getX(o)*nr*i/s,a.getY(o)*Math.PI*i/s);return a.needsUpdate=!0,r}function Dv(i,t=[0,0,0],e=[0,0,0],n=[1,1,1]){return _u.set(e[0],e[1],e[2]),uo.setFromEuler(_u),co.compose(Av.set(t[0],t[1],t[2]),uo,Cv.set(n[0],n[1],n[2])),i.applyMatrix4(co),i.normalizeNormals&&i.normalizeNormals(),i}function yn(){const i=new Map;return{add(t,e){let n=i.get(e);n||i.set(e,n=[]),n.push(t)},part(t,e,n,s,r){this.add(Dv(t,n,s,r),e)},build(t,e,n,s){for(const[r,a]of i){const o=a.length===1?a[0]:Sh(a,!1);if(!o){for(const h of a){const f=new K(h,r);f.castShadow=!!(e&&e.has(r)),f.receiveShadow=!!(n&&n.has(r)),t.add(f),s&&s.push(f)}continue}const l=new K(o,r);l.castShadow=!!(e&&e.has(r)),l.receiveShadow=!!(n&&n.has(r)),t.add(l),s&&s.push(l)}i.clear()}}}let pl=null;function Iv(){if(pl)return pl;const i=128,t=document.createElement("canvas");t.width=t.height=i;const e=t.getContext("2d"),n=e.createImageData(i,i),s=n.data,r=new Float32Array(i*i),a=mc(9182);for(let h=0;h<i;h++)for(let f=0;f<i;f++)r[h*i+f]=(Math.sin(f*1.9)+Math.sin(h*1.9))*.5+(a()-.5)*.9;const o=(h,f)=>r[(f+i)%i*i+(h+i)%i];for(let h=0;h<i;h++)for(let f=0;f<i;f++){const m=o(f+1,h)-o(f-1,h),u=o(f,h+1)-o(f,h-1),d=(h*i+f)*4;s[d]=128+m*26,s[d+1]=128+u*26,s[d+2]=255,s[d+3]=255}e.putImageData(n,0,0);const l=new gs(t);return l.wrapS=l.wrapT=ds,l.anisotropy=4,pl=l,l}function Lv(i){const e=document.createElement("canvas");e.width=e.height=256;const n=e.getContext("2d"),s=mc(1013+i.id*7331);n.fillStyle=i.base,n.fillRect(0,0,256,256);const r=[i.c1,i.c2,i.c3,i.c4],a=(m,u,d,c)=>{const v=[];for(let p=0;p<c;p++){const x=p/c*nr,w=d*(.5+s()*.8);v.push([m+Math.cos(x)*w,u+Math.sin(x)*w*(.7+s()*.5)])}for(let p=-1;p<=1;p++)for(let x=-1;x<=1;x++){const w=m+p*256,b=u+x*256;if(!(w<-70||w>326||b<-70||b>326)){n.beginPath();for(let C=0;C<v.length;C++){const V=v[C][0]+p*256,D=v[C][1]+x*256;C===0?n.moveTo(V,D):n.lineTo(V,D)}n.closePath(),n.fill()}}};for(let m=0;m<3;m++){const u=[34,90,70][m],d=[36,15,9][m];n.globalAlpha=[.95,.9,.86][m];for(let c=0;c<u;c++)n.fillStyle=r[s()*r.length|0],a(s()*256,s()*256,d*(.55+s()*.9),5+(s()*5|0))}n.globalAlpha=1;const o=n.getImageData(0,0,256,256),l=o.data,h=mc(4411+i.id);for(let m=0;m<256;m++)for(let u=0;u<256;u++){const d=(m*256+u)*4,c=Math.sin(u*.075+Math.sin(m*.012)*2.1)*8+Math.sin(u*.21+m*.03)*2.5,v=(u&1?3.2:-3.2)+(m&1?2.4:-2.4),p=(h()-.5)*20,w=Math.max(0,Math.sin(u*.02+m*.013)*.5+.5)*Math.max(0,m/256-.55)*46;l[d]=Math.max(0,Math.min(255,l[d]+c+v+p-w*.9)),l[d+1]=Math.max(0,Math.min(255,l[d+1]+c+v+p-w*.95)),l[d+2]=Math.max(0,Math.min(255,l[d+2]+c+v+p-w*1.15))}n.putImageData(o,0,0),n.globalAlpha=.12;for(let m=0;m<40;m++){n.fillStyle=m%3===0?"#cfc6ac":"#171a14";const u=3+s()*14;n.beginPath(),n.ellipse(s()*256,s()*256,u,u*(.2+s()*.5),s()*nr,0,nr),n.fill()}n.globalAlpha=1;const f=new gs(e);return f.wrapS=f.wrapT=ds,f.colorSpace=pn,f.anisotropy=4,f}const Mu=[{id:0,name:"woodland",base:"#4e4c39",c1:"#39402c",c2:"#1f231c",c3:"#6c6448",c4:"#3f3728",clothTint:16777215,gear:"#4a4b3e",gear2:"#5b5d49",glove:"#4b4234",leather:"#27231d",skin:"#a3785a",metalTint:"#33373a",face:"balaclava",goggles:"eyes",nvg:"mount",pack:!0},{id:1,name:"desert",base:"#8d7a58",c1:"#ac9a72",c2:"#645840",c3:"#77664a",c4:"#b5a37c",clothTint:16052198,gear:"#544c3c",gear2:"#8a7a58",glove:"#6b5a40",leather:"#403225",skin:"#b0835f",metalTint:"#3f3d35",face:"shemagh",goggles:"helmet",nvg:"stowed",pack:!0},{id:2,name:"urban",base:"#4a5053",c1:"#31383c",c2:"#1d2327",c3:"#666c6c",c4:"#3c4343",clothTint:15922420,gear:"#41474d",gear2:"#525b62",glove:"#2f3337",leather:"#1a1c1f",skin:"#8e6a52",metalTint:"#2e3336",face:"mask",goggles:"eyes",nvg:"active",pack:!1}],ml=new Map;function Uv(i){if(ml.has(i.id))return ml.get(i.id);const t=Lv(i),e=Iv(),n=new Pt(.65,.65),s=new he({map:t,normalMap:e,normalScale:n,color:i.clothTint,roughness:.93,metalness:.02,envMapIntensity:.95}),r=new he({color:new Jt(i.gear),roughness:.84,metalness:.1,envMapIntensity:.8}),a=new he({color:new Jt(i.gear2),roughness:.9,metalness:.04,envMapIntensity:.75}),o=new he({color:new Jt(i.metalTint),roughness:.52,metalness:.68,envMapIntensity:.95}),l=new he({color:1118996,roughness:.92,metalness:.02,envMapIntensity:.5}),h=new he({color:new Jt(i.glove),roughness:.84,metalness:.03,envMapIntensity:.65}),f=new he({color:new Jt(i.skin),roughness:.7,metalness:0,envMapIntensity:.7}),m=new he({color:new Jt(i.leather),roughness:.72,metalness:.06,envMapIntensity:.85}),u=new he({color:726040,roughness:.08,metalness:.94,envMapIntensity:2.4}),d={cloth:s,gear:r,gear2:a,metal:o,rubber:l,glove:h,skin:f,leather:m,lens:u,V:i};return ml.set(i.id,d),d}let Fa=null;function zv(){return Fa||(Fa={metal:new he({color:2303271,roughness:.58,metalness:.5,envMapIntensity:.45}),polymer:new he({color:1776670,roughness:.68,metalness:.42,envMapIntensity:.4}),tanPolymer:new he({color:1776670,roughness:.68,metalness:.42,envMapIntensity:.4})},Fa)}const ni=new N,Ur=new N,gl=new N,Ji=new N,vl=new N,Qi=new N,xl=new N,yu=new N;function _l(i,t,e,n,s,r){const a=i.position;ni.subVectors(e,a);let o=ni.length();if(o<1e-5)return;const l=n+s-.004,h=Math.abs(n-s)+.02;o>l?ni.multiplyScalar(l/o):o<h&&ni.normalize().multiplyScalar(h),o=ni.length(),ni.divideScalar(o);const f=qe.clamp((n*n+o*o-s*s)/(2*n*o),-1,1),m=Math.sqrt(Math.max(0,1-f*f));Ur.copy(r).addScaledVector(ni,-r.dot(ni)),Ur.lengthSq()<1e-7&&Ur.set(0,0,1).addScaledVector(ni,-ni.z),Ur.normalize(),gl.copy(a).addScaledVector(ni,n*f).addScaledVector(Ur,n*m),Ji.subVectors(a,gl).normalize(),vl.subVectors(e,gl).normalize(),Qi.crossVectors(Ji,vl),Qi.lengthSq()<1e-8&&Qi.set(1,0,0).addScaledVector(Ji,-Ji.x),Qi.normalize(),xl.crossVectors(Qi,Ji).normalize(),Qi.crossVectors(Ji,xl).normalize(),co.makeBasis(Qi,Ji,xl),i.quaternion.setFromRotationMatrix(co),uo.copy(i.quaternion).invert(),yu.copy(vl).applyQuaternion(uo),t.quaternion.setFromUnitVectors(Ev,yu)}const Ah=.935,Za=.435,Or=.395,Qs=.31,Wr=.285,Nv=new N(0,.012,.02),Fv=new N(0,.083,-.356);function Ov(i,t=0){const e=Mu[t%Mu.length],n=Uv(e),s=zv(),r=[],a=new Set([n.cloth,n.gear,n.leather,s.metal,s.polymer,s.tanPolymer]),o=new Set([n.cloth,n.gear,n.leather]),l=new xe,h=new xe;h.position.y=Ah,l.add(h);{const D=yn();D.part(ve(.325,.21,.22,.045),n.cloth,[0,.02,0]),D.part(ve(.3,.13,.195,.04),n.cloth,[0,-.075,.005]),D.part(fe(.285,.1,.055),n.cloth,[0,.02,.118],[.14,0,0]),D.build(h,a,o,r);const A=yn();A.part(ve(.34,.08,.24,.018),n.gear,[0,.085,0]),A.part(fe(.055,.042,.02),n.metal,[0,.085,-.124]);for(const y of[-1,1])A.part(ve(.085,.11,.06,.016),n.gear,[y*.105,.045,-.118]),A.part(fe(.07,.02,.05),n.metal,[y*.105,.102,-.12]);A.part(ve(.105,.115,.06,.016),n.gear,[.105,.03,.118]),A.part(ve(.035,.155,.052,.012),n.gear,[-.16,-.005,.02],[0,0,.09]),A.part(fe(.045,.04,.014),n.metal,[-.163,.072,.02]),A.part(Xe(.044,.044,.11,8),n.gear,[-.145,.01,.105]),A.build(h,a,o,r)}const f=new xe;f.position.y=.095,f.rotation.order="YXZ",h.add(f);{const D=yn();D.part(ve(.362,.34,.262,.072),n.cloth,[0,.285,0]),D.part(ve(.312,.18,.228,.05),n.cloth,[0,.085,.005]),D.part(ve(.425,.122,.215,.06),n.cloth,[0,.405,.005]),D.part(Xe(.055,.063,.11,8),n.cloth,[0,.49,.005]),D.part(Xe(.083,.077,.062,10),n.cloth,[0,.448,.005]),D.part(ve(.322,.29,.08,.03),n.gear,[0,.25,-.14]),D.part(ve(.312,.278,.062,.024),n.gear,[0,.26,.132]);for(const A of[-1,1])D.part(ve(.048,.17,.225,.016),n.gear,[A*.178,.14,0]),D.part(fe(.072,.03,.135),n.gear,[A*.11,.404,-.055],[.25,0,0]),D.part(fe(.068,.026,.125),n.gear,[A*.108,.404,.064],[-.3,0,0]),D.part(ve(.055,.095,.08,.014),n.gear,[A*.19,.105,-.035]);D.part(Xe(.009,.009,.1,6),n.gear,[.12,.4,.03],[.5,0,-.25]),D.part(Xe(.009,.009,.15,6),n.gear,[.124,.335,-.09],[1.3,0,0]),D.part(ve(.064,.12,.044,.014),n.gear,[.152,.296,.108]),D.part(Xe(.005,.0034,.3,5),n.gear,[.158,.525,.15],[-.3,0,.12]),e.pack?(D.part(ve(.26,.22,.12,.034),n.gear,[0,.3,.222]),D.part(ve(.215,.085,.085,.024),n.gear2,[0,.402,.212]),D.part(fe(.24,.022,.03),n.gear2,[0,.255,.284])):(D.part(ve(.235,.25,.09,.028),n.gear,[0,.3,.2]),D.part(fe(.2,.02,.025),n.gear2,[0,.26,.248]));for(const A of[-.1,0,.1])D.part(ve(.082,.125,.06,.016),n.gear2,[A,.125,-.207]),D.part(fe(.068,.024,.05),n.gear,[A,.19,-.212]),D.part(fe(.015,.06,.016),n.gear,[A,.148,-.238]);D.part(ve(.095,.085,.05,.012),n.gear2,[-.11,.318,-.185]),D.part(fe(.3,.018,.014),n.gear2,[0,.245,-.192]),D.part(fe(.3,.018,.014),n.gear2,[0,.34,-.192]);for(const A of[-1,1])D.part(ve(.118,.05,.175,.022),n.gear2,[A*.178,.452,0],[0,0,A*.3]);D.part(Xe(.019,.021,.055,8),n.metal,[-.112,.385,-.19],[Math.PI/2,0,0]),D.build(f,a,o,r)}const m=new xe;m.position.y=.505,m.rotation.order="YXZ",f.add(m),Bv(m,n,e,r,a);const u=D=>{const A=new xe;A.position.set(D*.197,.415,0),A.rotation.order="YXZ",f.add(A);const y=new xe;y.position.y=-Qs,A.add(y);const rt=new xe;rt.position.y=-Wr,y.add(rt);const S=yn();S.part(os(.076,10),n.cloth,[0,-.01,0],[0,0,0],[1,.95,1.06]),S.part(Xe(.063,.052,Qs,10),n.cloth,[0,-Qs*.5,0]),S.part(Xe(.055,.052,.055,10),n.cloth,[0,-Qs+.024,0]),S.part(fe(.05,.065,.012),n.cloth,[D*.055,-.13,-.02],[0,D*.35,0]),S.build(A,a,o,r);const z=yn();z.part(Xe(.053,.046,Wr,10),n.cloth,[0,-Wr*.5,0]),z.part(Xe(.056,.05,.1,10),n.cloth,[0,-.065,0]),z.build(y,a,o,r);const nt=yn();nt.part(ve(.064,.1,.09,.026),n.glove,[0,-.055,-.004]),nt.part(ve(.056,.038,.03,.012),n.glove,[D*.044,-.035,.002]);for(let q=0;q<3;q++)nt.part(ve(.052,.018,.019,.006),n.glove,[0,-.078,-.048]);return nt.part(ve(.028,.048,.04,.012),n.glove,[-D*.034,-.05,-.03]),nt.build(rt,a,o,r),{shoulder:A,elbow:y,hand:rt}},d=u(-1),c=u(1),v=D=>{const A=new xe;A.position.set(D*.108,0,0),A.rotation.order="YXZ",h.add(A);const y=new xe;y.position.y=-Za,A.add(y);const rt=new xe;rt.position.y=-Or,y.add(rt);const S=yn();S.part(Xe(.099,.079,Za,10),n.cloth,[0,-Za*.5,0]),S.part(os(.09,8),n.cloth,[0,-.005,0],[0,0,0],[.96,.8,1]),S.build(A,a,o,r);const z=yn();z.part(ve(.066,.14,.05,.015),n.gear,[D*.07,-.19,-.012]),z.part(fe(.06,.022,.04),n.gear,[D*.07,-.125,-.014]),D>0?(z.part(ve(.088,.165,.06,.018),n.gear,[.072,-.215,-.008]),z.part(fe(.032,.075,.038),n.gear,[.072,-.128,.014],[.28,0,0]),z.part(fe(.032,.026,.045),n.metal,[.072,-.088,.028],[.28,0,0]),z.part(fe(.098,.024,.11),n.gear,[.066,-.288,-.012]),z.part(fe(.095,.022,.105),n.gear,[.066,-.15,-.006])):z.part(ve(.062,.09,.045,.012),n.gear,[-.07,-.1,.012]),z.build(A,a,o,r);const nt=yn();nt.part(ve(.125,.13,.08,.03),n.gear,[0,-.022,-.05],[.12,0,0]),nt.part(fe(.108,.022,.04),n.gear,[0,.038,-.048]),nt.build(y,a,o,r);const q=yn();q.part(Xe(.078,.062,.05,10),n.cloth,[0,-.012,0]),q.part(Xe(.062,.052,Or,10),n.cloth,[0,-Or*.5,0]),q.part(Xe(.066,.062,.075,10),n.cloth,[0,-Or+.034,0]),q.build(y,a,o,r);const j=yn();return j.part(ve(.112,.125,.135,.024),n.leather,[0,.008,0]),j.part(ve(.118,.078,.26,.028),n.leather,[0,-.055,-.055]),j.part(ve(.128,.034,.29,.014),n.leather,[0,-.089,-.057]),j.part(ve(.11,.056,.065,.018),n.leather,[0,-.062,-.178]),j.part(fe(.104,.02,.032),n.leather,[0,-.02,-.105]),j.part(fe(.106,.018,.03),n.leather,[0,-.038,-.075]),j.build(rt,a,o,r),{hip:A,knee:y,ankle:rt}},p=v(-1),x=v(1),w=new xe;w.rotation.order="YXZ",f.add(w);const b=new Ze,C=new N(0,.052,-.6);b.position.copy(C),w.add(b);{const D=yn(),A=yn(),y=s.polymer,rt=s.polymer,S=.16;D.part(fe(.05,.078,.26,S),s.metal,[0,.046,-.11]),D.part(fe(.046,.05,.13,S),s.metal,[0,-.002,-.12]),D.part(fe(.014,.03,.055),s.metal,[.027,.052,-.12]),D.part(fe(.028,.016,.3,S),s.metal,[0,.09,-.13]);for(let nt=0;nt<8;nt++)D.part(fe(.03,.009,.013),s.metal,[0,.098,-.02-nt*.026]);A.part(Xe(.032,.029,.26,8,.3),y,[0,.052,-.37],[Math.PI/2,0,0],[1,1,.85]),D.part(fe(.026,.013,.24,S),s.metal,[0,.081,-.37]),D.part(fe(.013,.024,.17),s.metal,[.034,.05,-.365]),D.part(fe(.013,.024,.17),s.metal,[-.034,.05,-.365]),D.part(Xe(.0115,.0115,.135,8),s.metal,[0,.052,-.505],[Math.PI/2,0,0]),D.part(Xe(.016,.014,.062,8),s.metal,[0,.052,-.577],[Math.PI/2,0,0]),D.part(Xe(.0175,.0175,.013,8),s.metal,[0,.052,-.548],[Math.PI/2,0,0]),D.part(fe(.028,.03,.032),s.metal,[0,.077,-.493]),A.part(ve(.032,.12,.068,.009),rt,[0,-.077,-.155],[.06,0,0]),A.part(ve(.032,.085,.063,.009),rt,[0,-.16,-.172],[.24,0,0]),A.part(fe(.036,.014,.072),rt,[0,-.202,-.182],[.24,0,0]),A.part(ve(.035,.105,.052,.015),y,[0,-.045,.022],[-.33,0,0]),A.part(fe(.02,.009,.06),rt,[0,-.012,-.02]),D.part(Xe(.017,.017,.1,8),s.metal,[0,.055,.06],[Math.PI/2,0,0]),A.part(ve(.048,.09,.115,.014),y,[0,.035,.185]),A.part(ve(.04,.024,.1,.01),y,[0,.088,.175]),A.part(ve(.052,.098,.016,.006),y,[0,.032,.248]),D.part(fe(.036,.013,.08),s.metal,[0,.104,-.055]),D.part(fe(.052,.062,.017),s.metal,[0,.148,-.088]),D.part(fe(.052,.022,.064),s.metal,[0,.172,-.06]),D.part(fe(.052,.062,.015),s.metal,[0,.148,-.012]),D.part(fe(.028,.013,.032),s.metal,[0,.07,.012]),D.build(w,a,null,r),A.build(w,a,null,r);const z=yn();z.part(fe(.038,.044,.007),n.lens,[0,.148,-.083]),z.build(w,null,null,r)}const V=new ki(new Ei({map:i.sprites.flash,color:16769200,transparent:!0,blending:cn,depthWrite:!1,toneMapped:!1,opacity:0}));return V.scale.setScalar(.5),V.position.copy(C),w.add(V),{root:l,body:l,hips:h,torso:f,headPivot:m,armL:d,armR:c,legL:p,legR:x,weapon:w,weaponMuzzle:b,weaponFlash:V,variant:e,meshes:r,anchorR:Nv,anchorL:Fv,height:1.82,eyeHeight:1.685,dispose(){for(const D of r)D.geometry&&D.geometry.dispose();V.material.dispose()}}}function Bv(i,t,e,n,s,r){const a=yn();a.part(os(.1,14),t.skin,[0,.155,0],[0,0,0],[.79,.96,.9]),a.part(os(.09,12),t.skin,[0,.107,-.016],[0,0,0],[.64,.56,.62]);for(const o of[-1,1])a.part(os(.024,8),t.skin,[o*.077,.152,.006],[0,0,0],[.55,1,.8]);if(a.part(os(.103,14,.86,Math.PI-.86),t.gear,[0,.158,.002],[0,0,0],[.815,1,.935]),a.part(Xe(.064,.075,.12,10),t.gear,[0,.015,0]),a.part(os(.106,18,0,1.63),t.cloth,[0,.186,0],[0,0,0],[1.04,.98,1.1]),a.part(Pv(.105,.009,6,20),t.cloth,[0,.1805,0],[Math.PI/2,0,0],[1,1,1.06]),a.part(Xe(.1095,.1095,.024,20,.35,!0),t.gear2,[0,.207,0],[0,0,0],[1,1,1.06]),a.part(fe(.032,.018,.2,.2),t.cloth,[0,.281,.012],[.1,0,0]),e.face==="shemagh"&&(a.part(ve(.162,.105,.165,.04),t.cloth,[0,.098,-.004]),a.part(ve(.178,.06,.16,.032),t.cloth,[0,.158,.022],[.2,0,0])),e.goggles==="eyes"||e.face==="mask"){a.part(ve(.144,.056,.048,.016),t.gear,[0,.15,-.077],[.06,0,0]),a.part(fe(.156,.028,.026),t.gear,[0,.15,-.05]);for(const o of[-1,1])a.part(fe(.019,.038,.095),t.gear,[o*.084,.15,-.012])}else{a.part(ve(.144,.056,.058,.016),t.gear,[0,.252,-.072],[.95,0,0]);for(const o of[-1,1])a.part(fe(.019,.032,.08),t.gear,[o*.084,.244,-.02])}e.face==="mask"?(a.part(ve(.132,.108,.095,.03),t.gear,[0,.09,-.05]),a.part(Xe(.03,.03,.028,10),t.gear,[0,.095,-.112],[Math.PI/2,0,0])):(a.part(ve(.142,.088,.052,.022),t.gear,[0,.096,-.072]),a.part(fe(.06,.014,.02),t.gear2,[0,.05,-.096]));for(const o of[-1,1])a.part(fe(.013,.1,.013),t.gear,[o*.073,.09,-.012],[0,0,o*.12]);a.part(fe(.066,.02,.017),t.gear,[0,.04,-.048]),a.part(ve(.054,.044,.03,.008),t.metal,[0,.244,-.092]),a.part(fe(.026,.052,.017),t.metal,[0,.214,-.097],[.25,0,0]);for(const o of[-1,1])a.part(fe(.015,.026,.105),t.metal,[o*.1,.196,-.005]),a.part(fe(.013,.013,.032),t.metal,[o*.106,.17,-.046]);if(e.nvg==="active"){a.part(fe(.035,.03,.04),t.metal,[0,.248,-.12]);for(const o of[-1,1])a.part(Xe(.02,.022,.058,10),t.metal,[o*.025,.258,-.16],[Math.PI/2,0,0]),a.part(Xe(.021,.021,.008,10),t.lens,[o*.025,.258,-.19],[Math.PI/2,0,0])}else e.nvg==="stowed"&&a.part(fe(.044,.044,.054),t.metal,[0,.29,-.056],[.95,0,0]);(e.goggles==="eyes"||e.face==="mask")&&a.part(fe(.128,.04,.01),t.lens,[0,.15,-.1],[.06,0,0]),a.build(i,s,null,n)}const Ml=new In,Oa=new In,Su=new In,zr=new In,wu=new In,Xs=new N,qs=new N,kv=new wn(0,0,0,"YXZ");function yl(i,t){const{hips:e,torso:n,headPivot:s,legL:r,legR:a,armL:o,armR:l,weapon:h}=i,f=t.crouch||0,m=t.walkAmp||0,u=t.walkPhase||0,d=t.aim==null?1:t.aim,c=t.weaponLevel||0,v=t.aimPitch||0,p=t.flinch||0,x=t.recoil||0,w=t.limp||0,b=t.time||0,C=Math.sin(b*1.55),V=m*(.022*Math.abs(Math.sin(u))+.006*Math.sin(u*2));e.position.set(Math.sin(u)*.012*m,Ah-f*.285-V+C*.0035-w*.05,0);const D=d*.13;e.rotation.set(0,-Math.sin(u)*.1*m+D,0);const A=f*.38+m*.1+w*.08;n.rotation.set(-A+p*.34+x*.035+C*.005,Math.sin(u)*.135*m+d*.045-D*.72,Math.sin(u)*.028*m-p*.06+Math.sin(b*.7)*.004,"YXZ");const y=e.rotation.x+n.rotation.x,rt=e.rotation.y+n.rotation.y,S=1-d;h.position.set(.132+.05*S,.218-.118*S+C*.0045+x*.012-w*.075,-.185+.065*S+x*.03);const z=d*(v-(1-c)*.075)+S*-.58+w*.1,nt=d*(.06+(1-c)*.36)+S*.62-w*.1;h.rotation.set(z-y+x*.05,nt-rt,-.12-.14*S+Math.sin(b*.9)*.004,"YXZ"),zr.copy(h.quaternion),Xs.copy(i.anchorR).applyQuaternion(zr).add(h.position),qs.set(.45,-1,.3),_l(l.shoulder,l.elbow,Xs,Qs,Wr,qs),Xs.copy(i.anchorL).applyQuaternion(zr).add(h.position),qs.set(-.62,-1,.18),_l(o.shoulder,o.elbow,Xs,Qs,Wr,qs),Oa.multiplyQuaternions(l.shoulder.quaternion,l.elbow.quaternion).invert(),l.hand.quaternion.copy(Oa).multiply(zr),Oa.multiplyQuaternions(o.shoulder.quaternion,o.elbow.quaternion).invert(),o.hand.quaternion.copy(Oa).multiply(zr);const q=.26*m*(1+.5*m),j=.06*m+.03*m*m;Ml.copy(e.quaternion).invert();const Y=(ht,lt,Dt)=>{const yt=Math.max(0,-Math.sin(Dt)),dt=lt*.128+w*lt*.09,et=.105+yt*j+w*.14,Lt=-Math.cos(Dt)*q+(lt<0?-.035:.04)+f*.035+w*(lt<0?-.16:.22);Xs.set(dt,et,Lt).sub(e.position).applyQuaternion(Ml),qs.set(lt*.3,0,-1).applyQuaternion(Ml),_l(ht.hip,ht.knee,Xs,Za,Or,qs);const k=yt*.28*m+w*.4;wu.copy(ht.hip.quaternion).multiply(ht.knee.quaternion).invert(),Su.setFromEuler(kv.set(k,lt*.055,0,"YXZ")),ht.ankle.quaternion.copy(wu).multiply(Su)};Y(r,-1,u),Y(a,1,u+Math.PI);const W=(t.lookYaw||0)-rt;s.rotation.set(qe.clamp(v*.9-y,-.55,.6)+p*.16-w*.3+C*.006,qe.clamp(W,-1.05,1.05),(t.headRoll||0)+p*.12*(t.flinchSide||1)+w*.5*(t.deathSide||1),"YXZ")}const Hv=new N,Gv=new N,Ys=new N,Vv=new Bn;let Wv=0;const bu=1.685,Xv=1.3,Ba=.435,ka=.395;function Tu(i){for(;i>Math.PI;)i-=Math.PI*2;for(;i<-Math.PI;)i+=Math.PI*2;return i}const Ha=qe.clamp;class qv{constructor(t,e,n,s){this.scene=t,this.mats=e,this.colliders=n,this.rnd=s||Math.random,this.hp=100,this.alive=!0,this.state="advance",this.walkT=Math.random()*10,this.speed=0,this.deathT=0,this.flinch=0,this.recoil=0,this.canSee=!1,this.sightTimer=Math.random()*.3,this.burstLeft=0,this.fireTimer=.8+Math.random()*1.2,this.strafeDir=Math.random()>.5?1:-1,this.strafeTimer=1+Math.random()*2,this.repositionTimer=3+Math.random()*3,this.crouch=0,this.coverPoint=null,this.coverTimer=0,this.aimPitch=0,this.aimYaw=0,this.idleTime=0,this.lastDamage=0,this.aimBlend=1,this.weaponLevel=0,this.walkAmp=0,this.headYawS=0,this.aimPitchS=0,this.animT=Math.random()*6,this.weaponFlashT=0,this.deathSide=1,this.deathFall=1,this.deathPose={l:.5,r:.5},this.variant=Wv++%3,this.rig=Ov(e,this.variant),this.root=new xe,this.root.position.set(0,0,0),this.root.add(this.rig.root),t.add(this.root),this.body=this.rig.root,this.hips=this.rig.hips,this.torso=this.rig.torso,this.headPivot=this.rig.headPivot,this.armL=this.rig.armL,this.armR=this.rig.armR,this.legL=this.rig.legL,this.legR=this.rig.legR,this.weapon=this.rig.weapon,this.weaponMuzzle=this.rig.weaponMuzzle,this.weaponFlash=this.rig.weaponFlash,this.hitboxes=[],this.buildHitboxes(),this.restPose()}buildHitboxes(){const t=(e,n,s,r,a,o,l,h,f)=>{const m=new K(new Rt(e,n,s),Vv);return m.position.set(a,o,l),m.visible=!1,m.userData={enemy:this,part:h,dmg:f},r.add(m),this.hitboxes.push(m),m};this.headBox=t(.218,.256,.215,this.rig.headPivot,0,.161,-.005,"head",3.6),this.neckBox=t(.17,.14,.17,this.rig.torso,0,.49,0,"torso",1),this.torsoBox=t(.445,.4,.31,this.rig.torso,0,.255,0,"torso",1),this.hipBox=t(.36,.26,.27,this.rig.hips,0,.055,0,"torso",.9),this.armLBox=t(.135,.29,.155,this.rig.armL.shoulder,0,-.155,0,"arms",.6),this.armRBox=t(.135,.29,.155,this.rig.armR.shoulder,0,-.155,0,"arms",.6),this.foreLBox=t(.12,.25,.14,this.rig.armL.elbow,0,-.13,0,"arms",.6),this.foreRBox=t(.12,.25,.14,this.rig.armR.elbow,0,-.13,0,"arms",.6),this.legLBox=t(.165,Ba,.195,this.rig.legL.hip,0,-Ba*.5,0,"legs",.7),this.legRBox=t(.165,Ba,.195,this.rig.legR.hip,0,-Ba*.5,0,"legs",.7),this.shinLBox=t(.148,ka,.178,this.rig.legL.knee,0,-ka*.5,0,"legs",.65),this.shinRBox=t(.148,ka,.178,this.rig.legR.knee,0,-ka*.5,0,"legs",.65),this.footLBox=t(.135,.115,.3,this.rig.legL.ankle,0,-.05,-.055,"legs",.55),this.footRBox=t(.135,.115,.3,this.rig.legR.ankle,0,-.05,-.055,"legs",.55)}restPose(){yl(this.rig,{time:0,crouch:.1,walkAmp:0,walkPhase:0,aim:1,weaponLevel:0,aimPitch:0,lookYaw:0,flinch:0,recoil:0,limp:0})}applyBodyPose(t,e={}){yl(this.rig,{time:this.animT,crouch:this.crouch,walkAmp:this.walkAmp,walkPhase:this.walkT,aim:this.aimBlend,weaponLevel:this.weaponLevel,aimPitch:this.aimPitchS,lookYaw:this.headYawS,flinch:this.flinch,recoil:this.recoil,limp:e.limp||0,headRoll:e.headRoll||0,deathSide:this.deathSide,flinchSide:this.lastHitSide||1})}spawn(t,e,n=0){this.root.position.set(t,0,e),this.root.rotation.set(0,n,0),this.hp=100,this.alive=!0,this.state="advance",this.deathT=0,this.burstLeft=0,this.fireTimer=.6+Math.random()*1.4,this.crouch=.1,this.flinch=0,this.recoil=0,this.speed=0,this.walkAmp=0,this.aimBlend=1,this.weaponLevel=0,this.headYawS=0,this.aimPitchS=0,this.aimPitch=0,this.walkT=Math.random()*6,this.animT=0,this.coverPoint=null,this.coverTimer=0,this.canSee=!1,this.sightTimer=Math.random()*.3,this.lastDamage=0,this.burstLeft=0,this.aimYaw=0,this.idleTime=0,this.strafeDir=this.rnd()>.5?1:-1,this.strafeTimer=1+this.rnd()*2,this.repositionTimer=3+this.rnd()*3,this.deathFall=1,this.deathSide=1,this.deathTwist=0,this.weaponFlashT=0,this.weaponFlash.material.opacity=0,this.weapon.visible=!0;for(const s of this.hitboxes)s.visible=!1;this.restPose()}get eyePos(){return Hv.set(this.root.position.x,bu+this.root.position.y,this.root.position.z)}takeDamage(t,e,n,s="torso"){if(!this.alive)return!1;if(this.hp-=t,this.flinch=Math.min(1,this.flinch+.55),this.lastDamage=.5,s==="arms"&&(this.flinch*=.7),e){const r=e.x-this.root.position.x,a=e.z-this.root.position.z,o=Math.atan2(r,a)-this.root.rotation.y;this.lastHitSide=Math.sin(o)>0?1:-1}return this.hp<=0?(this.die(e,n),!0):(this.state==="advance"&&(this.state="engage"),!1)}die(t,e){this.alive=!1,this.state="dead",this.deathT=0,this.deathFall=this.rnd()>.42?1:-1,this.deathSide=this.rnd()>.5?1:-1,this.deathTwist=(this.rnd()-.5)*1.1,this.deathPose={l:this.rnd(),r:this.rnd()},this.speed=0,this.walkAmp=0,this.crouch=0,this.weapon.visible=!0;for(const n of this.hitboxes)n.visible=!1}canSeePlayer(t){const e=this.eyePos.clone(),n=t.clone(),s=n.x-e.x,r=n.z-e.z,a=Math.max(2,Math.floor(Math.hypot(s,r)/1.2));for(let o=1;o<a;o++){const l=o/a,h=e.x+s*l,f=e.z+r*l;for(const m of this.colliders)if(h>m.x0&&h<m.x1&&f>m.z0&&f<m.z1)return!1}return!0}resolveCollision(){const t=this.root.position,e=.34;for(const n of this.colliders)if(t.x>n.x0-e&&t.x<n.x1+e&&t.z>n.z0-e&&t.z<n.z1+e){const s=Math.abs(t.x-(n.x0-e)),r=Math.abs(n.x1+e-t.x),a=Math.abs(t.z-(n.z0-e)),o=Math.abs(n.z1+e-t.z),l=Math.min(s,r,a,o);l===s?t.x=n.x0-e:l===r?t.x=n.x1+e:l===a?t.z=n.z0-e:t.z=n.z1+e}t.x=Ha(t.x,-20,20),t.z=Ha(t.z,-63,50)}update(t,e){const n=e.playerPos;if(this.animT+=t,!this.alive){this.updateDeath(t);return}this.flinch=Math.max(0,this.flinch-t*2.8),this.recoil=Math.max(0,this.recoil-t*6),this.lastDamage=Math.max(0,this.lastDamage-t),this.weaponFlashT=Math.max(0,this.weaponFlashT-t),this.weaponFlash.material.opacity=this.weaponFlashT>0?1:0,this.sightTimer-=t,this.sightTimer<=0&&(this.sightTimer=.16+Math.random()*.12,this.canSee=this.canSeePlayer(n));const s=Gv.set(n.x-this.root.position.x,0,n.z-this.root.position.z),r=s.length(),a=s.clone().normalize();if(this.hp<38&&this.lastDamage>0&&this.state!=="cover"){const D=this.nearestCover(e.coverPoints,n);D&&(this.coverPoint=D,this.state="cover",this.coverTimer=2.2+Math.random()*2)}this.state==="cover"?(this.coverTimer-=t,this.coverTimer<=0&&(this.state=this.canSee?"engage":"advance",this.coverPoint=null)):this.state!=="dead"&&(this.canSee&&r<48?this.state="engage":this.state="advance"),this.state==="engage"&&r>52&&(this.state="advance");let o=0,l=0,h=0;if(this.state==="advance"){this.strafeTimer-=t,this.strafeTimer<=0&&(this.strafeTimer=1.4+Math.random()*2.2,this.strafeDir*=-1);const D=new N(-a.z,0,a.x).multiplyScalar(this.strafeDir*.55);Ys.copy(a).add(D).normalize(),o=Ys.x,l=Ys.z,h=3.3}else if(this.state==="engage"){this.repositionTimer-=t,this.strafeTimer-=t,this.strafeTimer<=0&&(this.strafeTimer=1+Math.random()*1.6,this.strafeDir*=-1);const D=15,A=r>D+6?1:r<D-6?-1:0,y=new N(-a.z,0,a.x).multiplyScalar(this.strafeDir);Ys.copy(a).multiplyScalar(A).add(y.multiplyScalar(.7)).normalize(),o=Ys.x*.66,l=Ys.z*.66,h=r>32?2.4:1.15,r<9&&(o=-a.x,l=-a.z,h=2.1)}else if(this.state==="cover"&&this.coverPoint){const D=this.coverPoint.x-this.root.position.x,A=this.coverPoint.z-this.root.position.z,y=Math.hypot(D,A);y>.7?(o=D/y,l=A/y,h=3.4):h=0}this.speed+=(h-this.speed)*Math.min(1,t*6);const f=this.speed>.35;this.speed>.02&&(this.root.position.x+=o*this.speed*t,this.root.position.z+=l*this.speed*t,this.resolveCollision());let m;this.state==="advance"&&this.speed>.3?m=Math.atan2(-o,-l):m=Math.atan2(-a.x,-a.z);const u=Tu(m-this.root.rotation.y);this.root.rotation.y+=u*Math.min(1,t*(this.state==="engage"?7:4.5));const d=Math.atan2(-a.x,-a.z),c=Tu(d-this.root.rotation.y),v=Ha(c*.8,-.95,.95);this.headYawS+=(v-this.headYawS)*Math.min(1,t*5.5);const p=n.y!=null?n.y:Xv,x=Math.atan2(p-(this.root.position.y+bu),Math.max(.8,r));this.aimPitchS+=(x-this.aimPitchS)*Math.min(1,t*5),this.aimPitch=this.aimPitchS;const w=this.state==="cover"?1:this.state==="engage"&&this.hp<62?.34:0;this.crouch+=(w-this.crouch)*Math.min(1,t*5);const b=f?Math.min(1.2,.5+this.speed*.24):0;this.walkAmp+=(b-this.walkAmp)*Math.min(1,t*7),this.walkT+=t*(f?2.4+this.speed*2.2:.85);const C=(this.state==="engage"||this.state==="cover")&&this.canSee?1:0;this.aimBlend+=(C-this.aimBlend)*Math.min(1,t*5.5);const V=this.burstLeft>0?1:0;this.weaponLevel+=(V-this.weaponLevel)*Math.min(1,t*12),this.applyBodyPose(t),this.state==="engage"&&this.canSee&&e.playerAlive?(this.fireTimer-=t,this.burstLeft>0?this.fireTimer<=0&&(this.shoot(e,r,n),this.burstLeft--,this.fireTimer=.085+Math.random()*.05):this.fireTimer<=0&&(this.burstLeft=3+Math.floor(Math.random()*4),this.fireTimer=.3+Math.random()*.35)):this.burstLeft>0&&(this.burstLeft=0)}updateDeath(t){this.deathT=Math.min(1,this.deathT+t*1.35);const e=this.deathT*this.deathT*(3-2*this.deathT),n=this.deathFall,s=(Math.PI*.5-.06)*n,r=Math.sin(Math.min(1,this.deathT*2.2)*Math.PI)*.09;this.root.rotation.x=s*e-r*(1-e),this.root.rotation.z=this.deathTwist*.55*e,this.root.position.y=.075*e,yl(this.rig,{time:this.animT,crouch:0,walkAmp:0,walkPhase:this.deathPose.l*2,aim:.25*(1-e),weaponLevel:0,aimPitch:-.1,lookYaw:0,flinch:0,recoil:0,limp:e,headRoll:.35*e*this.deathSide,deathSide:this.deathSide}),this.deathT>=1&&(this.root.position.y=.08),this.weaponFlash.material.opacity=0}shoot(t,e,n){this.weaponFlashT=.05,this.weaponFlash.material.opacity=1,this.weaponFlash.material.rotation=Math.random()*6,this.weaponFlash.scale.setScalar(.18+Math.random()*.1),this.recoil=.85,this.weaponLevel=1;const s=new N;this.weaponMuzzle.getWorldPosition(s);const r=t.playerSpeed||0,a=.32+e*.02+r*.05,o=new N((Math.random()-.5)*a,(Math.random()-.5)*a*.7,(Math.random()-.5)*a),l=n.clone().add(o),h=Ha(.72-e*.011-r*.035,.12,.72),f=Math.random()<h,m=f?n.clone().add(new N((Math.random()-.5)*.25,-.15,(Math.random()-.5)*.25)):l;t.fx.tracer(s,m,{color:16763274,width:.03,life:.05}),t.fx.muzzleFlash(s),f&&t.damagePlayer(4.5+Math.random()*2.5,this.root.position);const u=t.panFor?t.panFor(this.root.position):0;t.audio.enemyShot(u,e),t.onEnemyFire&&t.onEnemyFire(this.root.position,this),!f&&e<26&&Math.random()>.5&&t.audio.whiz(u)}nearestCover(t,e){let n=null,s=1/0;for(const r of t){const a=Math.hypot(r.x-this.root.position.x,r.z-this.root.position.z);if(a>14)continue;const o=Math.hypot(r.x-e.x,r.z-e.z),l=a*.6-o*.25+Math.random()*2;l<s&&(s=l,n=r)}return n}dispose(){this.scene.remove(this.root),this.rig.dispose()}}const Hc=new URLSearchParams(location.search),ai=Hc.get("shot")==="1",Ga=Hc.get("pose")||"hero",Ch=Hc.get("hidehud")==="1",Cn=[{id:"m4",name:"M4A1",magSize:30,reserve:180,dmg:30,rpm:720,auto:!0,spread:.0125,adsSpread:.0016,recoil:1,variant:"black",mode:"AUTO"},{id:"mk18",name:"MK18",magSize:25,reserve:150,dmg:34,rpm:800,auto:!0,spread:.015,adsSpread:.0021,recoil:1.18,variant:"tan",mode:"AUTO"}],Z={state:"loading",hp:100,maxHp:100,armor:60,maxArmor:60,score:0,kills:0,wave:1,waveRemaining:0,waveTotal:0,spawnQueue:[],spawnTimer:0,waveClearTimer:0,time:0,sinceDamage:99,weaponIndex:0,mag:30,reserve:180,weaponAmmo:[{mag:30,reserve:180},{mag:25,reserve:150}],fps:60,reloadTimer:-1,reloadTransferred:!1,fireCooldown:0,grenades:2,firing:!1,shotFired:!1,freezeEnemies:!1,debugWaves:!1,hitStop:0,lockHint:!1,debugAutoFire:!1,readyFrames:0,ready:!1,hurtTimer:0};let pe,kn,Qe,On,Oe,Te,Ne,Ge,Yv;const hn=[],ir=[];let fr,Gc=!1,Sl=0;const wl=new xh;let gc=0;const $v=document.getElementById("loading"),Eu=document.getElementById("load-fill"),ho=document.getElementById("load-text"),Rh=document.getElementById("menu"),$s=document.getElementById("pause"),vc=document.getElementById("death"),$r=document.getElementById("hud");function Ks(i,t){Eu&&(Eu.style.width=`${i*100}%`),ho&&t&&(ho.textContent=t)}const Nr=()=>new Promise(i=>requestAnimationFrame(()=>requestAnimationFrame(i)));async function Kv(){try{Ks(.05,"初始化渲染器…"),await Nr(),pe=q2(document.getElementById("gl"),"high"),Ks(.34,"生成程序化 PBR 材质与大气…"),await Nr(),kn=K2(pe),Ks(.58,"构建战区街区…"),await Nr(),Qe=uv(pe.mats,pe.sky.envTexture),Ks(.72,"装配武器与手部动画…"),await Nr(),On=gv(pe.scene,pe.mats),Oe=vv(),Te=wv(),Ne=bv(pe.renderer.domElement),Ge=Tv(pe.camera,kn.colliders,kn.bounds,Oe),fr=new xh,fr.far=160,rx(),Yv=pe.addOverlay(Qe.scene,Qe.camera),window.addEventListener("resize",Au),document.getElementById("deploy").addEventListener("click",()=>{Oe.init(),Zv(),ja(!0)}),document.getElementById("resume").addEventListener("click",()=>{Z.state="playing",$s.classList.add("hidden"),Ne.lock()}),document.getElementById("quit").addEventListener("click",()=>{$s.classList.add("hidden"),vc.classList.add("hidden"),$r.classList.add("hidden"),Rh.classList.remove("hidden"),Z.state="menu",Ne.unlock(),fo(),Qe.root.visible=!1}),document.getElementById("redeploy").addEventListener("click",()=>{vc.classList.add("hidden"),fo(),ja(!0)});for(const i of document.querySelectorAll(".quality-pills button"))i.addEventListener("click",()=>{const t=i.dataset.q||i.dataset.pq;pe.setQuality(t),Au();for(const e of document.querySelectorAll(".quality-pills button"))e.classList.toggle("active",(e.dataset.q||e.dataset.pq)===t);Oe.init(),Oe.ui()});Ne.on("unlock",()=>{ai||Z.state==="playing"&&(Z.state="paused",$s.classList.remove("hidden"))}),document.addEventListener("visibilitychange",()=>{document.hidden&&Z.state==="playing"&&!ai&&(Z.state="paused",$s.classList.remove("hidden"),Ne.unlock())}),Ne.on("key",i=>{i==="Escape"&&Z.state==="playing"&&(Z.state="paused",$s.classList.remove("hidden"),Ne.unlock()),Z.state==="playing"&&(i==="KeyR"&&Jr(),i==="KeyF"&&Qe.inspect(),i==="KeyG"&&ex(),i==="Digit1"&&Cu(0),i==="Digit2"&&Cu(1),i==="KeyP"&&(Z.state="paused",$s.classList.remove("hidden"),Ne.unlock()))}),pe.renderer.domElement.addEventListener("click",()=>{Z.state==="playing"&&!ai&&!Ne.locked&&Ne.lock()}),Ks(.92,"预热着色器…"),await Nr(),Qe.root.visible=!1,$r.classList.add("hidden"),Z.state="menu",Ks(1,"就绪"),setTimeout(()=>$v.classList.add("hidden"),260),ai&&(ja(!1,!0),ax()),gc=performance.now(),requestAnimationFrame(Uh)}catch(i){console.error(i),ho&&(ho.textContent="启动失败："+(i&&i.message?i.message:i))}}function Au(){const i=window.innerWidth/window.innerHeight;Qe.setAspect(i),pe.onResize()}function Zv(){Oe.ctx&&(Oe.ambient(),Oe.setMasterVolume(.58))}function ja(i=!0,t=!1){if(fo(),Rh.classList.add("hidden"),$r.classList.remove("hidden"),Qe.root.visible=!0,Z.state="playing",Ge.revive(1.2,33),Ge.setLook(-.03,-.015),t||Oe.uiConfirm(),i&&Ne.lock(),Ph(1),$r.classList.toggle("hidden",Ch),!ai){const e=document.getElementById("hint");e.textContent=""}}function fo(){Z.hp=Z.maxHp,Z.armor=Z.maxArmor,Z.score=0,Z.kills=0,Z.wave=1,Z.waveRemaining=0,Z.waveTotal=0,Z.spawnQueue.length=0,Z.spawnTimer=0,Z.waveClearTimer=0,Z.grenades=2,Z.reloadTimer=-1,Z.reloadTransferred=!1,Z.sinceDamage=99,Z.time=0,Z.weaponIndex=0,Z.weaponAmmo=[{mag:Cn[0].magSize,reserve:Cn[0].reserve},{mag:Cn[1].magSize,reserve:Cn[1].reserve}],Z.mag=Cn[0].magSize,Z.reserve=Cn[0].reserve;for(const i of hn)i.root.visible=!1;hn.length=0;for(const i of ir)pe.scene.remove(i.mesh);ir.length=0,Te.reset(),Te.setWeaponName(Cn[0].name,Cn[0].magSize,Cn[0].mode),Te.setAmmo(Z.mag,Z.reserve,Cn[0].name,Cn[0].mode),Te.setHealth(Z.hp,Vc(Z.armor)),Te.setScore(0,0),Te.setGrenades(2),Qe.setWeapon(Cn[0].variant)}function Vc(i){return Math.ceil(i/20)}function Ph(i){Z.wave=i;const t=Math.min(11,3+i);Z.waveTotal=t,Z.waveRemaining=t,Z.spawnQueue=[];const e=Ge.pos,n=kn.spawnPoints.slice();for(let s=0;s<t;s++){let r=null,a=-1;for(let o=0;o<4;o++){const l=n[Math.floor(Math.random()*n.length)],h=Math.hypot(l.x-e.x,l.z-e.z);h>a&&(a=h,r=l)}Z.spawnQueue.push({x:r.x+(Math.random()-.5)*2.2,z:r.z+(Math.random()-.5)*2.2})}Z.spawnTimer=.8,Z.waveClearTimer=0,Te.setWave(i),Te.setWaveProgress(0),Te.setObjective(`清剿残敌 · 剩余 ${t}`),Te.setHint("WAVE "+i),setTimeout(()=>Te.setHint(""),1400)}function ls(i){let t=hn.find(s=>!s.alive&&s.root.visible===!1)||hn.find(s=>!s.alive);if(!t){if(hn.length>=14)return;t=new qv(pe.scene,pe.mats,kn.colliders),hn.push(t)}const e=Ge.pos,n=Math.atan2(-(e.x-i.x),-(e.z-i.z));t.spawn(i.x,i.z,n),t.root.visible=!0,ai&&(t.state="engage")}function jv(i){if(ai&&!Z.debugWaves)return;if(Z.spawnQueue.length>0){Z.spawnTimer-=i;const e=hn.filter(n=>n.alive).length;if(Z.spawnTimer<=0&&e<6){const n=Z.spawnQueue.shift();ls(n),Z.spawnTimer=.75+Math.random()*.6}}const t=hn.filter(e=>e.alive).length;if(Z.waveRemaining<=0&&Z.spawnQueue.length===0&&t===0){if(Z.waveClearTimer===0){Z.waveClearTimer=.001,Te.setHint("WAVE CLEARED"),Z.score+=250,Te.setScore(Z.score,Z.kills);const e=xs();Z.mag=e.magSize,Z.reserve=e.reserve,Z.weaponAmmo[Z.weaponIndex]={mag:Z.mag,reserve:Z.reserve},Te.setAmmo(Z.mag,Z.reserve,e.name,e.mode),Z.grenades=Math.min(3,Z.grenades+1),Te.setGrenades(Z.grenades)}Z.waveClearTimer+=i,Z.waveClearTimer>4&&(Z.waveClearTimer=0,Ph(Z.wave+1))}Te.setWaveProgress(1-Z.waveRemaining/Math.max(1,Z.waveTotal)),(Z.waveRemaining>0||t>0)&&Te.setObjective(`清剿残敌 · 剩余 ${Math.max(t,Z.waveRemaining)}`)}const qn=new N,Jv=new N,fs=new N,po=new N,bl=new N,Zs=new N;function xs(){return Cn[Z.weaponIndex]}function Cu(i){if(i===Z.weaponIndex||Z.reloadTimer>=0)return;Z.weaponAmmo[Z.weaponIndex]={mag:Z.mag,reserve:Z.reserve},Z.weaponIndex=i;const t=Cn[i],e=Z.weaponAmmo[i]||{mag:t.magSize,reserve:t.reserve};Z.mag=e.mag,Z.reserve=e.reserve,Qe.setWeapon(t.variant),Te.setWeaponName(t.name,t.magSize,t.mode),Te.setAmmo(Z.mag,Z.reserve,t.name,t.mode),Oe.reload("bolt"),Z.fireCooldown=.35}function Dh(i){const t=pe.camera;return t.getWorldDirection(qn),fs.set(1,0,0).applyQuaternion(t.quaternion),po.set(0,1,0).applyQuaternion(t.quaternion),i.copy(t.position).addScaledVector(qn,.85).addScaledVector(fs,.13).addScaledVector(po,-.11),i}function Ih(){const i=xs();if(Z.mag<=0)return;Z.mag--,Te.setAmmo(Z.mag,Z.reserve,i.name,i.mode),Qe.fire(1);const t=Dh(Jv);On.muzzleFlash(t),Oe.gunshot(0),Ge.kick(.72*i.recoil+Math.random()*.16,(Math.random()-.5)*.3*i.recoil),Ge.addShake(.09);const e=Ge.state.speed,n=Ge.adsAmount,s=(n>.5?i.adsSpread:i.spread)*(1+e*1.4)*(1-n*.65);pe.camera.getWorldDirection(qn);const r=Math.random()*Math.PI*2,a=Math.sqrt(Math.random())*s;fs.set(1,0,0).applyQuaternion(pe.camera.quaternion),po.set(0,1,0).applyQuaternion(pe.camera.quaternion),qn.addScaledVector(fs,Math.cos(r)*a).addScaledVector(po,Math.sin(r)*a).normalize(),fr.set(pe.camera.position,qn);const o=kn.bulletTargets.slice();for(const f of hn)f.alive&&o.push(...f.hitboxes);const h=fr.intersectObjects(o,!1).find(f=>f.object.visible||f.object.userData.enemy);if(bl.copy(pe.camera.position).addScaledVector(qn,120),h){bl.copy(h.point),Zs.copy(h.face?h.face.normal:qn).transformDirection(h.object.matrixWorld).negate(),Zs.lengthSq()<.1&&Zs.copy(qn).negate();const f=h.object.userData.enemy;if(f&&f.alive){const m=h.object.userData.part,u=h.object.userData.dmg||1,d=m==="head",c=f.takeDamage(i.dmg*u,h.point,Zs,m);On.blood(h.point,Zs,qn),Oe.impact("flesh"),Oe.hitmarker(d),Te.hit(d,c),c&&Lh(f,d)}else{const m=h.object.material;let u="concrete";(m===pe.mats.metal||m===pe.mats.metalTan||m===pe.mats.rust||m===pe.mats.shop)&&(u="metal"),m===pe.mats.wood&&(u="wood"),On.impact(h.point,Zs,u),Oe.impact(u==="metal"?"metal":"concrete"),u==="metal"&&Math.random()>.65&&Oe.ricochet((Math.random()-.5)*.6)}}On.tracer(t,bl,{color:16764559,width:.028,life:.055}),Z.mag===0&&Z.reserve>0&&setTimeout(()=>{Z.state==="playing"&&Jr()},160)}function Qv(i){const t=xs();Z.fireCooldown-=i;const e=Ne.mouse.left&&Ne.locked&&Z.state==="playing"||Z.debugAutoFire;if(Z.firing=e,!(!(t.auto?e:Ne.mouse.leftPressed&&Ne.locked)||Z.fireCooldown>0||Z.reloadTimer>=0)){if(Z.mag<=0){Z.reserve>0&&Jr();return}Z.fireCooldown=60/t.rpm,Z.shotFired=!0,Ih()}}function Lh(i,t){Z.kills++,Z.waveRemaining=Math.max(0,Z.waveRemaining-1),Z.score+=t?150:100,Te.setScore(Z.score,Z.kills),Te.addKillFeed(t?"HOSTILE":"INSURGENT",t,xs().name),Z.hitStop=.055,Oe.killConfirm();const e=hn.filter(n=>!n.alive);if(e.length>6){const n=e[0];n.root.visible=!1}}function Jr(){const i=xs();Z.reloadTimer>=0||Z.mag>=i.magSize||Z.reserve<=0||(Z.reloadTimer=0,Z.reloadTransferred=!1,Qe.startReload(),Oe.reload("magOut"),setTimeout(()=>{Z.reloadTimer>=0&&Oe.reload("magIn")},700),setTimeout(()=>{Z.reloadTimer>=0&&Oe.reload("charge")},1500))}function tx(i){if(!(Z.reloadTimer<0)){if(Z.reloadTimer+=i,!Z.reloadTransferred&&Z.reloadTimer>1.28){Z.reloadTransferred=!0;const t=xs(),e=Math.min(t.magSize-Z.mag,Z.reserve);Z.mag+=e,Z.reserve-=e,Te.setAmmo(Z.mag,Z.reserve,t.name,t.mode)}Z.reloadTimer>2.05&&(Z.reloadTimer=-1,Z.reloadTransferred=!1,Z.mag<=0&&Z.reserve>0&&Jr())}}function ex(){if(Z.grenades<=0)return;Z.grenades--,Te.setGrenades(Z.grenades);const i=new Ci(.062,10,8),t=new he({color:3883570,roughness:.7,metalness:.35}),e=new K(i,t);e.castShadow=!0,pe.camera.getWorldDirection(qn),e.position.copy(pe.camera.position).addScaledVector(qn,.5);const n=qn.clone().multiplyScalar(15).add(new N(0,3.4,0));pe.scene.add(e),ir.push({mesh:e,vel:n,fuse:2.4,t:0}),Oe.reload("bolt")}function nx(i){for(let t=ir.length-1;t>=0;t--){const e=ir[t];if(e.t+=i,e.fuse-=i,e.vel.y-=16*i,e.mesh.position.addScaledVector(e.vel,i),e.mesh.rotation.x+=i*9,e.mesh.rotation.z+=i*5,e.mesh.position.y<.07&&(e.mesh.position.y=.07,e.vel.y<-.5&&Oe.impact("concrete",(Math.random()-.5)*.5,.5),e.vel.y*=-.35,e.vel.x*=.7,e.vel.z*=.7),e.fuse<=0){On.explosion(e.mesh.position.clone(),1),Oe.explosion(0,e.mesh.position.distanceTo(pe.camera.position)),Ge.addShake(.85);const n=e.mesh.position.distanceTo(pe.camera.position);n<7&&Wc(Math.max(10,85*(1-n/7)),e.mesh.position);for(const s of hn){if(!s.alive)continue;const r=s.root.position.distanceTo(e.mesh.position);r<7.5&&s.takeDamage(180*(1-r/7.5),e.mesh.position,new N(0,1,0),"torso")&&Lh(s,!1)}pe.scene.remove(e.mesh),ix(e.mesh),ir.splice(t,1)}}}function ix(i){i.geometry&&i.geometry.dispose(),i.material&&i.material.dispose()}function Wc(i,t){if(Z.state!=="playing"||Z.hp<=0||ai)return;Z.sinceDamage=0,Z.hurtTimer=.3;let e=i;if(Z.armor>0){const n=Math.min(Z.armor,e*.6);Z.armor-=n,e-=n}if(Z.hp-=e,Te.setHealth(Z.hp,Vc(Z.armor)),Te.flashDamage(Math.min(.85,.35+i/60)),Ge.addShake(Math.min(.7,.18+i/45)),Oe.hurt(),t){const n=t.x-pe.camera.position.x,s=t.z-pe.camera.position.z;let a=((Math.atan2(n,s)*180/Math.PI+360)%360-Ge.headingDeg+540)%360-180;Te.setDamage(a*Math.PI/180)}Z.hp<=0?sx():Z.hp<40&&Oe.setLowHealth(!0)}function sx(){Z.hp=0,Z.state="dead",Ge.die(),Qe.state.dead=!0,Oe.death(),Oe.setLowHealth(!1),Ne.unlock(),document.getElementById("final-kills").textContent=Z.kills,document.getElementById("final-wave").textContent=Z.wave,document.getElementById("final-score").textContent=Z.score,setTimeout(()=>vc.classList.remove("hidden"),900)}const hi={playerPos:new N,playerAlive:!0,playerSpeed:0,fx:null,audio:null,camera:null,coverPoints:[],damagePlayer:(i,t)=>Wc(i,t),panFor:null,onEnemyFire:null};function rx(){hi.fx=On,hi.audio=Oe,hi.camera=pe.camera,hi.coverPoints=kn.coverPoints,hi.panFor=i=>{const t=pe.camera,e=i.x-t.position.x,n=i.z-t.position.z,s=Math.hypot(e,n)||1;return fs.set(1,0,0).applyQuaternion(t.quaternion),qe.clamp(e/s*fs.x+n/s*fs.z,-1,1)},hi.onEnemyFire=i=>{Te.ping(i,pe.camera,1.4)}}function ax(){Ch&&$r.classList.add("hidden");const i={hero:{x:1.6,z:27.5,yaw:-.05,pitch:-.02,ads:!1},wide:{x:-2.2,z:41,yaw:.03,pitch:.03,ads:!1},combat:{x:.5,z:17,yaw:.02,pitch:-.01,ads:!1},gun:{x:0,z:12,yaw:0,pitch:0,ads:!0},enemy:{x:0,z:9,yaw:0,pitch:-.02,ads:!1},alley:{x:-5.5,z:8,yaw:.75,pitch:-.02,ads:!1}},t=i[Ga]||i.hero;Ge.revive(t.x,t.z),Ge.setLook(t.yaw,t.pitch),Z.spawnQueue.length=0,Z.waveRemaining=0;for(const e of hn)e.root.visible=!1,e.alive=!1;if(hn.length=0,Ga==="enemy"){Z.freezeEnemies=!0,ls({x:.45,z:4.6});for(const e of hn)e.root.visible=!0,e.state="engage",e.aimBlend=1,e.root.rotation.y=Math.PI;return}if(Ga==="combat"){ls({x:2.2,z:-2}),ls({x:-3.6,z:-9}),ls({x:4.8,z:-14}),ls({x:-1.2,z:-20});for(const e of hn)e.root.visible=!0,e.state="engage",e.aimBlend=1;setTimeout(()=>{if(!On)return;for(const n of hn){if(!n.alive)continue;const s=new N;n.weaponMuzzle.getWorldPosition(s),On.tracer(s,new N(s.x-1.5,1.5,s.z+15),{color:16763274,width:.03,life:.12})}const e=new N;Dh(e),On.muzzleFlash(e)},900)}Ga==="gun"&&(Ne.mouse.right=!0),Z.freezeEnemies=!1,setTimeout(()=>{Z.freezeEnemies=!0},1800)}function Uh(i){requestAnimationFrame(Uh);const t=Math.min(.05,(i-gc)/1e3||.016);gc=i;let e=t;t>1e-4&&(Z.fps=Z.fps*.94+1/t*.06),Z.hitStop>0&&(Z.hitStop=Math.max(0,Z.hitStop-t),e=t*.22),Z.state==="playing"||Z.state==="dead"?lx(e):Z.state==="menu"?ox(e):Z.state==="paused"&&pe.update(e,Ge.pos),pe.render(e),ai&&(Z.readyFrames++,!Z.ready&&Z.readyFrames>30&&(Z.ready=!0,window.__READY=!0,document.title="READY — DEEPSEEK OF DUTY"))}function ox(i){Z.time+=i;const t=Z.time,e=pe.camera;e.position.set(Math.sin(t*.07)*2.4,1.72+Math.sin(t*.3)*.02,34-Math.sin(t*.08)*5),e.rotation.order="YXZ",e.rotation.set(-.02+Math.sin(t*.17)*.012,-.04+Math.sin(t*.11)*.05,Math.sin(t*.13)*.004),Qe.root.visible=!1,zh(i),pe.update(i,e.position,Gc),kn.update(i,e),On.update(i)}function zh(i){Sl-=i,!(Sl>0)&&(Sl=.18,!(!kn||!pe)&&(wl.set(pe.camera.position,pe.sky.sunDir),wl.far=320,Gc=wl.intersectObjects(kn.bulletTargets,!1).length>0))}function lx(i){Z.time+=i;const t=Z.state==="playing",e=t?Ne.mouse.dx:0,n=t?Ne.mouse.dy:0;Ge.update(i,t?Ne:null,{ads:t&&Ne.mouse.right,sprinting:t&&Ne.down("ShiftLeft"),crouching:t&&(Ne.down("ControlLeft")||Ne.down("KeyC")),jump:t&&Ne.pressedOnce("Space")}),t&&(Qv(i),tx(i),nx(i),Z.sinceDamage+=i,Z.sinceDamage>4.2&&Z.hp<Z.maxHp&&(Z.hp=Math.min(Z.maxHp,Z.hp+26*i),Te.setHealth(Z.hp,Vc(Z.armor)),Z.hp>40&&Oe.setLowHealth(!1)),jv(i));const s=Z.hp>0;hi.playerPos.copy(pe.camera.position),hi.playerAlive=s,hi.playerSpeed=Ge.state.speed;for(const o of hn)if(o.root.visible){if(Z.freezeEnemies&&ai){o.weaponFlashT=Math.max(0,o.weaponFlashT-i),o.weaponFlash.material.opacity=o.weaponFlashT>0?1:0;continue}o.update(i,hi)}Qe.update(i,{speed:Ge.state.speed,sprinting:Ge.state.sprinting,ads:t&&Ne.mouse.right,lookDX:e,lookDY:n,dead:Z.state==="dead"}),Qe.camera.aspect=pe.camera.aspect,Qe.camera.updateProjectionMatrix(),Te.setHeading(Ge.headingDeg);const r=Ge.state.speed,a=(Z.firing?7:2)+r*9+(Ge.adsAmount>.5?0:4);Te.setSpread(a,Ge.adsAmount>.6),Te.setReloadPrompt(t&&(Z.mag===0||Z.mag<=Math.ceil(xs().magSize*.15)&&Z.reloadTimer<0)&&Z.reserve>0),Te.setGrenades(Z.grenades),Te.update(i),zh(i),pe.update(i,Ge.pos,Gc),kn.update(i,pe.camera),On.update(i),Qe.state.dead=Z.state==="dead",t&&!Ne.locked&&!ai?Z.lockHint||(Te.setHint("点击画面锁定鼠标"),Z.lockHint=!0):Z.lockHint&&(Te.setHint(""),Z.lockHint=!1),Ne.endFrame()}Kv();window.__game={get engine(){return pe},get level(){return kn},get player(){return Ge},get enemies(){return hn},get state(){return Z},get hud(){return Te},get fx(){return On},get viewmodel(){return Qe},startGame:ja,resetGame:fo,spawnEnemy:ls,applyPlayerDamage:Wc,fire:()=>{Ih()},reload:()=>Jr(),pick:(i=0,t=0)=>{var s,r,a,o,l;fr.setFromCamera(new Pt(i,t),pe.camera);const e=fr.intersectObjects(kn.bulletTargets,!1);if(!e.length)return null;const n=e[0];return{point:n.point.toArray().map(h=>+h.toFixed(2)),dist:+n.distance.toFixed(2),mat:((a=(r=(s=n.object.material)==null?void 0:s.color)==null?void 0:r.getHexString)==null?void 0:a.call(r))||null,mt:((o=n.object.material)==null?void 0:o.type)||null,name:n.object.name||((l=n.object.parent)==null?void 0:l.name)||""}},get fps(){return Z.fps}};
